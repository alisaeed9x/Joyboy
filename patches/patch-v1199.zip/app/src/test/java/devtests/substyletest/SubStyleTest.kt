package devtests.substyletest

import com.tttt.subtitler.*
var fails = 0
fun check(n: String, ok: Boolean, d: String = "") { if (ok) println("PASS $n") else { fails++; println("FAIL $n $d") } }
fun mk(g: String = "male", tr: String = "مرحبا يا أحمد", o: String = "hello", piv: String = "", cont: Boolean = false, ppl: List<String> = emptyList(), pl: List<String> = emptyList()) =
    Sub(0.0, 1.0, o, tr, g, "unknown", "none", ppl, pl, false, false, -1, "", false, "", cont, piv)
fun main() {
    check("كل ثيم فيه ألوان مختلفة وعددهم 11", Themes.all.size == 11 && Themes.all.map { it.id }.toSet().size == 11)
    check("ثيم الأصل الافتراضي primary", Themes.byId("default").primary == 0xFFF5A623.toInt())
    check("ثيم مجهول → الافتراضي", Themes.byId("zzz").id == "default")
    check("فاتح/غامق", Themes.byId("light").isLight && !Themes.byId("amoled").isLight)
    check("parse لون 3 خانات", Theme.parse("#fff") == 0xFFFFFFFF.toInt())
    val d = SubStyle()
    check("افتراضيات الأصل", d.scale == 100 && d.bgOpa == 45 && d.blur == 0 && d.animMs == 250 && d.splitThresh == 8 && d.font == "Cairo")
    val st = SubStyle.load { k, def -> mapOf("sub_scale" to "999", "sub_bgopa" to "-5", "sub_anim" to "bogus", "sub_dual" to "2")[k] ?: def }
    check("load بيقصّ القيم", st.scale == 200 && st.bgOpa == 0 && st.anim == "default" && st.dual == 2)
    check("13 أنيميشن و22 خط", SubStyle.entrances.size == 13 && SubStyle.fonts.size == 22)
    check("لون الذكر: أبيض (من غير لون جنس)", d.copy(plain = false).colorFor(mk("male")) == SubStyle.WHITE)
    check("لون الأنثى: أبيض (من غير لون جنس)", d.copy(plain = false).colorFor(mk("female")) == SubStyle.WHITE)
    check("لون موحّد", d.copy(plain = false, uniOn = true, uniColor = "#FFE600").colorFor(mk("female")) == 0xFFFFE600.toInt())
    check("نص أبيض عادي يغلب", d.copy(plain = true, uniOn = true).colorFor(mk("female")) == SubStyle.WHITE)
    check("سطر ثانوي: الأصلي", d.copy(dual = 1).secondary(mk()) == "hello")
    check("سطر ثانوي: نفس النص → فاضي", d.copy(dual = 1).secondary(mk(tr = "x", o = "x")) == "")
    check("سطر ثانوي: pivot", d.copy(dual = 2).secondary(mk(piv = "hi")) == "hi" && d.secondary(mk(piv = "hi")) == "")
    check("وضع 3: الأصلي بس", d.copy(dual = 3).mainText(mk()) == "hello" && d.copy(dual = 3).secondary(mk()) == "")
    check("وضع 4: الأصلي فوق والترجمة تحت", d.copy(dual = 4).mainText(mk()) == "hello" && d.copy(dual = 4).secondary(mk()) == mk().translated)
    check("وضع 4: نفس النص → فاضي", d.copy(dual = 4).secondary(mk(tr = "x", o = "x")) == "")
    check("وضع 3: بدون أسماء مظللة", d.copy(dual = 3).highlights("hello", mk()).isEmpty())
    check("تقسيم 10 كلمات بحد 8 → سطرين متوازنين", SubStyle.splitLong("1 2 3 4 5 6 7 8 9 10", 8) == "1 2 3 4 5\n6 7 8 9 10")
    check("جملة قصيرة ما بتتقسمش", SubStyle.splitLong("a b c", 8) == "a b c")
    check("استكمال ⋯", d.mainText(mk(cont = true)).endsWith(" ⋯"))
    val s = mk(tr = "قابلت أحمد في القاهرة وأحمد ضحك", ppl = listOf("أحمد"), pl = listOf("القاهرة"))
    val hl = d.copy(plain = false).highlights(s.translated, s)
    check("تلوين الأسماء والأماكن", hl.count { !it.third } == 2 && hl.count { it.third } == 1)
    check("fontPx بيحترم الحدود والسكيل", SubStyle.fontPx(1080, 2f, 100) == 36f && SubStyle.fontPx(300, 2f, 200) == 52f)
    check("الافتراضي زي الـ HTML: ألوان وتمييز (مش أبيض بس) + تقسيم العرض مقفول", !d.plain && !d.splitOn && SubStyle.load { _, def -> def }.let { !it.plain && !it.splitOn })
    check("قسّم عند الترقيم: شغّال افتراضيًا", d.punctOn && SubStyle.load { _, def -> def }.punctOn)
    check("ألوان المتحدثين: كل سطر لونه مختلف", SubStyle.lineColors(listOf(mk("male"), mk("male"))).let { it[0] != it[1] } && SubStyle.lineColors(listOf(mk("male"), mk("female"))).let { it[0] == SubStyle.WHITE && it[1] != it[0] })
    check("plain: حجم ثابت ومن غير تمييز", d.copy(plain = true).sizeFor(1) == 1f && d.copy(plain = true).sizeFor(20) == 1f && d.copy(plain = true).highlights("أحمد", mk(ppl = listOf("أحمد"))).isEmpty())
    check("غير plain: تكبير تلقائي وأبيض عادي", d.copy(plain = false).sizeFor(1) == 1.18f && d.copy(plain = false).colorFor(mk("female")) == SubStyle.WHITE)
    check("mainText ما بيقسّمش (التقسيم بالتتابع)", d.mainText(mk(tr = "1 2 3 4 5 6 7 8 9 10")) == "1 2 3 4 5 6 7 8 9 10")
    if (fails > 0) { println("فشل $fails"); System.exit(1) } else println("كل الاختبارات نجحت")
}
