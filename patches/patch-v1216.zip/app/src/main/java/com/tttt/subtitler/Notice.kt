package com.tttt.subtitler

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * إشعار صغير فوق الشاشة (بديل التوست بالكامل). مفيش Toast في أي حتة في البرنامج.
 * - show: سطر صغير بيختفي لوحده (أو بلمسة).
 * - ask: إشعار بسؤال (نعم / لا) وشريط رفيع بيعدّ تنازلي، ولو ما حدش ردّ في المهلة (5 ثواني) بيختفي.
 * بيتفتح كنافذة فوق كل حاجة (حتى فوق الدايلوجات) بدون ما ياخد الفوكس.
 */
object Notice {
    private val main = Handler(Looper.getMainLooper())
    private var removeCur: (() -> Unit)? = null
    private var timeout: Runnable? = null

    private fun activityOf(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }

    private fun theme(c: Context): Theme = try { Themes.current() } catch (_: Throwable) { Themes.all[0] }

    private fun statusBarH(a: Activity): Int {
        val id = a.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) a.resources.getDimensionPixelSize(id) else 0
    }

    /** (v603) خلفية كبسولة التلفزيون: لون الكارت شبه شفاف + حد رفيع + نص دايري كامل (بتتحسب على الحجم الفعلي عن طريق cornerRadius كبير) */
    private fun tvCapsuleBg(th: Theme, radiusPx: Float, strokePx: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor((th.card and 0x00FFFFFF) or 0xF2000000.toInt()); setStroke(strokePx.coerceAtLeast(1), th.border); cornerRadius = radiusPx
        }

    /** (v606) ألوان كبسولة التلفزيون على طريقة One UI: سطح غامق/فاتح شبه شفاف مشتق من السمة + نص بتباين مضمون (فاتح على الغامق وغامق على الفاتح) */
    private class TvLook(val fill: Int, val stroke: Int, val fg: Int, val sub: Int, val btnFill: Int, val btnFg: Int, val dot: Int)
    private fun mix(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int) = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(ch(Color.red(a), Color.red(b)), ch(Color.green(a), Color.green(b)), ch(Color.blue(a), Color.blue(b)))
    }
    private fun tvLook(th: Theme): TvLook {
        val dark = !th.isLight
        val base = if (dark) mix(th.card, Color.BLACK, 0.55f) else mix(th.card, Color.WHITE, 0.65f)
        val fill = (base and 0x00FFFFFF) or (if (dark) 0xF0000000.toInt() else 0xF5000000.toInt())
        val fg = if (Theme.lum(base) > 0.5) Color.BLACK else Color.WHITE
        val sub = if (fg == Color.BLACK) 0xFF3A3A3A.toInt() else 0xFFD0D0D0.toInt()
        val stroke = if (dark) 0x55FFFFFF else 0x33000000
        val btnFill = th.primary
        val btnFg = if (Theme.lum(th.primary) > 0.55) Color.BLACK else Color.WHITE
        return TvLook(fill, stroke, fg, sub, btnFill, btnFg, th.primary)
    }
    private fun tvCapsule(look: TvLook, radiusPx: Float, strokePx: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply { setColor(look.fill); setStroke(strokePx.coerceAtLeast(1), look.stroke); cornerRadius = radiusPx }

    private fun removeNow() {
        timeout?.let { main.removeCallbacks(it) }; timeout = null
        val r = removeCur; removeCur = null
        try { r?.invoke() } catch (_: Throwable) {}
    }

    fun dismiss() { if (Looper.myLooper() == Looper.getMainLooper()) removeNow() else main.post { removeNow() } }

    /**
     * (v799) أثناء تنفيذ أمر جاي من ريموت الموبايل: الإشعارات ما تظهرش على التلفزيون — بتتجمّع هنا وبتترجع للموبايل يعرضها هو.
     * بيلتقط بس الإشعارات اللي بتتنده من خيط الواجهة جوه نافذة الأمر نفسه.
     */
    @Volatile private var capture: StringBuilder? = null
    fun beginCapture() { capture = StringBuilder() }
    fun endCapture(): String { val c = capture; capture = null; return c?.toString()?.trim() ?: "" }

    /** إشعار عادي صغير */
    fun show(c: Context, msg: String, ms: Long = 2400L) {
        val cap = capture
        if (cap != null && Looper.myLooper() == Looper.getMainLooper()) { if (cap.isNotEmpty()) cap.append(" · "); cap.append(msg); return }
        NoticeLog.add(msg)
        if (NoticeLog.sinkFor(c)) return   // (v217) المشغّل فاتح: الإشعار بيتسجّل في مثلث ▲ فوق اليمين بدل ما يطلع عايم
        present(c, msg, null, null, ms, null, null)
    }

    /** إشعار بسؤال. onNo بتتنادي لو دوس «لا» أو عدّت المهلة من غير رد */
    fun ask(c: Context, msg: String, yes: String, no: String, ms: Long = 5000L, onYes: () -> Unit, onNo: () -> Unit) {
        present(c, msg, yes, no, ms, onYes, onNo)
    }

    private fun present(c: Context, msg: String, yes: String?, no: String?, ms: Long, onYes: (() -> Unit)?, onNo: (() -> Unit)?) {
        val act = activityOf(c)
        if (act == null) { onNo?.let { main.post { it() } }; return }
        main.post {
            if (act.isFinishing || act.isDestroyed) { onNo?.invoke(); return@post }
            try { if (act.isInPictureInPictureMode) { LogStore.add("🔕 إشعار (PiP): $msg"); onNo?.invoke(); return@post } } catch (_: Throwable) {}
            removeNow()
            val th = theme(act); val ui = Ui(act, th)
            val d = act.resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()
            val onPrimary = if (th.isLight) Color.WHITE else Color.BLACK
            // (v603) على التلفزيون: كبسولة كبيرة مقروءة من بعيد (شكل كبسولات One UI) — الموبايل/التابلت زي ما هم بالظبط
            val tv = try { DeviceUi.isTv(act) } catch (_: Throwable) { false }
            val maxW = (act.resources.displayMetrics.widthPixels * (if (tv) 0.5f else 0.82f)).toInt()
            val msgSize = if (tv) 17f else 12.5f   // (v613) أصغر (كانت 27)
            val padH = if (tv) 26 else 16
            val padV = if (tv) 12 else 8
            val radius = if (tv) 40 else 20
            val look = tvLook(th)

            // كبسولة على قد الكلام بس (زي إشعارات سامسونج): بتنزل من فوق في النص وبتطلع تاني
            val pill = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = if (tv) tvCapsule(look, dp(radius).toFloat(), dp(2)) else ui.box(th.card, th.border, 20)
                setPadding(dp(padH), dp(padV), dp(padH), dp(padV))
                if (tv) elevation = dp(14).toFloat()
                // (v224) الحواف كانت مربعة (ظل/خلفية مستطيلة حوالين الكبسولة): قصّ دايري بنفس نصف القطر وشيل الظل المستطيل
                outlineProvider = object : android.view.ViewOutlineProvider() {
                    override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, if (tv) v.height / 2f else dp(20).toFloat()) }
                }
                clipToOutline = true
            }
            // (v614) على التلفزيون: كل حاجة في الكبسولة على صف واحد (الكلام + أزرار نعم/لا جنبه)، والحجم ثابت — الكلام الطويل بيتحرك (marquee) ينساب جوه الكبسولة بدل ما تكبر أو تنزل سطر
            val asking = yes != null && no != null
            val rowTv = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            val msgTv = IconTextView(act).apply {
                textSize = msgSize; setTextColor(if (tv) look.fg else th.text)
                LoadUi.set(this, if (msg.trimStart().startsWith("🔄")) "⏳" + msg.trimStart().removePrefix("🔄") else msg)   // (v1122) «🔄 بجيب…» برضه لودينج (مش زرار)
                // «⏳ …» ← لودينج البرنامج المتحرك بدل الإيموجي
                gravity = Gravity.CENTER
                if (tv) {
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    setSingleLine(true); ellipsize = TextUtils.TruncateAt.MARQUEE; marqueeRepeatLimit = -1
                    isSelected = true   // النافذة مش واخدة فوكس فالـ marquee محتاجة selected عشان تتحرك
                    maxWidth = maxW - dp(padH * 2) - (if (asking) dp(200) else 0)
                } else {
                    maxLines = 3; ellipsize = TextUtils.TruncateAt.END; maxWidth = maxW - dp(padH * 2)
                }
            }
            if (tv) {
                pill.addView(rowTv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
                rowTv.addView(msgTv, LinearLayout.LayoutParams(-2, -2))
            } else {
                pill.addView(msgTv, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
            }
            var done = false
            lateinit var wrapRef: View
            fun finish(cb: (() -> Unit)?) {
                if (done) return; done = true
                timeout?.let { main.removeCallbacks(it) }; timeout = null
                cb?.invoke()
                // خروج بحركة لفوق ثم الإزالة (لو إشعار تاني حل مكانه قبل كده بيتشال فورًا من removeNow)
                val mine = removeCur
                try {
                    wrapRef.animate().alpha(0f).translationY(-(wrapRef.height + dp(12)).toFloat()).setDuration(170)
                        .withEndAction { if (removeCur === mine) removeNow() else try { mine?.invoke() } catch (_: Throwable) {} }.start()
                } catch (_: Throwable) { removeNow() }
            }

            if (yes != null && no != null) {
                fun chip(t: String, primary: Boolean, f: () -> Unit) = IconTextView(act).apply {
                    text = t; textSize = if (tv) 16f else 12.5f; gravity = Gravity.CENTER; minHeight = dp(if (tv) 36 else 40)
                    setPadding(dp(if (tv) 18 else 14), dp(4), dp(if (tv) 18 else 14), dp(4))
                    if (tv) {
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        setTextColor(if (primary) look.btnFg else look.fg)
                        background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = dp(32).toFloat(); if (primary) setColor(look.btnFill) else { setColor(Color.TRANSPARENT); setStroke(dp(2), look.stroke) } }
                    } else {
                        setTextColor(if (primary) onPrimary else th.text)
                        background = ui.box(if (primary) th.primary else th.surface, if (primary) th.primary else th.border, 16)
                    }
                    setOnClickListener { f() }
                }
                if (tv) {
                    // نفس الصف: الكلام ثم نعم ثم لا (من غير سطر تاني)
                    rowTv.addView(chip(yes, true) { finish(onYes) }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(16) })
                    rowTv.addView(chip(no, false) { finish(onNo) }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
                } else {
                    val row = LinearLayout(act).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(6)) }
                    row.addView(chip(yes, true) { finish(onYes) }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
                    row.addView(chip(no, false) { finish(onNo) }, LinearLayout.LayoutParams(-2, -2))
                    pill.addView(row, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
                }
                val bar = View(act).apply { setBackgroundColor(if (tv) look.dot else th.primary) }
                pill.addView(bar, LinearLayout.LayoutParams(-1, dp(2)))
                bar.post {
                    bar.pivotX = bar.width.toFloat()
                    bar.animate().scaleX(0f).setDuration(ms).setInterpolator(LinearInterpolator()).start()
                }
            } else {
                pill.setOnClickListener { finish(null) }
            }

            val wrap = FrameLayout(act).apply { setPadding(dp(8), dp(if (tv) 12 else 6), dp(8), dp(6)); addView(pill, FrameLayout.LayoutParams(-2, -2)) }
            wrapRef = wrap
            wrap.alpha = 0f; wrap.translationY = -dp(60).toFloat()

            val tok = try { act.window.decorView.windowToken } catch (_: Throwable) { null }
            var added = false
            if (tok != null) {
                try {
                    val wm = act.windowManager
                    val lp = WindowManager.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_APPLICATION_PANEL,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                    ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; token = tok; y = statusBarH(act) + (if (tv) (act.resources.displayMetrics.heightPixels * 0.04f).toInt() else 0) }
                    wm.addView(wrap, lp)
                    removeCur = { try { wm.removeViewImmediate(wrap) } catch (_: Throwable) {} }
                    added = true
                } catch (_: Throwable) {}
            }
            if (!added) {
                try {
                    val content = act.findViewById<ViewGroup>(android.R.id.content)
                    content.addView(wrap, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
                    removeCur = { try { content.removeView(wrap) } catch (_: Throwable) {} }
                } catch (_: Throwable) { onNo?.invoke(); return@post }
            }
            wrap.animate().alpha(1f).translationY(0f).setDuration(220).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            val t = Runnable { finish(onNo) }
            timeout = t; main.postDelayed(t, if (tv && yes == null) maxOf(ms, 2600L) else ms)
        }
    }
}


/**
 * (v217) سجل الإشعارات: كل Notice.show بيتسجّل هنا (الأحدث الأول). لو شاشة المشغّل فاتحة (attach) الإشعار مابيطلعش عايم،
 * وبيظهر كمثلث ▲ أحمر شفاف جنب عدّاد الجمل، ولمسة عليه بتفتح قايمة منسدلة بالإشعارات. برّه المشغّل (الإعدادات مثلًا) الإشعار العايم زي ما هو.
 */
object NoticeLog {
    class Item(val at: Long, val msg: String)
    private val items = ArrayList<Item>()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var owner: Activity? = null
    @Volatile private var onChange: (() -> Unit)? = null

    fun attach(a: Activity, f: () -> Unit) { owner = a; onChange = f }
    fun detach(a: Activity) { if (owner === a) { owner = null; onChange = null } }

    fun sinkFor(c: Context): Boolean {
        val o = owner ?: return false
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x === o && !o.isFinishing; x = x.baseContext }
        return false
    }

    fun add(msg: String) {
        val now = System.currentTimeMillis()
        synchronized(items) {
            val top = items.firstOrNull()
            if (top != null && top.msg == msg && now - top.at < 3000L) return
            items.add(0, Item(now, msg))
            while (items.size > 80) items.removeAt(items.size - 1)
        }
        LogStore.add("🔔 $msg")
        val f = onChange
        if (f != null) main.post { try { f() } catch (_: Throwable) {} }
    }

    fun list(): List<Item> = synchronized(items) { ArrayList(items) }
    fun clear() { synchronized(items) { items.clear() }; val f = onChange; if (f != null) main.post { try { f() } catch (_: Throwable) {} } }
}


/**
 * (v680) كبسولة تقدم الإرسال: بتنزل من فوق أول ما تبعت ملفات للتلفزيون (من غير شاشات/أكواد/أرقام) وفيها اسم + شريط تقدم + نسبة،
 * وبتتحدّث لوحدها وبتختفي بعد ما يخلص. دوسة عليها = onTap (تفاصيل). مرتبطة بالأكتيفيتي اللي بعتنا منها.
 */
object SendPill {
    private val main = Handler(Looper.getMainLooper())
    private class Pill(val root: LinearLayout, val title: TextView, val sub: TextView, val bar: View, var pct: Int) { var hide: Runnable? = null }
    private val pills = java.util.WeakHashMap<Activity, Pill>()

    private fun build(act: Activity, onTap: (() -> Unit)?): Pill {
        val d = act.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val title = TextView(act).apply { textSize = 13f; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END }
        val sub = TextView(act).apply { textSize = 11f; setTextColor(0xFFCDBFAE.toInt()); setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END }
        lateinit var p: Pill
        val bar = object : View(act) {
            private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
            private val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF4ADE80.toInt() }
            private val rc = RectF()
            override fun onDraw(c: Canvas) {
                val r = height / 2f
                rc.set(0f, 0f, width.toFloat(), height.toFloat()); c.drawRoundRect(rc, r, r, bg)
                val w = width * (p.pct.coerceIn(0, 100) / 100f)
                if (w > 0f) { rc.set(0f, 0f, maxOf(w, height.toFloat()), height.toFloat()); c.drawRoundRect(rc, r, r, fg) }
            }
        }
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(10), dp(18), dp(12)); elevation = dp(12).toFloat()
            background = android.graphics.drawable.GradientDrawable().apply { setColor(0xF00F0F0F.toInt()); setStroke(dp(1), 0x66D4B896); cornerRadius = dp(22).toFloat() }
            addView(title, LinearLayout.LayoutParams(-1, -2))
            addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
            addView(bar, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(7) })
            if (onTap != null) setOnClickListener { try { onTap() } catch (_: Throwable) {} }
        }
        p = Pill(root, title, sub, bar, 0)
        return p
    }

    /** يظهر/يتحدّث. pct < 0 = جاري التجهيز (من غير نسبة) */
    fun update(act: Activity, titleText: String, pct: Int, subText: String = "", onTap: (() -> Unit)? = null) {
        main.post {
            try {
                if (act.isFinishing || act.isDestroyed) return@post
                var p = pills[act]
                if (p == null || p.root.parent == null) {
                    p = build(act, onTap); pills[act] = p
                    val host = act.findViewById<ViewGroup>(android.R.id.content) ?: return@post
                    val d = act.resources.displayMetrics.density
                    host.addView(p.root, FrameLayout.LayoutParams((minOf(act.resources.displayMetrics.widthPixels - (24 * d).toInt(), (380 * d).toInt())), -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = (34 * d).toInt() })
                }
                p.hide?.let { main.removeCallbacks(it) }; p.hide = null
                p.title.text = titleText; p.sub.text = subText; p.sub.visibility = if (subText.isEmpty()) View.GONE else View.VISIBLE
                p.pct = pct.coerceAtLeast(0); p.bar.invalidate()
            } catch (_: Throwable) {}
        }
    }

    /** نهاية الإرسال: رسالة أخيرة وبعد [afterMs] تختفي */
    fun finish(act: Activity, msg: String, ok: Boolean, afterMs: Long = 3500L) {
        main.post {
            try {
                val p = pills[act] ?: return@post
                p.title.text = msg; p.sub.visibility = View.GONE
                if (ok) p.pct = 100
                p.bar.invalidate()
                val r = Runnable { try { (p.root.parent as? ViewGroup)?.removeView(p.root); pills.remove(act) } catch (_: Throwable) {} }
                p.hide?.let { main.removeCallbacks(it) }; p.hide = r; main.postDelayed(r, afterMs)
            } catch (_: Throwable) {}
        }
    }
}
