# Joyboy v1294 — إصلاح بناء v1293
## إصلاح
1. [إصلاح] «Unresolved reference notInt/hide»: YtStore الحقيقي جوّه YtNp.kt (الملف المستقل YtStore.kt ملف قديم بيتمسح قبل الكومبايل بقاعدة kt_manifest) — نقلت إضافات «مش مهتم» جوّه YtNp.kt.
## ملاحظات
1. ما اتعملش compile محلي: الـCI هو اللي هيتأكد.
