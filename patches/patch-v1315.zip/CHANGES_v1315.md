# v1315 — إصلاح بيلد v1314

## الإصلاح
- HideBox.kt: `File.copyTo` في كوتلن بيرجّع File مش Boolean — كان مكتوب `copyTo(...) && delete()` فكسر الكومبايل (سطر 59 و78). بقوا سطرين متتاليين: `copyTo(...); delete()`.

## الملفات
- HideBox.kt
