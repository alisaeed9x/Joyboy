package com.tttt.subtitler

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.locks.ReentrantLock

/** (v253) جسر JNI لـ whisper.cpp (cpp/jni.cpp). المكتبة arm64 بس؛ لو مش موجودة loaded = false والأوفلاين بيتقفل لوحده */
object WhisperLib {
    @Volatile var loaded = false; private set
    init { try { System.loadLibrary("subwhisper"); loaded = true } catch (_: Throwable) {} }
    @JvmStatic external fun nInit(path: String): Long
    @JvmStatic external fun nFree(h: Long)
    /** (v748) مسار موديل VAD (Silero) أو "" لإيقافه — بيتطبّق على التفريغات الجاية */
    @JvmStatic external fun nVad(path: String)
    @JvmStatic external fun nProgress(): Int   // (v415) تقدم التفريغ الحالي 0..100
    @JvmStatic external fun nRun(h: Long, pcm: FloatArray, threads: Int, lang: String, prompt: String, slot: Int): ByteArray   // (v420) slot: خانة التفريغ المتوازي
}

/**
 * (v253) الترانسكريبشن الأوفلاين: Whisper شغّال على الموبايل نفسه — من غير مفتاح ولا نت (النت بس لتنزيل الموديل مرة واحدة).
 * بيستبدل نسخ الصوت بجيميناي؛ الترجمة لسه جيميناي (نص بس). أي فشل ← الباتش بيتنسخ بجيميناي (الاحتياطي).
 * الرد بيتحوّل لنفس JSON بتاع جيميناي في الترانسكريبشن فباقي المحرك (TParse ← الترجمة السياقية) ما بيتغيّرش.
 */
object Offline {
    class Model(val id: String, val label: String, val file: String, val approxMb: Int, val note: String)
    val models = listOf(
        Model("tiny", "🚀 tiny", "ggml-tiny-q5_1.bin", 31, "الأسرع بكتير"),
        Model("base", "⚡ base", "ggml-base-q5_1.bin", 60, "⭐ الأساسي — سريع وخفيف"),
        Model("small", "⚖ small", "ggml-small-q5_1.bin", 185, "أدق ومتوازن"),
        Model("medium", "🎯 medium", "ggml-medium-q5_0.bin", 520, "الأدق — بطيء وبياخد رام كتير (~1.5GB)، مش لأي موبايل"),
        Model("turbo", "🏆 large-v3-turbo", "ggml-large-v3-turbo-q5_0.bin", 547, "(v696) الأقوى للياباني والإنجليزي — أسرع من medium بكتير (~574MB ملف). مفيش تفريغ متوازي معاه")
    )
    const val BASE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"
    val langIds = listOf("", "en", "ar", "fr", "es", "tr", "ko", "ja", "zh", "ru", "de", "it", "hi", "fa", "ur")
    val langLabels = listOf("تلقائي", "إنجليزي", "عربي", "فرنساوي", "إسباني", "تركي", "كوري", "ياباني", "صيني", "روسي", "ألماني", "إيطالي", "هندي", "فارسي", "أوردو")   // (v255) بالعربي بس — الاسم بحروفه الأصلية كان بيلخبط

    /** (v271) المكان الدائم للموديلات: Android/media/<الحزمة>/models — بيفضل بعد مسح/إعادة تثبيت التطبيق (زي نسخة المفاتيح). لو مش متاح بيرجع لـ filesDir */
    @Volatile var dir: File? = null   // بيتظبط من Cfg.init
    /** (v271) مكان الموديلات القديم (filesDir) — بنقرا منه لو الموديل لسه مانتقلش، وبينتقل لوحده في الخلفية */
    @Volatile var legacy: File? = null
    /** (v1325) الافتراضي دايمًا يتحوّل لأحدث موديل متنزّل (الأعلى إصدارًا يكسب — ترتيب القايمة من الأقدم للأحدث، turbo في الآخر):
     *  اختيار صريح (off_model) بيتحترم بس لو الموديل ده متنزّل فعلًا؛ لو مش متنزّل (أو مفيش اختيار) أحدث موديل موجود على الجهاز بياخد مكانه.
     *  قبل كده الافتراضي كان base + ترحيل بيرجّع small ← base، فموديل زي turbo بعد ما يتنزّل مكانش بيتشاف: «التفريغ» كان بيرفض يتفعّل ويطلب تنزيل base.
     *  لو مفيش أي موديل متنزّل: الاختيار الصريح (هدف التنزيل) أو base. */
    fun model(): Model {
        val chosen = models.firstOrNull { it.id == Cfg.str("off_model", "") }
        if (chosen != null && downloaded(chosen)) return chosen
        val newest = models.lastOrNull { downloaded(it) }
        if (newest != null) return newest
        return chosen ?: models.first { it.id == "base" }
    }
    /** (v271) الملف الكامل لو موجود في أي مكان (الجديد الأول)، وإلا مساره في المكان الجديد (للتنزيل) */
    fun pick(rel: String, minBytes: Long): File? {
        ModelStore.resolve(rel)?.let { f -> if (f.isFile && f.length() > minBytes) return f }   // (v696) ملف اتختار من الموبايل (SAF) — بيتفتح من غير نسخ
        val n = dir?.let { File(it, rel) }
        if (n != null && n.isFile && n.length() > minBytes) return n
        val o = legacy?.let { File(it, rel) }
        if (o != null && o.isFile && o.length() > minBytes) return o
        return n ?: o
    }
    /** (v271) كل الأماكن اللي ممكن الموديل يكون فيها (للمسح) */
    fun roots(): List<File> = listOfNotNull(dir, legacy).distinctBy { it.path }
    // ===== (v748) VAD (Silero) — ملف صغير (~0.9 ميجا) بيتنزّل لوحده في الخلفية؛ لو مش موجود التفريغ بيشتغل زي الأول =====
    private const val VAD_REL = "whisper/ggml-silero-v5.1.2.bin"
    private const val VAD_URL = "https://huggingface.co/ggml-org/whisper-vad/resolve/main/ggml-silero-v5.1.2.bin"
    @Volatile private var vadTry = 0L
    fun vadOn(): Boolean = Cfg.bool("stt_vad", true)
    /** مسار موديل VAD لو موجود وشغّال، وإلا "" (وبيحاول ينزّله في الخلفية كل 10 دقايق) */
    fun vadPath(): String {
        if (!vadOn()) return ""
        val f = pick(VAD_REL, 500_000L)
        if (f != null && f.isFile && f.length() > 500_000L) return f.path
        val now = System.currentTimeMillis()
        if (f != null && now - vadTry > 600_000L) {
            vadTry = now
            Thread { try { fetch(VAD_URL, f, 500_000L) { _, _ -> } } catch (_: Throwable) {} }.also { it.isDaemon = true; it.start() }
        }
        return ""
    }
    fun file(m: Model = model()): File? = pick("whisper/" + m.file, m.approxMb * 600_000L)
    fun downloaded(m: Model = model()): Boolean = file(m)?.let { it.isFile && it.length() > m.approxMb * 600_000L } ?: false
    /** (v698) الموبايل وهو بيفرّغ لصالح التلفزيون بيستخدم لغة التلفزيون اليدوية (على الخيط ده بس) */
    val langOv = ThreadLocal<String?>()
    fun txReady(): Boolean = engine().ready()
    fun lang(): String { langOv.get()?.let { return if (it in langIds) it else "" }; return Cfg.str("stt_lang", "").trim().let { if (it in langIds) it else "" } }
    /** (v255) المحركات المتاحة: Whisper (لكل اللغات) و sherpa-onnx SenseVoice (إنجليزي/ياباني/كوري/صيني) */
    val engines: List<SttEngine> = listOf(WhisperStt)
    /** المحرك المختار (مفتاح stt_engine: whisper | sherpa، الافتراضي whisper). لو المختار مش مدعوم على الجهاز أو مش بيفهم اللغة ← whisper */
    fun engine(): SttEngine = engines.firstOrNull { it.id == Cfg.str("stt_engine", "whisper") && it.supported() && it.handles(lang()) } ?: WhisperStt
    /** (v395) التفريغ السحابي الخارجي اتشال — دايمًا false */
    fun remoteOn(): Boolean = false
    /** true = الترانسكريبشن بيتعمل أوفلاين (مفعّل + الموديل نازل + المكتبة موجودة) والوضع بيبقى «نسخ ثم ترجمة سياقية» */
    fun on(): Boolean = configured() && System.currentTimeMillis() >= coolUntil
    /** (v262) الأوفلاين متظبّط (مفعّل + الموديل نازل) بغض النظر عن فترة الراحة بعد الأعطال. بيحدد وضع الترجمة (سياقية / جوجل)، أما on() فبيحدد مين بينسخ دلوقتي — قبل كده فترة الراحة كانت بتحوّل الترجمة من جوجل لجيميناي وسط الشغل */
    fun configured(): Boolean = Cfg.bool("stt_offline", false) && (engine().ready() || Offload.wanted())   // (v698) المعالجة على الموبايل: مفيش موديلات هنا
    /** حالة الأوفلاين للعرض في الإعدادات */
    fun status(): String = when {
        !WhisperLib.loaded -> "⛔ الأوفلاين مش مدعوم على جهازك (محتاج معالج 64-bit)."
        !downloaded() -> "⬇ الموديل لسه منزّلش (~${model().approxMb} ميجا، مرة واحدة بس)."
        !Cfg.bool("stt_offline", false) -> "الموديل نازل ✅ — الأوفلاين مقفول، جيميناي هو اللي بينسخ."
        else -> "✅ الأوفلاين شغّال: Whisper ${model().id} بينسخ على الجهاز، وجيميناي بيترجم ويكمّل لو الأوفلاين فشل."
    }
    /** طول جزء الترجمة السياقية بالدقايق: 5/10/20، أو 0 لو الأوفلاين مقفول (السلوك القديم) */
    fun partMin(): Int = if (!configured()) 0 else Cfg.int("ctx_min", 3).let { if (it == 1 || it == 3 || it == 5 || it == 10 || it == 20) it else 3 }
    /** (v266) «لحظي»: كل باتش يتفرّغ يتترجم فورًا (ctx_min = 1) */
    fun live(): Boolean = configured() && partMin() == 1

    // ===== (v267) قفل اللغة: أول باتش «مضمون» يحدد لغة الفيديو، وباقي الباتشات بتتفرّغ بيها (Whisper الصغير بيغلط في الاكتشاف التلقائي) =====
    /** حالة قفل اللغة لفيديو واحد (كل Engine عنده واحدة) */
    class Session { @Volatile var lang = ""; @Volatile var badRun = 0; /** (v411) لغة Whisper المبدئية (مش مقفولة) — للترجمة بس، بعد فحص إن حروف النص مطابقة */ @Volatile var hint = "" }
    /** true = آخر نداء transcribe على الخيط ده اتنفّذ فعلًا على الجهاز (مش فولباك جيميناي) */
    val ranOffline = ThreadLocal<Boolean>()
    /** اللغة اللي اتفرّغ بيها آخر باتش على الخيط ده ("" = اكتشاف تلقائي) */
    val usedLang = ThreadLocal<String>()
    /** (v415) الباتش اللي المحرك بيبعته للتفريغ دلوقتي (الإنجن بيحطه قبل النداء) + حالة التفريغ الشغّال فعلًا */
    val batchTag = ThreadLocal<Int>()
    @Volatile var runIdx = -1
    @Volatile var runStart = 0L
    private fun pctTxt(): String = if (engine().id == "whisper") (try { WhisperLib.nProgress().coerceIn(0, 99) } catch (_: Throwable) { 0 }).toString() + "%" else "شغّال"
    // (v700) مرحلة تحميل الموديل في الرام (Whisper الكبير بياخد ثواني كتير قبل أول %): نسبة تقديرية من وقت آخر تحميل لنفس الموديل
    @Volatile var loadStart = 0L
    @Volatile var loadId = ""
    @Volatile var loadWhat = "Whisper"
    @Volatile private var loadExpMs = 1L
    fun loadBegin(id: String, approxMb: Int, what: String = "Whisper") {
        loadWhat = what
        val prev = Cfg.str("whload_" + what + id, "").toLongOrNull() ?: 0L
        loadExpMs = if (prev > 300L) prev else (approxMb * 14L).coerceAtLeast(1500L)
        loadId = id; loadStart = System.currentTimeMillis()
    }
    fun loadEnd(ok: Boolean) {
        val took = System.currentTimeMillis() - loadStart
        if (ok && loadStart > 0L && took > 300L) try { Cfg.put("whload_" + loadWhat + loadId, took.toString()) } catch (_: Throwable) {}
        loadStart = 0L
    }
    private fun loadPct(): Int = if (loadStart == 0L) -1 else ((System.currentTimeMillis() - loadStart) * 100L / loadExpMs).toInt().coerceIn(0, 99)
    /** نسبة Whisper الحالية (-1 = مفيش تفريغ ولا تحميل شغّال). أثناء تحميل الموديل = نسبة التحميل التقديرية */
    fun livePct(): Int = if (loadStart != 0L) loadPct() else if (runIdx < 0 || engine().id != "whisper") -1 else try { WhisperLib.nProgress().coerceIn(0, 99) } catch (_: Throwable) { 0 }
    fun liveShort(): String? = if (loadStart != 0L) "⏳ تحميل الموديل · ~" + loadPct() + "%" else if (runIdx < 0) null else "🎙 باتش ${runIdx + 1} · " + pctTxt()
    fun liveLine(): String? = if (loadStart != 0L) "⏳ بيحمّل موديل ${loadWhat} ${loadId} في الرام — ~" + loadPct() + "% (تقديري) · من ${(System.currentTimeMillis() - loadStart) / 1000}ث" else if (runIdx < 0) null else "🎙 ${engName()} شغّال — باتش ${runIdx + 1}: " + pctTxt() + " · من ${(System.currentTimeMillis() - runStart) / 1000}ث"
    /** (v413) اللغة اللي Whisper كشفها فعلًا في آخر باتش على الخيط ده */
    val gotLang = ThreadLocal<String>()
    /** (v413) آخر لغة كشفها Whisper للفيديو الجاري (بتتعرض تحت اسم الفيديو) — بتتصفّر مع كل إنجن جديد */
    @Volatile var detectedLang = ""

    private fun lettersOf(t: String) = t.filter { it.isLetter() }
    private fun ratio(t: String, f: (Char) -> Boolean): Double { val l = lettersOf(t); return if (l.isEmpty()) 0.0 else l.count(f).toDouble() / l.length }
    /** النص اللي طلع شكله بحروف اللغة المكتشفة؟ (لو Whisper قال «روسي» والنص لاتيني يبقى الاكتشاف غلط) */
    private fun scriptFits(lang: String, text: String): Boolean = when (lang) {
        "ar", "fa", "ur" -> ratio(text) { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' || it in '\uFB50'..'\uFEFF' } > 0.6
        "ru", "uk", "bg" -> ratio(text) { it in '\u0400'..'\u04FF' } > 0.6
        "ko" -> ratio(text) { it in '\uAC00'..'\uD7AF' || it in '\u1100'..'\u11FF' } > 0.5
        "ja" -> ratio(text) { it in '\u3040'..'\u30FF' || it in '\u4E00'..'\u9FFF' } > 0.5
        "zh" -> ratio(text) { it in '\u4E00'..'\u9FFF' } > 0.6
        "hi" -> ratio(text) { it in '\u0900'..'\u097F' } > 0.6
        "en", "fr", "es", "de", "it", "tr", "pt", "nl" -> ratio(text) { it.code < 0x250 } > 0.85
        else -> true
    }

    /** بيقفل اللغة بعد أول نتيجة مضمونة (3 جمل+ · 40 حرف+ · ثقة كويسة · الحروف مطابقة للغة)، وبيفكّها لو النتيجة بقت زبالة مرتين ورا بعض */
    private fun noteLang(sess: Session, res: SttResult, forced: String, log: (String) -> Unit) {
        val good = res.segs.filter { it.text.isNotBlank() && it.logProb > -1.0 && it.noSpeech < 0.5 }
        if (forced.isNotEmpty()) {   // اللغة مقفولة: لو النتيجة وحشة مرتين ورا بعض نرجع للاكتشاف التلقائي
            val avg = if (res.segs.size >= 4) res.segs.map { it.logProb }.average() else 0.0
            if (avg < -1.4) { if (++sess.badRun >= 2) { sess.lang = ""; sess.badRun = 0; log("🌐 الأوفلاين: نتيجة اللغة المقفولة ($forced) وحشة مرتين — رجعت للاكتشاف التلقائي") } } else sess.badRun = 0
            return
        }
        val txt = good.joinToString(" ") { it.text }
        if (res.lang.isEmpty() || good.size < 3 || txt.length < 40 || !scriptFits(res.lang, txt)) return
        sess.lang = res.lang; sess.badRun = 0
        log("🔒 الأوفلاين: لغة الفيديو اتقفلت على (${res.lang}) — باقي الباتشات هتتفرّغ بيها")
    }

    // ===== التفريغ =====
    // (v420) تفريغ متوازي: لحد MAX_PAR باتش في نفس الوقت، كل باتش على خانة whisper مستقلة (موديل + state). الترتيب بالتذكرة (الأقدم الأول).
    // rw: التفريغ = قفل قراءة (متوازي)، وتحرير/حذف الموديل = قفل كتابة (بيستنى كل التفريغات تخلص)
    const val MAX_PAR = 3
    private val rw = java.util.concurrent.locks.ReentrantReadWriteLock(true)
    private val slotLock = ReentrantLock(true)
    private val slotCv = slotLock.newCondition()
    private val slotBusy = BooleanArray(MAX_PAR)
    private var tkNext = 0L
    private var tkServe = 0L
    private val tkSkip = HashSet<Long>()
    /** الخانة اللي الخيط الحالي شغّال عليها (WhisperStt بيقراها) */
    val slotTl = ThreadLocal<Int>()
    /** عدد الباتشات المتوازية المسموحة: الافتراضي 2 (base/small)، 1 لـ medium أو لو المحرك مش Whisper. الإعداد stt_par = 1..3 */
    fun par(): Int {
        if (engine().id != "whisper") return 1
        val heavy = model().id == "medium" || model().id == "turbo"   // (v696)
        val d = if (heavy) 1 else 2
        val v = Cfg.int("stt_par", d).coerceIn(1, 2)   // (v450) 3 خانات طلعت أبطأ (≈1.07×) وبتبطّأ استخراج الصوت
        return if (heavy) 1 else v
    }
    private fun busyCount(): Int = slotBusy.count { it }
    private fun advanceServe() { tkServe++; while (tkSkip.remove(tkServe)) tkServe++ }
    private fun acquireSlot(): Int {
        slotLock.lock()
        try {
            val my = tkNext++
            try {
                while (true) {
                    if (my == tkServe) {
                        val p = par()
                        val f = (0 until p).firstOrNull { !slotBusy[it] }
                        if (f != null) { slotBusy[f] = true; advanceServe(); slotCv.signalAll(); return f }
                    }
                    slotCv.await(500, java.util.concurrent.TimeUnit.MILLISECONDS)
                }
            } catch (t: Throwable) {
                if (my == tkServe) advanceServe() else tkSkip.add(my)
                slotCv.signalAll()
                throw t
            }
        } finally { slotLock.unlock() }
    }
    private fun releaseSlot(i: Int) { slotLock.lock(); try { slotBusy[i] = false; slotCv.signalAll() } finally { slotLock.unlock() } }
    @Volatile private var coolUntil = 0L
    @Volatile private var fails = 0

    private fun threadsAll(): Int = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(3, 4)   // (v450) فوق 4 خيوط الأنوية الصغيرة بتبطّأ الباقي (قياس لوج v448: 6 خيوط ≈1.3× · خانتين×3 خيوط ≈1.6×) · (v394) كان cores/2 بحد أقصى 4
    /** (v420) الخيوط بتتقسّم على الباتشات الشغّالة فعلًا دلوقتي (باتش لوحده ياخد الكل) */
    private fun threads(active: Int = 1): Int = if (active <= 1) threadsAll() else (threadsAll() / active).coerceAtLeast(2)

    /** ينسخ [wav] (PCM16 mono 16kHz بهيدر 44 بايت) على الجهاز بالمحرك المختار. أي فشل ← [fallback] (طلب جيميناي الأصلي) */
    fun transcribe(wav: ByteArray, durSec: Double, terms: String, log: (String) -> Unit, fallback: () -> Api.Result, warn: (String) -> Unit = {}, sess: Session? = null): Api.Result {
        if (Offload.wanted()) return Offload.transcribe(wav, durSec, terms, log, sess)   // (v698) م7: الموبايل هو اللي بيفرّغ
        ranOffline.set(false)
        val eng = engine()
        val tq = System.currentTimeMillis()
        val slot = acquireSlot()
        slotTl.set(slot)
        if (LocalMt.isLoaded()) try { LocalMt.release() } catch (_: Throwable) {}   // (v696) رام: التفريغ والترجمة ورا بعض مش مع بعض
        rw.readLock().lock()
        try {
            val waited = System.currentTimeMillis() - tq
            if (waited > 5000) log("⏳ الأوفلاين: الباتش استنى دوره ${waited / 1000}ث (خانات التفريغ ${par()})")
            eng.prepare(log)
            val myIdx = batchTag.get() ?: -1; runIdx = myIdx; runStart = System.currentTimeMillis()   // (v415)
            val pcm = toFloats(wav) ?: run { log("⚠ الأوفلاين: صيغة الصوت مش مدعومة — جيميناي هو اللي نسخ الباتش"); switchNote("صيغة الصوت مش مدعومة", warn); return fallback() }
            val t0 = System.currentTimeMillis()
            val act = slotLock.let { it.lock(); try { busyCount() } finally { it.unlock() } }
            val thr = threads(act)
            log("📴 بدأ التفريغ (${eng.id}): ${"%.0f".format(durSec)}ث صوت · $thr خيوط" + (if (par() > 1) " · خانة ${slot + 1}/${par()} (شغّال $act)" else ""))   // (v263)
            val manual = lang()
            val locked = if (manual.isEmpty() && eng.id == "whisper") sess?.lang.orEmpty() else ""
            val useLang = manual.ifEmpty { locked }
            usedLang.set(useLang)
            val res = eng.transcribe(pcm, useLang, terms.trim().take(200), thr)
            if (sess != null && eng.id == "whisper") noteLang(sess, res, locked, log)
            if (sess != null && sess.lang.isEmpty() && res.lang.isNotEmpty()) {   // (v411) اكتشاف Whisper قبل القفل: بيتستخدم كتلميح لموديل الترجمة بس لو الحروف مطابقة
                val gt = res.segs.filter { it.text.isNotBlank() && it.logProb > -1.0 && it.noSpeech < 0.5 }.joinToString(" ") { it.text }
                if (gt.length >= 15 && scriptFits(res.lang, gt)) sess.hint = res.lang
            }
            gotLang.set(res.lang)
            if (manual.isEmpty() && eng.id == "whisper") detectedLang = (sess?.lang.orEmpty()).ifEmpty { sess?.hint.orEmpty() }.ifEmpty { res.lang }
            val outLang = manual.ifEmpty { if (eng.id == "whisper") sess?.lang.orEmpty() else res.lang }   // (v267) لغة غير مضمونة ما بتتبلّغش للمحرك (كانت بتبوّظ srcLang بـ «ru» لفيديو إنجليزي)
            val took = System.currentTimeMillis() - t0
            log("📴 أوفلاين (${eng.id}): ${"%.0f".format(durSec)}ث صوت ← ${took / 1000}ث (${"%.1f".format(durSec * 1000.0 / took.coerceAtLeast(1))}× سرعة)")
            fails = 0
            ranOffline.set(true)
            return Api.Result(toJson(res, outLang), "STOP")
        } catch (e: SttInitFail) {
            log("⚠ الأوفلاين: ${e.message} — جيميناي هو اللي بينسخ")
            switchNote((e.message ?: "مش شغّال").take(70), warn)
            cool()
            return fallback()
        } catch (e: Throwable) {
            log("⚠ الأوفلاين فشل: ${(e.message ?: e.javaClass.simpleName).take(100)} — جيميناي هو اللي بينسخ الباتش ده")
            if (++fails >= 3) { cool(); fails = 0; log("🛟 الأوفلاين فشل 3 مرات ورا بعض — جيميناي بينسخ 5 دقايق"); switchNote("فشل 3 مرات ورا بعض — جيميناي بينسخ 5 دقايق", warn) }
            else switchNote("فشل في باتش", warn)
            return fallback()
        } finally { if (runIdx == (batchTag.get() ?: -1)) runIdx = -1; rw.readLock().unlock(); releaseSlot(slot) }   // (v420) مايمسحش عرض باتش تاني لسه شغّال
    }

    /** (v259) جيميناي مش موجود يكمّل بدل الأوفلاين لو فشل (مفيش مفتاح حقيقي) */
    private fun noFallback(): Boolean = !TrWizard.hasGeminiKey()
    private fun engName(): String = when (engine().id) { "remote" -> "التفريغ السحابي"; "sherpa" -> "SenseVoice"; else -> "Whisper" }
    /** (v389) إشعار واحد «فشل ← تم التحويل لجيميناي»؛ لو مفيش مفتاح جيميناي (مفيش تحويل) مفيش إشعار (اللوج بس) */
    private fun switchNote(reason: String, warn: (String) -> Unit) { if (!noFallback()) softNotice("🔄 فشل " + engName() + " ($reason) — تم التحويل لجيميناي", warn) }
    private fun who(): String = if (noFallback()) "مفيش مفتاح جيميناي يكمّل بدله — الباتش هيتعاد" else "جيميناي بينسخ"
    /** راحة الأوفلاين 5 دقايق بعد الأعطال — إلا لو مفيش مفتاح (مفيش بديل، فنكمّل نحاول) */
    private fun cool() { if (!noFallback()) coolUntil = System.currentTimeMillis() + 300_000L }

    @Volatile private var warnAt = 0L
    /** (v257) إشعار للمستخدم بحد أقصى مرة كل 20 ث — اللوج بيسجّل كل مرة، لكن الإشعار مايفضلش يطلع على كل باتش */
    fun softNotice(msg: String, f: (String) -> Unit) {
        val n = System.currentTimeMillis()
        if (n - warnAt < 20_000L) return
        warnAt = n
        try { f(msg) } catch (_: Throwable) {}
    }

    /** (v257) الأوفلاين مفعّل بس مش شغّال دلوقتي؟ بيرجّع السبب (للإشعار)، أو null لو شغّال أو مقفول أصلًا */
    fun whyOff(): String? = when {
        !Cfg.bool("stt_offline", false) -> null
        System.currentTimeMillis() < coolUntil -> "📴 الأوفلاين مرتاح لحد ما تعدّي 5 دقايق بعد الأعطال — جيميناي هو اللي بينسخ دلوقتي"
        Offload.wanted() -> null
        !engine().ready() -> "📴 الأوفلاين مفعّل بس موديل التفريغ مش نازل — جيميناي هو اللي بينسخ. نزّله من الإعدادات ← 🎙 التفريغ والصوت"
        else -> null
    }

    private fun toFloats(b: ByteArray): FloatArray? {
        if (b.size < 46 || b[0] != 'R'.code.toByte()) return null
        val rate = (b[24].toInt() and 255) or ((b[25].toInt() and 255) shl 8) or ((b[26].toInt() and 255) shl 16)
        val ch = (b[22].toInt() and 255)
        if (rate != 16000 || ch != 1) return null
        val n = (b.size - 44) / 2
        if (n < 1600) return null
        val out = FloatArray(n)
        var o = 44
        for (i in 0 until n) { out[i] = ((b[o].toInt() and 255) or (b[o + 1].toInt() shl 8)).toShort() / 32768f; o += 2 }
        return out
    }

    /** نتيجة أي محرك ← نفس JSON جيميناي. بنشيل الأجزاء اللي شكلها هلوسة على صمت/موسيقى/تكرار (مشترك بين المحركات) */
    private fun toJson(res: SttResult, langOut: String): String {
        val out = JSONArray()
        for (g in res.segs) {
            val t = g.text.trim()
            if (t.isEmpty() || t.startsWith("[") && t.endsWith("]") || t.startsWith("(") && t.endsWith(")")) continue   // [موسيقى] (تصفيق) — مش كلام
            if ((g.noSpeech > 0.6 && g.logProb < -0.8) || g.logProb < -1.8) continue
            out.put(JSONObject().put("start", g.start).put("end", g.end).put("original", t)
                .put("gender", "unknown").put("addressee", "unknown").put("topic_gender", "none")
                .put("people", JSONArray()).put("places", JSONArray()).put("is_song", false).put("emotion", "neutral")
                .put("low_confidence", g.logProb < -1.0).put("overlap", false).put("speaker_tag", "").put("is_continuation", false).put("faint", false))
        }
        return JSONObject().put("subtitles", out).apply { if (langOut.isNotEmpty()) put("detected_source_language", langOut) }.toString()
    }

    // ===== تنزيل الموديل (بيكمّل من حيث وقف) =====
    @Volatile private var dlThread: Thread? = null
    @Volatile private var dlCancel = false
    fun downloading(): Boolean = dlThread?.isAlive == true
    fun cancelDownload() { dlCancel = true }

    /** (v255) تنزيل ملف واحد بالاستكمال. [progress] (نزّل، الكلّي) بالبايت. بيرمي IOException عند أي مشكلة */
    internal fun fetch(url: String, dst: File, minBytes: Long, progress: (Long, Long) -> Unit) {
        dst.parentFile?.mkdirs()
        val part = File(dst.path + ".part")
        var have = if (part.isFile) part.length() else 0L
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20000; c.readTimeout = 30000
            if (have > 0) c.setRequestProperty("Range", "bytes=$have-")
            val code = c.responseCode
            if (code == 416) { have = 0L; part.delete(); throw IOException("اتعاد من الأول — جرّب تاني") }
            if (code != 200 && code != 206) throw IOException("HTTP $code")
            if (code == 200 && have > 0) { have = 0L; part.delete() }   // السيرفر ما دعمش الاستكمال
            val total = have + c.contentLengthLong.coerceAtLeast(0L)
            java.io.FileOutputStream(part, have > 0).use { os ->
                c.inputStream.use { ins ->
                    val buf = ByteArray(64 * 1024); var last = 0L
                    while (true) {
                        if (dlCancel) throw IOException("اتلغى")
                        val n = ins.read(buf); if (n < 0) break
                        os.write(buf, 0, n); have += n
                        val now = System.currentTimeMillis()
                        if (now - last > 400) { last = now; progress(have, total) }
                    }
                }
            }
            progress(have, have)
        } finally { try { c.disconnect() } catch (_: Throwable) {} }
        if (have < minBytes) throw IOException("التنزيل ناقص — جرّب تاني")
        if (dst.exists()) dst.delete()
        if (!part.renameTo(dst)) throw IOException("مقدرتش أحفظ الملف")
    }

    /** بيشغّل [work] في خيط التنزيل. [done] بتتنده مرة واحدة: null = نجح، غير كده سبب الفشل */
    private fun startDl(done: (String?) -> Unit, work: () -> Unit) {
        if (downloading()) return
        dlCancel = false
        dlThread = Thread {
            var err: String? = null
            try { work() } catch (e: Throwable) { err = (e.message ?: e.javaClass.simpleName).take(120) }
            try { done(err) } catch (_: Throwable) {}
        }.also { it.isDaemon = true; it.start() }
    }

    /** تنزيل موديل Whisper. [progress] (نزّل، الكلّي) بالبايت من خيط التنزيل */
    fun download(m: Model, progress: (Long, Long) -> Unit, done: (String?) -> Unit) {
        if (downloading()) return
        val dst = file(m) ?: run { done("مفيش مساحة تخزين"); return }
        startDl(done) {
            fetch(BASE_URL + m.file, dst, m.approxMb * 600_000L, progress)
            releaseSafe(WhisperStt)
        }
    }

    /** (v696) تنزيل أي موديل (whisper/... أو mt/...) بالاستكمال من التطبيق. [rel] زي مفاتيح ModelStore. بيفحص المساحة الفاضية الأول */
    fun fetchModel(rel: String, url: String, approxMb: Int, progress: (Long, Long) -> Unit, done: (String?) -> Unit) {
        if (downloading()) return
        val d = dir ?: run { done("مفيش مساحة تخزين"); return }
        val dst = File(d, rel)
        val have = File(dst.path + ".part").let { if (it.isFile) it.length() else 0L }
        val need = approxMb * 1_048_576L - have + 100L * 1_048_576L
        val free = try { d.usableSpace } catch (_: Throwable) { Long.MAX_VALUE }
        if (free < need) { done("المساحة الفاضية مش كفاية (محتاج ~" + (need / 1_048_576L) + " ميجا)"); return }
        startDl(done) {
            fetch(url, dst, approxMb * 600_000L, progress)
            if (rel.startsWith("whisper/")) releaseSafe(WhisperStt) else LocalMt.release()
        }
    }
    fun whisperUrl(m: Model): String = BASE_URL + m.file

    /** (v261) تحرير الموديل بنفس قفل التفريغ: لو باتش بيتفرّغ دلوقتي بيستنى يخلص، وإلا release() كان ممكن يحرّر الموديل وهو شغّال ← كراش native */
    /** (v696) تحرير Whisper بقفل الكتابة (قبل تحميل موديل الترجمة) */
    fun releaseWhisper() { try { releaseSafe(WhisperStt) } catch (_: Throwable) {} }
    private fun releaseSafe(e: SttEngine) { rw.writeLock().lock(); try { e.release() } finally { rw.writeLock().unlock() } }

    fun delete(m: Model = model()) {
        for (r in roots()) File(File(r, "whisper"), m.file).let { it.delete(); File(it.path + ".part").delete() }   // (v271) الجديد والقديم
        Thread { try { releaseSafe(WhisperStt) } catch (_: Throwable) {} }.also { it.isDaemon = true; it.start() }
    }

    // ===== (v271) نقل الموديلات من filesDir لمكان دائم (بيتعمل مرة واحدة في الخلفية) =====
    @Volatile private var migrating = false
    /** بيدوّر في المكان القديم على موديلات كاملة ويكوّشها للمكان الدائم (نسخ ← تحقق من الحجم ← مسح القديم). أي فشل = بنسيب القديم زي ما هو */
    fun migrateLegacy() {
        val nw = dir ?: return; val old = legacy ?: return
        if (nw.path == old.path || migrating) return
        migrating = true
        Thread {
            try {
                val items = ArrayList<Triple<String, Long, SttEngine>>()
                for (m in models) items.add(Triple("whisper/" + m.file, m.approxMb * 600_000L, WhisperStt))
                for ((rel, min, eng) in items) {
                    val src = File(old, rel); val dst = File(nw, rel)
                    if (!src.isFile || src.length() <= min) continue
                    if (dst.isFile && dst.length() == src.length()) { releaseSafe(eng); src.delete(); continue }
                    if (downloading()) continue
                    if ((nw.parentFile ?: nw).usableSpace < src.length() + 100_000_000L) continue
                    dst.parentFile?.mkdirs()
                    val part = File(dst.path + ".mig")
                    try {
                        src.inputStream().use { i -> part.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
                        if (part.length() != src.length()) { part.delete(); continue }
                        if (dst.exists()) dst.delete()
                        if (!part.renameTo(dst)) { part.delete(); continue }
                        releaseSafe(eng)   // لو الموديل متحمّل من القديم: اتحرر وهيتحمّل من الجديد
                        src.delete()
                    } catch (_: Throwable) { try { part.delete() } catch (_: Throwable) {} }
                }
            } finally { migrating = false }
        }.also { it.isDaemon = true; it.priority = Thread.MIN_PRIORITY; it.start() }
    }
}
