package com.tttt.subtitler

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.GridView
import android.widget.PopupMenu
import android.widget.TextView
import com.bumptech.glide.Glide
import org.json.JSONObject
import org.schabi.newpipe.extractor.Page
import java.util.Locale

/**
 * (v325) يوتيوب جوه التطبيق — بدل صفحة الويب (YoutubeUi): واجهة أصلية على NewPipeExtractor (نفس محرك Flow).
 * بحث باقتراحات (فيديوهات/قنوات/قوايم) · الرئيسية بمقترحات من سجلك · اشتراكاتي (فيد مدموج) · السجل · المحفوظات ·
 * صفحة قناة باشتراك · قوايم تشغيل. أي فيديو بتدوس عليه بيفتح في مشغّلنا (onPlay)، وضغطة طويلة = قايمة (ترجمة/حفظ/قناة/نسخ).
 * نفس واجهة YoutubeUi القديمة (root · refresh · onHide · importUri · back) فMain بيبدّل الاسم بس.
 */
class YtProUi(private val act: Activity, private val ui: Ui, private val th: Theme,
              private val recents: () -> Map<String, *>,
              private val onPlay: (String, String, Boolean) -> Unit,
              private val onBrowser: (String) -> Unit,
              private val onImport: () -> Unit,
              private val onAudio: (NpItem) -> Unit = {},                      // (v337) 🎧 صوت بس في مشغّل الموسيقى
              private val onDownload: (NpItem, Boolean) -> Unit = { _, _ -> },
              private val onPubHistory: () -> Unit = {},
              private val onPlayAt: ((String, String, Boolean, Long, YtPick?) -> Unit)? = null,
              private val onOpenPage: ((NpItem, Long) -> Unit)? = null) {   // (v402) تشغيل من ثانية معيّنة (زرار التكبير في المشغّل المصغّر)   // (v349) السجل العام   // (v337) ⬇ تحميل (true = صوت بس)

    private class St(val title: String, val tab: Int, val items: ArrayList<NpItem>, var next: Page?, val more: ((Page) -> YtRes)?,
                      val chUrl: String?, val chName: String?, val q: String?, val filter: String,
                      val vid: NpItem? = null, val det: YtDetail? = null) {
        var pos = 0
        var durF = 0; var dateF = 0   // (v469) C5: فلاتر بحث (مدة/تاريخ) بتتطبق على صفحات التحميل التالية كمان
        var liveF = false   // (v1303) فلتر «مباشر» في البحث
        var cMode = false; var cLoaded = false; val ci = ArrayList<NpItem>(); var cn: Page? = null; var cm: ((Page) -> YtRes)? = null
        var typeF = 0   // (v864) فلتر نوع الاشتراكات: 0 الكل · 1 فيديوهات · 2 شورتس · 3 بوستات
        var shelfOn = false   // (v865) الشورتس بتتجمّع 4-4 في «رف» (زي يوتيوب)
        fun list(): ArrayList<NpItem> {
            if (cMode) return ci
            var src: List<NpItem> = items
            if (tab == 0) { val hid = YtStore.notInt(); if (hid.isNotEmpty()) src = src.filter { it.kind != 0 || ("v:" + it.id !in hid && "c:" + it.channel !in hid) } }   // (v1291) مش مهتم بيخبّي من الرئيسية
            val base: ArrayList<NpItem> = if (typeF == 0) ArrayList(src) else ArrayList(src.filter { typeOk(it, typeF) })
            return if (shelfOn && (typeF == 0 || typeF == 2)) shelfify(base) else base
        }
        fun nxt(): Page? = if (cMode) cn else next
        fun mf(): ((Page) -> YtRes)? = if (cMode) cm else more
    }

    private val skinInit = YtSkin.init(th, act)   // (v471) ألوان وخط يوتيوب بقوا من سمة البرنامج نفسها (كانت ألوان يوتيوب الثابتة)
    val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(YtSkin.bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
    private val h = Handler(Looper.getMainLooper())
    // (v337) لودينج ويندوز (نفس اللي في المشغّل) بدل «⏳ …» وقت البحث/التحميل، وطبقة لودينج فوق الصفحة وقت جلب رابط الفيديو
    private val spinDr = WinSpinnerDrawable().apply { setColorFilter(PorterDuffColorFilter(th.primary, PorterDuff.Mode.SRC_IN)) }
    private val spinView = View(act).apply { foreground = spinDr }
    // (v389) اللودينج كان بيتحرّك لنص الصفحة بس بيتحط تحت الـ ListView (اللي ليه خلفية) فكان مخفي في الرئيسية والاشتراكات — بقى طبقة فوق الصفحة في النص
    private val spinBox = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE; isClickable = false
        addView(spinView, LinearLayout.LayoutParams(ui.dp(64), ui.dp(64)))
        addView(ui.text("جاري التحميل…", 12f, th.muted).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(8), 0, 0) }, LinearLayout.LayoutParams(-2, -2))
    }
    // (v1304) Shimmer skeleton: كروت رمادية وامضة بشكل القايمة وقت التحميل (زي يوتيوب) ورا اللودر
    private val skelBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setBackgroundColor(YtSkin.bg); layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(12), ui.dp(8), ui.dp(12), 0) }
    private val skelAnim = android.animation.ValueAnimator.ofFloat(0.45f, 1f).apply { duration = 750; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE; addUpdateListener { skelBox.alpha = it.animatedValue as Float } }
    private fun skelBuild() {
        for (r in 0 until 6) {
            val rowV = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            rowV.addView(View(act).apply { background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(10).toFloat() } }, LinearLayout.LayoutParams(ui.dp(150), ui.dp(86)))
            val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(12), ui.dp(6), 0, 0) }
            col.addView(View(act).apply { background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(7).toFloat() } }, LinearLayout.LayoutParams(-1, ui.dp(14)).apply { marginEnd = ui.dp(48) })
            col.addView(View(act).apply { background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(6).toFloat() } }, LinearLayout.LayoutParams(-1, ui.dp(11)).apply { topMargin = ui.dp(10); marginEnd = ui.dp(130) })
            rowV.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            skelBox.addView(rowV, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, ui.dp(6), 0, ui.dp(6)) })
        }
    }
    private fun spin(on: Boolean) { if (on) { spinBox.visibility = View.VISIBLE; spinDr.start(); skelBox.visibility = View.VISIBLE; skelAnim.start() } else { spinBox.visibility = View.GONE; spinDr.stop(); skelBox.visibility = View.GONE; skelAnim.cancel() }; loadBusy = on; updateLine() }

    // (v407) الخط الأزرق الرفيع فوق (تحميل صفحة أو تحديث خلفي) + كبسولة «⬆ فيديوهات جديدة» لما التحديث الخلفي يجيب جديد وإنت نازل في القايمة
    private val topLine = YtTopLine(act)
    private var loadBusy = false
    private var bgBusy = false
    private val lineWatch = Runnable { loadBusy = false; bgBusy = false; updateLine() }
    private fun updateLine() {
        h.removeCallbacks(lineWatch)
        topLine.stop()   // (v1107) الخط الأزرق اللي فوق اتشال — بدله دايرة التحميل الدايرية (نفس لودينج البرنامج)
        if (loadBusy || bgBusy) h.postDelayed(lineWatch, 40_000L)
        val showPtr = bgBusy && !loadBusy && spinBox.visibility != View.VISIBLE
        ptr.animate().cancel()
        if (showPtr) { ptr.rotation = 0f; ptrDr.start(); ptr.animate().alpha(1f).translationY(ui.dp(10).toFloat()).setDuration(Skins.dur(180L)).start() }
        else ptr.animate().alpha(0f).translationY(-ui.dp(50).toFloat()).setDuration(Skins.dur(160L)).withEndAction { ptrDr.stop() }.start()
    }
    private fun bgLine(on: Boolean) { bgBusy = on; updateLine() }
    private var pendingItems: List<NpItem>? = null
    private var pendingTab = -1
    private val newPill = TextView(act).apply {
        text = "⬆ فيديوهات جديدة"; textSize = 13f; setTextColor(YtSkin.onAccent); gravity = Gravity.CENTER; includeFontPadding = false
        typeface = YtSkin.medium
        setPadding(ui.dp(16), 0, ui.dp(16), 0); elevation = ui.dp(6).toFloat()
        background = GradientDrawable().apply { setColor(YtSkin.accent); cornerRadius = ui.dp(18).toFloat() }
        visibility = View.GONE; alpha = 0f
        setOnClickListener { applyPending() }
    }
    private var pillN = 1
    private fun showPill(n: Int) {
        pillN = n
        if (DeviceUi.isTv(act)) return   // (v575) تلفزيون: من غير كبسولة «فيديوهات جديدة» — العدّاد بقى جنب تاب «الاشتراكات»
        if (watch.isOpen || chan.isOpen) return   // (v428) الكبسولة بس في الرئيسية/الاشتراكات — مش فوق صفحة مشاهدة أو قناة
        if (true) return   // (v758) الكبسولة اتشالت
        newPill.text = if (n >= 2) "⬆ " + n + " فيديو جديد" else "⬆ فيديوهات جديدة"
        newPill.animate().cancel()
        if (newPill.visibility != View.VISIBLE) { newPill.visibility = View.VISIBLE; newPill.translationY = -ui.dp(12).toFloat(); newPill.alpha = 0f }
        newPill.animate().alpha(1f).translationY(0f).setDuration(Skins.dur(220L)).start()
    }
    private fun hidePill() {
        pendingItems = null; pendingTab = -1
        if (newPill.visibility != View.VISIBLE) return
        newPill.animate().cancel()
        newPill.animate().alpha(0f).translationY(-ui.dp(12).toFloat()).setDuration(Skins.dur(160L)).withEndAction { newPill.visibility = View.GONE }.start()
    }
    /** (v428) فتح/قفل صفحة المشاهدة أو القناة: الكبسولة تتخبّى فورًا (elevation بتاعها كان بيرسمها فوق الصفحة) وترجع لما ترجع للقايمة */
    private fun pillGate(covered: Boolean) {
        if (covered) { newPill.animate().cancel(); newPill.visibility = View.GONE; newPill.alpha = 0f; return }
        val st = cur
        if (pendingItems != null && st != null && st.tab == pendingTab && st.vid == null && st.q == null && st.chUrl == null) showPill(pillN)
    }
    /** دوسة على الكبسولة: القايمة تتبدّل بالجديد وترجع لفوق */
    /** (v1336) عند تبديل القايمة: انقل لوجو كل قناة من العناصر القديمة للجديدة بنفس channelId عشان اللوجو ما يختفيش لحد ما يتجلب من الشبكة */
    private fun carryAvatars(from: List<NpItem>, to: List<NpItem>) {
        val m = HashMap<String, String>()
        for (x in from) if (x.avatar.isNotBlank() && x.channelId.isNotBlank()) m[x.channelId] = x.avatar
        if (m.isEmpty()) return
        for (x in to) if (x.avatar.isBlank()) { val a = m[x.channelId]; if (!a.isNullOrBlank()) x.avatar = a }
    }
    private fun applyPending() {
        val p = pendingItems; val t = pendingTab
        hidePill()
        val st = cur ?: return
        if (p == null || st.tab != t || st.vid != null) return
        carryAvatars(st.items, p)
        st.items.clear(); st.items.addAll(p); st.pos = 0
        if (t == 1) { try { YtNotify.markSeen(p); YtNotify.markOpened(act) } catch (_: Throwable) {} }   // اللي اتعرض ما يجيش عليه عدّاد/إشعار
        animRows = true; h.postDelayed({ animRows = false }, 700L)
        adapter.set(st.list()); lv.setSelection(0)
    }
    /** تحديث خلفي خلص (0 = الرئيسية · 1 = الاشتراكات): لو فيه جديد مش معروض والصفحة دي مفتوحة → كبسولة */
    private fun onFeedUpdate(tab: Int, fresh: List<NpItem>) {
        if (act.isFinishing || act.isDestroyed) return
        bgLine(false)
        val st = cur ?: return
        if (st.tab != tab || st.vid != null || st.q != null || st.chUrl != null || st.items.isEmpty()) return
        if (tab == 0 && chipSel != 0) return
        val vids = fresh.filter { it.kind == 0 }
        if (vids.isEmpty()) return
        if (tab == 1) YtSnap.save(act, 1, vids)   // (v472) آخر نسخة سليمة للاشتراكات
        val have = HashSet<String>(); for (x in st.items) have.add(x.id)
        val seenIds: Set<String> = if (tab == 0) YtStore.read(YtStore.HIST).map { it.id }.toHashSet() else emptySet()
        val items = if (tab == 0) vids.filter { it.id !in seenIds } else vids
        val newOnes = items.count { it.id !in have }
        if (newOnes < (if (tab == 0) 6 else 1)) return
        carryAvatars(st.items, items)
        pendingItems = items; pendingTab = tab
        showPill(newOnes)
    }
    // فحص دوري (كل 4 دقايق) وإنت فاتح الرئيسية أو الاشتراكات: لو فيه فيديوهات جديدة تظهر الكبسولة من غير ما تعمل تحديث
    private val pollRun: Runnable = object : Runnable {
        override fun run() {
            h.postDelayed(this, 4 * 60_000L)
            if (navSel != 1) { tvBadgeRefresh(true); try { YtNotify.mtPeek(act) } catch (_: Throwable) {} }   // (v575) · (v1107) عدّاد «الاشتراكات»
            if (root.visibility != View.VISIBLE || watch.isOpen || chan.isOpen || bgBusy || loadBusy) return
            val st = cur ?: return
            if (st.vid != null || st.q != null || st.chUrl != null) return
            if (st.tab == 1) {
                val subs = YtStore.read(YtStore.SUBS)
                if (YtMtFeed.usableCached()) { /* (v1104 Y3) اشتراكات المحرك: التحديث بالسحب أو بفتح الصفحة */ }
                else if (subs.isNotEmpty()) { bgLine(true); YtRss.refreshAsync(subs) }
            } else if (st.tab == 0 && chipSel == 0) {
                if (YtMtFeed.usableCached()) {   // (v1104 Y3) رئيسية المحرك
                    if (YtMtFeed.homeAgeMs() > 5 * 60_000L && YtMtFeed.refreshHomeAsync(YtStore.read(YtStore.HIST))) bgLine(true)
                } else if (YtNp.homeAgeMs() > 5 * 60_000L) {
                    if (YtNp.refreshHomeAsync(YtStore.read(YtStore.HIST), YtStore.read(YtStore.SUBS))) bgLine(true)
                }
            }
        }
    }
    // (v1107) «اتشاف» في الرئيسية = ظهر على الشاشة وإنت بتسكرول (من الأول لحد أبعد مكان وصلتله). «اتفرّجت عليه» = اتفتح فعلًا (السجل HIST) وده اللي بيتشال من الرئيسية.
    private var homeSeenFor: Any? = null
    private var homeSeenMax = -1
    private fun markHomeViewed() {
        val st = cur ?: return
        if (st !== homeSeenFor || homeSeenMax < 0) return
        if (st.tab != 0 || st.vid != null || st.q != null || st.chUrl != null || chipSel != 0) return
        if (!YtMtFeed.usableCached()) return
        val l = st.list(); val ids = ArrayList<String>()
        for (i in 0..minOf(homeSeenMax, l.size - 1)) { val x = l[i]; if (x.kind == 0 && x.id.length == 11) ids.add(x.id) }
        YtMtFeed.markViewed(ids)
    }
    private fun startPoll() { h.removeCallbacks(pollRun); h.postDelayed(pollRun, 4 * 60_000L) }

    // (v407) recents() بتقرا ملف recent.json وتحلّله — كانت بتتنده لكل كارت في كل getView (سبب تقطيع/بطء الفتح والسكرول). دلوقتي كاش 3 ثواني
    private var recMemo: Map<String, *> = emptyMap<String, Any?>()
    private var recMemoAt = 0L
    private fun recs(): Map<String, *> {
        val n = android.os.SystemClock.uptimeMillis()
        if (n - recMemoAt > 3000L) { recMemo = try { recents() } catch (_: Throwable) { emptyMap<String, Any?>() }; recMemoAt = n }
        return recMemo
    }
    // (v390) سحب لتحت = تحديث (الرئيسية · الاشتراكات · أنت) زي قايمة الفيديوهات
    private val ptrDr = WinSpinnerDrawable().apply { setColorFilter(PorterDuffColorFilter(th.primary, PorterDuff.Mode.SRC_IN)) }   // (v1107) دايرة التحديث = لودينج البرنامج بدل 🔄 والخط الأزرق
    private val ptr = FrameLayout(act).apply {
        background = ui.box(th.surface, th.border, 22)
        elevation = ui.dp(6).toFloat(); alpha = 0f; translationY = -ui.dp(50).toFloat()
        addView(View(act).apply { foreground = ptrDr }, FrameLayout.LayoutParams(ui.dp(26), ui.dp(26), Gravity.CENTER))
    }
    private fun endPull() {
        lv.animate().translationY(0f).setDuration(250).start()
        if (!(bgBusy || loadBusy)) ptr.animate().alpha(0f).translationY(-ui.dp(50).toFloat()).setDuration(250).start()
    }
    private fun pullRefresh() {
        when (cur?.tab) {
            0 -> { YtNp.clearHome(); YtMtFeed.dropHomeSnap(); if (YtAccount.loggedIn()) YtAccount.syncAsync(true); openTab(0) }
            1 -> openSubs(true)
            4 -> if (YtAccount.loggedIn()) syncNow() else openTab(4)
        }
    }
    private val busyDr = WinSpinnerDrawable()
    private val busyOff = Runnable { busy(false) }
    /** (v337) بيتضاف في Main فوق الصفحة (pane) — بيظهر وإحنا بنجيب رابط الفيديو قبل ما المشغّل يفتح */
    val busyView = FrameLayout(act).apply {
        visibility = View.GONE; isClickable = true; setBackgroundColor(0x66000000)
        addView(View(act).apply { foreground = busyDr }, FrameLayout.LayoutParams(ui.dp(72), ui.dp(72), Gravity.CENTER))
    }
    fun busy(on: Boolean) {
        h.removeCallbacks(busyOff)
        if (on) { busyView.visibility = View.VISIBLE; busyDr.start(); h.postDelayed(busyOff, 40_000L) }
        else { busyView.visibility = View.GONE; busyDr.stop() }
    }
    /** (v467) يوتيوب بيحترم وضع الواجهة: تابلت/تلفزيون/لاندسكيب = شبكة أعمدة، مش قايمة موبايل ممدودة */
    private fun ytCols(): Int = when { DeviceUi.isTv(act) -> 3; DeviceUi.isTablet(act) -> 2; act.resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE -> 2; else -> 1 }
    private val lv = GridView(act)
    /** (v477) عرض كارت الفيديو: على التلفزيون عرض العمود (4 أعمدة)، وعلى الباقي عرض الشاشة زي ما كان */
    private fun cardW(): Int {
        val sw = act.resources.displayMetrics.widthPixels
        return if (DeviceUi.isTv(act)) (sw - ui.dp(32) - ui.dp(24)) / 3 else sw   // (v674) تلفزيون: 3 مربعات في الصف
    }
    /** (v477) تلفزيون: التركيز يروح لشبكة الفيديوهات (بيتندهي من Main لما تفتح تبويب يوتيوب) */
    fun tvFocusList() { if (DeviceUi.isRemote(act)) lv.post { try { if (root.visibility == View.VISIBLE && lv.isShown && !watch.isOpen && !chan.isOpen) lv.requestFocus() } catch (_: Throwable) {} } }   // (v479) مايسرقش التركيز وصفحة المشاهدة/القناة مفتوحة
    private lateinit var ytDock: YtDock               // (v417) شريط مصغّر سفلي بيكمّل الفيديو لما تنزّل من صفحة المشاهدة
    private lateinit var watch: YtWatchPage          // (v402) صفحة المشاهدة (مشغّل مصغّر + تعليقات + مقترحات)
    private lateinit var chan: YtChannelPage         // (v403) صفحة القناة (بانر + اشتراك + جرس + تابات)
    private var navBar: View? = null
    private var navLine: View? = null
    private var lastDownX = 0
    @Volatile private var animRows = false
    private val statusTv: TextView
    private val search: EditText
    private val sugBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
    // (v348) شريط يوتيوب السفلي + الشورتس: page = كل الشاشة القديمة (بحث/قوايم)، shortsHost = صفحة الشورتس فوقها
    private val page = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
    private var navSel = 0
    private lateinit var topTitle: TextView
    private lateinit var bellBadge: TextView   // (v1304) عدّاد الإشعارات غير المقروءة على الجرس
    private var inxDlg: android.app.Dialog? = null
    private var expDlg: android.app.Dialog? = null
    private val lite = act.packageName.endsWith(".lite")
    /** (v475) تبويبات يوتيوب في شريط البرنامج السفلي: Main بيسمع هنا (onTab) وبيبعت الضغطات (tapTab) */
    var onTab: ((Int) -> Unit)? = null
    val currentTab: Int get() = navSel
    private val promptBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; visibility = View.GONE; setPadding(ui.dp(28), ui.dp(16), ui.dp(28), ui.dp(16)) }
    private val navIcons = ArrayList<YtIcon>()
    private val navLabs = ArrayList<TextView>()
    private val navBars = ArrayList<View>()   // (v472) خط التمييز تحت التبويب النشط
    private val railLabs = ArrayList<TextView>()   // (v1323) ليبلات الريل الجانبي الشمال (الرئيسية · الاشتراكات · أنا)
    private var ytRail: View? = null
    private val chanRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
    private val chanName: TextView
    private val subBtn: TextView
    private val filterRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
    private val subsRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }   // (v327)
    private lateinit var notifBtn: TextView
    private val filterViews = ArrayList<TextView>()

    private val detailBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(ui.dp(10), ui.dp(2), ui.dp(10), ui.dp(4)) }
    private lateinit var dThumb: ImageView
    private lateinit var dTitle: TextView
    private lateinit var dMeta: TextView
    private lateinit var dChan: TextView
    private lateinit var dDesc: TextView
    private lateinit var dSave: TextView
    private lateinit var dRel: TextView
    private lateinit var dCom: TextView
    private var cur: St? = null
    private val stack = ArrayList<St>()
    private var gen = 0
    private var loadingMore = false
    private var sugGen = 0
    private var retry: (() -> Unit)? = null
    private val adapter = Adapter()
    private val FILTERS = listOf("" to "الكل", "videos" to "فيديوهات", "channels" to "قنوات", "playlists" to "قوايم")
    // (v469) C5/C10: ترتيب القوايم · إخفاء المُشاهَد · فلاتر بحث (مدة/تاريخ) · تشغيل قايمة كاملة
    private var sortMode = 0
    private var typeMode = 0
    private val typeLabels = listOf("الكل", "فيديوهات", "شورتس", "بوستات")
    private var ctlType: TextView? = null
    private var hideSeen = try { Cfg.str("ytp_hide_seen", "0") == "1" } catch (_: Throwable) { false }
    private var pendDurF = 0; private var pendDateF = 0; private var pendLiveF = false   // (v1303) + مباشر
    private var pendingPlayAll = false
    private val sortLabels = listOf("الافتراضي", "الأحدث", "الأكثر مشاهدة", "الأطول", "الأقصر", "الأقدم")   // (v1300) + الأقدم
    private val durLabels = listOf("الكل", "قصير", "متوسط", "طويل")
    private val dateLabels = listOf("الكل", "اليوم", "الأسبوع", "الشهر", "آخر ساعة", "السنة")   // (v1303) + آخر ساعة/السنة
    private var ctlRow: LinearLayout? = null
    private var ctlSort: TextView? = null
    private var ctlHide: TextView? = null
    private var ctlDur: TextView? = null
    private var ctlDate: TextView? = null
    private var ctlLive: TextView? = null   // (v1303) شريحة فلتر المباشر

    // (v397) شريط يوتيوب العلوي (شعار + أيقونات) وشريط البحث وشرائح الرئيسية
    private val appBar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setBackgroundColor(YtSkin.bg) }
    private val searchBar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; visibility = View.GONE; setBackgroundColor(YtSkin.bg) }
    private var searchTyping = false
    private val HOME_CHIPS = listOf("الكل" to "", "الرائج" to "mt:trending", "موسيقى" to "mt:music", "ألعاب" to "mt:gaming", "أخبار" to "mt:news", "رياضة" to "mt:sports", "مباشر" to "mt:live")   // (v1298) شرائح أقسام حقيقية من محرك MeeTube (مع رجوع للبحث لو المحرك مش متاح)
    private val chipViews = ArrayList<TextView>()
    private var chipSel = 0
    private val chipsScroll = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; visibility = View.GONE; setBackgroundColor(YtSkin.bg) }

    init {
        // (v397) الشريط العلوي زي يوتيوب: شعار + أيقونات (إشعارات · بحث · إعدادات)؛ البحث بيفتح شريط (سهم رجوع + خانة + مسح)
        search = EditText(act).apply {
            hint = "ابحث في يوتيوب"; setHintTextColor(YtSkin.sub); setTextColor(YtSkin.text); textSize = 15f
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_SEARCH; gravity = Gravity.CENTER_VERTICAL or Gravity.START
            setPadding(ui.dp(16), 0, ui.dp(12), 0)
            background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(20).toFloat() }
            setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEARCH) { doSearch(text.toString()); true } else false }
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { suggest(s?.toString() ?: "") }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        fun iconBtn(kind: String, desc: String, onClick: () -> Unit): YtIcon = YtIcon(act, kind).apply {
            contentDescription = desc; foreground = YtSkin.ripple(true); setOnClickListener { onClick() }
        }
        // (v479 م5) تلفزيون: زرار 🎤 بحث صوتي (RecognizerIntent) جنب البحث — الكتابة بلوحة مفاتيح النظام زي ما هي
        fun micBtn(): TextView = TextView(act).apply { text = "🎤"; textSize = 20f; gravity = Gravity.CENTER; foreground = YtSkin.ripple(true); contentDescription = "بحث صوتي"; setOnClickListener { startVoice() } }
        // (v472) تبويبات يوتيوب (الرئيسية · الاشتراكات · أنت) بقت في الصف العلوي نفسه مع البحث والإعدادات — مفيش شريط سفلي تاني فوق شريط البرنامج
        val tabsBox = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val tabCells = arrayOfNulls<View>(3)
        listOf("الرئيسية", "الاشتراكات", "أنت").forEachIndexed { i, name ->
            val lab = TextView(act).apply { text = name; textSize = 14.5f; gravity = Gravity.CENTER; setSingleLine(); includeFontPadding = false; typeface = YtSkin.medium }
            val bar = View(act).apply { background = GradientDrawable().apply { setColor(YtSkin.accent); cornerRadius = ui.dp(2).toFloat() }; visibility = View.INVISIBLE }
            val cell = FrameLayout(act).apply { foreground = YtSkin.ripple(); setOnClickListener { navTap(i) } }
            cell.addView(lab, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            cell.addView(bar, FrameLayout.LayoutParams(ui.dp(26), ui.dp(3), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            navLabs.add(lab); navBars.add(bar)
            tabCells[i] = cell
        }
        for (i in intArrayOf(1, 0, 2)) tabsBox.addView(tabCells[i]!!, LinearLayout.LayoutParams(0, -1, 1f))   // (v674) تلفزيون: الاشتراكات أول زرار (الأساسي) ثم الرئيسية ثم أنت — الأرقام الداخلية زي ما هي
        appBar.setPadding(ui.dp(6), ui.dp(2), ui.dp(4), ui.dp(2))
        // (v475) التبويبات (الرئيسية · الاشتراكات · أنا) بقت في الشريط السفلي بتاع البرنامج — فوق بقى عنوان الصفحة + بحث + إعدادات بس
        topTitle = TextView(act).apply { text = "يوتيوب"; textSize = 19f; setTextColor(YtSkin.text); typeface = YtSkin.medium; gravity = Gravity.CENTER_VERTICAL or Gravity.START; setSingleLine(); setPadding(ui.dp(12), 0, ui.dp(8), 0) }
        appBar.addView(topTitle, LinearLayout.LayoutParams(0, ui.dp(46), 1f))
        if (DeviceUi.isTv(act)) {   // (v527) تلفزيون: تابات يوتيوب (الرئيسية · الاشتراكات · أنا) جوه صفحة يوتيوب نفسها (الشريط السفلي مشال على التلفزيون) — بالأسهم + OK
            for (k in 0 until tabsBox.childCount) tabsBox.getChildAt(k).apply { isFocusable = true; isClickable = true }
            appBar.addView(tabsBox, LinearLayout.LayoutParams(ui.dp(360), ui.dp(46)).apply { marginEnd = ui.dp(10) })
        }
        if (DeviceUi.isRemote(act)) appBar.addView(micBtn(), LinearLayout.LayoutParams(ui.dp(48), ui.dp(44)))
        appBar.addView(iconBtn("search", "بحث") { enterSearch(true) }, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        appBar.addView(TextView(act).apply { text = "🧭"; textSize = 19f; gravity = Gravity.CENTER; foreground = YtSkin.ripple(true); contentDescription = "استكشاف"; setOnClickListener { showExplore() } }, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))   // (v1304) استكشاف
        bellBadge = TextView(act).apply { textSize = 10.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = YtSkin.medium; background = GradientDrawable().apply { setColor(0xFFFF3B30.toInt()); cornerRadius = ui.dp(8).toFloat() }; visibility = View.GONE; setPadding(ui.dp(4), 0, ui.dp(4), 0); minWidth = ui.dp(16) }
        val bellCell = FrameLayout(act).apply { foreground = YtSkin.ripple(true); contentDescription = "الإشعارات"; setOnClickListener { showInbox() } }   // (v1304) صندوق الإشعارات
        bellCell.addView(YtIcon(act, "bell"), FrameLayout.LayoutParams(-1, -1))
        bellCell.addView(bellBadge, FrameLayout.LayoutParams(-2, ui.dp(16), Gravity.TOP or Gravity.END).apply { topMargin = ui.dp(3); marginEnd = ui.dp(1) })
        appBar.addView(bellCell, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        appBar.addView(iconBtn("gear", "إعدادات يوتيوب") { settings() }, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        val backBtn = iconBtn("back", "رجوع") { exitSearch() }.apply { scaleX = -1f }
        val clearBtn = iconBtn("close", "مسح") { search.setText(""); search.requestFocus(); showKb() }
        searchBar.setPadding(ui.dp(4), ui.dp(4), ui.dp(8), ui.dp(4))
        searchBar.addView(backBtn, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        searchBar.addView(search, LinearLayout.LayoutParams(0, ui.dp(40), 1f))
        if (DeviceUi.isRemote(act)) searchBar.addView(micBtn(), LinearLayout.LayoutParams(ui.dp(48), ui.dp(44)))
        searchBar.addView(clearBtn, LinearLayout.LayoutParams(ui.dp(44), ui.dp(44)))
        page.addView(appBar, LinearLayout.LayoutParams(-1, -2))
        page.addView(searchBar, LinearLayout.LayoutParams(-1, -2))
        page.addView(sugBox, LinearLayout.LayoutParams(-1, -2))
        // (v397) شرائح الرئيسية (الكل · موسيقى · ألعاب …): الضغط على شريحة بيبدّل فيد الرئيسية من غير ما تسيب الصفحة
        val chipRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(8)) }
        HOME_CHIPS.forEachIndexed { i, (label, term) ->
            val tv = TextView(act).apply {
                text = label; textSize = 14f; gravity = Gravity.CENTER; includeFontPadding = false; setSingleLine()
                typeface = YtSkin.medium
                setPadding(ui.dp(12), 0, ui.dp(12), 0)
                setOnClickListener { homeChip(i, term) }
            }
            chipViews.add(tv)
            chipRow.addView(tv, LinearLayout.LayoutParams(-2, ui.dp(32)).apply { marginEnd = ui.dp(8) })
        }
        chipsScroll.addView(chipRow)
        page.addView(chipsScroll, LinearLayout.LayoutParams(-1, -2))
        paintHomeChips()

        // صف القناة (اسم + اشتراك)
        chanName = ui.text("", 15f, th.text, true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END }
        subBtn = ui.text("🔔 اشترك", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(ui.dp(14), ui.dp(6), ui.dp(14), ui.dp(6))
            setOnClickListener { toggleSub() }
        }
        chanRow.setPadding(ui.dp(14), ui.dp(4), ui.dp(14), ui.dp(6))
        chanRow.addView(chanName, LinearLayout.LayoutParams(0, -2, 1f))
        chanRow.addView(subBtn, LinearLayout.LayoutParams(-2, -2))
        page.addView(chanRow, LinearLayout.LayoutParams(-1, -2))

        // (v327) صف الاشتراكات: إشعارات الفيديوهات الجديدة + تحديث
        notifBtn = ui.text("", 12f, th.text, true).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(4), ui.dp(6), ui.dp(4), ui.dp(6)); setSingleLine(); ellipsize = TextUtils.TruncateAt.END
            setOnClickListener { toggleNotif() }
        }
        val refBtn = ui.text("🔄 تحديث", 12f, th.primary, true).apply {
            gravity = Gravity.CENTER; setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6)); setOnClickListener { openSubs(true) }
        }
        subsRow.setPadding(ui.dp(14), ui.dp(2), ui.dp(10), ui.dp(4))
        subsRow.addView(notifBtn, LinearLayout.LayoutParams(0, -2, 1f))
        subsRow.addView(refBtn, LinearLayout.LayoutParams(-2, -2))
        page.addView(subsRow, LinearLayout.LayoutParams(-1, -2))
        paintNotif()
        YtRss.attach(act); YtAccount.init(act)
        YtNp.attach(act)   // (v407) كاش الرئيسية على الملف
        YtMtFeed.attach(act); Thread { try { YtMtFeed.usable() } catch (_: Throwable) {} }.also { it.isDaemon = true }.start()   // (v1104 Y3) نعرف من بدري لو حساب الكود مسجّل
        YtMtFeed.onHome = { r -> act.runOnUiThread { onFeedUpdate(0, r.items) } }
        YtNp.onHome = { r -> act.runOnUiThread { onFeedUpdate(0, r.items) } }
        YtRss.onFeed = { r -> act.runOnUiThread { onFeedUpdate(1, r.items) } }
        try { YtNotify.schedule(act) } catch (_: Throwable) {}

        // فلاتر نتايج البحث
        filterRow.setPadding(ui.dp(8), 0, ui.dp(8), ui.dp(6)); filterRow.layoutDirection = View.LAYOUT_DIRECTION_RTL
        FILTERS.forEach { (k, n) ->
            val tv = ui.text(n, 12f, th.text).apply {
                gravity = Gravity.CENTER; setPadding(ui.dp(12), ui.dp(5), ui.dp(12), ui.dp(5)); tag = k
                setOnClickListener { cur?.q?.let { q -> doSearch(q, k) } }
            }
            filterViews.add(tv)
            filterRow.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) })
        }
        // (v1300) زرار إعدادات البحث الكاملة (النوع + الترتيب في مكان واحد زي يوتيوب)
        val gear = ui.text("⚙ فلاتر", 12f, th.text).apply {
            gravity = Gravity.CENTER; setPadding(ui.dp(12), ui.dp(5), ui.dp(12), ui.dp(5))
            setOnClickListener { searchSettings() }
        }
        paintChip(gear, false)
        filterRow.addView(gear, LinearLayout.LayoutParams(-2, -2).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) })
        page.addView(HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(filterRow) }, LinearLayout.LayoutParams(-1, -2))

        // (v469) صف التحكم في القوايم: ترتيب · إخفاء المُشاهَد · (للبحث) مدة/تاريخ الرفع
        val ctl = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; visibility = View.GONE; setPadding(ui.dp(8), 0, ui.dp(8), ui.dp(6)) }
        fun ctlChip(onClick: (View) -> Unit): TextView = ui.text("", 12f, th.text).apply { gravity = Gravity.CENTER; setPadding(ui.dp(12), ui.dp(5), ui.dp(12), ui.dp(5)); setOnClickListener { v -> onClick(v) }; paintChip(this, false) }
        ctlType = ctlChip { v -> typeMenu(v) }
        ctlSort = ctlChip { v -> sortMenu(v) }
        ctlHide = ctlChip { toggleHideSeen() }
        ctlDur = ctlChip { v -> durMenu(v) }
        ctlDate = ctlChip { v -> dateMenu(v) }
        ctlLive = ctlChip { pendLiveF = !pendLiveF; cur?.let { st -> st.q?.let { q -> doSearch(q, st.filter) } } }   // (v1303) مباشر
        for (c in listOf(ctlType!!, ctlSort!!, ctlHide!!, ctlDur!!, ctlDate!!, ctlLive!!)) ctl.addView(c, LinearLayout.LayoutParams(-2, -2).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) })
        ctlRow = ctl
        page.addView(HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(ctl) }, LinearLayout.LayoutParams(-1, -2))

        // (v326) صندوق تفاصيل الفيديو: صورة ▶ + عنوان + أزرار + وصف + مقترحات/تعليقات
        dThumb = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(th.surface) }
        val playMark = ui.text("▶", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER; background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(0x99000000.toInt()) } }
        val tbox = FrameLayout(act).apply { setOnClickListener { playCur(false) } }
        tbox.addView(dThumb, FrameLayout.LayoutParams(-1, -1))
        tbox.addView(playMark, FrameLayout.LayoutParams(ui.dp(36), ui.dp(36), Gravity.CENTER))
        dTitle = ui.text("", 14f, th.text, true).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END }
        dMeta = ui.text("", 11f, th.muted).apply { maxLines = 2 }
        val tcol = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(10), 0, ui.dp(10), 0) }
        tcol.addView(dTitle, LinearLayout.LayoutParams(-1, -2)); tcol.addView(dMeta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(4) })
        val r1 = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        r1.addView(tbox, LinearLayout.LayoutParams(ui.dp(130), ui.dp(73))); r1.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f))
        dChan = ui.text("", 13f, th.primary, true).apply { setSingleLine(); ellipsize = TextUtils.TruncateAt.END; setPadding(0, ui.dp(8), 0, ui.dp(4))
            setOnClickListener { cur?.det?.let { d -> openChannel(d.channelUrl, d.channel) } } }
        fun chip(t: String, onClick: () -> Unit) = ui.text(t, 12.5f, th.text, true).apply {
            gravity = Gravity.CENTER; setPadding(ui.dp(10), ui.dp(7), ui.dp(10), ui.dp(7)); setSingleLine(); setOnClickListener { onClick() }; paintChip(this, false) }
        val bPlay = chip("▶ شغّل") { playCur(false) }
        val bTr = chip("🌐 شغّل وترجم") { playCur(true) }
        dSave = chip("🔖 احفظ") { saveCur() }
        val bCopy = chip("📋") { cur?.let { st -> copy(YtNp.watchUrl(st.vid?.id ?: "")) } }
        val btns = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf(bPlay, bTr, dSave, bCopy).forEach { b -> btns.addView(b, LinearLayout.LayoutParams(0, -2, if (b === bCopy) 0.5f else 1f).apply { setMargins(ui.dp(2), 0, ui.dp(2), 0) }) }
        dDesc = ui.text("", 12f, th.muted).apply { maxLines = 3; ellipsize = TextUtils.TruncateAt.END; setPadding(0, ui.dp(8), 0, ui.dp(6))
            setOnClickListener { maxLines = if (maxLines == 3) 40 else 3 } }
        dRel = chip("📑 مقترحات") { setMode(false) }
        dCom = chip("💬 تعليقات") { setMode(true) }
        if (DeviceUi.isTv(act)) dCom.visibility = View.GONE
        val seg = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf(dRel, dCom).forEach { b -> seg.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(ui.dp(2), 0, ui.dp(2), 0) }) }
        detailBox.addView(r1, LinearLayout.LayoutParams(-1, -2)); detailBox.addView(dChan, LinearLayout.LayoutParams(-1, -2))
        detailBox.addView(btns, LinearLayout.LayoutParams(-1, -2)); detailBox.addView(dDesc, LinearLayout.LayoutParams(-1, -2)); detailBox.addView(seg, LinearLayout.LayoutParams(-1, -2))
        page.addView(detailBox, LinearLayout.LayoutParams(-1, -2))

        statusTv = ui.text("", 14f, th.muted).apply { gravity = Gravity.CENTER; setPadding(ui.dp(20), ui.dp(30), ui.dp(20), 0); visibility = View.GONE; setOnClickListener { retry?.invoke() } }
        page.addView(statusTv, LinearLayout.LayoutParams(-1, -2))
        page.addView(promptBox, LinearLayout.LayoutParams(-1, 0, 1f))   // (v475) شاشة «سجّل دخول / زامن» بدل «مفيش حاجة»

        lv.apply {
            setBackgroundColor(YtSkin.bg); selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
            numColumns = ytCols(); horizontalSpacing = ui.dp(6); verticalSpacing = ui.dp(6); stretchMode = GridView.STRETCH_COLUMN_WIDTH
            if (DeviceUi.isRemote(act)) {   // (v477) يوتيوب على التلفزيون: تحديد واضح بالريموت + Menu = قايمة الفيديو
                selector = GradientDrawable().apply { setColor(0x14FFFFFF); setStroke(ui.dp(3), YtSkin.accent); cornerRadius = ui.dp(10).toFloat() }
                setDrawSelectorOnTop(true); descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
                isFocusable = true; isFocusableInTouchMode = false
                horizontalSpacing = ui.dp(12); verticalSpacing = ui.dp(12); setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(24)); clipToPadding = false
                setOnKeyListener { _, k, e ->
                    if (e.action == android.view.KeyEvent.ACTION_DOWN && (k == android.view.KeyEvent.KEYCODE_MENU || k == android.view.KeyEvent.KEYCODE_BUTTON_Y)) {
                        val item = cur?.list()?.getOrNull(selectedItemPosition); val sv = selectedView
                        if (item != null && sv != null && item.kind != 3 && item.kind != 4 && item.kind != 5 && item.id != "act") { menu(sv, item); true } else false
                    } else false
                }
            }
            this.adapter = this@YtProUi.adapter
            setOnItemClickListener { _, view, p, _ -> cur?.list()?.getOrNull(p)?.let { if (it.kind != 3) open(it, view) } }
            // (v471) تسخين: أول ما صباعك يلمس فيديو بنبدأ نجيب رابطه — لما ترفع صباعك يكون غالبًا جاهز
            setOnTouchListener { v, e ->
                if (e.actionMasked == android.view.MotionEvent.ACTION_DOWN) {
                    try { val g = v as GridView; val p = g.pointToPosition(e.x.toInt(), e.y.toInt()); cur?.list()?.getOrNull(p)?.let { if (it.kind == 0 && it.id.length == 11) YtFast.warm(it.id) } } catch (_: Throwable) {}
                }
                false
            }
            setOnItemLongClickListener { _, v, p, _ -> cur?.list()?.getOrNull(p)?.let { if (it.kind == 3 || it.kind == 4) copy(it.title) else if (it.kind == 5) { } else if (it.id != "act") menu(v, it) }; true }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(v: AbsListView?, s: Int) { if (s == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) { prewarmVisible(); try { markHomeViewed() } catch (_: Throwable) {} } }   // (v472)
                override fun onScroll(v: AbsListView?, first: Int, vis: Int, total: Int) {
                    if (total > 0 && first + vis >= total - 3) loadMore()
                    if (vis > 0) { val c0 = cur; if (homeSeenFor !== c0) { homeSeenFor = c0; homeSeenMax = -1 }; if (first + vis - 1 > homeSeenMax) homeSeenMax = first + vis - 1 }   // (v1107) أبعد مكان وصلتله في الرئيسية
                }
            })
        }
        page.addView(lv, LinearLayout.LayoutParams(-1, 0, 1f))
        lv.viewTreeObserver.addOnGlobalLayoutListener { val c = ytCols(); if (lv.numColumns != c) lv.numColumns = c }   // (v467) الأعمدة بتتظبط لو الوضع/الاتجاه اتغيّر
        run {
            var y0 = 0f; var pulling = false; var pd = 0f
            val thr = ui.dp(60).toFloat()
            lv.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { y0 = e.rawY; lastDownX = e.rawX.toInt(); pulling = false; false }
                    MotionEvent.ACTION_MOVE -> {
                        val t = cur?.tab ?: -1
                        if ((t != 0 && t != 1 && t != 4) || spinBox.visibility == View.VISIBLE) return@setOnTouchListener false
                        val dy = e.rawY - y0
                        val atTop = lv.firstVisiblePosition == 0 && (lv.childCount == 0 || lv.getChildAt(0).top >= lv.paddingTop)
                        if (!pulling && dy > ui.dp(10) && atTop) {
                            pulling = true; y0 = e.rawY
                            val c = MotionEvent.obtain(e); c.action = MotionEvent.ACTION_CANCEL; lv.onTouchEvent(c); c.recycle()
                        }
                        if (pulling) {
                            pd = ((e.rawY - y0) * 0.5f).coerceIn(0f, ui.dp(120).toFloat())
                            lv.translationY = pd; ptr.translationY = pd - ui.dp(50)
                            ptr.alpha = (pd / ui.dp(40)).coerceIn(0f, 1f); ptr.rotation = pd * 4f
                            true
                        } else false
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        if (pulling) {
                            pulling = false
                            val go = pd >= thr && e.actionMasked == MotionEvent.ACTION_UP
                            endPull()
                            if (go) pullRefresh()
                            true
                        } else false
                    }
                    else -> false
                }
            }
        }
        // (v348) شريط يوتيوب السفلي: الرئيسية · الاشتراكات · الشورتس · أنت
        val content = FrameLayout(act)
        content.addView(page, FrameLayout.LayoutParams(-1, -1))
        skelBuild()
        content.addView(skelBox, FrameLayout.LayoutParams(-1, -1).apply { topMargin = ui.dp(92) })   // (v1304) تحت الشريط العلوي والشرائح تقريبًا
        content.addView(spinBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))   // (v389)
        content.addView(ptr, FrameLayout.LayoutParams(ui.dp(44), ui.dp(44), Gravity.TOP or Gravity.CENTER_HORIZONTAL))   // (v390)
        content.addView(topLine, FrameLayout.LayoutParams(-1, ui.dp(3), Gravity.TOP))   // (v407) الخط الأزرق
        content.addView(newPill, FrameLayout.LayoutParams(-2, ui.dp(36), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(58) })   // (v407) كبسولة «فيديوهات جديدة»
        chan = YtChannelPage(act, ui, object : YtChanHost {   // (v403) تحت صفحة المشاهدة: فيديو من القناة بيفتح المشاهدة فوقها
            override fun openVideo(v: NpItem) { open(v, null) }
            override fun download(v: NpItem) { dlMenu(chan, v) }   // (v459) زرار ⬇ على كروت القناة
            override fun audio(v: NpItem) { playAudio(v) }   // (v472)
            override fun openPlaylist(url: String, title: String) { chan.close(false); load("📃 " + title, -1, null, null, null, "", true, false) { YtNp.playlist(url) } }
            override fun state(open: Boolean) { setNavHidden(open || watch.isOpen); pillGate(open || watch.isOpen); if (!open) tvFocusList() }   // (v479 م5) التركيز يرجع للشبكة
        })
        content.addView(chan, FrameLayout.LayoutParams(-1, -1))
        watch = YtWatchPage(act, ui, object : YtWatchHost {   // (v402)
            override fun expand(id: String, title: String, posMs: Long, translate: Boolean, pick: YtPick?) {
                val f = onPlayAt
                if (f != null) f(id, title, translate, posMs, pick) else onPlay(id, title, translate)
            }
            override fun openChannel(url: String, name: String) { watch.close(false); this@YtProUi.openChannel(url, name, "") }
            override fun openVideo(v: NpItem) { open(v, null) }   // (v1132) صفحة المشاهدة رجعت: التالي من قائمة الانتظار بيفتح عليها (التلفزيون مبيفتحش الصفحة أصلًا من open())
            override fun audio(v: NpItem) { playAudio(v) }
            override fun download(anchor: View, v: NpItem) { dlMenu(anchor, v) }
            override fun state(open: Boolean) { if (open) ytDock.dismiss(); setNavHidden(open || chan.isOpen); pillGate(open || chan.isOpen); if (!open) tvFocusList() }   // (v479 م5)
            override fun dock(item: NpItem, kept: YtKept) { ytDock.show(item, kept) }   // (v417)
        })
        content.addView(watch, FrameLayout.LayoutParams(-1, -1))
        ytDock = YtDock(act, ui) { id, t, pos, pk -> val f = onPlayAt; if (f != null) f(id, t, false, pos, pk) else onPlay(id, t, false) }   // (v417)
        content.addView(ytDock, FrameLayout.LayoutParams(-1, ui.dp(58), Gravity.BOTTOM))

        // (v1327) ريل تبويبات يوتيوب (الرئيسية · الاشتراكات · أنا) نزل تحت فوق الشريط الأساسي وبقى كبسولة جلاسي زيه بالظبط، وبيترفع فوق الدوك لما فيديو يتصغّر (بطلب علي). التلفزيون عنده تبويباته فوق واللايت خلاياه تحت زي ما هما
        if (!DeviceUi.isTv(act) && !act.packageName.endsWith(".lite")) {
            val rr = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            val cap: ViewGroup = if (MtGlass.on()) {
                val g = FrameLayout(act)
                g.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
                g.addView(rr, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
                g
            } else {
                rr.background = GradientDrawable().apply { setColor(MtGlass.barSolid(th)); cornerRadius = ui.dp(34).toFloat(); setStroke(ui.dp(1), MtGlass.rim(th)) }
                rr.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
                rr
            }
            val railNames = listOf("الرئيسية", "الاشتراكات", "أنا"); val railEmos = listOf("🏠", "📺", "👤")
            for (i in 0..2) {
                val cell = TextView(act).apply {
                    text = railTxt(railEmos[i], railNames[i], 0); textSize = 11f; gravity = Gravity.CENTER; setTextColor(YtSkin.sub); typeface = YtSkin.medium
                    setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4)); foreground = YtSkin.ripple(true)
                    setOnClickListener { tapTab(i) }
                }
                railLabs.add(cell)
                rr.addView(cell, LinearLayout.LayoutParams(-2, -2).apply { setMargins(ui.dp(2), 0, ui.dp(2), 0) })
            }
            val host = object : FrameLayout(act) {
                private var dx = 0f; private var drag = false; private var base = 0f
                override fun onInterceptTouchEvent(e: android.view.MotionEvent): Boolean {
                    when (e.actionMasked) {
                        android.view.MotionEvent.ACTION_DOWN -> { dx = e.rawX; drag = false; base = translationX }
                        android.view.MotionEvent.ACTION_MOVE -> if (!drag && Math.abs(e.rawX - dx) > ui.dp(10)) { drag = true; parent?.requestDisallowInterceptTouchEvent(true) }
                    }
                    return drag
                }
                override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
                    when (e.actionMasked) {
                        android.view.MotionEvent.ACTION_MOVE -> {
                            val pw = (parent as? View)?.width ?: 0
                            val lim = ((pw - width) / 2f).coerceAtLeast(0f)
                            translationX = (base + e.rawX - dx).coerceIn(-lim, lim)
                        }
                        android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> { if (drag) { try { Cfg.put("yt_rail_x", translationX.toInt().toString()) } catch (_: Throwable) {} }; drag = false }
                    }
                    return true
                }
            }
            host.addView(cap, FrameLayout.LayoutParams(-2, -2))
            host.translationX = try { Cfg.int("yt_rail_x", 0).toFloat() } catch (_: Throwable) { 0f }
            ytRail = host
            content.addView(host, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            ytDock.onVis = { ytDock.post { railInset() } }
            // (v1331) زجاج الريل = نفس زجاج شريط الأدوات حرفيًا: بلور حي فوق مصدر الصفحة + نفس التنت وبيتبع سلايدر «الشفافية والبلر»
            // (v1334) إصلاح الفورس كلوز: الريل جوه مصدر الزجاج نفسه، فالبلور الحي بيسجّل نفسه ويكرش — رجعنا لتنت ثابت بنفس قيمة الشريط حرفيًا (نفس الشفافية، من غير بلور)
            val paintRail = {
                if (MtGlass.on()) try { cap.background = GradientDrawable().apply { setColor(MtGlass.ak(MeeRes.color("meetube_glass_tint", 0x66FAFAFA, 0x66000000))); cornerRadius = ui.dp(34).toFloat(); setStroke(ui.dp(1), MtGlass.ak(MeeRes.color("meetube_glass_rim", 0x3DFFFFFF, 0x1F000000))) } } catch (_: Throwable) {}
            }
            host.post { railInset(); paintRail() }
        }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        navBar = null; navLine = null   // (v472) الشريط السفلي الخاص بيوتيوب اتشال (التبويبات فوق)
        paintNav()
    }

    // ───────── واجهة Main ─────────
    // (v621) كان refresh() بيعمل notifyDataSetChanged + يمسح كاش الـrecents (قراءة ملف على الـUI thread) في نفس لحظة بداية الأنيميشن ← تهنيج. دلوقتي بعد ما الانزلاق يخلص
    private val softRefresh = Runnable { recMemoAt = 0L; try { adapter.notifyDataSetChanged() } catch (_: Throwable) {} }
    /** (v1246) فيه فيديوهات جديدة (العدّاد الأحمر) ← الاشتراكات · مفيش ← الرئيسية */
    private fun landTab(): Int = try { if (YtNotify.badgeCount() > 0) 1 else 0 } catch (_: Throwable) { 0 }
    private var leftYt = false   // (v1107)
    fun refresh() {
        bellRefresh()   // (v1304)
        if (cur == null) { recMemoAt = 0L; leftYt = false; openTab(landTab()) }   // (v1107) بيفتح على الرئيسية دايمًا (كان الاشتراكات)
        else if (leftYt && !watch.isOpen && !chan.isOpen && cur?.let { it.tab == 1 && it.vid == null && it.q == null && it.chUrl == null } == true) { leftYt = false; recMemoAt = 0L; openTab(landTab()) }   // (v1107) خرجت من يوتيوب وإنت في الاشتراكات ورجعت ← الرئيسية
        else { leftYt = false; h.removeCallbacks(softRefresh); h.postDelayed(softRefresh, 280L) }
        startPoll()
    }
    /** (v1106) رجعت للتطبيق: لو صفحة «سجّل دخولك» لسه ظاهرة والدخول تم وإنت بره (أو الحالة اتغيّرت) → حمّل الصفحة فورًا من غير ما تنقل بين التابات */
    fun onAppResume() {
        if (promptBox.visibility != View.VISIBLE) return
        val tab = cur?.tab ?: navSel
        if (tab != 0 && tab != 1) return
        Thread {
            val ok = try { YtMtFeed.reset(); MtYt.signedIn() } catch (_: Throwable) { false }
            if (ok) { try { YtMtFeed.markSigned(true) } catch (_: Throwable) {}; act.runOnUiThread { if (!act.isFinishing && !act.isDestroyed && promptBox.visibility == View.VISIBLE) { if (tab == 1) openSubs(true) else openTab(0) } } }
        }.also { it.isDaemon = true; it.start() }
    }
    fun onHide() { leftYt = true; YtNotify.clearNew(); try { markHomeViewed() } catch (_: Throwable) {}; hideKb(); sugBox.visibility = View.GONE; watch.pause(); h.removeCallbacks(pollRun); h.removeCallbacks(softRefresh); if (DeviceUi.isTv(act) && navSel == 1) { try { YtNotify.markOpened(act) } catch (_: Throwable) {} } }   // (v575) خرجت من الاشتراكات = العدّ من دلوقتي
    /** (v348) Main.onStop: الشورتس تقف لما التطبيق يروح الخلفية أو يظهر المشغّل فوقه (بترجع في refresh() مع onResume) */
    fun onPause() { watch.pause(); ytDock.pause() }
    /** (v1162) صفحة المشاهدة اتصغّرت: المشغّل الشغّال بيتسلّم للدوك السفلي (instant لأن الحركة اتعملت في الصفحة) */
    fun dockKept(item: NpItem, kept: YtKept) { ytDock.show(item, kept, true) }
    /** (v606) خروج من التطبيق (Home/Recents) والفيديو شغّال في صفحة المشاهدة أو الشريط السفلي: يتسلّم للمشغّل الكامل ويدخل PiP. true = اتسلّم */
    fun leaveForPip(): Boolean {
        if (Cfg.str("yt_auto_pip", "1") == "0") return false
        return try {
            (::watch.isInitialized && watch.pipHandoff()) || (::ytDock.isInitialized && ytDock.pipHandoff())
        } catch (e: Throwable) { LogStore.err("YtProUi:leaveForPip", e); false }
    }
    fun destroy() { h.removeCallbacks(pollRun); h.removeCallbacks(softRefresh); h.removeCallbacks(lineWatch); YtNp.onHome = null; YtMtFeed.onHome = null; YtRss.onFeed = null; try { ytDock.dismiss() } catch (_: Throwable) {}; watch.release() }
    /** (v479 م5) بحث صوتي على التلفزيون: النتيجة بترجع من Main.onActivityResult (كود 78) */
    private fun startVoice() {
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "قول اسم الفيديو…")
            }
            act.startActivityForResult(i, 78)
        } catch (e: Exception) { LogStore.err("YtPro:voice", e); Notice.show(act, "⚠ البحث الصوتي مش متاح على الجهاز ده", 2200L) }
    }
    fun voiceResult(q: String) { if (q.isNotBlank()) doSearch(q.trim()) }

    fun back(): Boolean {
        if (watch.isOpen) { if (watch.tvBack()) return true; watch.close(true); return true }   // (v402) (v479 م5) تلفزيون: أول Back يرجّع التركيز للفيديو
        if (chan.isOpen) { if (chan.tvBack()) return true; chan.close(true); return true }     // (v403) (v479 م5)
        if (sugBox.visibility == View.VISIBLE) { sugBox.visibility = View.GONE; return true }
        if (stack.isNotEmpty()) { gen++; bind(stack.removeAt(stack.size - 1)); return true }
        if (searchBar.visibility == View.VISIBLE) { exitSearch(); return true }   // (v397)
        return false
    }
    /** ملف اشتراكات: NewPipe JSON أو subscriptions.csv بتاع Google Takeout */
    fun importUri(u: Uri) {
        Thread {
            var n = 0
            try {
                val txt = act.contentResolver.openInputStream(u)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val subs = YtStore.read(YtStore.SUBS)
                fun add(url: String, name: String) { if (url.isNotBlank() && subs.none { it.channelUrl == url }) { subs.add(NpItem("", name.ifBlank { url }, "", url, "", -1L, 0L, "", 1, url)); n++ } }
                if (txt.trimStart().startsWith("{")) {
                    val arr = JSONObject(txt).optJSONArray("subscriptions")
                    if (arr != null) for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); add(o.optString("url"), o.optString("name")) }
                } else {
                    txt.lineSequence().drop(1).forEach { l ->
                        val p = l.split(","); if (p.size >= 3) { val id = p[0].trim(); if (id.startsWith("UC")) add("https://www.youtube.com/channel/$id", p.drop(2).joinToString(",").trim().trim('"')) }
                    }
                }
                YtStore.write(YtStore.SUBS, subs)
            } catch (e: Throwable) { act.runOnUiThread { Notice.show(act, ("⚠ ملف الاشتراكات ماتقرّاش: " + (e.message ?: "")).toString(), 3600L) }; return@Thread }
            act.runOnUiThread { Notice.show(act, ("✅ اتضاف $n اشتراك").toString(), 3000L); if (cur?.tab == 1) openTab(1) }
        }.start()
    }

    // ───────── (v397) بحث + شرائح ─────────
    private fun showKb() { try { search.requestFocus(); (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT) } catch (_: Throwable) {} }
    private fun enterSearch(focus: Boolean) {
        searchTyping = focus
        appBar.visibility = View.GONE; searchBar.visibility = View.VISIBLE
        if (focus) { search.requestFocus(); h.postDelayed({ showKb() }, 80L); if (search.text.isNullOrEmpty()) showHistory() }
    }
    private fun exitSearch() {
        searchTyping = false
        hideKb(); sugBox.visibility = View.GONE; searchBar.visibility = View.GONE; appBar.visibility = View.VISIBLE
        val wasResults = cur?.q != null
        search.setText("")
        if (wasResults) openTab(0)
    }
    private fun paintHomeChips() {
        chipViews.forEachIndexed { i, tv ->
            val on = i == chipSel
            tv.setTextColor(if (on) YtSkin.chipOnText else YtSkin.text)
            tv.background = GradientDrawable().apply { setColor(if (on) YtSkin.chipOnBg else YtSkin.chip); cornerRadius = ui.dp(8).toFloat() }
        }
    }
    private fun homeChip(i: Int, term: String) {
        if (i == chipSel && i != 0) return
        chipSel = i; paintHomeChips()
        if (i == 0) { openTab(0); return }
        hideKb()
        if (term.startsWith("mt:")) {   // (v1298) قسم حقيقي من يوتيوب
            val kind = term.removePrefix("mt:")
            val label = HOME_CHIPS[i].first
            load("🏠 " + label, 0, null, null, null, "", false, false) {
                val hh = YtStore.read(YtStore.HIST)
                val r = try { YtMtFeed.section(kind, hh) } catch (_: Throwable) { null }
                if (r != null && r.items.isNotEmpty()) Pair(r, { p: Page -> YtMtFeed.more(p, hh) })
                else { val rr = YtNp.searchFirst(label, "videos"); Pair(rr, { p: Page -> YtNp.searchMore(label, "videos", p) }) }
            }
            return
        }
        load("🏠 " + term, 0, null, null, null, "", false, false) { val r = YtNp.searchFirst(term, "videos"); Pair(r, { p: Page -> YtNp.searchMore(term, "videos", p) }) }
    }

    /** (v575) تلفزيون: الرئيسية مالهاش صفحة تالية في يوتيوب نفسها — فبنولّد دفعة جديدة (اشتراكات عشوائية + مقترحات) في كل مرة توصل لآخر الصفحة، من غير توقف */
    private fun homeFirst(r: YtRes, hh: List<NpItem>, ss: List<NpItem>): Pair<YtRes, ((Page) -> YtRes)?> =
        if (!DeviceUi.isTv(act)) Pair(r, null)
        else Pair(YtRes(r.items, Page("ytp:home:more")), { _: Page -> val m = YtNp.homeMore(hh, ss); YtRes(m.items, Page("ytp:home:more")) })

    // ───────── تنقّل ─────────
    private fun openTab(i: Int) {
        if (i != 1) YtNotify.clearNew(); hideKb(); sugBox.visibility = View.GONE; stack.clear(); paintTabs(i); hidePill()
        searchTyping = false; searchBar.visibility = View.GONE; appBar.visibility = View.VISIBLE   // (v397)
        if (i == 0) { chipSel = 0; paintHomeChips() }
        when (i) {
            0 -> load("🏠 الرئيسية", 0, null, null, null, "", false, false) {
                val hh = YtStore.read(YtStore.HIST); var ss = YtStore.read(YtStore.SUBS)
                // (v1104 Y3) الرئيسية من محرك MeeTube (حساب الكود): كل الفيديوهات + تحميل مفتوح. فاضية/فشلت ← المسار القديم تحت زي ما هو
                // (v1332) العرض الفوري قبل أي تشغيل للمحرك: usable() بيشغّل المحرك وبياخد ثواني — الكاش يتفحص الأول
                if (YtMtFeed.usableCached()) {
                    val seenH = hh.map { it.id }.toHashSet()
                    val stH = YtMtFeed.homeStale()?.let { c0 -> YtRes(c0.filter { x -> x.id !in seenH }, null) }?.takeIf { it.items.size >= 6 }
                    if (stH != null) {
                        if (YtMtFeed.refreshHomeAsync(hh)) act.runOnUiThread { bgLine(true) }
                        return@load homeFirst(stH, hh, ss)
                    }
                }
                if (YtMtFeed.usable()) {
                    val m = try { YtMtFeed.home(hh) } catch (e: Throwable) { LogStore.err("YtProUi:mtHome", e); null }
                    if (m != null) {
                        val shown = HashSet<String>(); m.items.forEach { shown.add(it.id) }
                        return@load Pair(m, { p: Page -> val x = YtMtFeed.more(p, hh); YtRes(x.items.filter { shown.add(it.id) }, x.next) })
                    }
                    LogStore.add("⚠ رئيسية المحرك رجعت فاضية — بجرّب المسار القديم")
                }
                if (ss.isEmpty() && YtAccount.loggedIn()) { try { YtAccount.syncSubs() } catch (_: Throwable) {}; ss = YtStore.read(YtStore.SUBS) }   // (v375) مسجّل بجوجل ولسه ما فتحتش الاشتراكات: هات القنوات الأول
                if (YtAccount.loggedIn()) YtAccount.syncAsync()   // (v390) مزامنة تلقائية في الخلفية في كل دخول للرئيسية (نجحت الرئيسية ولا فشلت)، مش بس بعد الفشل
                // (v407) أي رئيسية محفوظة (حتى لو قديمة، أو من الملف بعد قفل البرنامج) بتتعرض فورًا، والتحديث في الخلفية وبعدها كبسولة «فيديوهات جديدة»
                val seenIds = hh.map { it.id }.toHashSet()
                val cached = YtNp.homeStale()?.let { c0 -> YtRes(c0.items.filter { x -> x.id !in seenIds }, null) }?.takeIf { it.items.size >= 6 }
                if (cached != null) {
                    if (YtNp.homeAgeMs() > 90_000L && YtNp.refreshHomeAsync(hh, ss)) act.runOnUiThread { bgLine(true) }
                    homeFirst(cached, hh, ss)
                }
                else {
                    // (v389) علاج ذاتي: لو الرئيسية فضيت أو فشلت (كان لازم تدخل «أنت» وتعمل مزامنة) → نعمل نفس المزامنة + نعيد تهيئة NewPipe ونحاول تاني
                    var err: Throwable? = null
                    var r = try { YtNp.home(hh, ss) } catch (e: Throwable) { err = e; YtRes(emptyList(), null) }
                    if (r.items.isEmpty()) {
                        LogStore.add("🩹 الرئيسية فاضية" + (err?.let { " (" + (it.message ?: it.javaClass.simpleName).take(80) + ")" } ?: "") + " — مزامنة + إعادة تهيئة وإعادة محاولة")
                        YtNp.reset()
                        if (YtAccount.loggedIn()) { try { YtAccount.syncSubs() } catch (e: Throwable) { LogStore.add("⚠ مزامنة العلاج الذاتي فشلت: " + (e.message ?: "").take(100)) }; ss = YtStore.read(YtStore.SUBS) }
                        try { r = YtNp.home(hh, ss); err = null } catch (e: Throwable) { err = e }
                    }
                    if (r.items.isEmpty() && err != null) throw err
                    homeFirst(r, hh, ss)
                }
            }
            1 -> {
                val subs = YtStore.read(YtStore.SUBS)
                if (subs.isEmpty() && !YtAccount.loggedIn() && !YtMtFeed.usableCached()) { bind(St("📺 اشتراكاتي", 1, ArrayList(), null, null, null, null, null, "")); emptyPrompt(1, null) }
                else openSubs(false)
            }
            2, 3 -> showLocal(i, false)
            4 -> openYou()
        }
    }

    // ───────── (v348) شريط يوتيوب السفلي + الشورتس ─────────
    /** (v475) i: 0 الرئيسية · 1 الاشتراكات · 2 أنا. دوسة على التبويب وانت فيه: يرجّعك لفوق ويحدّث (نفس سحب التحديث). comeBack = جاي من بوابة تانية: لو إنت أصلًا على الصفحة دي ما يعملش حاجة */
    fun tapTab(i: Int, comeBack: Boolean = false) {
        val st = cur
        val atRoot = st != null && !watch.isOpen && !chan.isOpen && st.vid == null && st.q == null && st.chUrl == null && stack.isEmpty() && st.tab == (if (i == 2) 4 else i)
        if (atRoot && comeBack) return
        if (watch.isOpen) watch.close(false)
        if (chan.isOpen) chan.close(false)
        if (atRoot) {
            try { lv.smoothScrollToPosition(0); lv.setSelection(0) } catch (_: Throwable) {}
            when (i) { 0, 1 -> pullRefresh(); else -> openTab(4) }
            return
        }
        when (i) { 0 -> openTab(0); 1 -> openTab(1); else -> openTab(4) }
    }
    private fun navTap(i: Int) { tapTab(i) }   // (v351) الشورتس اتشالت
    /** (v575) تلفزيون: رقم أحمر بين قوسين جنب «الاشتراكات» = فيديوهات جديدة من آخر ما خرجت من الاشتراكات. جوه الاشتراكات بيفصل */
    private fun tvSubsBadge() {
        if (!DeviceUi.isTv(act)) return
        val lab = navLabs.getOrNull(1) ?: return
        val n = if (navSel == 1) 0 else try { YtNotify.badgeCount() } catch (_: Throwable) { 0 }
        if (n <= 0) { lab.text = "الاشتراكات"; return }
        val sb = android.text.SpannableStringBuilder("الاشتراكات ")
        val st0 = sb.length
        sb.append("(").append(if (n > 99) "99+" else n.toString()).append(")")
        sb.setSpan(android.text.style.ForegroundColorSpan(0xFFFF3B30.toInt()), st0, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), st0, sb.length, android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        lab.text = sb
    }
    private fun tvBadgeRefresh(force: Boolean) {
        if (!DeviceUi.isTv(act)) return
        try { YtNotify.refreshBadge(act, force) { act.runOnUiThread { tvSubsBadge() } } } catch (_: Throwable) {}
    }
    private fun paintNav() {
        for (i in navLabs.indices) {
            val on = i == navSel
            navLabs[i].setTextColor(if (on) YtSkin.accent else YtSkin.sub)
            val b = navBars.getOrNull(i) ?: continue
            if (on && b.visibility != View.VISIBLE) { b.visibility = View.VISIBLE; b.scaleX = 0.2f; b.animate().cancel(); b.animate().scaleX(1f).setDuration(Skins.dur(200L)).start() }
            else if (!on) { b.animate().cancel(); b.visibility = View.INVISIBLE }
        }
        for (i in railLabs.indices) {   // (v1327) تفعيل التاب في الريل: لون + كبسولة تحديد زي الشريط الأساسي
            val on = i == navSel
            railLabs[i].setTextColor(if (on) YtSkin.accent else YtSkin.sub)
            railLabs[i].background = if (on) GradientDrawable().apply { setColor(MtGlass.selected(th)); cornerRadius = ui.dp(22).toFloat(); setStroke(1, MtGlass.rim(th)) } else null
        }
        railSubsBadge()
    }
    /** (v1323) عدّاد «جديد» على زرار الاشتراكات في الريل الجانبي (موبايل) — نفس فكرة بادج التلفزيون */
    private fun railSubsBadge() {
        val lab = railLabs.getOrNull(1) ?: return
        val n = if (navSel == 1) 0 else try { YtNotify.badgeCount() } catch (_: Throwable) { 0 }
        lab.text = railTxt("📺", "الاشتراكات", n)
    }
    /** (v1327) نص خلية الريل: إيموجي أكبر من الليبل (زي خلايا الشريط الأساسي 16/11) */
    private fun railTxt(emo: String, lab: String, badge: Int): CharSequence {
        val s = emo + "\n" + lab + if (badge > 0) " (" + (if (badge > 99) "99+" else badge.toString()) + ")" else ""
        val sp = android.text.SpannableString(s)
        sp.setSpan(android.text.style.RelativeSizeSpan(1.45f), 0, emo.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sp
    }
    /** (v1327) الريل فوق الشريط العايم، وفوق الدوك لما يكون ظاهر: مفيش عنصر يغطّي التاني (بطلب علي) */
    private fun railInset() {
        val r = ytRail ?: return
        val lp = r.layoutParams as? FrameLayout.LayoutParams ?: return
        val bt = try { MtFloat.barTop(act) } catch (_: Throwable) { 0 }
        val b = if (bt > 0) bt + ui.dp(8) else ui.dp(12)
        if (lp.bottomMargin != b) { lp.bottomMargin = b; r.layoutParams = lp }
        // الدوك فوق الريل (الريل لازق فوق الشريط)
        if (::ytDock.isInitialized) { ytDock.extraBottom = if (r.visibility == View.VISIBLE) (if (r.height > 0) r.height else ui.dp(52)) + ui.dp(8) else 0; ytDock.reinset() }
    }
    // ───────── (v1291) «أنت»: زي صفحة You في يوتيوب الرسمي — كارت الحساب فوق، أرفف أفقية بالصور (السجل · أكمل · المحفوظات)، وتحتها قوايمك والتحميلات والإعدادات ─────────
    private fun yrow(title: String, sub: String, key: String) = NpItem("act", title, sub, "", "", -1L, -1L, "", 2, "yta:$key")
    private val youShelves = LinkedHashMap<String, List<NpItem>>()   // (v1291) بيانات الأرفف الأفقية في «أنت» — kind 6 بتقرا منها بالمفتاح اللي في url
    private fun openYou() {
        val rows = ArrayList<NpItem>()
        youShelves.clear()
        val logged = YtAccount.loggedIn()
        if (logged) {
            val nm = try { MtYt.accountName() } catch (_: Throwable) { "" }
            val em = try { MtYt.accountEmail() } catch (_: Throwable) { "" }
            val av = try { MtYt.accountAvatar() } catch (_: Throwable) { "" }
            rows.add(NpItem("act", if (nm.isBlank()) "حساب يوتيوب" else nm, em, "", "", -1L, -1L, "", 7, "ythdr:", 0L, av))
        } else {
            rows.add(NpItem("act", "سجّل دخولك ليوتيوب", "اشتراكاتك وقوايمك وسجلك وفيديوهات الإعجاب بتظهر هنا", "", "", -1L, -1L, "", 7, "ythdr:"))
        }
        val hist = YtStore.read(YtStore.HIST)
        if (hist.isNotEmpty()) { youShelves["hist"] = hist.take(20); rows.add(NpItem("act", "سجل المشاهدة", "", "", "", -1L, -1L, "", 6, "ythshelf:hist")) }
        val cont = try { YtProg.continueItems(recs()) } catch (_: Throwable) { emptyList<NpItem>() }
        if (cont.isNotEmpty()) { youShelves["cont"] = cont.take(20); rows.add(NpItem("act", "أكمل المشاهدة", "", "", "", -1L, -1L, "", 6, "ythshelf:cont")) }
        val saved = YtStore.read(YtStore.SAVED)
        if (saved.isNotEmpty()) { youShelves["saved"] = saved.take(20); rows.add(NpItem("act", "المحفوظات", "", "", "", -1L, -1L, "", 6, "ythshelf:saved")) }
        if (logged) {
            rows.addAll(YtAccount.menuItems().dropLast(2))   // المزامنة والخروج بقوا زراير في كارت الحساب فوق
            if (YtStore.read(YtStore.SUBS).isEmpty()) rows.add(yrow("🔄 زامن اشتراكاتك دلوقتي", "لسه مفيش قنوات متزامنة من حسابك", "!sync"))
        }
        rows.add(yrow("📥 التحميلات", "الفيديوهات والصوتيات اللي نزّلتها من يوتيوب", "!dl"))
        rows.add(yrow("🕘 السجل العام", "فيديوهات وصوتيات من كل المصادر — بالمسح", "!pub"))
        rows.add(yrow("⚙ إعدادات يوتيوب", "الجودة · حفظ السجل · المسح", "!set"))
        if (lite) rows.add(yrow("⚙ إعدادات المشغّل والتطبيق", "الترجمة · شكل الترجمة · المظهر · الخلفية · الأمان", "!setall"))   // (v475) اللايت: «أنا» و«الإعدادات» مدموجين
        bind(St("👤 أنت", 4, rows, null, null, null, null, null, ""))
    }
    /** السجل المحلي (2) أو المحفوظات (3): push=true بيحط الصفحة الحالية في الـstack عشان الرجوع يرجّعك لـ«أنت» */
    private fun showLocal(tab: Int, push: Boolean) {
        val prev = cur; val prevPos = lv.firstVisiblePosition
        if (push && prev != null) { prev.pos = prevPos; stack.add(prev) }
        gen++
        val l = ArrayList(YtStore.read(if (tab == 2) YtStore.HIST else YtStore.SAVED))
        val st = St(if (tab == 2) "🕘 السجل" else "🔖 المحفوظات", tab, l, null, null, null, null, null, "")
        if (!push && prev != null && prev.tab == tab) st.pos = prevPos
        bind(st)
        if (l.isEmpty()) status(if (tab == 2) "السجل فاضي" else "مفيش محفوظات — ضغطة طويلة على أي فيديو ← 🔖")
    }

    /** (v1300) إعدادات البحث الكاملة زي يوتيوب الرسمي: النوع (الكل/فيديو/قناة/قايمة) + الترتيب (الأكثر مطابقة/الأحدث/الأقدم/الأطول/الأقصر) */
    private fun searchSettings() {
        val st = cur ?: return; val q = st.q ?: return
        val sortNames = listOf("الأكثر مطابقة", "الأحدث", "الأقدم", "الأطول", "الأقصر")
        val sortModes = intArrayOf(0, 1, 5, 3, 4)   // أرقام sortMode المقابلة
        var selType = FILTERS.indexOfFirst { it.first == st.filter }.coerceAtLeast(0)
        var selSort = sortModes.indexOf(sortMode).coerceAtLeast(0)
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val d = android.app.AlertDialog.Builder(act).setView(android.widget.ScrollView(act).apply { addView(box) }).create()
        fun refill() {
            box.removeAllViews()
            fun optRow(label: String, on: Boolean, click: () -> Unit) = ui.text((if (on) "● " else "○ ") + label, 14f, if (on) th.text else th.muted, on).apply {
                setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(10)); setOnClickListener { click() }
            }
            box.addView(ui.text("النوع", 15f, th.text, true).apply { setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(4)) })
            FILTERS.forEachIndexed { i, (_, n) -> box.addView(optRow(n, i == selType) { selType = i; refill() }) }
            box.addView(ui.text("الترتيب", 15f, th.text, true).apply { setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(4)) })
            sortNames.forEachIndexed { i, n -> box.addView(optRow(n, i == selSort) { selSort = i; refill() }) }
            val apply = ui.text("تطبيق", 15f, YtSkin.accent, true).apply { setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(14)); foreground = YtSkin.ripple() }
            apply.setOnClickListener {
                d.dismiss()
                val nf = FILTERS[selType].first
                sortMode = sortModes[selSort]
                if (nf != st.filter) doSearch(q, nf)   // النوع الجديد = بحث جديد (والترتيب بيتطبق على النتايج في bind)
                else cur?.let { s -> applyListPrefs(s); adapter.set(s.list()); paintCtl(s) }   // نفس النوع: رتّب المعروض بس
            }
            box.addView(apply)
        }
        refill()
        d.show()
    }

    private fun doSearch(q0: String, filter: String = "") {   // (v1288) الافتراضي «الكل» (فيديوهات + قنوات + قوايم) زي يوتيوب الرسمي
        val q = q0.trim(); if (q.isEmpty()) return
        shAdd(q)
        hideKb(); sugBox.visibility = View.GONE; search.setText(q); search.setSelection(q.length); sugGen++
        enterSearch(false); chipsScroll.visibility = View.GONE   // (v397)
        paintTabs(-1)
        val df = pendDurF; val tf = pendDateF; val lf = pendLiveF   // (v469) C5 · (v1303) مباشر
        load("🔍 $q", -1, null, null, q, filter, true, false, df, tf, lf) { val r = YtNp.searchFiltered(q, filter, df, tf, lf); Pair(r, { p: Page -> val m = YtNp.searchMore(q, filter, p); YtRes(YtNp.applyF(m.items, df, tf, lf), m.next) }) }
    }

    /** (v402) فيديو: صفحة المشاهدة (بأنيميشن من مكان الكارت) أو المشغّل مباشرة حسب إعداد «لما تدوس على فيديو» */
    /** (v406) علامة «مدبلج»: من الكاش، وإلا نفحص لغات الصوت في الخلفية بعد ما الكارت يفضل ظاهر ~0.8 ثانية */
    private fun bindDub(c: Card, vi: NpItem) {
        c.dub.tag = vi.id; c.dub.visibility = View.GONE; c.newB.translationY = 0f
        if (vi.kind != 0 || vi.id.length != 11 || !YtDub.enabled()) return
        val cached = YtDub.get(vi.id)
        if (cached != null) { paintDub(c, vi, cached); return }
        c.root.postDelayed({
            if (c.dub.tag == vi.id) YtDub.request(vi.id) { l -> act.runOnUiThread { if (c.dub.tag == vi.id) paintDub(c, vi, l) } }
        }, 800L)
    }
    private fun paintDub(c: Card, vi: NpItem, langs: List<String>) {
        if (!YtDub.isDubbed(langs)) { c.dub.visibility = View.GONE; c.newB.translationY = 0f; return }
        c.dub.visibility = View.VISIBLE; c.newB.translationY = ui.dp(26).toFloat()   // (v1149) «جديد» على اليمين تحت «مدبلج» لو الاتنين ظاهرين
        c.dub.setOnClickListener { x ->
            val m = android.widget.PopupMenu(act, x)
            val pref = YtLang.pref()
            langs.forEachIndexed { i, l -> m.menu.add(0, i, i, (if (l == pref) "✓ " else "") + "🌐 " + YtLang.name(l, false)) }
            m.setOnMenuItemClickListener { mi -> YtLang.setOverride(vi.id, langs[mi.itemId]); open(vi, c.root); true }
            m.show()
        }
    }

    private fun setNavHidden(h: Boolean) { navBar?.visibility = if (h) View.GONE else View.VISIBLE; navLine?.visibility = if (h) View.GONE else View.VISIBLE; ytRail?.visibility = if (h) View.GONE else View.VISIBLE; try { railInset() } catch (_: Throwable) {} }   // (v1323) الريل الجانبي بيختفي مع صفحة المشاهدة/القناة

    private fun watchVideo(v: NpItem, view: View?) {
        hideKb(); sugBox.visibility = View.GONE
        markCtx()
        val it = asWatch(v)
        if (YtStore.histOn()) YtStore.addFront(YtStore.HIST, it, 200)
        logWatch(it, false)
        YtStore.markApp(it.id)
        watch.seekOnOpenMs = try { YtProg.resumeMs(it.id, recs()["yt:" + it.id] as? Recent) } catch (_: Throwable) { 0L }   // (v469) C6
        if (YtPlayerPage.on(act)) {
            val fp = onOpenPage
            if (fp != null) {
                fp(it, watch.seekOnOpenMs)
                return
            }
        }
        var r: android.graphics.Rect? = null
        if (view != null) {
            val loc = IntArray(2); view.getLocationOnScreen(loc)
            val w = view.width; val x = loc[0]
            if (w > 0) r = android.graphics.Rect(x, loc[1], x + w, loc[1] + w * 9 / 16)
        }
        watch.open(it, r)
    }

    private fun open(it: NpItem, srcView: View? = null) {
        if (it.kind == 2 && it.url.startsWith("yta:")) { openAcc(it); return }
        if (it.url == "ytpl:all") { cur?.let { st -> playAll(st) }; return }   // (v469) C7
        if (it.url.startsWith("ytdm:")) { Notice.show(act, "ده تنزيل شغّال في مدير تنزيلات النظام — لما يخلص هيظهر تحت في القايمة والملف في التنزيلات/Subtitler", 3000L); return }   // (v469) C3
        if (it.url.startsWith("ytdlp:")) {   // (v1295) مهمة yt-dlp: الخلصانة بتتفتح، الشغّالة رسالة
            val t = TaskCenter.items.firstOrNull { x -> "ytdlp:" + x.id == it.url }
            val u = t?.outUri
            if (t != null && t.state == 2 && u != null) {
                try { act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, t.mime.ifBlank { "video/mp4" }).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                catch (_: Throwable) { Notice.show(act, "الملف في التنزيلات/Subtitler", 2200L) }
            } else Notice.show(act, "التحميل لسه شغّال — تابعه من مركز المهام", 2200L)
            return
        }
        when (it.kind) {
            0 -> if (YtOpen.mode() == YtOpen.PAGE && it.id.length == 11 && !DeviceUi.isTv(act) && !PlayTarget.enabled()) watchVideo(it, srcView) else play(it, false)   // (v560) وضع التلفزيون = play() ← PlayTarget يبعت للتلفزيون   // (v494) وضع التلفزيون: دايمًا المشغّل على طول   // (v337) دوسة على الفيديو = يتشغّل على طول (التفاصيل من الضغطة الطويلة ← ℹ)
            1 -> openChannel(it.channelUrl, it.title, it.thumb)
            2 -> load("📃 " + it.title, -1, null, null, null, "", true, false) { YtNp.playlist(it.url) }
            4 -> try { act.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(it.url))) } catch (e: Throwable) { LogStore.err("Yt:post", e) }   // (v864) بوست ← يتفتح في المتصفح
        }
    }

    /** (v403) صفحة القناة الجديدة (بانر + أفاتار + مشتركين + اشترك + جرس + تابات). لو اللينك ناقص بندوّر على القناة بالاسم */
    private fun openChannel(url: String, name: String, avatar: String = "") {
        if (url.isBlank() && name.isBlank()) { Notice.show(act, ("القناة دي مالهاش لينك").toString(), 2500L); return }
        hideKb(); sugBox.visibility = View.GONE
        chan.open(url, name, avatar)
    }

    // ───────── (v346) حساب جوجل ─────────
    private fun startLogin() {
        val from = navSel
        val after: (Boolean) -> Unit = { ok ->
            act.runOnUiThread {
                if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                if (ok) { Notice.show(act, "✅ اتسجّل الدخول", 2200L); syncNow(); openTab(if (from == 2) 4 else from) }
                else Notice.show(act, "اتقفلت صفحة الدخول من غير ما يتم", 2200L)
            }
        }
        // (v1104 Y4) الدخول بكود التفعيل على الموبايل والتلفزيون (مفيش QR ولا كوكيز ولا WebView جوجل)
        YtAccount.login(act, ui, th, after)
    }
    private fun syncNow() {
        Notice.show(act, "🔄 بجيب اشتراكاتك من يوتيوب…", 2000L)
        Thread {
            try {
                val n = YtAccount.syncSubs()
                act.runOnUiThread {
                    if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                    Notice.show(act, "✅ اتضاف $n قناة جديدة (الإجمالي " + YtStore.read(YtStore.SUBS).size + ")", 3500L)
                    when (cur?.tab) { 0 -> openTab(0); 1 -> openSubs(false); 4 -> openTab(4) }
                }
            } catch (e: Throwable) {
                act.runOnUiThread { Notice.show(act, "⚠ " + (e.message ?: "فشلت المزامنة").take(140), 4800L) }
            }
        }.start()
    }
    private fun openAcc(it: NpItem) {
        val key = it.url.removePrefix("yta:")
        when (key) {
            "!sync" -> syncNow()
            "!hist" -> showLocal(2, true)
            "!cont" -> showContinue()
            "!pub" -> onPubHistory()
            "!saved" -> showLocal(3, true)
            "!dl" -> openDownloads()
            "!login" -> startLogin()
            "!set" -> settings()
            "!setall" -> (act as? MainActivity)?.openSettingsRoot()
            "!out" -> GAlert(act).setTitle("🚪 تسجيل الخروج").setMessage("هتتشال بيانات الدخول من التطبيق. الاشتراكات اللي اتحفظت هتفضل زي ما هي.")
                .setPositiveButton("خروج") { _, _ -> YtAccount.logout(); Notice.show(act, "اتسجّل الخروج", 2000L); openTab(4) }
                .setNegativeButton("إلغاء", null).show()
            else -> {
                val t = if (key.startsWith("VLPL")) "📃 " + it.title else it.title
                load(t, -1, null, null, null, "", true, false) { Pair(YtAccount.listFirst(key), { p: Page -> YtAccount.listMore(p) }) }
            }
        }
    }

    private fun toggleSub() {
        val st = cur ?: return; val url = st.chUrl ?: return
        val now = YtStore.toggle(YtStore.SUBS, NpItem("", st.chName ?: url, "", url, "", -1L, 0L, "", 1, url))
        paintSub(now); try { YtNotify.schedule(act) } catch (_: Throwable) {}
        Notice.show(act, (if (now) "✅ اشتركت في " + (st.chName ?: "") else "اتشال الاشتراك").toString(), 2200L)
    }

    // ───────── (v327) فيد الاشتراكات RSS + إشعارات ─────────
    private fun openSubs(force: Boolean) {
        hidePill()
        val subs = YtStore.read(YtStore.SUBS)
        if (subs.isEmpty() && !YtAccount.loggedIn() && !YtMtFeed.usableCached()) { openTab(1); return }
        hideKb(); sugBox.visibility = View.GONE; stack.clear(); paintTabs(1)
        load("📺 اشتراكاتي", 1, null, null, null, "", false, false) {
            // (v1104 Y3) الاشتراكات من محرك MeeTube (حساب الكود): الأحدث أولًا + تحميل مفتوح. فاضية/فشلت ← المسار القديم (الكوكيز/RSS) تحت زي ما هو
            if (YtMtFeed.usable()) {
                val m = try { YtMtFeed.subs() } catch (e: Throwable) { LogStore.err("YtProUi:mtSubs", e); null }
                if (m != null) {
                    val shown = HashSet<String>(); m.items.forEach { shown.add(it.id) }
                    try { YtNotify.noteNewMt(m.items.map { it.id }); YtNotify.markSeen(m.items); YtNotify.mtMarkSubs(m.items.map { it.id }); YtNotify.markOpened(act) } catch (_: Throwable) {}   // (v1107) اللي ظهر في القايمة = اتشاف ← العدّاد يتصفّر
                    return@load Pair(m, { p: Page -> val x = YtMtFeed.more(p); YtRes(x.items.filter { shown.add(it.id) }, x.next) })
                }
                LogStore.add("⚠ اشتراكات المحرك رجعت فاضية — بجرّب المسار القديم")
            }
            // (v346) لو مسجّل بجوجل: بنزامن قنوات الحساب الأول (كل 6 ساعات أو لما تدوس تحديث) وبعدين نقرأ الاشتراكات من جديد
            // (v350) لو القنوات فاضية أو المزامنة فشلت: نحاول تاني ونظهر السبب بدل «مفيش نتايج» الصامتة
            var syncErr: String? = null
            if (YtAccount.loggedIn() && (force || YtStore.read(YtStore.SUBS).isEmpty())) {
                try { YtAccount.syncSubs() } catch (e: Throwable) { syncErr = e.message ?: e.javaClass.simpleName }
            } else if (YtAccount.loggedIn()) {   // (v390) مزامنة تلقائية في الخلفية في كل دخول؛ لو جابت قنوات جديدة والصفحة لسه مفتوحة بتتحدّث
                YtAccount.syncAsync { n -> if (n > 0) act.runOnUiThread { if (!act.isFinishing && !act.isDestroyed && cur?.tab == 1) openSubs(false) } }
            }
            val subsNow = YtStore.read(YtStore.SUBS)
            var r = YtRes(emptyList(), null)
            var more: ((Page) -> YtRes)? = null
            // (v471) مسجّل بحسابك: فيد الاشتراكات الرسمي الأول — طلب واحد بدل طلب لكل قناة، العناوين بلغة حسابك، والمدد والتصفّح للصفحات اللي بعدها، وأقل فشلًا من RSS.
            // RSS (بإعادة المحاولة ورابط قايمة الرفع) بقى الاحتياطي. الإعداد yt_subs_official
            val official = YtAccount.loggedIn() && Cfg.bool("yt_subs_official", true)
            if (official) {
                try {
                    val a = YtAccount.listFirst("FEsubscriptions")
                    val vids = a.items.filter { (it.kind == 0 || it.kind == 4) }
                    if (vids.isNotEmpty()) {
                        // (v754) نجيب أول 3 صفحات من الفيد الرسمي (كان صفحة واحدة بس) عشان الفيديوهات الجديدة كلها تيجي قبل القديمة
                        val acc = ArrayList<NpItem>(vids); val seen0 = HashSet<String>(); acc.removeAll { !seen0.add(it.id) }
                        var nx = a.next; var pg = 0
                        while (nx != null && pg < 5) { pg++; try { val x = YtAccount.listMore(nx); for (v in x.items) if ((v.kind == 0 || v.kind == 4) && seen0.add(v.id)) acc.add(v); nx = x.next } catch (_: Throwable) { break } }
                        r = YtRes(acc, nx); more = { p -> val x = YtAccount.listMore(p); YtRes(x.items.filter { (it.kind == 0 || it.kind == 4) }, x.next) }
                    }
                } catch (e: Throwable) {
                    if (syncErr == null) syncErr = e.message ?: e.javaClass.simpleName
                    LogStore.add("⚠ فيد الاشتراكات الرسمي فشل — بجرّب RSS: " + (e.message ?: e.javaClass.simpleName).take(80))
                }
            }
            if (official && r.items.isNotEmpty()) {   // (v751) ترتيب بالأحدث بوقت رفع دقيق من RSS + فيديوهات جديدة فاتت الصفحة الرسمية
                try {
                    val ex = java.util.concurrent.Executors.newSingleThreadExecutor()
                    val fut = ex.submit(java.util.concurrent.Callable<List<NpItem>> { YtRss.feed(subsNow, force, false).items })
                    val live: List<NpItem> = try { fut.get(if (force) 40L else 7L, java.util.concurrent.TimeUnit.SECONDS) } catch (_: Throwable) {
                        // (v757) الفحص الحي أبطأ من 7 ثواني: نعرض اللي جاهز دلوقتي والباقي يكمّل في الخلفية وتطلع كبسولة «⬆ فيديوهات جديدة»
                        YtRss.refreshAsync(subsNow); YtRss.cachedFeed(subsNow)?.items.orEmpty()
                    } finally { ex.shutdown() }
                    val rssItems = live.filter { it.kind == 0 }   // (v754) فحص حي بدل كاش قديم
                    r = YtRes(YtRss.mergeLatest(r.items, rssItems), r.next)
                    val m0 = more
                    if (m0 != null) { val shown = HashSet<String>(); r.items.forEach { shown.add(it.id) }; more = { p -> val x = m0(p); YtRes(x.items.filter { shown.add(it.id) }, x.next) } }
                } catch (_: Throwable) {}
            }
            if (r.items.isEmpty()) {
                r = YtRss.feed(subsNow, force, !force)   // (v354) أول عرض فوري من الكاش لو موجود
                if (!force && r.items.isNotEmpty()) { act.runOnUiThread { bgLine(true) }; YtRss.refreshAsync(subsNow) }   // وبنحدّث في الخلفية للزيارة الجاية (والكبسولة لو فيه جديد)
            }
            if (more == null && r.items.size > 45 && r.next == null) {   // (v863) كان للتلفزيون بس — دلوقتي «تحميل المزيد» على الموبايل كمان   // (v674) تلفزيون: احتياطي RSS على صفحات 45 فيديو عشان التحميل يكمّل مع النزول
                val all = r.items
                r = YtRes(all.take(45), Page("ytp:rss:45"))
                more = { p -> val o = (p.url ?: "").substringAfterLast(':').toIntOrNull() ?: all.size; val e = minOf(all.size, o + 45); YtRes(if (o < e) all.subList(o, e).toList() else emptyList(), if (e < all.size) Page("ytp:rss:" + e) else null) }
            }
            if (r.items.isEmpty() && YtAccount.loggedIn() && !official) {
                // (v350) بديل: فيد الاشتراكات الرسمي من حسابك مباشرة (من غير RSS)
                try {
                    val a = YtAccount.listFirst("FEsubscriptions")
                    val vids = a.items.filter { it.kind == 0 }
                    if (vids.isNotEmpty()) { r = YtRes(vids, a.next); more = { p -> val x = YtAccount.listMore(p); YtRes(x.items.filter { it.kind == 0 }, x.next) } }
                } catch (e: Throwable) { if (syncErr == null) syncErr = e.message ?: e.javaClass.simpleName }
            }
            if (r.items.isEmpty() && syncErr != null) throw RuntimeException(syncErr)
            if (r.items.isNotEmpty()) { YtNotify.noteNewTs(r.items); YtNotify.markSeen(r.items); YtNotify.markOpened(act) }   // اللي اتعرض ما يجيش عليه إشعار ولا عدّاد
            Pair(r, more)
        }
    }
    private fun paintNotif() {
        if (!::notifBtn.isInitialized) return
        notifBtn.text = if (YtNotify.enabled()) "🔔 إشعارات الفيديوهات الجديدة: شغّالة" else "🔕 إشعارات الفيديوهات الجديدة: مقفولة"
        notifBtn.alpha = if (YtNotify.enabled()) 1f else 0.6f
    }
    private fun toggleNotif() {
        val on = !YtNotify.enabled(); YtNotify.setEnabled(act, on); paintNotif()
        Notice.show(act, (if (on) "🔔 هتجيلك إشعارات بالفيديوهات الجديدة (فحص كل ساعة تقريبًا)" else "🔕 الإشعارات اتقفلت").toString(), 2600L)
    }
    /** (v532) لينك يوتيوب مش فيديو (من الريموت/مشاركة): قناة ← صفحة القناة · قايمة تشغيل ← القايمة · غير كده بيفضل في يوتيوب نفسه */
    fun openUrl(u: String): Boolean {
        return try {
            val low = u.lowercase()
            when {
                Regex("youtube\\.com/(@|channel/|c/|user/)").containsMatchIn(low) -> { openChannel(u, "", ""); true }
                low.contains("list=") -> { load("📃 قايمة تشغيل", -1, null, null, null, "", true, false) { YtNp.playlist(u) }; true }
                else -> false
            }
        } catch (e: Throwable) { LogStore.err("YtProUi:openUrl", e); false }
    }

    /** فتح تفاصيل فيديو من معرّفه (من إشعار مثلًا) */
    fun openVideo(id: String) {
        onPlay(id, "", false)   // (v337) من الإشعار: تشغيل مباشر من غير صفحة التفاصيل
    }

    // ───────── تحميل وعرض ─────────
    private fun load(title: String, tab: Int, chUrl: String?, chName: String?, q: String?, filter: String, push: Boolean, showChan: Boolean,
                     durF: Int = 0, dateF: Int = 0, liveF: Boolean = false,
                     job: () -> Pair<YtRes, ((Page) -> YtRes)?>) {
        val my = ++gen
        val prev = cur; val prevPos = lv.firstVisiblePosition
        retry = { load(title, tab, chUrl, chName, q, filter, push, showChan, durF, dateF, liveF, job) }   // (v1303) إعادة المحاولة بقت بتحافظ على الفلاتر
        // (v472) الرئيسية والاشتراكات بتفتح فورًا من آخر نسخة سليمة (قرص) من غير شاشة فاضية؛ التحديث في الخلفية، ولو فشل/رجع فاضي النسخة القديمة بتفضل
        val snap: List<NpItem>? = if (!push && chUrl == null && q == null && (tab == 0 || tab == 1)) {
            try {
                if (tab == 1) YtSnap.load(act, 1)
                else { val seen = YtStore.read(YtStore.HIST).map { it.id }.toHashSet(); (if (YtMtFeed.usableCached()) YtMtFeed.homeStale() else YtNp.homeStale()?.items)?.filter { it.id !in seen }?.takeIf { it.size >= 6 } }
            } catch (_: Throwable) { null }
        } else null
        val snapL: List<NpItem> = snap ?: emptyList()
        val onSnap = snapL.isNotEmpty()
        if (onSnap) {
            val s0 = St(title, tab, ArrayList(snapL), null, null, chUrl, chName, q, filter)
            bind(s0); bgLine(true)
        } else {
            status("⏳ …", null); adapter.clear(); chanRow.visibility = View.GONE; filterRow.visibility = View.GONE; detailBox.visibility = View.GONE; subsRow.visibility = View.GONE
        }
        Thread {
            try {
                if (tab != 1 && !(tab == 0 && YtMtFeed.usable())) YtNp.init()   // (v1104 Y3) رئيسية المحرك مش محتاجة NewPipe  // (v472) الاشتراكات مش محتاجة NewPipe (الفيد الرسمي/RSS) — NewPipe بيتهيّأ لوحده لو احتاجه كاحتياطي
                val (r, more) = job()
                if (tab == 1 && r.items.isNotEmpty()) YtSnap.save(act, 1, r.items)
                act.runOnUiThread {
                    try {   // (v1300) أي خطأ في bind كان بيسيب اللودر شغّال للأبد (الاستثناء بيطلع على خيط الواجهة برّه catch بتاع الخيط)
                    if (my != gen || act.isFinishing || act.isDestroyed) return@runOnUiThread
                    if (onSnap) {
                        bgLine(false)
                        val c = cur
                        if (r.items.isEmpty() || c == null || c.tab != tab || c.vid != null || c.q != null || c.chUrl != null) return@runOnUiThread   // رجع فاضي أو إنت مشيت لصفحة تانية: نسيب كل حاجة زي ما هي
                        val nst0 = St(title, tab, ArrayList(r.items), r.next, more, chUrl, chName, q, filter)
                        nst0.durF = durF; nst0.dateF = dateF; nst0.liveF = liveF
                        val same = r.items.take(8).map { it.id } == snapL.take(8).map { it.id }
                        val keep = lv.firstVisiblePosition
                        if (same) { nst0.pos = keep; cur = nst0; adapter.set(nst0.list()); lv.setSelection(keep) }   // نفس القايمة: تتحدّث في مكانها (وتركّب التصفّح للصفحات اللي بعدها)
                        else if (keep > 1) { pendingItems = r.items; pendingTab = tab; showPill(r.items.count { x -> snapL.none { it.id == x.id } }.coerceAtLeast(1)) }   // إنت نازل في القايمة: كبسولة «فيديوهات جديدة»
                        else { animRows = true; h.postDelayed({ animRows = false }, 700L); bind(nst0) }
                        return@runOnUiThread
                    }
                    if (push && prev != null) { prev.pos = prevPos; stack.add(prev) }
                    val nst = St(title, tab, ArrayList(r.items), r.next, more, chUrl, chName, q, filter)
                    nst.durF = durF; nst.dateF = dateF; nst.liveF = liveF
                    bind(nst)
                    if (r.items.isEmpty()) { if (tab == 0 || tab == 1) emptyPrompt(tab, null) else status("مفيش نتايج\n\n(دوس هنا لإعادة المحاولة)", retry) }   // (v475)
                    } catch (e: Throwable) {   // (v1300)
                        LogStore.err("YtProUi:bind", e)
                        if (my == gen && !act.isFinishing && !act.isDestroyed) status("⚠ حصل خطأ في العرض: " + (e.message ?: e.javaClass.simpleName).take(120) + "\n\n(دوس هنا لإعادة المحاولة)", retry)
                    }
                }
            } catch (e: Throwable) {
                act.runOnUiThread {
                    if (my != gen || act.isFinishing || act.isDestroyed) return@runOnUiThread
                    if (onSnap) { bgLine(false); Notice.show(act, "⚠ تعذّر التحديث — عرضت آخر نسخة محفوظة", 2400L); return@runOnUiThread }
                    if (prev != null) cur = prev
                    if ((tab == 0 || tab == 1) && chUrl == null && q == null) emptyPrompt(tab, e.message ?: e.javaClass.simpleName)   // (v475) بدل رسالة خطأ لوحدها: زرار دخول/مزامنة/إعادة محاولة
                    else status("⚠ " + (e.message ?: e.javaClass.simpleName).take(160) + "\n\n(دوس هنا لإعادة المحاولة)", retry)
                }
            }
        }.start()
        // (v1300) كلب حراسة ضد «اللودر بيهنج»: لو التحميل عدّى 60 ثانية من غير نتيجة (شبكة معلّقة/خطأ مكتوم) نعرض إعادة المحاولة بدل ما يفضل يلف
        h.postDelayed({ if (my == gen && loadBusy && !act.isFinishing && !act.isDestroyed) status("⚠ التحميل أخد وقت أطول من المعتاد\n\n(دوس هنا لإعادة المحاولة)", retry) }, 60_000L)
    }

    /** (v472) تسخين استباقي: لما القايمة تقف نجيب روابط أول فيديوهين ظاهرين (خفيف) ونحمّل صور اللي جاي — الفتح بعدها شبه فوري */
    private fun prewarmVisible() {
        try {
            if (!Cfg.bool("yt_prewarm", true)) return
            val st = cur ?: return
            if (watch.isOpen || chan.isOpen || st.vid != null) return
            val l = st.list(); if (l.isEmpty()) return
            val f = lv.firstVisiblePosition.coerceAtLeast(0)
            var n = 0
            for (i in f until minOf(l.size, f + 4)) { val x = l[i]; if (x.kind == 0 && x.id.length == 11) { YtFast.warm(x.id); if (++n >= 2) break } }
            val sw = act.resources.displayMetrics.widthPixels
            for (i in (f + 3) until minOf(l.size, f + 9)) { val t = l[i].thumb; if (t.isNotBlank()) Glide.with(act).load(t).centerCrop().override(sw, sw * 9 / 16).preload() }
        } catch (_: Throwable) {}
    }

    private fun bind(st: St) {
        cur = st; statusTv.visibility = View.GONE; spin(false); hidePrompt()
        st.typeF = if (st.tab == 1 && st.chUrl == null && st.q == null && st.vid == null) typeMode else 0   // (v864)
        st.shelfOn = st.tab == 1 && st.chUrl == null && st.q == null && st.vid == null && !DeviceUi.isTv(act)   // (v865)
        // (v469) C7: صف «شغّل الكل» على رأس أي قايمة تشغيل
        if (st.vid == null && st.title.startsWith("📃") && st.items.any { it.kind == 0 } && st.items.none { it.url == "ytpl:all" })
            st.items.add(0, NpItem("act", "▶ شغّل الكل", st.title.removePrefix("📃").trim(), "", "", -1L, st.items.count { it.kind == 0 }.toLong(), "", 2, "ytpl:all"))
        if (pendingPlayAll && st.vid == null && st.title.startsWith("📃")) { pendingPlayAll = false; h.postDelayed({ playAll(st) }, 350L) }
        applyListPrefs(st)   // (v469) C10
        paintCtl(st)
        val det = st.vid != null
        detailBox.visibility = if (det) View.VISIBLE else View.GONE
        chanRow.visibility = if (st.chUrl != null && !det) View.VISIBLE else View.GONE
        subsRow.visibility = View.GONE   // (v1107) صف «إشعارات الفيديوهات الجديدة + تحديث» اتشال
        // (v1291) شريط أفاتار القنوات فوق الاشتراكات (زي يوتيوب الرسمي)
        if (st.tab == 1 && st.chUrl == null && st.q == null && st.vid == null && !DeviceUi.isTv(act) && st.items.none { it.kind == 6 }) {
            val subs0 = YtStore.read(YtStore.SUBS)
            if (subs0.isNotEmpty()) { youShelves["subs"] = subs0.take(40); st.items.add(0, NpItem("act", "الاشتراكات", "", "", "", -1L, -1L, "", 6, "ythshelf:subs")) }
        }
        if (st.chUrl != null) { chanName.text = st.chName ?: ""; paintSub(YtStore.contains(YtStore.SUBS, NpItem("", "", "", st.chUrl, "", -1L, 0L, "", 1, st.chUrl))) }
        filterRow.visibility = if (st.q != null && !det) View.VISIBLE else View.GONE
        filterViews.forEach { tv -> paintChip(tv, tv.tag == st.filter) }
        if (det) paintDetail(st)
        animRows = true; h.postDelayed({ animRows = false }, 700L)   // (v354) ظهور ناعم: الصفوف الأولى بتطلع بالتتابع
        adapter.grid = false   // (v397) كروت يوتيوب بدل الشبكة
        adapter.cards = st.tab == 0 || st.tab == 1 || st.q != null || st.chUrl != null || det
        chipsScroll.visibility = if (st.tab == 0 && !det && st.chUrl == null && !DeviceUi.isTv(act)) View.VISIBLE else View.GONE   // (v575) تلفزيون: من غير شرائح (موسيقى/ألعاب/…)
        if (st.q != null) enterSearch(false) else if (!searchTyping) { searchBar.visibility = View.GONE; appBar.visibility = View.VISIBLE }
        adapter.set(st.list()); lv.setSelection(st.pos)
        if (DeviceUi.isRemote(act) && (act.currentFocus == null || (act.currentFocus === search && !searchTyping))) tvFocusList()   // (v477) (v479 م5) بعد البحث التركيز ينتقل لنتايج البحث
        h.postDelayed({ prewarmVisible() }, 450L)   // (v472)
        if (st.tab >= 0) paintTabs(st.tab) else if (det) paintTabs(-1)
        if (DeviceUi.isTv(act)) tvCrumb(st, det)   // (v527)
    }

    /** (v527) تلفزيون: «إنت فين» — مسار ثابت فوق: يوتيوب › الاشتراكات › قناة X (أو بحث: كذا / اسم القسم) */
    private fun tvCrumb(st: St, det: Boolean) {
        if (!::topTitle.isInitialized) return
        val sb = StringBuilder("يوتيوب › ").append(when (navSel) { 0 -> "الرئيسية"; 1 -> "الاشتراكات"; else -> "أنا" })
        if (st.chUrl != null) sb.append(" › قناة ").append(st.chName ?: "")
        else if (st.q != null) sb.append(" › بحث: ").append(st.q)
        else if (st.tab >= 2 && st.title.isNotBlank()) sb.append(" › ").append(st.title)
        else if (det) sb.append(" › تفاصيل")
        topTitle.text = sb.toString(); topTitle.textSize = 17f
    }

    // ───────── (v326) تفاصيل الفيديو ─────────
    private fun openDetail(v: NpItem) {
        hideKb(); sugBox.visibility = View.GONE
        val my = ++gen
        val prev = cur; val prevPos = lv.firstVisiblePosition
        status("⏳ …", null); adapter.clear(); chanRow.visibility = View.GONE; filterRow.visibility = View.GONE; detailBox.visibility = View.GONE; subsRow.visibility = View.GONE
        retry = { openDetail(v) }
        Thread {
            try {
                val d = YtNp.details(v.id)
                act.runOnUiThread {
                    if (my != gen || act.isFinishing || act.isDestroyed) return@runOnUiThread
                    if (prev != null) { prev.pos = prevPos; stack.add(prev) }
                    bind(St(v.title, -1, ArrayList(d.related), null, null, null, null, null, "", v, d))
                    if (d.related.isEmpty()) status("مفيش مقترحات")
                }
            } catch (e: Throwable) {
                act.runOnUiThread {
                    if (my != gen || act.isFinishing || act.isDestroyed) return@runOnUiThread
                    if (prev != null) cur = prev
                    status("⚠ " + (e.message ?: e.javaClass.simpleName).take(160) + "\n\n(دوس هنا لإعادة المحاولة)", retry)
                }
            }
        }.start()
    }

    private fun detItem(st: St): NpItem {
        val v = st.vid!!; val d = st.det
        return NpItem(v.id, d?.title?.ifBlank { v.title } ?: v.title, d?.channel?.ifBlank { v.channel } ?: v.channel, d?.channelUrl?.ifBlank { v.channelUrl } ?: v.channelUrl,
            d?.thumb?.ifBlank { v.thumb } ?: v.thumb, d?.dur ?: v.dur, v.count, v.age, 0, v.url)
    }
    /** (v407) سجل يوتيوب المنفصل (yt_history.json): كل فيديو/صوت بيتفتح من يوتيوب بيتسجّل بقناته */
    private fun logWatch(it: NpItem, audio: Boolean) { try { YtHistory.add(act, it.id, it.title, it.channel, audio) } catch (_: Throwable) {} }
    private fun playCur(tr: Boolean) { val st = cur ?: return; if (st.vid == null) return; play(detItem(st), tr) }
    /** عنصر من التحميلات url بتاعه مكان الملف — بنرجّعه لرابط الفيديو قبل التشغيل/السجل */
    private fun asWatch(it: NpItem): NpItem = if (it.url.startsWith("http")) it else NpItem(it.id, it.title, it.channel, it.channelUrl, it.thumb, it.dur, it.count, it.age, 0, YtNp.watchUrl(it.id))
    /** (v340) لو الفيديو اتفتح من قايمة تشغيل (أو أي قايمة فيديوهات) نسجّلها عشان لوحة «التالي» تعرضها */
    private fun markCtx() { val st = cur; if (st != null && st.vid == null && st.title.startsWith("📃")) YtNext.setContext(st.list(), st.title.removePrefix("📃").trim()) else YtNext.clearContext() }
    private fun play(it0: NpItem, tr: Boolean) {
        markCtx(); ytDock.dismiss()   // (v417)
        val it = asWatch(it0)
        if (YtStore.histOn()) YtStore.addFront(YtStore.HIST, it, 200)
        logWatch(it, false)
        YtStore.markApp(it.id)
        // (v469) C6: استكمال تلقائي من آخر موضع (إلا في وضع الترجمة)
        if (!tr) {
            val rs = try { YtProg.resumeMs(it.id, recs()["yt:" + it.id] as? Recent) } catch (_: Throwable) { 0L }
            val f = onPlayAt
            if (rs > 0 && f != null) { f(it.id, it.title, false, rs, null); return }
        }
        onPlay(it.id, it.title, tr)
    }
    private fun playAudio(it0: NpItem) {
        markCtx(); ytDock.dismiss()   // (v417)
        val it = asWatch(it0)
        if (YtStore.histOn()) YtStore.addFront(YtStore.HIST, it, 200)
        logWatch(it, true)
        YtStore.markApp(it.id)
        onAudio(it)
    }
    /** (v472) ⬇ على أي صورة فيديو: صفحة اختيار الجودة مباشرة (من غير قايمة وسيطة) */
    private fun dlMenu(anchor: View, it: NpItem) {
        qualityDl(asWatch(it))
    }   // (v1323) yt-dlp اتشال من البرنامج: التحميل بقى كله من «المحمّل العادي» مباشرة (فيديو بكل الجودات + 🎧 صوت بس m4a زي ما هو من يوتيوب من غير تحويل)
    /** (v472) اختيار الجودة ← مهمة تحميل في «المهام» (دايرة التقدم العايمة + عدّاد الباقي). الروابط بتتجاب من نفس السباق السريع (YtFast) بدل NewPipe التقيل */
    // (v1113) حجم الملف بيتجاب بـ HEAD على نفس الرابط — لو فشل الحجم بيتساب من الصف من غير ما يظهر رقم غلط
    private fun headBytes(u: String, ua: String): Long {
        if (u.isBlank()) return -1L
        fun probe(method: String): Long = try {
            val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 4000
            c.readTimeout = 4000
            if (ua.isNotBlank()) c.setRequestProperty("User-Agent", ua)
            if (method == "GET") c.setRequestProperty("Range", "bytes=0-0")
            c.connect()
            // (v1119) HEAD أحيانًا بيرجع من غير Content-Length على روابط جوجل؛ GET بـRange بيرجع الحجم الكلي في Content-Range
            var len = c.getHeaderField("Content-Length")?.toLongOrNull() ?: -1L
            if (method == "GET") len = c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull() ?: -1L
            try { c.disconnect() } catch (_: Throwable) {}
            len
        } catch (_: Throwable) { -1L }
        val a = probe("HEAD")
        return if (a > 0) a else probe("GET")
    }
    // (v1113) تنسيق الحجم: ميجا برقم عشري واحد، أو جيجا لو 1024 ميجا أو أكتر
    private fun fmtBytes(b: Long): String {
        val mb = b / 1048576.0
        if (mb >= 1024.0) return String.format(java.util.Locale.US, "%.1f GB", mb / 1024.0)
        return String.format(java.util.Locale.US, "%.1f MB", mb)
    }
    private fun qualityDl(v: NpItem) {
        // (v1119) الشيت بيفتح فورًا (لودينج جواه) — كان مستني كل الروابط + كل الـHEAD ورا بعض (تقيل: لحد ٥ث لكل واحد) وبعدين يظهر.
        // الصفوف بتظهر أول ما الجودات توصل، والأحجام بتتكتب في كل صف لوحدها لما توصل (بالتوازي).
        val th = Glass.theme(); val u = Ui(act, th)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val loadTv = u.text("⏳ بجيب الجودات…", 15f, th.text).apply { gravity = Gravity.CENTER; setPadding(0, u.dp(22), 0, u.dp(22)) }
        col.addView(loadTv, LinearLayout.LayoutParams(-1, -2))
        val dlg = GAlert(act).setTitle("⬇ اختار جودة التحميل").setView(col).setNegativeButton("إلغاء", null).show()
        class Row(val label: String, val url: String, val aud: String, val h: Int, val audioOnly: Boolean)
        Thread {
            val rows = ArrayList<Row>()
            var uas = ""
            try {
                val g = YtFast.video(v.id, 0)
                if (g != null) {
                    uas = g.ua
                    val a = org.json.JSONArray(g.qlist)
                    var anyAud = ""
                    for (i in 0 until a.length()) {
                        val o = a.getJSONObject(i)
                        val au = o.optString("a")
                        if (au.isNotBlank() && anyAud.isEmpty()) anyAud = au
                        rows.add(Row("🎬 " + o.optString("l"), o.optString("u"), au, o.optInt("h", 0), false))
                    }
                    val audioUrl = anyAud.ifBlank { try { YtFast.audio(v.id, 0)?.url ?: "" } catch (_: Throwable) { "" } }
                    if (audioUrl.isNotBlank()) rows.add(Row("🎧 صوت بس", audioUrl, "A", 0, true))
                }
            } catch (_: Throwable) {}
            // قايمة الجودات مش جاية: على الأقل رابط واحد بالجودة الافتراضية
            if (rows.isEmpty()) {
                try {
                    val g2 = YtFast.video(v.id, 0)
                    if (g2 != null && g2.url.isNotBlank()) { uas = g2.ua; rows.add(Row("🎬 الجودة الافتراضية", g2.url, g2.audio ?: "", 0, false)) }
                } catch (_: Throwable) {}
            }
            val uaF = uas
            act.runOnUiThread {
                if (act.isFinishing || act.isDestroyed) return@runOnUiThread
                if (rows.isEmpty()) { loadTv.text = "⚠ ما قدرتش أجيب روابط التحميل"; return@runOnUiThread }
                col.removeView(loadTv)
                val tvs = ArrayList<TextView>()
                var vHead = false; var aHead = false
                for (r in rows) {
                    // (v1121) عناوين: الفيديوهات (جودة + حجم) فوق، والصوت لوحده تحت
                    if (!r.audioOnly && !vHead) { vHead = true; col.addView(u.text("🎬 الفيديو — الجودة والحجم", 12f, th.muted, true).apply { setPadding(u.dp(4), u.dp(2), u.dp(4), u.dp(2)) }) }
                    if (r.audioOnly && !aHead) { aHead = true; col.addView(u.text("🎧 الصوت", 12f, th.muted, true).apply { setPadding(u.dp(4), u.dp(8), u.dp(4), u.dp(2)) }) }
                    val tv = u.text(r.label, 15f, th.text).apply { setPadding(u.dp(14), u.dp(12), u.dp(14), u.dp(12)); background = u.box(th.surface, th.border, 12) }
                    Glass.pressable(tv)
                    tv.setOnClickListener {
                        dlg.dismiss()
                        YtDlTask.start(act.applicationContext, v, r.url, if (r.audioOnly) null else r.aud, uaF, r.audioOnly, r.h)
                        Notice.show(act, "⬇ اتضاف للمهام — الدايرة العايمة بتوريك الباقي", 2600L)
                    }
                    col.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, u.dp(3), 0, u.dp(3)) })
                    tvs.add(tv)
                }
                // الأحجام: كل رابط HEAD مرة واحدة (الصوت المشترك بين الجودات بيتجاب مرة) وبالتوازي، والصف بيتحدّث لما حجمه يوصل
                val cache = java.util.concurrent.ConcurrentHashMap<String, Long>()
                val pool = java.util.concurrent.Executors.newFixedThreadPool(4) { r -> Thread(r).apply { isDaemon = true } }
                fun sz(url: String): Long = if (url.isBlank() || url == "A") -1L else cache.getOrPut(url) { headBytes(url, uaF) }
                for ((i, r) in rows.withIndex()) pool.execute {
                    val vb = if (r.audioOnly) 0L else sz(r.url)
                    val ab = if (r.audioOnly) sz(r.url) else sz(r.aud)
                    var lab = r.label
                    if (r.audioOnly) {
                        val dur = v.dur
                        if (ab > 0 && dur > 0) { val kbps = ab * 8 / dur / 1000; if (kbps > 0) lab += " · " + kbps + " kbps" }
                        if (ab > 0) lab += " · " + fmtBytes(ab)
                    } else {
                        val tot = (if (vb > 0) vb else 0L) + (if (ab > 0) ab else 0L)
                        if (tot > 0) lab += "  ·  " + fmtBytes(tot)
                    }
                    if (lab != r.label) act.runOnUiThread { if (!act.isFinishing && !act.isDestroyed) tvs[i].text = lab }
                }
                pool.shutdown()
            }
        }.apply { isDaemon = true }.start()
    }
    // ───────── (v337) إعدادات يوتيوب ─────────
    private fun settings() {
        val m = act as? MainActivity
        if (m != null) { m.openSettingsTab("youtube"); return }   // (v355) إعدادات يوتيوب بقت قسم جوه إعدادات البرنامج
        settingsLegacy()
    }
    // (v1113) إعدادات يوتيوب جوه إعدادات البرنامج بتنادي دول
    fun openDownloadsPage() { openDownloads() }
    fun openAccountTab() { openTab(4) }
    private fun settingsLegacy() {
        val q = Cfg.int("yt_maxh", 0)
        val items = arrayOf("🎞 الجودة الافتراضية: " + (if (q <= 0) "أعلى جودة" else q.toString() + "p"),
            "🕘 حفظ سجل المشاهدة: " + (if (YtStore.histOn()) "شغّال" else "مقفول"),
            "📥 التحميلات المسجّلة", "🗑 مسح السجل", "🗑 مسح سجل التحميلات",
            "👤 حساب جوجل: " + (if (YtAccount.loggedIn()) "مسجّل الدخول" else "مش مسجّل"),
            "⏭ تخطي الرعاة (SponsorBlock): " + (if (YtSponsor.on()) "شغّال" else "مقفول"))
        GAlert(act).setTitle("⚙ إعدادات يوتيوب").setItems(items) { _, w ->
            when (w) {
                0 -> qualityDialog()
                1 -> { val on = !YtStore.histOn(); Cfg.put("ytp_hist_on", if (on) "1" else "0"); Notice.show(act, (if (on) "🕘 السجل شغّال" else "🕘 السجل اتقفل (اللي اتسجّل قبل كده لسه موجود)").toString(), 2400L) }
                2 -> openDownloads()
                3 -> { YtStore.write(YtStore.HIST, emptyList()); PlayTarget.clearTvHistory(act, "yt"); Notice.show(act, ("🗑 السجل اتمسح").toString(), 1800L); if (cur?.tab == 2) showLocal(2, false) }
                4 -> { YtStore.write(YtStore.DL, emptyList()); Notice.show(act, ("🗑 سجل التحميلات اتمسح").toString(), 1800L) }
                5 -> openTab(4)
                6 -> { val on = !YtSponsor.on(); Cfg.put("yt_sponsor", if (on) "1" else "0"); Notice.show(act, (if (on) "⏭ تخطي الرعاة شغّال" else "⏭ تخطي الرعاة اتقفل").toString(), 2200L) }
                else -> {}
            }
        }.setNegativeButton("إغلاق", null).show()
    }
    private fun qualityDialog() {
        val hs = intArrayOf(0, 1080, 720, 480, 360, 240)
        val labels = hs.map { if (it == 0) "أعلى جودة" else it.toString() + "p" }.toTypedArray()
        GAlert(act).setTitle("🎞 الجودة الافتراضية").setItems(labels) { _, w ->
            Cfg.put("yt_maxh", hs[w].toString()); Notice.show(act, ("🎞 الجودة الافتراضية: " + labels[w]).toString(), 2200L); TvQ.askPin(act, hs[w])   // (v1163)
        }.setNegativeButton("إلغاء", null).show()
    }
    private fun openDownloads() {
        hideKb(); sugBox.visibility = View.GONE
        val my = ++gen
        val prev = cur; val prevPos = lv.firstVisiblePosition
        Thread {
            val rows = ArrayList<NpItem>()
            // (v1295) تحميلات yt-dlp الشغّالة/الخلصانة من مركز المهام فوق القايمة
            try {
                for (t in TaskCenter.items) {
                    if (t.kind != "download") continue
                    if (!(t.title.startsWith("⬇ yt-dlp: ") || t.title.startsWith("🎵 yt-dlp: "))) continue
                    val st = when (t.state) { 0 -> "مستني"; 1 -> t.pct.toString() + "% · " + t.msg; 2 -> "✅ خلص · " + t.msg; 3 -> "⚠ فشل: " + t.msg; 4 -> "اتلغى"; 5 -> "اتوقف"; 6 -> "متوقف مؤقتًا"; else -> "" }
                    rows.add(NpItem("act", t.title, st.take(90), "", "", -1L, -1L, "", 2, "ytdlp:" + t.id))
                }
            } catch (_: Throwable) {}
            try { for (r in YtDl.recs()) { val st = YtDl.status(act, r); rows.add(NpItem("act", (if (r.audio) "🎧 " else "🎬 ") + r.title, st.first + " · " + r.q, "", "", -1L, -1L, "", 2, "ytdm:" + r.dmId)) } } catch (_: Throwable) {}
            rows.addAll(YtStore.read(YtStore.DL))
            act.runOnUiThread {
                if (my != gen || act.isFinishing || act.isDestroyed) return@runOnUiThread
                if (prev != null && prev.title != "📥 التحميلات") { prev.pos = prevPos; stack.add(prev) }
                bind(St("📥 التحميلات", -1, rows, null, null, null, null, null, ""))
                if (rows.isEmpty()) status("مفيش تحميلات — ضغطة طويلة على أي فيديو ← ⬇")
            }
        }.apply { isDaemon = true }.start()
        // (v469) تحديث حي لحالة تنزيلات DownloadManager وانت في الصفحة
        h.postDelayed({ if (cur?.title == "📥 التحميلات" && !watch.isOpen && !chan.isOpen) openDownloads() }, 4000L)
    }
    private fun saveCur() {
        val st = cur ?: return; if (st.vid == null) return
        val on = YtStore.toggle(YtStore.SAVED, detItem(st)); Notice.show(act, (if (on) "🔖 اتحفظ" else "اتشال من المحفوظات").toString(), 1800L); paintDetail(st)
    }
    private fun copy(t: String) { (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", t)); Notice.show(act, ("📋 اتنسخ").toString(), 1500L) }

    private fun paintDetail(st: St) {
        val v = st.vid ?: return; val d = st.det
        dTitle.text = d?.title?.ifBlank { v.title } ?: v.title
        val views = d?.views ?: v.count
        dMeta.text = listOf(if (views >= 0) fmtN(views) + " مشاهدة" else "", if ((d?.likes ?: -1L) >= 0) "👍 " + fmtN(d!!.likes) else "", d?.age ?: v.age).filter { it.isNotBlank() }.joinToString(" · ")
        dChan.text = "📺 " + (d?.channel?.ifBlank { v.channel } ?: v.channel)
        if (v.id.length == 11) YtDislike.fetch(v.id) { dd -> act.runOnUiThread { if (dd >= 0 && cur?.vid?.id == v.id && !dMeta.text.contains("👎")) dMeta.text = dMeta.text.toString() + " · 👎 " + fmtN(dd) } }   // (v469) C8
        dDesc.text = (d?.desc ?: "").trim().ifBlank { "(مفيش وصف)" }; dDesc.maxLines = 3
        dSave.text = if (YtStore.contains(YtStore.SAVED, v)) "❌ محفوظ" else "🔖 احفظ"
        paintChip(dRel, !st.cMode); paintChip(dCom, st.cMode)
        val tu = d?.thumb?.ifBlank { v.thumb } ?: v.thumb
        try { if (tu.isNotBlank()) Glide.with(act).load(tu).centerCrop().override(ui.dp(300), ui.dp(170)).into(dThumb) else Glide.with(act).clear(dThumb) } catch (_: Throwable) {}
    }

    private fun setMode(comments: Boolean) {
        val st = cur ?: return; val v = st.vid ?: return
        if (st.cMode == comments) return
        st.cMode = comments; paintChip(dRel, !comments); paintChip(dCom, comments); statusTv.visibility = View.GONE
        if (!comments || st.cLoaded) { adapter.set(st.list()); lv.setSelection(0); if (st.list().isEmpty()) status(if (comments) "مفيش تعليقات" else "مفيش مقترحات"); return }
        adapter.clear(); status("⏳ …", null)
        Thread {
            try {
                val (r, more) = YtNp.comments(v.id)
                act.runOnUiThread {
                    st.ci.addAll(r.items); st.cn = r.next; st.cm = more; st.cLoaded = true
                    if (cur === st && st.cMode) { statusTv.visibility = View.GONE; adapter.set(st.ci); if (st.ci.isEmpty()) status("مفيش تعليقات") }
                }
            } catch (e: Throwable) {
                act.runOnUiThread { if (cur === st && st.cMode) { st.cMode = false; paintChip(dCom, false); paintChip(dRel, true); adapter.set(st.items); status("⚠ التعليقات مش متاحة: " + (e.message ?: e.javaClass.simpleName).take(120)) } }
            }
        }.start()
    }

    private var moreEmpty = 0
    private fun loadMore() {
        val st = cur ?: return; val nx = st.nxt() ?: return; val mf = st.mf() ?: return
        if (loadingMore) return
        loadingMore = true
        val inC = st.cMode
        Thread {
            try {
                val r = mf(nx)
                act.runOnUiThread {
                    if (cur === st && st.cMode == inC) {
                        val l = if (inC) st.ci else st.items; val before = st.list().size; val seen = l.map { it.id + it.url + it.title.take(40) }.toHashSet()
                        r.items.forEach { if (seen.add(it.id + it.url + it.title.take(40))) l.add(it) }   // (v865) بنضيف على القايمة الأصلية (list() ممكن تبقى نسخة مفلترة/مجمّعة)
                        if (inC) st.cn = r.next else st.next = r.next
                        if (!inC) applyListPrefs(st)   // (v469) C10
                        adapter.set(st.list())
                        // (v575) تلفزيون: لو الدفعة رجعت من غير جديد (كلها مكررة/مفلترة) كمّل لوحدك بدل ما التحميل يقف
                        if (DeviceUi.isTv(act) && !inC && st.next != null && st.list().size == before && moreEmpty++ < 8) h.postDelayed({ if (cur === st) loadMore() }, 400L) else if (st.list().size != before) moreEmpty = 0
                    }
                    loadingMore = false
                }
            } catch (_: Throwable) { act.runOnUiThread { if (inC) st.cn = null else if (!DeviceUi.isTv(act)) st.next = null; loadingMore = false } }   // (v575) تلفزيون: فشل مؤقت ما يوقفش التحميل — بيتعاد مع السكرول الجاي
        }.start()
    }

    // ───────── (v475) شاشة «مش مسجّل دخول» / «لسه ما اتزامنتش» بزرار في النص بدل «مفيش حاجة» ─────────
    private fun hidePrompt() { if (promptBox.visibility == View.VISIBLE) promptBox.visibility = View.GONE; if (lv.visibility != View.VISIBLE) lv.visibility = View.VISIBLE }
    private fun showPrompt(msg: String, vararg acts: Pair<String, () -> Unit>) {
        spin(false); statusTv.visibility = View.GONE
        promptBox.removeAllViews()
        promptBox.addView(ui.text(msg, 15f, th.text).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, ui.dp(14)) }, LinearLayout.LayoutParams(-1, -2))
        acts.forEachIndexed { k, a -> promptBox.addView(ui.button(a.first, k == 0) { a.second() }, LinearLayout.LayoutParams(-1, -2)) }
        lv.visibility = View.GONE; promptBox.visibility = View.VISIBLE
    }
    /** الرئيسية/الاشتراكات رجعت فاضية أو فشلت: لو مش مسجّل ← تسجيل الدخول، لو مسجّل ولسه ما اتزامنش ← مزامنة. why = سبب الفشل لو فيه */
    private fun emptyPrompt(tab: Int, why: String?) {
        val pre = if (why.isNullOrBlank()) "" else "⚠ " + why.take(140) + "\n\n"
        if (!YtAccount.loggedIn()) {
            val m = if (tab == 1) "مش مسجّل دخول في يوتيوب.\nسجّل دخولك عشان تظهرلك اشتراكاتك." else "مش مسجّل دخول في يوتيوب.\nسجّل دخولك عشان الرئيسية تظهرلك فيديوهات على ذوقك."
            if (tab == 1) showPrompt(pre + m, "🔐 تسجيل الدخول" to { startLogin() }, "📥 استورد ملف اشتراكات" to { onImport() }, "↻ إعادة المحاولة" to { openTab(tab) })
            else showPrompt(pre + m, "🔐 تسجيل الدخول" to { startLogin() }, "↻ إعادة المحاولة" to { openTab(tab) })
        } else {
            val m = if (tab == 1) "الاشتراكات لسه ما اتزامنتش مع حسابك." else "الرئيسية فاضية لحد ما حسابك يتزامن."
            showPrompt(pre + m, "🔄 مزامنة الآن" to { syncNow() }, "↻ إعادة المحاولة" to { openTab(tab) })
        }
    }

    private fun status(t: String, onTap: (() -> Unit)? = null) {
        hidePrompt()
        retry = onTap
        if (t.startsWith("⏳")) { statusTv.visibility = View.GONE; spin(true) }   // (v337) لودينج بدل النص
        else { spin(false); statusTv.text = t; statusTv.visibility = View.VISIBLE }
    }

    // ───────── اقتراحات البحث ─────────
    // (v1288) سجل البحث: آخر 15 كلمة، بتظهر لما خانة البحث فاضية، ✕ لحذف واحدة و«مسح الكل»
    private fun shRead(): MutableList<String> = Cfg.str("yt_search_hist", "").split('\n').map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    private fun shWrite(l: List<String>) { Cfg.put("yt_search_hist", l.take(15).joinToString("\n")) }
    private fun shAdd(q: String) { val l = shRead(); l.removeAll { it.equals(q, true) }; l.add(0, q); shWrite(l) }
    private fun showHistory() {
        val l = shRead()
        if (l.isEmpty()) { sugBox.visibility = View.GONE; return }
        sugBox.removeAllViews()
        l.forEach { s ->
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setBackgroundColor(th.card) }
            row.addView(ui.text("🕘  $s", 14f, th.text).apply { setPadding(ui.dp(18), ui.dp(10), ui.dp(8), ui.dp(10)); setOnClickListener { doSearch(s) } }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(ui.text("✕", 15f, th.muted).apply { setPadding(ui.dp(14), ui.dp(10), ui.dp(18), ui.dp(10)); setOnClickListener { val x = shRead(); x.removeAll { it == s }; shWrite(x); showHistory() } }, LinearLayout.LayoutParams(-2, -2))
            sugBox.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        sugBox.addView(ui.text("🗑 مسح سجل البحث", 12.5f, th.muted).apply { setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(12)); setBackgroundColor(th.card); setOnClickListener { shWrite(emptyList()); sugBox.visibility = View.GONE } }, LinearLayout.LayoutParams(-1, -2))
        sugBox.visibility = View.VISIBLE
    }
    private fun suggest(q: String) {
        val my = ++sugGen
        if (q.isEmpty() && searchTyping) { showHistory(); return }
        if (q.length < 2) { sugBox.visibility = View.GONE; return }
        h.postDelayed({
            if (my != sugGen) return@postDelayed
            Thread {
                val l = YtNp.suggestions(q).take(8)
                act.runOnUiThread {
                    if (my != sugGen || l.isEmpty()) { if (my == sugGen) sugBox.visibility = View.GONE; return@runOnUiThread }
                    sugBox.removeAllViews()
                    l.forEach { s ->
                        sugBox.addView(ui.text("🔍  $s", 14f, th.text).apply {
                            setPadding(ui.dp(18), ui.dp(10), ui.dp(18), ui.dp(10)); setBackgroundColor(th.card)
                            setOnClickListener { doSearch(s) }
                        }, LinearLayout.LayoutParams(-1, -2))
                    }
                    sugBox.visibility = View.VISIBLE
                }
            }.start()
        }, 250L)
    }

    // ───────── (v469) تحكم القوايم: ترتيب · إخفاء مُشاهَد · فلاتر بحث ─────────
    private fun paintCtl(st: St?) {
        val row = ctlRow ?: return
        val show = st != null && st.vid == null && st.tab != 2 && st.tab != 3 && st.tab != 4 && !st.title.startsWith("📥")
        row.visibility = if (show) View.VISIBLE else View.GONE
        if (!show || st == null) return
        ctlSort?.text = "↕ ترتيب: " + (if (st.q != null && sortMode == 0) "الأكثر مطابقة" else sortLabels[sortMode])   // (v1300) تسمية يوتيوب في البحث
        ctlType?.let { it.visibility = if (st.tab == 1 && st.chUrl == null && st.q == null) View.VISIBLE else View.GONE; it.text = "🎞 النوع: " + typeLabels[typeMode]; paintChip(it, typeMode != 0) }
        ctlHide?.let { it.text = if (hideSeen) "🙈 المُشاهَد: مخفي" else "👁 المُشاهَد: ظاهر"; paintChip(it, hideSeen) }
        val isSearch = st.q != null
        ctlDur?.visibility = if (isSearch) View.VISIBLE else View.GONE
        ctlDate?.visibility = if (isSearch) View.VISIBLE else View.GONE
        ctlLive?.let { it.visibility = if (isSearch) View.VISIBLE else View.GONE; it.text = if (st.liveF) "🔴 مباشر ✓" else "🔴 مباشر"; paintChip(it, st.liveF) }   // (v1303)
        if (isSearch) { ctlDur?.text = "⏱ المدة: " + durLabels[st.durF]; ctlDate?.text = "📅 الرفع: " + dateLabels[st.dateF] }
    }
    private fun applyListPrefs(st: St) {
        if (st.vid != null || st.tab == 2 || st.tab == 3 || st.tab == 4 || st.title.startsWith("📥")) return
        if (hideSeen) { val done = try { YtProg.completedIds(recs()) } catch (_: Throwable) { emptySet() }; if (done.isNotEmpty()) st.items.removeAll { it.kind == 0 && it.id in done } }
        when (sortMode) {
            1 -> st.items.sortByDescending { it.ts }
            2 -> st.items.sortByDescending { it.count }
            3 -> st.items.sortByDescending { it.dur }
            4 -> st.items.sortBy { if (it.dur > 0) it.dur else Long.MAX_VALUE }
            5 -> st.items.sortBy { if (it.ts > 0) it.ts else Long.MAX_VALUE }   // (v1300) الأقدم (اللي مالهاش تاريخ في الآخر)
        }
        val pa = st.items.firstOrNull { it.url == "ytpl:all" }
        if (pa != null) { st.items.remove(pa); st.items.add(0, pa) }
    }
    /** (v865) قايمة الشورتس اللي بيتسوايب عليها المشغّل اللايت: كل شورتس الفيد المحمّل بالترتيب الزمني */
    private fun shortsQueue(): List<NpItem> = cur?.items?.filter { it.kind == 0 && isShortLike(it) } ?: emptyList()
    private fun typeMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        typeLabels.forEachIndexed { i, l -> m.menu.add(0, i, i, (if (i == typeMode) "✓ " else "") + l) }
        m.setOnMenuItemClickListener { mi ->
            typeMode = mi.itemId
            cur?.let { st -> st.typeF = typeMode; st.pos = 0; adapter.set(st.list()); lv.setSelection(0); paintCtl(st) }
            true
        }
        m.show()
    }
    private fun sortMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        sortLabels.forEachIndexed { i, l -> m.menu.add(0, i, i, (if (i == sortMode) "✓ " else "") + l) }
        m.setOnMenuItemClickListener { mi -> sortMode = mi.itemId; cur?.let { st -> applyListPrefs(st); adapter.set(st.list()); paintCtl(st) }; true }
        m.show()
    }
    private fun durMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        durLabels.forEachIndexed { i, l -> m.menu.add(0, i, i, (if (i == pendDurF) "✓ " else "") + l) }
        m.setOnMenuItemClickListener { mi -> pendDurF = mi.itemId; cur?.let { st -> st.q?.let { q -> doSearch(q, st.filter) } }; true }
        m.show()
    }
    private fun dateMenu(anchor: View) {
        val m = PopupMenu(act, anchor)
        dateLabels.forEachIndexed { i, l -> m.menu.add(0, i, i, (if (i == pendDateF) "✓ " else "") + l) }
        m.setOnMenuItemClickListener { mi -> pendDateF = mi.itemId; cur?.let { st -> st.q?.let { q -> doSearch(q, st.filter) } }; true }
        m.show()
    }
    private fun toggleHideSeen() {
        hideSeen = !hideSeen
        try { Cfg.put("ytp_hide_seen", if (hideSeen) "1" else "0") } catch (_: Throwable) {}
        Notice.show(act, if (hideSeen) "🙈 الفيديوهات اللي كمّلتها هتتخبّى من القوايم" else "👁 المُشاهَد هيرجع يظهر", 2200L)
        val st = cur ?: return
        if (hideSeen) { applyListPrefs(st); adapter.set(st.list()); paintCtl(st) }
        else when {
            st.tab == 0 -> openTab(0)
            st.tab == 1 -> openSubs(false)
            st.q != null -> doSearch(st.q!!, st.filter)
            else -> paintCtl(st)
        }
    }
    /** (v469) C7: تشغيل قايمة كاملة من أولها بالترتيب (سياق «التالي» بياخد القايمة كلها) */
    private fun playAll(st: St) {
        val first = st.items.firstOrNull { it.kind == 0 } ?: return
        Notice.show(act, "▶ بنشغّل القايمة من الأول (" + st.items.count { it.kind == 0 } + " فيديو)", 2200L)
        play(first, false)
    }
    /** (v469) C6: قسم «أكمل المشاهدة» */
    private fun showContinue() {
        val prev = cur; val prevPos = lv.firstVisiblePosition
        if (prev != null) { prev.pos = prevPos; stack.add(prev) }
        gen++
        val items = ArrayList(try { YtProg.continueItems(recs()) } catch (_: Throwable) { emptyList<NpItem>() })
        bind(St("⏩ أكمل المشاهدة", -1, items, null, null, null, null, null, ""))
        if (items.isEmpty()) status("مفيش حاجة بدأتها ووقفت في النص — أي فيديو تفتحه وتقف بيه هيظهر هنا")
    }
    /** (v469) C11: مشاركة (بطابع زمني لو الفيديو ليه موضع محفوظ) */
    private fun shareItem(it: NpItem) {
        val sec = try { YtProg.resumeMs(it.id, recs()["yt:" + it.id] as? Recent) / 1000L } catch (_: Throwable) { 0L }
        val u = YtNp.watchUrl(it.id) + if (sec > 5) "&t=" + sec + "s" else ""
        try { act.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, u), "مشاركة")) } catch (_: Throwable) {}
    }

    // ───────── قايمة الضغطة الطويلة ─────────
    private fun menu(anchor: View, it: NpItem) {
        val m = PopupMenu(act, anchor)
        if (it.kind == 0) {
            m.menu.add(0, 1, 0, "▶ شغّل"); m.menu.add(0, 2, 1, "🌐 شغّل وترجم"); m.menu.add(0, 10, 7, "ℹ التفاصيل"); m.menu.add(0, 11, 8, "🎧 صوت بس (مشغّل الموسيقى)")
            if (!DeviceUi.isTv(act)) {
                m.menu.add(0, 12, 9, "⬇ تحميل صوت")
                m.menu.add(0, 13, 10, "⬇ تحميل فيديو")
            }
            m.menu.add(0, 3, 2, if (YtStore.contains(YtStore.SAVED, it)) "❌ شيل من المحفوظات" else "🔖 احفظ")
            if (it.channelUrl.isNotBlank()) m.menu.add(0, 4, 3, "📺 افتح القناة")
            m.menu.add(0, 5, 4, "📋 انسخ اللينك"); m.menu.add(0, 6, 5, "🌐 افتحه في المتصفح")
            m.menu.add(0, 15, 11, "⏭ شغّل بعده (قائمة الانتظار)"); m.menu.add(0, 16, 12, "↗ مشاركة")   // (v469) C9/C11
            m.menu.add(0, 17, 13, "➕ إضافة للليستة")   // (v694)
            m.menu.add(0, 18, 14, "🚫 مش مهتم")   // (v1291)
            if (it.channel.isNotBlank()) m.menu.add(0, 19, 15, "🚫 ماتقترحش قناة «" + it.channel.take(20) + "»")   // (v1291)
            if (cur?.tab == 2) m.menu.add(0, 7, 6, "🗑 شيل من السجل")
        } else {
            m.menu.add(0, 8, 0, "فتح"); m.menu.add(0, 5, 1, "📋 انسخ اللينك")
            if (it.kind == 2 && !it.url.startsWith("yta:")) m.menu.add(0, 14, 3, "▶ شغّل الكل")   // (v469) C7
            if (it.kind == 1) m.menu.add(0, 9, 2, if (YtStore.contains(YtStore.SUBS, it)) "❌ إلغاء الاشتراك" else "🔔 اشترك")
        }
        m.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> play(it, false)
                2 -> play(it, true)
                10 -> openDetail(it)
                11 -> playAudio(it)
                12 -> onDownload(asWatch(it), true)
                13 -> onDownload(asWatch(it), false)
                3 -> { val on = YtStore.toggle(YtStore.SAVED, it); Notice.show(act, (if (on) "🔖 اتحفظ" else "اتشال من المحفوظات").toString(), 1800L); if (cur?.tab == 3) showLocal(3, false) }
                4 -> openChannel(it.channelUrl, it.channel, it.avatar)
                5 -> copy(if (it.kind == 0) YtNp.watchUrl(it.id) else it.url)
                6 -> onBrowser(YtNp.watchUrl(it.id))
                7 -> { YtStore.remove(YtStore.HIST, it); showLocal(2, false) }
                15 -> { YtQueue.addNext(it); Notice.show(act, "⏭ اتضاف لقائمة الانتظار — هيتشغّل بعد الحالي", 2200L) }
                16 -> shareItem(it)
                17 -> PlayQueueUi.add(act, YtNp.watchUrl(it.id), it.title)   // (v694)
                18 -> { YtStore.hide("v:" + it.id); Notice.show(act, "👌 هنقترح حاجات زي دي أقل", 1800L); cur?.let { st -> if (st.tab == 0) adapter.set(st.list()) } }   // (v1291)
                19 -> { YtStore.hide("c:" + it.channel); Notice.show(act, ("👌 قناة «" + it.channel + "» مش هتتقترح تاني").toString(), 2000L); cur?.let { st -> if (st.tab == 0) adapter.set(st.list()) } }   // (v1291)
                8 -> open(it)
                14 -> { pendingPlayAll = true; open(it) }
                9 -> { val on = YtStore.toggle(YtStore.SUBS, it); Notice.show(act, (if (on) "✅ اشتركت" else "اتشال الاشتراك").toString(), 1800L) }
            }
            true
        }
        m.show()
    }

    // ───────── رسم ─────────
    /** sel: 0 رئيسية · 1 اشتراكات · 2/3/4 = «أنت» · غير كده (بحث/قناة) بيسيب التحديد زي ما هو */
    private fun paintTabs(sel: Int) {
        val prevSel = navSel
        if (sel in 0..1) navSel = sel else if (sel in 2..4) navSel = 2
        if (DeviceUi.isTv(act) && prevSel == 1 && navSel != 1) { try { YtNotify.markOpened(act) } catch (_: Throwable) {}; tvBadgeRefresh(true) }   // (v575) خرجت من الاشتراكات: العدّ يبدأ من دلوقتي
        paintNav()
        tvSubsBadge()
        bellRefresh()   // (v1304)
        if (navSel != 1) tvBadgeRefresh(false)   // (v575) تحديث العدّاد (كل 5 دقايق بالكتير)
        if (::topTitle.isInitialized) topTitle.text = when (navSel) { 0 -> "الرئيسية"; 1 -> "الاشتراكات"; else -> "أنا" }
        try { onTab?.invoke(navSel) } catch (_: Throwable) {}
    }
    /** (v1304) عدّاد الجرس: عدد إشعارات صندوق الإشعارات غير المقروءة */
    fun bellRefresh() { try { if (!::bellBadge.isInitialized) return; val n = YtNotify.inboxUnread(); if (n <= 0) bellBadge.visibility = View.GONE else { bellBadge.visibility = View.VISIBLE; bellBadge.text = if (n > 99) "99+" else n.toString() } } catch (_: Throwable) {} }

    /** (v1304) صندوق الإشعارات: آخر الفيديوهات الجديدة من الاشتراكات (زي يوتيوب) — فتحه بيصفّر العدّاد */
    private fun showInbox() {
        val items = try { YtNotify.inbox() } catch (_: Throwable) { emptyList<YtNotify.InboxItem>() }
        try { YtNotify.inboxMarkRead() } catch (_: Throwable) {}
        bellRefresh()
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        if (items.isEmpty()) box.addView(ui.text("مفيش إشعارات لسه — أول ما قناة مشترك فيها تنزل فيديو جديد هيظهر هنا.", 13.5f, YtSkin.sub).apply { setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(8)) })
        for (inx in items) {
            val row = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(12), ui.dp(8), ui.dp(12), ui.dp(8)); foreground = YtSkin.ripple(); background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(12).toFloat() } }
            row.addView(ui.text(inx.title, 13.5f, YtSkin.text, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
            row.addView(ui.text(inx.channel + " · " + YtRss.ageOf(inx.ts), 11.5f, YtSkin.sub).apply { setPadding(0, ui.dp(3), 0, 0) })
            row.setOnClickListener { try { inxDlg?.dismiss() } catch (_: Throwable) {}; openVideo(inx.id) }
            box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4)) })
        }
        inxDlg = ui.sheet(act, "🔔 الإشعارات", listOf<View>(box), false); inxDlg?.show()
    }

    /** (v1304) استكشاف: أقسام يوتيوب (الرائج/موسيقى/ألعاب/أخبار/رياضة/مباشر) في صفحة مستقلة — الدوسة بتحمّل القسم في الرئيسية */
    private fun showExplore() {
        val cats = listOf("🔥" to 1, "🎵" to 2, "🎮" to 3, "📰" to 4, "⚽" to 5, "🔴" to 6)
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(8)) }
        var row: LinearLayout? = null
        cats.forEachIndexed { i, (emoji, chip) ->
            if (i % 2 == 0) { row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }; box.addView(row, LinearLayout.LayoutParams(-1, -2)) }
            val tile = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, ui.dp(16), 0, ui.dp(16)); foreground = YtSkin.ripple(); background = GradientDrawable().apply { setColor(YtSkin.surface); cornerRadius = ui.dp(14).toFloat() }
                addView(ui.text(emoji, 26f, YtSkin.text))
                addView(ui.text(HOME_CHIPS[chip].first, 13.5f, YtSkin.text, true).apply { setPadding(0, ui.dp(4), 0, 0) })
                setOnClickListener { try { expDlg?.dismiss() } catch (_: Throwable) {}; if (navSel != 0) navTap(0); homeChip(chip, HOME_CHIPS[chip].second) }
            }
            row?.addView(tile, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) })
        }
        expDlg = ui.sheet(act, "🧭 استكشاف", listOf<View>(box), false); expDlg?.show()
    }

    private fun paintChip(tv: TextView, on: Boolean) {
        tv.setTextColor(if (on) YtSkin.chipOnText else YtSkin.text)
        tv.background = GradientDrawable().apply { setColor(if (on) YtSkin.chipOnBg else YtSkin.chip); cornerRadius = ui.dp(8).toFloat() }
    }
    private fun paintSub(on: Boolean) {
        subBtn.text = if (on) "✅ مشترك" else "🔔 اشترك"
        subBtn.background = GradientDrawable().apply { setColor(if (on) th.muted else th.primary); cornerRadius = ui.dp(16).toFloat() }
    }
    private fun hideKb() { try { (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0) } catch (_: Throwable) {} }

    private fun fmtN(n: Long): String = when {
        n < 0 -> ""; n < 1000 -> n.toString()
        n < 1_000_000 -> String.format(Locale.US, "%.1fK", n / 1000.0)
        n < 1_000_000_000 -> String.format(Locale.US, "%.1fM", n / 1_000_000.0)
        else -> String.format(Locale.US, "%.1fB", n / 1_000_000_000.0)
    }
    private fun fmtDur(s: Long): String = if (s == -2L) "🔴 مباشر" else if (s <= 0) "" else if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60) else String.format(Locale.US, "%d:%02d", s / 60, s % 60)

    private class Hold(val thumb: ImageView, val dur: TextView, val title: TextView, val meta: TextView, val box: View, val col: View, val btns: View, val aud: View, val dl: View)

    private class Cell(val root: LinearLayout, val thumb: ImageView, val dur: TextView, val title: TextView, val meta: TextView)

    private class Card(val root: LinearLayout, val thumb: ImageView, val dur: TextView, val prog: View, val av: TextView, val avImg: ImageView,
                        val title: TextView, val meta: TextView, val more: View, val dub: TextView, val dl: View, val aud: View, val newB: TextView)

    /** (v397) كارت فيديو زي يوتيوب: صورة بعرض الشاشة 16:9 (مدة + شريط استكمال) + أفاتار القناة + العنوان + «القناة · المشاهدات · الوقت» + ⋮ */
    private fun makeCard(): Card {
        val sw = cardW()
        val medium = YtSkin.medium
        val thumb = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(YtSkin.surface) }
        val dur = TextView(act).apply {
            textSize = 12f; setTextColor(Color.WHITE); includeFontPadding = false; typeface = medium
            setPadding(ui.dp(5), ui.dp(3), ui.dp(5), ui.dp(3))
            background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = ui.dp(4).toFloat() }
        }
        val prog = View(act).apply { setBackgroundColor(YtSkin.accent); visibility = View.GONE }
        val box = FrameLayout(act)
        box.addView(thumb, FrameLayout.LayoutParams(-1, -1))
        box.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8)) })
        box.addView(prog, FrameLayout.LayoutParams(0, ui.dp(3), Gravity.BOTTOM or Gravity.START))
        // (v406) علامة «مدبلج» (بتظهر لو الفيديو ليه أكتر من لغة صوت) — دوسة عليها بتختار اللغة
        val dub = TextView(act).apply {
            text = "🌐 مدبلج"; textSize = 11f; setTextColor(Color.WHITE); includeFontPadding = false; typeface = medium; visibility = View.GONE
            setPadding(ui.dp(7), ui.dp(4), ui.dp(7), ui.dp(4)); background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = ui.dp(5).toFloat() }
        }
        box.addView(dub, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8)) })
        // (v1144) علامة «جديد» على فيديوهات الاشتراكات اللي اتضافت من آخر مرة فتحت فيها الاشتراكات — بتختفي لما تخرج وتدخل تاني
        val newB = TextView(act).apply {
            text = "جديد"; textSize = 11f; setTextColor(Color.WHITE); includeFontPadding = false; typeface = medium; visibility = View.GONE
            setPadding(ui.dp(7), ui.dp(4), ui.dp(7), ui.dp(4)); background = GradientDrawable().apply { setColor(0xFFE53935.toInt()); cornerRadius = ui.dp(5).toFloat() }
        }
        box.addView(newB, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply { setMargins(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8)) })
        val tb = YtThumbBtns.attach(act, ui, box)   // (v472) 🎧 صوت + ⬇ تحميل فوق كل صورة
        val av = TextView(act).apply { gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.WHITE); includeFontPadding = false; typeface = medium }
        val avImg = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE }
        val avBox = FrameLayout(act)
        avBox.addView(av, FrameLayout.LayoutParams(-1, -1)); avBox.addView(avImg, FrameLayout.LayoutParams(-1, -1))
        val title = TextView(act).apply { textSize = if (DeviceUi.isTv(act)) 16f else 14f; setTextColor(YtSkin.text); maxLines = 2; ellipsize = TextUtils.TruncateAt.END; typeface = medium }
        val meta = TextView(act).apply { textSize = if (DeviceUi.isTv(act)) 13f else 12f; setTextColor(YtSkin.sub); maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(title, LinearLayout.LayoutParams(-1, -2))
        col.addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(3) })
        val more = YtIcon(act, "more").apply { foreground = YtSkin.ripple(true); glyph = 0.8f; contentDescription = "المزيد"; if (DeviceUi.isRemote(act)) visibility = View.GONE }   // (v521) تلفزيون: ⋮ بتاعة اللمس اتشالت (Menu بالريموت)
        val info = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.TOP
            setPadding(ui.dp(4), ui.dp(12), ui.dp(12), ui.dp(16))
        }
        info.addView(avBox, LinearLayout.LayoutParams(ui.dp(36), ui.dp(36)).apply { marginEnd = ui.dp(12) })
        info.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        info.addView(more, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)))
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        root.addView(box, LinearLayout.LayoutParams(-1, sw * 9 / 16))
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        return Card(root, thumb, dur, prog, av, avImg, title, meta, more, dub, tb.dl, tb.aud, newB)
    }

    /** (v378) كارت فيديو للشبكة (الرئيسية): صورة 16:9 وتحتها اسم الفيديو ثم القناة */
    private fun makeCell(): Cell {
        val cw = (act.resources.displayMetrics.widthPixels - ui.dp(40)) / 2
        val th0 = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(th.surface) }
        val dur = ui.text("", 11f, Color.WHITE, true).apply { setPadding(ui.dp(5), ui.dp(1), ui.dp(5), ui.dp(1)); background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = ui.dp(4).toFloat() } }
        val box = FrameLayout(act)
        box.addView(th0, FrameLayout.LayoutParams(-1, -1))
        box.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) })
        val title = ui.text("", 13f, th.text, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
        val meta = ui.text("", 11f, th.muted).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        col.addView(box, LinearLayout.LayoutParams(-1, cw * 9 / 16))
        col.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(6) })
        col.addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(2) })
        return Cell(col, th0, dur, title, meta)
    }

    private inner class Adapter : BaseAdapter() {
        private var items: List<NpItem> = emptyList()
        var grid = false   // (v378) الرئيسية: فيديوهين جنب بعض
        var cards = false  // (v397) كروت يوتيوب
        fun set(l: List<NpItem>) { items = l; notifyDataSetChanged() }
        fun clear() { items = emptyList(); notifyDataSetChanged() }
        override fun getCount() = if (grid) (items.size + 1) / 2 else items.size
        override fun getItem(p: Int) = if (grid) items[p * 2] else items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 6
        override fun getItemViewType(p: Int): Int = if (grid) 1 else when (items[p].kind) { 5 -> 3; 6 -> 4; 7 -> 5; else -> if (cards && items[p].kind == 0 && items[p].id != "act") 2 else 0 }
        /** (v1291) كارت الحساب في صفحة «أنت» (kind 7): أفاتار + اسم + إيميل + زراير (مزامنة/خروج أو دخول) */
        private inner class YHdrHold(val av: android.widget.TextView, val avImg: ImageView, val name: android.widget.TextView, val sub: android.widget.TextView, val chip1: android.widget.TextView, val chip2: android.widget.TextView)
        private fun youHeaderView(p: Int, cv: View?): View {
            val hd: YHdrHold; val v: View
            if (cv == null) {
                val av = ui.text("", 22f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
                val avImg = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                val avBox = FrameLayout(act)
                avBox.addView(av, FrameLayout.LayoutParams(-1, -1)); avBox.addView(avImg, FrameLayout.LayoutParams(-1, -1))
                val name = ui.text("", 17f, th.text, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                val sub = ui.text("", 12f, th.muted).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
                col.addView(name, LinearLayout.LayoutParams(-1, -2)); col.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(2) })
                val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(avBox, LinearLayout.LayoutParams(ui.dp(56), ui.dp(56)).apply { marginEnd = ui.dp(14) })
                top.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                fun chip() = ui.text("", 13f, YtSkin.accent, true).apply {
                    setPadding(ui.dp(12), ui.dp(7), ui.dp(12), ui.dp(7))
                    background = GradientDrawable().apply { cornerRadius = ui.dp(18).toFloat(); setStroke(ui.dp(1), YtSkin.accent) }
                    foreground = YtSkin.ripple(true)
                }
                val chip1 = chip(); val chip2 = chip()
                val chips = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                chips.addView(chip1, LinearLayout.LayoutParams(-2, -2)); chips.addView(chip2, LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(8) })
                val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(12), ui.dp(12), ui.dp(12), ui.dp(12)) }
                box.addView(top, LinearLayout.LayoutParams(-1, -2)); box.addView(chips, LinearLayout.LayoutParams(-2, -2).apply { topMargin = ui.dp(10) })
                hd = YHdrHold(av, avImg, name, sub, chip1, chip2); box.tag = hd; v = box
            } else { v = cv; hd = cv.tag as YHdrHold }
            val it = items[p]
            val logged = YtAccount.loggedIn()
            hd.name.text = it.title
            hd.sub.text = it.channel + if (it.chanVerified) " ✔" else ""   // (v1303) ✔ التوثيق
            hd.sub.visibility = if (it.channel.isBlank()) View.GONE else View.VISIBLE
            hd.av.text = if (logged) it.title.trim().take(1).uppercase(Locale.getDefault()) else "👤"
            hd.av.background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(YtSkin.avatarColor(it.title)) }
            if (it.avatar.isNotBlank()) {   // (v1336) اللوجو يظهر حتى من غير تسجيل دخول
                hd.avImg.visibility = View.VISIBLE
                try { Glide.with(act).load(it.avatar).circleCrop().override(ui.dp(112), ui.dp(112)).into(hd.avImg) } catch (_: Throwable) {}
            } else { hd.avImg.visibility = View.GONE; try { Glide.with(act).clear(hd.avImg) } catch (_: Throwable) {} }
            if (logged) {
                hd.chip1.text = "🔄 مزامنة الاشتراكات"; hd.chip1.setOnClickListener { openAcc(yrow("", "", "!sync")) }
                hd.chip2.text = "🚪 تسجيل الخروج"; hd.chip2.visibility = View.VISIBLE; hd.chip2.setOnClickListener { openAcc(yrow("", "", "!out")) }
            } else {
                hd.chip1.text = "🔐 تسجيل الدخول بالكود"; hd.chip1.setOnClickListener { openAcc(yrow("", "", "!login")) }
                hd.chip2.visibility = View.GONE; hd.chip2.setOnClickListener(null)
            }
            return v
        }
        /** (v1291) رف أفقي في صفحة «أنت» (kind 6): عنوان + «عرض الكل» + كروت 16:9 بتتسكرول بالعرض — url = ythshelf:hist|cont|saved */
        private inner class YShelfHold(val label: android.widget.TextView, val all: android.widget.TextView, val row: LinearLayout)
        private fun youShelfView(p: Int, cv: View?): View {
            val hd: YShelfHold; val v: View
            if (cv == null) {
                val label = ui.text("", 15f, th.text, true)
                val all = ui.text("عرض الكل", 13f, YtSkin.accent, true).apply { setPadding(ui.dp(8), ui.dp(4), ui.dp(2), ui.dp(4)); foreground = YtSkin.ripple(true) }
                val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
                head.addView(label, LinearLayout.LayoutParams(0, -2, 1f)); head.addView(all, LinearLayout.LayoutParams(-2, -2))
                val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                // (v1292) FrameLayout.LayoutParams — كوتلن مابيشوفش الكلاسات المتداخلة من الكلاس الابن
                val scroll = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(row, FrameLayout.LayoutParams(-2, -2)) }
                val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(10)) }
                box.addView(head, LinearLayout.LayoutParams(-1, -2)); box.addView(scroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(6) })
                hd = YShelfHold(label, all, row); box.tag = hd; v = box
            } else { v = cv; hd = cv.tag as YShelfHold }
            val it = items[p]
            val key = it.url.removePrefix("ythshelf:")
            hd.label.text = it.title
            hd.all.setOnClickListener { when (key) { "hist" -> showLocal(2, true); "saved" -> showLocal(3, true); else -> showContinue() } }
            hd.row.removeAllViews()
            if (key == "subs") {   // (v1291) شريط الاشتراكات: دواير قنوات بالصورة والاسم — دوسة تفتح القناة
                hd.all.visibility = View.GONE
                for (vi in youShelves[key].orEmpty()) {
                    val letter = ui.text("", 18f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
                    val avImg = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                    val avBox = FrameLayout(act)
                    avBox.addView(letter, FrameLayout.LayoutParams(-1, -1)); avBox.addView(avImg, FrameLayout.LayoutParams(-1, -1))
                    val nm = ui.text("", 10.5f, th.text, false).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER_HORIZONTAL }
                    val cell = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; foreground = YtSkin.ripple(true) }
                    cell.addView(avBox, LinearLayout.LayoutParams(ui.dp(56), ui.dp(56)))
                    cell.addView(nm, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(4) })
                    val cname = vi.title.trim()
                    letter.text = if (cname.isEmpty()) "📺" else cname.substring(0, cname.offsetByCodePoints(0, 1)).uppercase(Locale.getDefault())
                    letter.background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(YtSkin.avatarColor(cname)) }
                    nm.text = cname
                    val av0 = if (vi.avatar.isNotBlank()) vi.avatar else vi.thumb
                    avImg.tag = vi.channelUrl
                    if (av0.isNotBlank()) { try { Glide.with(act).load(av0).circleCrop().override(ui.dp(112), ui.dp(112)).into(avImg) } catch (_: Throwable) {} }
                    else YtMtFeed.avatarAsync(act, vi.channelUrl) { u -> vi.avatar = u; act.runOnUiThread { try { if (avImg.tag === vi.channelUrl || avImg.tag == vi.channelUrl) Glide.with(act).load(u).circleCrop().override(ui.dp(112), ui.dp(112)).into(avImg) } catch (_: Throwable) {} } }
                    cell.setOnClickListener { openChannel(vi.channelUrl, vi.title, vi.avatar) }
                    cell.setOnLongClickListener { x -> menu(x, vi); true }
                    hd.row.addView(cell, LinearLayout.LayoutParams(ui.dp(64), -2).apply { marginEnd = ui.dp(6) })
                }
                return v
            }
            hd.all.visibility = View.VISIBLE
            val cw = ui.dp(150); val chh = cw * 9 / 16
            for (vi in youShelves[key].orEmpty()) {
                val thumb = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                val dur = ui.text("", 10.5f, Color.WHITE, true).apply { setPadding(ui.dp(4), 0, ui.dp(4), ui.dp(1)); background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = ui.dp(4).toFloat() } }
                val tbox = FrameLayout(act).apply { clipToOutline = true; background = GradientDrawable().apply { cornerRadius = ui.dp(8).toFloat(); setColor(th.surface) } }
                tbox.addView(thumb, FrameLayout.LayoutParams(-1, -1))
                tbox.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) })
                val title = ui.text("", 11.5f, th.text, false).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                val meta = ui.text("", 10f, th.muted, false).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
                val cell = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; foreground = YtSkin.ripple(true) }
                cell.addView(tbox, LinearLayout.LayoutParams(cw, chh))
                cell.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(4) })
                cell.addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(1) })
                val d = fmtDur(vi.dur)
                dur.text = d; dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
                title.text = vi.title
                meta.text = listOf(vi.channel + if (vi.chanVerified) " ✔" else "", vi.age).filter { x -> x.isNotBlank() }.joinToString(" · ")   // (v1303) ✔ التوثيق
                try { if (vi.thumb.isNotBlank()) Glide.with(act).load(vi.thumb).centerCrop().into(thumb) else Glide.with(act).clear(thumb) } catch (_: Throwable) {}
                cell.setOnClickListener { open(vi, cell) }
                cell.setOnLongClickListener { x -> if (vi.id != "act") menu(x, vi); true }
                hd.row.addView(cell, LinearLayout.LayoutParams(cw, -2).apply { marginEnd = ui.dp(8) })
            }
            return v
        }
        private fun gridView(p: Int, cv: View?): View {
            val row: LinearLayout
            if (cv == null) {
                row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(10)) }
                val a = makeCell(); val b = makeCell()
                row.addView(a.root, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(ui.dp(5), 0, ui.dp(5), 0) })
                row.addView(b.root, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(ui.dp(5), 0, ui.dp(5), 0) })
                row.tag = arrayOf(a, b)
            } else row = cv as LinearLayout
            @Suppress("UNCHECKED_CAST") val pair = row.tag as Array<Cell>
            for (k in 0..1) {
                val c = pair[k]; val idx = p * 2 + k
                if (idx >= items.size) { c.root.visibility = View.INVISIBLE; c.root.setOnClickListener(null); c.root.setOnLongClickListener(null); continue }
                c.root.visibility = View.VISIBLE
                val vi = items[idx]
                c.title.text = vi.title
                c.title.alpha = if (vi.kind == 0 && recs().containsKey("yt:" + vi.id)) 0.6f else 1f
                c.meta.text = listOf(vi.channel, vi.age).filter { x -> x.isNotBlank() }.joinToString(" · ")
                val d = if (vi.kind == 0) fmtDur(vi.dur) else if (vi.kind == 2) "☰ " + act.getString(R.string.yt_playlist_badge) else ""   // (v1300) بادج القايمة
                c.dur.text = d; c.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
                try { if (vi.thumb.isNotBlank()) Glide.with(act).load(vi.thumb).centerCrop().override(ui.dp(300), ui.dp(170)).into(c.thumb) else Glide.with(act).clear(c.thumb) } catch (_: Throwable) {}
                c.root.setOnClickListener { if (vi.kind != 3) open(vi, c.root) }
                c.root.setOnLongClickListener { x -> if (vi.id != "act") menu(x, vi); true }
            }
            return row
        }
        private inner class ShelfHold(val label: TextView, val cells: Array<FrameLayout>, val imgs: Array<ImageView>, val titles: Array<TextView>)
        /** (v865) «رف الشورتس»: 4 شورتس جنب بعض (9:16) في كارت بعرض الفيديو العادي، دوسة = المشغّل اللايت (سويب للي بعده) */
        private fun shelfView(p: Int, cv: View?): View {
            val hd: ShelfHold; val v: View
            if (cv == null) {
                val sw = act.resources.displayMetrics.widthPixels
                val pad = ui.dp(10); val gap = ui.dp(6)
                val cw = (sw - 2 * pad - 3 * gap) / 4; val chh = cw * 16 / 9
                val label = ui.text("🩳 شورتس", 14f, th.text, true).apply { setPadding(ui.dp(2), 0, ui.dp(2), ui.dp(6)) }
                val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                val cells = Array(4) { FrameLayout(act).apply { background = GradientDrawable().apply { cornerRadius = ui.dp(10).toFloat(); setColor(th.surface) }; clipToOutline = true } }
                val imgs = Array(4) { ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP } }
                val titles: Array<TextView> = Array(4) { ui.text("", 10.5f, Color.WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(ui.dp(5), ui.dp(16), ui.dp(5), ui.dp(5)); background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xCC000000.toInt())) } }
                for (k in 0 until 4) {
                    cells[k].addView(imgs[k], FrameLayout.LayoutParams(-1, -1))
                    cells[k].addView(titles[k], FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
                    row.addView(cells[k], LinearLayout.LayoutParams(cw, chh).apply { if (k < 3) marginEnd = gap })
                }
                val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(pad, ui.dp(8), pad, ui.dp(10)); addView(label); addView(row) }
                hd = ShelfHold(label, cells, imgs, titles); box.tag = hd; v = box
            } else { v = cv; hd = cv.tag as ShelfHold }
            val ids = items[p].url.removePrefix("ytshelf:").split(",").filter { x -> x.isNotBlank() }
            for (k in 0 until 4) {
                val c = hd.cells[k]
                if (k >= ids.size) { c.visibility = View.INVISIBLE; c.setOnClickListener(null); c.setOnLongClickListener(null); continue }
                val id = ids[k]; val info = shortInfo[id]
                c.visibility = View.VISIBLE
                hd.titles[k].text = info?.title ?: ""
                try { Glide.with(act).load("https://i.ytimg.com/vi/$id/hqdefault.jpg").centerCrop().into(hd.imgs[k]) } catch (_: Throwable) {}
                c.setOnClickListener { val s = info ?: shortsQueue().firstOrNull { q -> q.id == id }; if (s != null) play(s, false) else onPlay(id, "", false) }   // (v1103 Y2) ShortsPlayer اتمسح v889 — الشورتس بتتفتح كفيديو عادي (تبويب الشورتس = T5)
                c.setOnLongClickListener { x -> info?.let { menu(x, it) }; true }
            }
            return v
        }
        private fun cardView(p: Int, cv: View?): View {
            val c: Card
            val v: View
            if (cv == null) { c = makeCard(); v = c.root; v.tag = c } else { v = cv; c = cv.tag as Card }
            val sw = cardW()
            val vi = items[p]
            v.animate().cancel()
            if (animRows && p < 4) {
                v.alpha = 0f; v.translationY = ui.dp(14).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(p * 28L).setDuration(Skins.dur(200L)).setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start()
            } else { v.alpha = 1f; v.translationY = 0f }
            c.title.text = vi.title
            c.newB.visibility = if (YtNotify.isNew(vi.id)) View.VISIBLE else View.GONE   // (v1144)
            c.meta.text = listOf(if (YtRss.isShort(vi.id)) "🩳 شورتس" else "", vi.channel + if (vi.chanVerified) " ✔" else "", if (vi.count >= 0) fmtN(vi.count) + " مشاهدة" else "", vi.age).filter { x -> x.isNotBlank() }.joinToString(" · ")   // (v1303) ✔ التوثيق
            val d = fmtDur(vi.dur)
            c.dur.text = d; c.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
            val rec = recs()["yt:" + vi.id] as? Recent
            val fr = if (rec != null && rec.durSec > 0.0) (rec.posSec / rec.durSec).coerceIn(0.0, 1.0) else 0.0
            if (fr > 0.01) { c.prog.layoutParams.width = (sw * fr).toInt(); c.prog.requestLayout(); c.prog.visibility = View.VISIBLE } else c.prog.visibility = View.GONE
            val nm = vi.channel.trim()
            c.av.text = if (nm.isEmpty()) "▶" else nm.substring(0, nm.offsetByCodePoints(0, 1)).uppercase(Locale.getDefault())
            c.av.background = GradientDrawable().apply { setShape(GradientDrawable.OVAL); setColor(YtSkin.avatarColor(nm)) }
            if (vi.avatar.isNotBlank()) {
                c.avImg.visibility = View.VISIBLE
                try { Glide.with(act).load(vi.avatar).circleCrop().override(ui.dp(72), ui.dp(72)).into(c.avImg) } catch (_: Throwable) {}
            } else {
                c.avImg.visibility = View.GONE
                try { Glide.with(act).clear(c.avImg) } catch (_: Throwable) {}
                // (v1144) لوجو القناة ناقص (RSS/بحث/مقترحات) ← نجيبه في الخلفية ونحطه
                YtMtFeed.avatarAsync(act, vi.channelId.ifBlank { vi.channelUrl }) { u ->
                    vi.avatar = u
                    act.runOnUiThread { try { if (items.getOrNull(p) === vi && c.title.text.toString() == vi.title) { c.avImg.visibility = View.VISIBLE; Glide.with(act).load(u).circleCrop().override(ui.dp(72), ui.dp(72)).into(c.avImg) } } catch (_: Throwable) {} }
                }
            }
            try {
                if (vi.thumb.isNotBlank()) Glide.with(act).load(vi.thumb).centerCrop().override(sw, sw * 9 / 16)
                    .transition(com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade(140)).into(c.thumb)
                else Glide.with(act).clear(c.thumb)
            } catch (_: Throwable) {}
            c.more.setOnClickListener { x -> menu(x, vi) }
            YtThumbBtns.bind(c.aud, c.dl, vi.id, { playAudio(vi) }, { dlMenu(c.dl, vi) })   // (v472) 🎧 / ⬇ فوق الصورة
            bindDub(c, vi)
            // (v403) دوسة على صورة القناة أو سطر «القناة · المشاهدات» = صفحة القناة
            val chOpen = View.OnClickListener { openChannel(vi.channelUrl, vi.channel, vi.avatar) }
            val chMenu = View.OnLongClickListener { x -> menu(x, vi); true }
            for (cv2 in listOf<View>(c.av, c.avImg, c.meta)) { cv2.setOnClickListener(chOpen); cv2.setOnLongClickListener(chMenu) }
            return v
        }
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            if (grid) return gridView(p, cv)
            if (items[p].kind == 5) return shelfView(p, cv)
            if (items[p].kind == 6) return youShelfView(p, cv)   // (v1291)
            if (items[p].kind == 7) return youHeaderView(p, cv)   // (v1291)
            if (cards && items[p].kind == 0 && items[p].id != "act") return cardView(p, cv)
            val hd: Hold
            val v: View
            if (cv == null) {
                val th0 = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(th.surface) }
                val dur = ui.text("", 11f, Color.WHITE, true).apply { setPadding(ui.dp(5), ui.dp(1), ui.dp(5), ui.dp(1)); background = GradientDrawable().apply { setColor(0xCC000000.toInt()); cornerRadius = ui.dp(4).toFloat() } }
                val box = FrameLayout(act)
                box.addView(th0, FrameLayout.LayoutParams(-1, -1))
                box.addView(dur, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) })
                val title = ui.text("", 14f, th.text, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                val meta = ui.text("", 11f, th.muted).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END }
                val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(10), 0, ui.dp(10), 0); gravity = Gravity.CENTER_VERTICAL }
                col.addView(title, LinearLayout.LayoutParams(-1, -2)); col.addView(meta, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(4) })
                val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6)) }
                row.addView(box, LinearLayout.LayoutParams(ui.dp(150), ui.dp(85)))
                row.addView(col, LinearLayout.LayoutParams(0, ui.dp(85), 1f))
                // (v472) 🎧 صوت بس · ⬇ تحميل بقوا فوق الصورة نفسها (كانوا على الجنب)
                val tb = YtThumbBtns.attach(act, ui, box, 30)
                hd = Hold(th0, dur, title, meta, box, col, tb.row, tb.aud, tb.dl); row.tag = hd; v = row
            } else { v = cv; hd = cv.tag as Hold }
            val it = items[p]
            // (v354) أنيميشن سلس: لو الصف لسه بيظهر من عرض جديد (أول 9 صفوف) بيدخل fade + slide بتتابع، غير كده بيتصفّر من أي أنيميشن قديم
            v.animate().cancel()
            if (animRows && p < 9) {
                v.alpha = 0f; v.translationY = ui.dp(22).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(p * 38L).setDuration(Skins.dur(300L)).setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start()
            } else { v.alpha = 1f; v.translationY = 0f }
            hd.title.text = it.title
            val cm = it.kind == 3 || it.kind == 4 || it.id == "act"
            hd.box.visibility = if (cm) View.GONE else View.VISIBLE
            val vid = it.kind == 0 && it.id.isNotBlank()
            hd.btns.visibility = if (vid) View.VISIBLE else View.GONE
            if (vid) { val item = it; YtThumbBtns.bind(hd.aud, hd.dl, item.id, { playAudio(item) }, { dlMenu(hd.dl, item) }) }
            hd.title.maxLines = if (cm) 10 else 2
            (hd.col.layoutParams as LinearLayout.LayoutParams).height = if (cm) -2 else ui.dp(85)
            val seen = it.kind == 0 && recs().containsKey("yt:" + it.id)
            hd.title.alpha = if (seen) 0.6f else 1f
            hd.meta.text = when (it.kind) {
                4 -> listOf("📝 بوست", it.channel, it.age).filter { s -> s.isNotBlank() }.joinToString(" · ")
                3 -> listOf(it.channel, if (it.count > 0) "♥ " + fmtN(it.count) else "", it.age).filter { s -> s.isNotBlank() }.joinToString(" · ")
                0 -> listOf(if (YtRss.isShort(it.id)) "🩳 شورتس" else "", it.channel, if (it.count >= 0) fmtN(it.count) + " مشاهدة" else "", it.age).filter { s -> s.isNotBlank() }.joinToString(" · ")
                1 -> "📺 قناة" + if (it.count >= 0) " · " + fmtN(it.count) + " مشترك" else ""
                2 -> if (it.id == "act") it.channel else "📃 قايمة" + (if (it.channel.isNotBlank()) " · " + it.channel else "") + if (it.count >= 0) " · " + it.count + " فيديو" else ""
                else -> "📃 قايمة" + (if (it.channel.isNotBlank()) " · " + it.channel else "") + if (it.count >= 0) " · " + it.count + " فيديو" else ""
            }
            if (cm) return v
            val d = if (it.kind == 0) fmtDur(it.dur) else if (it.kind == 2 && it.id != "act") "☰ " + act.getString(R.string.yt_playlist_badge) else ""   // (v1300) بادج القايمة على الصورة
            hd.dur.text = d; hd.dur.visibility = if (d.isEmpty()) View.GONE else View.VISIBLE
            try { if (it.thumb.isNotBlank()) Glide.with(act).load(it.thumb).centerCrop().override(ui.dp(300), ui.dp(170)).into(hd.thumb) else Glide.with(act).clear(hd.thumb) } catch (_: Throwable) {}
            return v
        }
    }
}

/** (v865) معلومات الشورتس اللي اتجمّعت في أرفف (id ← العنصر) عشان الرف يعرض عناوينها */
private val shortInfo = java.util.concurrent.ConcurrentHashMap<String, NpItem>()
private fun isShortLike(x: NpItem): Boolean = YtRss.isShort(x.id) || x.dur in 1L..60L

/** (v865) كل 4 شورتس متتالية في الترتيب الزمني ← رف واحد (kind = 5) في مكان أحدث واحد فيهم؛ الباقي بيتشال من مكانه */
private fun shelfify(src: List<NpItem>): ArrayList<NpItem> {
    val shorts = src.filter { it.kind == 0 && isShortLike(it) }
    if (shorts.isEmpty()) return ArrayList(src)
    val groups = shorts.chunked(4)
    val groupOf = HashMap<String, Int>()
    groups.forEachIndexed { gi, g -> g.forEach { groupOf[it.id] = gi; shortInfo[it.id] = it } }
    val placed = HashSet<Int>(); val out = ArrayList<NpItem>(src.size)
    for (x in src) {
        val gi = if (x.kind == 0) groupOf[x.id] else null
        if (gi == null) { out.add(x); continue }
        if (placed.add(gi)) {
            val g = groups[gi]
            out.add(NpItem(g[0].id, "شورتس", "", "", "", -1L, -1L, g[0].age, 5, "ytshelf:" + g.joinToString(",") { it.id }, g[0].ts))
        }
    }
    return out
}

/** (v864) فلتر نوع الاشتراكات: 1 فيديوهات · 2 شورتس · 3 بوستات */
private fun typeOk(it: NpItem, f: Int): Boolean = when (f) {
    1 -> it.kind == 0 && !isShortLike(it)
    2 -> it.kind == 0 && isShortLike(it)
    3 -> it.kind == 4
    else -> true
}
