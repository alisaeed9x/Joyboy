package com.tttt.subtitler

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * (v518) تحديث التلفزيون من الموبايل على الواي فاي:
 * الموبايل بيعرض نسخته (ملف الـAPK بتاعه بيوزّعه هو) ← التلفزيون بيسألك «تحديث؟» ← ينزّل ← شاشة تثبيت أندرويد.
 * أندرويد بيطلّع شاشة تأكيد التثبيت على التلفزيون (مفيش تثبيت صامت) ومحتاج صلاحية «تثبيت تطبيقات غير معروفة» مرة واحدة.
 * الـAPK لازم يكون متوقّع بنفس مفتاح التوقيع (ده بيحصل أصلًا في بناء GitHub).
 */
object TvUpdate {
    private val h = Handler(Looper.getMainLooper())
    @Volatile var pendingApk: File? = null
    @Volatile private var downloading = false
    /** (v563) رسالة آخر تنضيف للملفات القديمة (TvModeFab بيعرضها مرة وبيصفّرها) */
    @Volatile var cleanMsg: String? = null

    private fun vcode(pi: android.content.pm.PackageInfo): Long = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()

    /** (v563) لو الملف المنزّل قبل كده كامل وسليم (الحجم = حجم الموبايل + بيتقرا كـAPK + نفس الحزمة والنسخة المعروضة) بيرجّعه؛ غير كده null (ناقص/نسخة تانية ← يتنزّل من جديد) */
    fun readyFile(ctx: Context, o: TvLink.Offer): File? {
        return try {
            val f = File(ctx.cacheDir, "tv_update.apk")
            if (downloading || !f.isFile || f.length() < 100_000L) return null
            if (o.size > 0L && f.length() != o.size) return null
            val pi = ctx.packageManager.getPackageArchiveInfo(f.path, 0) ?: return null
            if (pi.packageName != ctx.packageName || vcode(pi) != o.ver) return null
            f
        } catch (_: Throwable) { null }
    }

    /** (v688) رقم الإصدار بس («6.88») — رقم البناء (#29123456) اتشال من نوافذ التحديث */
    fun verLabel(name: String, @Suppress("UNUSED_PARAMETER") code: Long): String = name

    /** (v657) النسخة القديمة (أحمر) ← سهم ← النسخة الجديدة (أخضر) — بتظهر في كل نوافذ التحديث */
    fun flowView(a: Context, oldName: String, newName: String): View {
        val th = Glass.theme(); val d = a.resources.displayMetrics.density
        val big = try { TvFocus.onCtx(a) } catch (_: Throwable) { false }
        fun box(label: String, v: String, c: Int) = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding((14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt(), (10 * d).toInt())
            background = GradientDrawable().apply { setColor((c and 0x00FFFFFF) or 0x26000000); cornerRadius = 14 * d; setStroke((2 * d).toInt(), c) }
            addView(TextView(a).apply { text = label; textSize = if (big) 14f else 12f; setTextColor(th.muted); gravity = Gravity.CENTER })
            addView(TextView(a).apply { text = v.ifEmpty { "?" }; textSize = if (big) 28f else 22f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(c); gravity = Gravity.CENTER })
        }
        val arrow = object : View(a) {
            private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            override fun onDraw(c: android.graphics.Canvas) {
                val w = width.toFloat(); val cy = height / 2f; val s = 7f * d
                p.style = android.graphics.Paint.Style.STROKE; p.strokeWidth = 3f * d; p.strokeCap = android.graphics.Paint.Cap.ROUND; p.color = th.text
                c.drawLine(w - 2f * d, cy, 3f * d, cy, p)          // من اليمين (القديم) لليسار (الجديد)
                c.drawLine(3f * d, cy, 3f * d + s * 1.4f, cy - s, p); c.drawLine(3f * d, cy, 3f * d + s * 1.4f, cy + s, p)
            }
        }
        return LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER
            setPadding(0, (10 * d).toInt(), 0, (6 * d).toInt())
            addView(box("الحالية", oldName, th.danger))
            addView(arrow, LinearLayout.LayoutParams((56 * d).toInt(), (40 * d).toInt()).apply { setMargins((6 * d).toInt(), 0, (6 * d).toInt(), 0) })
            addView(box("الجديدة", newName, th.success))
        }
    }


    /**
     * (v563) تنضيف ملفات التحديث القديمة (APK) من مجلدات التطبيق نفسه (الكاش والملفات الداخلية/الخارجية الخاصة بيه) — مفيش وصول لأي مكان تاني.
     * بيتشال: المتثبّت نسخته (أو أقدم) · الناقص/التالف · ملف حزمة تانية (اللانشر/push_apk). بيفضل: تحديث نسخته أحدث من المتثبّت لسه ما اتثبّتش.
     * أي ملف أحدث من 30 دقيقة ما بيتلمسش (ممكن لسه بيتنزّل/بيتوزّع). لو مفيش وصول لمجلد أو الملف رفض يتمسح ← بيتخطّى (مابنحاولش بطريقة تانية).
     */
    fun cleanOld(ctx: Context) {
        if (downloading) return
        try {
            val installed = LinkVer.code(ctx)
            var n = 0; var bytes = 0L; var denied = 0
            val dirs = listOfNotNull(ctx.cacheDir, ctx.filesDir, try { ctx.externalCacheDir } catch (_: Throwable) { null }, try { ctx.getExternalFilesDir(null) } catch (_: Throwable) { null })
            for (d in dirs) {
                val fs = (try { d.listFiles() } catch (_: Throwable) { null }) ?: continue
                for (f in fs) {
                    val nm = f.name.lowercase()
                    if (!f.isFile || !nm.endsWith(".apk") || !(nm.startsWith("tv_update") || nm.startsWith("push_apk") || nm.contains("update"))) continue
                    if (System.currentTimeMillis() - f.lastModified() < 30L * 60000L) continue
                    val pi = try { ctx.packageManager.getPackageArchiveInfo(f.path, 0) } catch (_: Throwable) { null }
                    if (pi != null && pi.packageName == ctx.packageName && vcode(pi) > installed) continue   // تحديث لسه مستني التثبيت
                    val sz = f.length()
                    if (f.delete()) { n++; bytes += sz } else denied++
                }
            }
            val msg = if (n > 0 || denied > 0) "🧹 ملفات التحديث القديمة: اتمسح " + n + " (" + (bytes / 1048576L) + " MB)" + (if (denied > 0) " — و" + denied + " ما قدرتش أمسحهم (مفيش صلاحية)" else "") else ""
            if (msg.isNotEmpty()) { LogStore.add(msg); cleanMsg = msg }
        } catch (e: Throwable) { LogStore.err("TvUpdate:clean", e) }
    }

    fun ask(a: Activity, o: TvLink.Offer, done: (Boolean) -> Unit) {
        try {
            GAlert(a).setTitle("⬆ تحديث من الموبايل").setView(flowView(a, verLabel(LinkVer.name(a), LinkVer.code(a)), verLabel(o.vname, o.ver)))
                .setMessage(if (o.force) "«" + o.from + "» بيدفع تحديث إجباري: Subtitler " + o.vname + " (على التلفزيون دلوقتي: " + LinkVer.name(a) + ").\nتنزّله وتثبّته دلوقتي من الموبايل على الواي فاي؟" else "«" + o.from + "» عليه Subtitler " + o.vname + " (أحدث من اللي على التلفزيون: " + LinkVer.name(a) + ").\nتنزّله دلوقتي من الموبايل على الواي فاي؟")
                .setPositiveButton("تحديث") { _, _ -> done(true); download(a, o) }
                .setNegativeButton("لاحقًا") { _, _ -> done(false) }
                .setOnCancelListener { done(false) }
                .show()
        } catch (e: Throwable) { LogStore.err("TvUpdate:ask", e); done(false) }
    }

    fun download(a: Activity, o: TvLink.Offer) {
        if (downloading) return   // (v573) تنزيل شغّال بالفعل (دفع تاني أو رجوع الشاشة) ← ما نبدأش واحد تاني
        readyFile(a, o)?.let { rf ->   // (v563) موجود كامل: من غير تنزيل
            // (v680) على التلفزيون: من كذا لكذا (الإصدار + رقم التحديث)، والتثبيت يبدأ لوحده بعد ثواني أو بالزرار
            try {
                var went = false
                val go = { if (!went) { went = true; install(a, rf) } }
                val dlg = GAlert(a).setTitle("✅ التحديث موجود كامل").setView(flowView(a, verLabel(LinkVer.name(a), LinkVer.code(a)), verLabel(o.vname, o.ver)))
                    .setPositiveButton("تثبيت الآن") { _, _ -> go() }.setNegativeButton("إلغاء") { _, _ -> went = true }.create()
                dlg.show()
                h.postDelayed({ try { if (!went) { dlg.dismiss(); go() } } catch (_: Throwable) {} }, 3500L)
            } catch (e: Throwable) { LogStore.err("TvUpdate:ready", e); install(a, rf) }
            return
        }
        val tv = IconTextView(a).apply {
            textSize = 16f
            setTextColor(Themes.byId(Cfg.str("theme", "mx")).text)
            LoadUi.set(this, "⏳ بتواصل مع الموبايل…")
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val p = (16 * a.resources.displayMetrics.density).toInt(); setPadding(p, p, p, p)
        }
        // (v531) شريط تقدّم حقيقي تحت النسبة والميجات (قبل كده كان نص بس)
        val dd = a.resources.displayMetrics.density
        val bar = android.widget.ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000; isIndeterminate = true
            try { progressTintList = android.content.res.ColorStateList.valueOf(Themes.byId(Cfg.str("theme", "mx")).primary) } catch (_: Throwable) {}
        }
        val boxV = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            // (v680) من كذا لكذا: إصدار + رقم التحديث الحاليين على التلفزيون ← الجديدين اللي جايين من الموبايل
            try { addView(flowView(a, verLabel(LinkVer.name(a), LinkVer.code(a)), verLabel(o.vname, o.ver)), LinearLayout.LayoutParams(-1, -2).apply { setMargins((12 * dd).toInt(), (6 * dd).toInt(), (12 * dd).toInt(), 0) }) } catch (_: Throwable) {}
            addView(tv, LinearLayout.LayoutParams(-1, -2))
            addView(bar, LinearLayout.LayoutParams(-1, (14 * dd).toInt()).apply { setMargins((16 * dd).toInt(), 0, (16 * dd).toInt(), (16 * dd).toInt()) })
        }
        var cancelled = false
        // (v1052) تصغير: الشاشة تتحوّل لكبسولة صغيرة فوق (تقدّم + الوقت الباقي + سرعة النت)، والدوسة عليها بترجّع الشاشة الكاملة
        var dlg: android.app.Dialog? = null
        var capsule: FrameLayout? = null
        var capTv: TextView? = null
        var capBar: android.widget.ProgressBar? = null
        var finished = false
        fun removeCapsule() {
            try { capsule?.let { (it.parent as? ViewGroup)?.removeView(it) } } catch (_: Throwable) {}
            capsule = null; capTv = null; capBar = null
        }
        lateinit var showFull: () -> Unit
        fun minimize() {
            try {
                if (finished) return
                val big = try { TvFocus.onCtx(a) } catch (_: Throwable) { false }
                val th = Themes.byId(Cfg.str("theme", "mx"))
                val t = TextView(a).apply { text = "⬇ التحديث…"; textSize = if (big) 16f else 13f; setTextColor(th.text); gravity = Gravity.CENTER; maxLines = 1; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                val b = android.widget.ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 1000; isIndeterminate = bar.isIndeterminate; progress = bar.progress
                    try { progressTintList = android.content.res.ColorStateList.valueOf(th.primary) } catch (_: Throwable) {}
                }
                val inner = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                    val ph = (14 * dd).toInt(); val pv = (7 * dd).toInt(); setPadding(ph, pv, ph, pv)
                    background = GradientDrawable().apply { setColor((th.card and 0x00FFFFFF) or 0xF2000000.toInt()); cornerRadius = 22 * dd; setStroke((1 * dd).toInt(), th.primary) }
                    addView(t, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
                    addView(b, LinearLayout.LayoutParams(((if (big) 340 else 230) * dd).toInt(), (5 * dd).toInt()).apply { topMargin = (4 * dd).toInt(); gravity = Gravity.CENTER_HORIZONTAL })
                }
                val fl = FrameLayout(a).apply {
                    isClickable = true; isFocusable = true; elevation = 24 * dd
                    addView(inner, FrameLayout.LayoutParams(-2, -2))
                    setOnClickListener { removeCapsule(); showFull() }
                }
                val root = a.window.decorView as ViewGroup
                root.addView(fl, FrameLayout.LayoutParams(-2, -2).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; topMargin = (14 * dd).toInt() })
                capsule = fl; capTv = t; capBar = b
            } catch (e: Throwable) { LogStore.err("TvUpdate:min", e); removeCapsule(); showFull() }
        }
        showFull = {
            dlg = try {
                GAlert(a).setTitle("⬇ تنزيل التحديث").setView(boxV).setCancelable(false)
                    .setNeutralButton("▁ تصغير") { _, _ -> minimize() }
                    .setNegativeButton("إلغاء") { _, _ -> cancelled = true }.create().also { it.show() }
            } catch (e: Throwable) { LogStore.err("TvUpdate:dlg", e); null }
        }
        minimize()   // (v1053) التنزيل بيبدأ كبسولة صغيرة علطول — الدوسة عليها بتفتح الشاشة الكاملة (فيها إلغاء)
        Thread {
            val f = File(a.cacheDir, "tv_update.apk")
            var ok = false; var msg = ""
            downloading = true
            try {
                // (v1348) التلفزيون بينزّل النسخة المناسبة ليه من النت من نفس فيرجن الموبايل (بطلب علي) — لو النت فشل أو الفيرجن مش موجود: لينك الموبايل على الواي فاي زي الأول
                var src = o.url
                h.post { try { tv.text = "⏳ بيجيب لينك نسخة التلفزيون من النت…" } catch (_: Throwable) {} }
                val np = resolveNet(o)
                if (np != null) {
                    src = np.first
                    h.post { try { tv.text = "⬇ بينزّل نسخة التلفزيون من النت…" } catch (_: Throwable) {} }
                }
                try { f.delete() } catch (_: Exception) {}
                val c = URL(src).openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 15000
                if (c.responseCode != 200) throw IOException((if (np != null) "رد النت " else "رد الموبايل ") + c.responseCode)
                val total = c.contentLengthLong
                c.inputStream.use { ins ->
                    FileOutputStream(f).use { out ->
                        val buf = ByteArray(65536)
                        var got = 0L; var lastUi = 0L
                        val t0 = System.currentTimeMillis(); var spT = t0; var spB = 0L; var spd = 0.0   // (v564) سرعة مُلَسَّنة (بايت/ثانية)
                        while (true) {
                            if (cancelled) throw IOException("اتلغى")
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); got += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 400L) {
                                lastUi = now
                                val g = got
                                val dt = now - spT
                                if (dt >= 800L) { val inst = (g - spB) * 1000.0 / dt; spd = if (spd <= 0.0) inst else spd * 0.6 + inst * 0.4; spT = now; spB = g }
                                val sp = spd
                                val etaS = if (sp > 1.0 && total > g) ((total - g) / sp).toLong() else -1L
                                val elapsedS = (now - t0) / 1000L
                                val info = "\n⏱ المتبقي: " + (if (etaS >= 0) etaS.toString() + " ثانية" else "بحسب…") + "   •   🚀 السرعة: " + (if (sp > 1.0) String.format(java.util.Locale.US, "%.1f MB/s", sp / 1048576.0) else "…") + "   •   مضى: " + elapsedS + " ث"
                                h.post {
                                    tv.text = "⬇ " + (if (total > 0) (g * 100 / total).toString() + "%   " else "") + (g / 1048576L) + " / " + (total / 1048576L) + " MB" + info
                                    if (total > 0) { bar.isIndeterminate = false; bar.progress = (g * 1000L / total).toInt().coerceIn(0, 1000) }
                                    capTv?.text = "⬇ " + (if (total > 0) (g * 100 / total).toString() + "%" else (g / 1048576L).toString() + " MB") +
                                        "  ·  ⏱ " + (if (etaS >= 0) (if (etaS >= 60) (etaS / 60).toString() + "د " + (etaS % 60) + "ث" else etaS.toString() + "ث") else "…") +
                                        "  ·  🚀 " + (if (sp > 1.0) String.format(java.util.Locale.US, "%.1f MB/s", sp / 1048576.0) else "…")
                                    capBar?.let { cb -> if (total > 0) { cb.isIndeterminate = false; cb.progress = bar.progress } }
                                }
                            }
                        }
                    }
                }
                if (total > 0 && f.length() != total) throw IOException("الملف ناقص")
                ok = true
            } catch (e: Exception) { msg = e.message ?: "فشل"; try { f.delete() } catch (_: Exception) {} }
            finally { downloading = false }
            h.post {
                finished = true
                try { dlg?.dismiss() } catch (_: Throwable) {}
                removeCapsule()
                if (ok) install(a, f) else if (!cancelled) Notice.show(a, "⚠ التحديث فشل: $msg", 3500L) else if (!o.force) TvLink.declineOffer(o)   // (v573) إلغاء التنزيل ← ما يعرضش نفس النسخة أوتوماتيك تاني
            }
        }.also { it.isDaemon = true }.start()
    }

    /** (v1348) بيدوّر في ريليزات GitHub على نفس فيرجن الموبايل (vname) وبيرجّع لينك وحجم الـAPK المناسب لمعمارية التلفزيون — null لو النت فشل أو الفيرجن مش موجود (بنرجع للينك الموبايل) */
    private fun resolveNet(o: TvLink.Offer): Pair<String, Long>? {
        return try {
            val want = UpdateSheet.verParts(o.vname)
            if (want.isEmpty()) return null
            val c = URL("https://api.github.com/repos/alisaeed9x/Joyboy/releases?per_page=30").openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 7000; c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("User-Agent", "Joyboy")
                if (c.responseCode != 200) return null
                val arr = org.json.JSONArray(c.inputStream.bufferedReader().readText())
                for (i in 0 until arr.length()) {
                    val rel = arr.optJSONObject(i) ?: continue
                    if (rel.optBoolean("draft")) continue
                    val got = UpdateSheet.verParts(rel.optString("name"))
                    if (got.size < 2 || !sameVer(got, want)) continue
                    val pick = UpdateSheet.pickApkAsset(rel.optJSONArray("assets"))   // (v1302) اختيار معمارية الجهاز — هنا التلفزيون
                    if (pick.first.isNotBlank()) return pick
                }
                null
            } finally { try { c.disconnect() } catch (_: Throwable) {} }
        } catch (_: Throwable) { null }
    }

    private fun sameVer(a: List<Int>, b: List<Int>): Boolean { val n = maxOf(a.size, b.size); for (i in 0 until n) if (a.getOrElse(i) { 0 } != b.getOrElse(i) { 0 }) return false; return true }

    fun install(a: Activity, f: File) {
        PermAsk.installApps(a, { doInstall(a, f) }, { })
    }

    private fun doInstall(a: Activity, f: File) {
        try {
            pendingApk = null
            val uri = FileProvider.getUriForFile(a, a.packageName + ".fmprov", f)
            a.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Throwable) { LogStore.err("TvUpdate:install", e); Notice.show(a, "⚠ ما قدرتش أبدأ التثبيت", 3000L) }
    }

    /** بيتنادى لما أي شاشة ترجع قدّام: لو كنا مستنيين صلاحية التثبيت وبقت متاحة نكمل */
    fun resumePending(a: Activity) {
        val f = pendingApk ?: return
        try {
            if (Build.VERSION.SDK_INT >= 26 && a.packageManager.canRequestPackageInstalls() && f.isFile) install(a, f)
        } catch (_: Throwable) {}
    }
}

/** (v518) شاشة «ريموت الموبايل» على التلفزيون: العنوان + كود الإقران + الريموتات المتصلة (فصل / مسح) */
object TvLinkUi {
    fun show(a: Activity) {
        try {
            TvLink.start(a)
            val th = Themes.byId(Cfg.str("theme", "mx")); val ui = Ui(a, th)
            val code = TvLink.newCode()
            val col = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(ui.dp(18), ui.dp(8), ui.dp(18), ui.dp(8))
            }
            val addr = TvLink.address()
            col.addView(ui.text(if (addr.isEmpty()) "⚠ مش متصل بواي فاي" else "عنوان التلفزيون: $addr", 14f, th.muted))
            col.addView(ui.text("افتح Subtitler على الموبايل (أيقونة «ريموت التلفزيون») — هيلاقي التلفزيون لوحده. أي موبايل جديد بيطلب الكود الجاي تحت (أو بيظهر على الشاشة أول ما يحاول).", 13f, th.text).apply { setPadding(0, ui.dp(8), 0, ui.dp(8)) })
            col.addView(ui.text("كود إقران موبايل جديد (10 دقايق):", 13f, th.muted))
            col.addView(ui.text(code, 30f, th.primary, true).apply { setPadding(0, ui.dp(4), 0, ui.dp(10)) })
            // (v598) QR للاقتران لو الاتصال التلقائي فشل: الموبايل ← ريموت التلفزيون ← «📷 امسح QR»
            val tvIp = TypeServer.ip()
            if (tvIp.isNotEmpty()) {
                val qr = QrCode.bitmap("subtitler://pair?h=" + tvIp + "&p=" + TvLink.PORT + "&c=" + code, ui.dp(200))
                if (qr != null) {
                    col.addView(android.widget.ImageView(a).apply { setImageBitmap(qr); setBackgroundColor(Color.WHITE); setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8)) }, LinearLayout.LayoutParams(ui.dp(200), ui.dp(200)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = ui.dp(6) })
                    col.addView(ui.noHint().apply { setPadding(0, 0, 0, ui.dp(10)) })
                }
            }
            // (v519) التحكم في التطبيقات التانية (نتفليكس…) محتاج «إمكانية الوصول» مرة واحدة
            val accOn = TvAccess.connected
            col.addView(ui.text(if (accOn) "✅ التحكم في التطبيقات التانية شغّال (إمكانية الوصول)" else "⚠ التحكم بالأسهم والتاتش باد في التطبيقات التانية متوقّف — الصوت والتشغيل والرئيسية شغّالين", 13f, if (accOn) th.success else th.danger).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
            if (!accOn) col.addView(ui.button("♿ فعّل «إمكانية الوصول» لـ Subtitler") { TvAccess.openSettings(a) })
            val list = TvLink.remoteList()
            col.addView(ui.text(if (list.isEmpty()) "لسه مفيش ريموتات مقترنة." else "الريموتات المقترنة (دوس على واحد للفصل أو المسح):", 14f, th.text, true))
            lateinit var dlg: android.app.Dialog
            for (r in list) {
                val on = r.alive()
                col.addView(ui.button((if (on) "🟢 " else "⚪ ") + r.name + (if (on) " — متصل" else " — مش متصل")) {
                    try { dlg.dismiss() } catch (_: Throwable) {}
                    manage(a, r.id, r.name)
                })
            }
            dlg = GAlert(a).setTitle("📱 ريموت الموبايل").setView(col).setNegativeButton("إغلاق", null).create()
            dlg.show()
        } catch (e: Throwable) { LogStore.err("TvLinkUi:show", e) }
    }

    private fun manage(a: Activity, id: String, name: String) {
        GAlert(a).setTitle(name).setItems(arrayOf("⛔ فصل دلوقتي (يرجع لو دوس اتصال)", "🗑 مسح من المقترنين (يحتاج كود تاني)")) { _, i ->
            if (i == 0) TvLink.kick(id) else TvLink.forget(id)
        }.setNegativeButton("إلغاء", null).show()
    }
}
