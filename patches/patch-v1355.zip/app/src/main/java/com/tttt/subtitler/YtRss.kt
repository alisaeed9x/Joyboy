package com.tttt.subtitler

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.OffsetDateTime
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/**
 * (v327) فيد الاشتراكات بـ RSS: https://www.youtube.com/feeds/videos.xml?channel_id=UC…
 * خفيف (طلب واحد صغير لكل قناة) ووقت الرفع دقيق. كاش لكل قناة في الذاكرة + ملف (filesDir/yt_rss.json).
 * القناة اللي مالهاش معرّف UC… أو فشل الـ RSS بتاعها ومفيش كاش → بنرجع للطريقة البطيئة (NewPipe channel()).
 */
object YtRss {
    const val TTL_MS = 30 * 60 * 1000L   // (v792) 15->30 دقيقة: نص الطلبات عند فتح التطبيق
    private const val MAX_CH = 1000   // (v756) كان 300 (و120 قبلها) ← اشتراكات كتير كانت بتتقصّ
    private const val PER_CH = 15   // (v863) كان 8 — RSS بيرجّع لحد 15، وقناة بتنزّل كتير كانت بتفوّتك فيديوهات
    private val RX = Regex("/channel/(UC[A-Za-z0-9_-]{22})")

    private class Entry(val t: Long, val items: List<NpItem>)
    private val mem = HashMap<String, Entry>()
    @Volatile private var dir: File? = null
    @Volatile private var loaded = false

    fun attach(c: Context) { if (dir == null) dir = c.applicationContext.filesDir }

    fun chanId(url: String): String? = RX.find(url)?.groupValues?.get(1) ?: YtChanId.cachedOnly(url)   // (v469) C2: معرّف محفوظ لقنوات @handle

    // ───────── كاش الملف ─────────
    @Synchronized private fun loadDisk() {
        if (loaded) return
        loaded = true
        try {
            val f = File(dir ?: return, "yt_rss2.json"); if (!f.isFile) return
            val o = JSONObject(f.readText())
            for (k in o.keys()) {
                val e = o.getJSONObject(k); val a = e.getJSONArray("i"); val l = ArrayList<NpItem>()
                for (n in 0 until a.length()) {
                    val x = a.getJSONObject(n)
                    l.add(mk(x.optString("i"), x.optString("t"), x.optString("c"), x.optString("u"), x.optLong("p"), x.optLong("v", -1L)).also { if (x.optInt("s", 0) == 1) shortIds.add(it.id) })
                }
                mem[k] = Entry(e.optLong("t"), l)
            }
        } catch (_: Throwable) {}
    }

    @Synchronized private fun saveDisk(keep: Set<String>) {
        try {
            val d = dir ?: return
            val o = JSONObject()
            for ((k, e) in mem) {
                if (k !in keep) continue
                val a = JSONArray()
                for (it in e.items) a.put(JSONObject().put("i", it.id).put("t", it.title).put("c", it.channel).put("u", it.channelUrl).put("p", it.ts).put("v", it.count).put("s", if (it.id in shortIds) 1 else 0))
                o.put(k, JSONObject().put("t", e.t).put("i", a))
            }
            val tmp = File(d, "yt_rss2.json.tmp"); tmp.writeText(o.toString()); tmp.renameTo(File(d, "yt_rss2.json"))
        } catch (_: Throwable) {}
    }

    private fun mk(id: String, title: String, ch: String, chUrl: String, ts: Long, views: Long) =
        NpItem(id, title, ch, chUrl, "https://i.ytimg.com/vi/$id/mqdefault.jpg", -1L, views, ageOf(ts), 0, "https://www.youtube.com/watch?v=$id", ts)

    /** «منذ 3 أيام» من وقت دقيق */
    /** (v864) معرّفات الشورتس اللي اتشافت في RSS (بتتحفظ في الكاش) */
    val shortIds: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet<String>())
    fun isShort(id: String): Boolean = id in shortIds || id in YtAccount.shorts
    fun ageOf(ts: Long): String {
        if (ts <= 0L) return ""
        val s = (System.currentTimeMillis() - ts) / 1000L
        if (s < 0) return ""
        fun u(n: Long, one: String, two: String, few: String, many: String): String =
            "منذ " + when { n == 1L -> one; n == 2L -> two; n in 3L..10L -> "$n $few"; else -> "$n $many" }
        return when {
            s < 60 -> "الآن"
            s < 3600 -> u(s / 60, "دقيقة", "دقيقتين", "دقائق", "دقيقة")
            s < 86400 -> u(s / 3600, "ساعة", "ساعتين", "ساعات", "ساعة")
            s < 86400 * 30 -> u(s / 86400, "يوم", "يومين", "أيام", "يومًا")
            s < 86400 * 365 -> u(s / (86400 * 30), "شهر", "شهرين", "شهور", "شهرًا")
            else -> u(s / (86400 * 365), "سنة", "سنتين", "سنين", "سنة")
        }
    }

    // ───────── تحميل وتحليل RSS ─────────
    // (v792) GET شرطي: ETag/Last-Modified محفوظين على القرص → لو مفيش جديد السيرفر يرد 304 (~300 بايت بدل ~15 ك.ب لكل قناة)
    private class NotModified : RuntimeException("304")
    private val valid = HashMap<String, Pair<String, String>>()   // url -> (etag, lastModified)
    @Volatile private var validLoaded = false
    @Synchronized private fun loadValid() {
        if (validLoaded) return
        validLoaded = true
        try {
            val f = File(dir ?: return, "yt_rss_v.json"); if (!f.isFile) return
            val o = JSONObject(f.readText())
            for (k in o.keys()) { val a = o.getJSONArray(k); valid[k] = Pair(a.optString(0), a.optString(1)) }
        } catch (_: Throwable) {}
    }
    @Synchronized private fun saveValid(keepIds: Set<String>) {
        try {
            val d = dir ?: return
            val o = JSONObject()
            for ((k, v) in valid) { if (keepIds.none { k.contains(it) || k.contains("UU" + it.substring(2)) }) continue; o.put(k, JSONArray().put(v.first).put(v.second)) }
            val tmp = File(d, "yt_rss_v.json.tmp"); tmp.writeText(o.toString()); tmp.renameTo(File(d, "yt_rss_v.json"))
        } catch (_: Throwable) {}
    }
    private fun http(url: String, cond: Boolean = false): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 6000; c.readTimeout = 9000   // (v354) ????: ?????? ??????? ?? ?????? ????? ???
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
        if (cond) synchronized(this) { valid[url] }?.let { v ->
            if (v.first.isNotEmpty()) c.setRequestProperty("If-None-Match", v.first)
            if (v.second.isNotEmpty()) c.setRequestProperty("If-Modified-Since", v.second)
        }
        try {
            val code = c.responseCode
            if (code == 304) throw NotModified()
            if (code != 200) throw RuntimeException("RSS " + code)
            val et = c.getHeaderField("ETag") ?: ""; val lm = c.getHeaderField("Last-Modified") ?: ""
            if (et.isNotEmpty() || lm.isNotEmpty()) synchronized(this) { valid[url] = Pair(et, lm) }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    fun parse(xml: String, chUrl: String): List<NpItem> {
        val p = Xml.newPullParser(); p.setInput(xml.reader())
        val out = ArrayList<NpItem>()
        var inEntry = false; var inAuthor = false
        var id = ""; var title = ""; var pub = ""; var views = -1L; var author = ""; var feedAuthor = ""; var isShort = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name) {
                    "entry" -> { inEntry = true; id = ""; title = ""; pub = ""; views = -1L; author = ""; isShort = false }
                    "link" -> if (inEntry && (p.getAttributeValue(null, "href") ?: "").contains("/shorts/")) isShort = true   // (v863) رابط الشورتس في RSS بيبقى /shorts/ID
                    "author" -> inAuthor = true
                    "yt:videoId" -> if (inEntry) id = p.nextText().trim()
                    "title" -> if (inEntry) title = p.nextText().trim()
                    "published" -> if (inEntry) pub = p.nextText().trim()
                    "name" -> if (inAuthor) { val n = p.nextText().trim(); if (inEntry) author = n else feedAuthor = n }
                    "media:statistics" -> if (inEntry) views = p.getAttributeValue(null, "views")?.toLongOrNull() ?: -1L
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name) {
                    "author" -> inAuthor = false
                    "entry" -> {
                        inEntry = false
                        if (id.isNotEmpty()) {
                            if (isShort || title.contains("#shorts", true)) shortIds.add(id)   // (v864) الشورتس بتظهر (بعلامة) مش بتتشال
                            val ts = try { OffsetDateTime.parse(pub).toInstant().toEpochMilli() } catch (_: Throwable) { 0L }
                            out.add(mk(id, title, author.ifEmpty { feedAuthor }, chUrl, ts, views))
                        }
                    }
                }
            }
            ev = p.next()
        }
        return out
    }

    /** (v471) RSS يوتيوب بيرجّع 404/500 عشوائي لقنوات سليمة — كان فشل واحد = القناة تختفي من الفيد. دلوقتي: لو فشل رابط القناة بنجرّب رابط قايمة «الرفع» (UU…)
     *  وبنعيد مرة واحدة؛ وأخطاء الشبكة (مفيش نت/مهلة) ما بنكرّرهاش عشان ما نعلّقش. */
    private fun getFeed(cid: String, chUrl: String, cond: Boolean = false): List<NpItem> {
        loadValid()
        val urls = listOf("https://www.youtube.com/feeds/videos.xml?channel_id=$cid", "https://www.youtube.com/feeds/videos.xml?playlist_id=UU" + cid.substring(2))
        var last: Throwable? = null
        for (round in 0..1) {
            for (u in urls) {
                try { return parse(http(u, cond), chUrl).take(PER_CH) }
                catch (t: NotModified) { throw t }
                catch (t: java.net.UnknownHostException) { throw t }
                catch (t: java.net.ConnectException) { throw t }
                catch (t: java.net.SocketTimeoutException) { last = t; break }
                catch (t: Throwable) { last = t }
            }
            if (round == 0) try { Thread.sleep(300L + (Math.random() * 300L).toLong()) } catch (_: Throwable) {}
        }
        throw last ?: RuntimeException("RSS")
    }

    // (v1174) الرجوع لـNewPipe (صفحة القناة كاملة = تقيل): كان بيتكرر مع كل تحديث للقنوات اللي من غير معرّف UC أو اللي RSS بتاعها فشل.
    // دلوقتي: نتيجته بتتكاشّى 30 دقيقة، ومعرّف القناة بيتحفظ عشان المرة الجاية تتحدّث بـRSS الخفيف.
    private val fbMem = HashMap<String, Entry>()
    private fun fbCached(chUrl: String): List<NpItem>? {
        val e = synchronized(this) { fbMem[chUrl] } ?: return null
        return if (System.currentTimeMillis() - e.t < TTL_MS) e.items else null
    }
    private fun fbFetch(chUrl: String): List<NpItem> {
        YtNp.init()
        val items = YtNp.channel(chUrl).first.items.filter { it.kind == 0 }.take(6)
        synchronized(this) { fbMem[chUrl] = Entry(System.currentTimeMillis(), items) }
        try {
            items.firstNotNullOfOrNull { it.channelId.takeIf { c -> c.startsWith("UC") } ?: RX.find(it.channelUrl)?.groupValues?.get(1) }?.let { YtChanId.put(chUrl, it) }
        } catch (_: Throwable) {}
        return items
    }
    private fun fetchOne(cid: String, chUrl: String, force: Boolean, staleOk: Boolean = false): List<NpItem> {
        val now = System.currentTimeMillis()
        val e = synchronized(this) { mem[cid] }
        loadValid()
        val hasV = synchronized(this) { valid.containsKey("https://www.youtube.com/feeds/videos.xml?channel_id=$cid") }   // (v1174) عندنا ETag للقناة: كل تحديث GET شرطي (304 ≈ 300 بايت) بدل ما نستنى 30 دقيقة
        if (!force && e != null && (staleOk || (now - e.t < TTL_MS && !hasV))) return e.items   // (v354) staleOk: اعرض الكاش فورًا حتى لو قديم
        return try {
            val l = getFeed(cid, chUrl, e != null)
            synchronized(this) { mem[cid] = Entry(now, l) }
            l
        } catch (n: NotModified) {   // (v792) مفيش جديد: جدّد التوقيت وارجع للمحفوظ
            if (e != null) { synchronized(this) { mem[cid] = Entry(now, e.items) }; e.items } else throw n
        } catch (t: Throwable) { e?.items ?: throw t }   // فشل → آخر كاش لو موجود
    }

    /** (v469) C12 فيديوهات قناة واحدة من RSS (بديل خفيف واحتياطي لصفحة القناة لما NewPipe يفشل) */
    fun channelVideos(cid: String, chUrl: String): List<NpItem> = fetchOne(cid, chUrl, false)

    /** فيد مدموج من كل الاشتراكات، الأحدث أولًا. force = تجاهل الكاش */
    private val feedLock = Any()
    private val fbBudget = java.util.concurrent.atomic.AtomicInteger(0)
    /** (v354) يحدّث الكاش في الخلفية (القنوات المنتهية بس) من غير ما يعطّل الشاشة — الزيارة الجاية تلاقي فيد جديد */
    /** (v407) بيتنده (من خيط خلفي) لما التحديث الخلفي يخلص — تبويب الاشتراكات بيقارن ويظهر كبسولة «فيديوهات جديدة» */
    @Volatile var onFeed: ((YtRes) -> Unit)? = null
    /** (v1354) تحديث خلفي شغال دلوقتي (الواجهة بتستناه قبل إعلان «مفيش فيديوهات» — بطلب علي) */
    @Volatile var refreshingNow = false
    fun refreshAsync(subs: List<NpItem>) {
        refreshingNow = true
        Thread {
            var r: YtRes? = null
            try { r = feed(subs, false, false) } catch (_: Throwable) {}
            finally { refreshingNow = false }
            try { onFeed?.invoke(r ?: YtRes(emptyList(), null)) } catch (_: Throwable) {}
        }.apply { isDaemon = true; start() }
    }
    /** staleOk: لو للقناة كاش (حتى لو قديم) بيتعرض فورًا من غير شبكة */
    /** (v407) من الكاش بس (من غير شبكة ومن غير قفل): لو كل قنوات الاشتراكات ليها معرّف UC وكاش. غير كده null (ويكمّل المسار العادي).
     *  قبل كده فتح الاشتراكات كان بيستنى نهاية أي فحص خلفي شغّال (لحد 40 ثانية) لأن الاتنين على نفس القفل */
    fun cachedFeed(subs: List<NpItem>): YtRes? {
        loadDisk()
        val all = ArrayList<NpItem>()
        synchronized(this) {
            // (v471) من الكاش بس حتى لو قناة أو اتنين مالهمش كاش لسه (كان لازم الكل، فأي قناة جديدة بتخلّي الفتح بطيء/فاضي) — الناقص بيتجاب في التحديث الخلفي وتظهر كبسولة «فيديوهات جديدة»
            for (s in subs.take(MAX_CH)) {
                val cid = chanId(s.channelUrl) ?: continue
                val e = mem[cid] ?: continue
                all.addAll(e.items)
            }
        }
        if (all.isEmpty()) return null
        val fresh = all.distinctBy { it.id }.map { if (it.ts > 0L) NpItem(it.id, it.title, it.channel, it.channelUrl, it.thumb, it.dur, it.count, ageOf(it.ts), it.kind, it.url, it.ts, it.avatar, it.channelId) else it }
        return YtRes(fresh.sortedByDescending { it.ts }.take(600), null)
    }

    /** (v407) عينة سريعة للرئيسية: [n] قناة عشوائية (ليها معرّف UC) → RSS بالتوازي (القنوات اللي كاشها لسه صالح من غير شبكة). مش بتقفل feedLock ومحدودة بـ7 ثواني */
    fun sample(subs: List<NpItem>, n: Int): List<NpItem> {
        loadDisk()
        val chans = subs.filter { chanId(it.channelUrl) != null }.shuffled().take(n)
        if (chans.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(minOf(6, chans.size))
        try {
            val fs = chans.map { s -> pool.submit(Callable<List<NpItem>> { try { fetchOne(chanId(s.channelUrl)!!, s.channelUrl, false, false) } catch (_: Throwable) { emptyList() } }) }
            val out = ArrayList<NpItem>()
            val dl = System.currentTimeMillis() + 7000L
            for (f in fs) try { out.addAll(f.get(maxOf(1L, dl - System.currentTimeMillis()), java.util.concurrent.TimeUnit.MILLISECONDS)) } catch (_: Throwable) {}
            return out.distinctBy { it.id }.map { if (it.ts > 0L) NpItem(it.id, it.title, it.channel, it.channelUrl, it.thumb, it.dur, it.count, ageOf(it.ts), it.kind, it.url, it.ts, it.avatar, it.channelId) else it }
        } finally { pool.shutdownNow() }
    }

    /** (v751) فيد الاشتراكات الرسمي بيرجّع أعمار نصية («منذ 3 أيام») وترتيبه مش دايمًا بالأحدث (فيديو حديث وبعده قديم). هنا: وقت الرفع الدقيق من RSS لو موجود،
     *  والترتيب بالأحدث، وبنضيف أي فيديو جديد من RSS الصفحة الرسمية فوّتته (أحدث من أقدم فيديو في الصفحة). الشورتس بتتشال بالعنوان/المدة بقدر الإمكان. */
    fun mergeLatest(official: List<NpItem>, rss: List<NpItem>): List<NpItem> {
        if (official.isEmpty()) return rss
        val byId = HashMap<String, NpItem>(); for (x in rss) byId[x.id] = x
        val fixed = official.map { o ->
            val r = byId[o.id]
            val ts = when { r != null && r.ts > 0L -> r.ts; o.ts > 0L -> o.ts; else -> YtNp.ageMs(o.age) }
            NpItem(o.id, o.title, o.channel.ifBlank { r?.channel ?: "" }, o.channelUrl.ifBlank { r?.channelUrl ?: "" }, o.thumb, o.dur, if (o.count >= 0L) o.count else (r?.count ?: -1L),
                if (ts > 0L && (r != null || o.age.isBlank())) ageOf(ts) else o.age, o.kind, o.url, ts, o.avatar.ifBlank { r?.avatar ?: "" }, o.channelId.ifBlank { r?.channelId ?: "" })
        }
        val ids = fixed.map { it.id }.toHashSet()
        val cutoff = minOf(fixed.filter { it.ts > 0L && it.kind == 0 }.minOfOrNull { it.ts } ?: return fixed.sortedByDescending { it.ts }, System.currentTimeMillis() - 3 * 86_400_000L)   // (v867) كان بيرجّع من غير ترتيب   // (v754) دايمًا آخر 3 أيام على الأقل من RSS
        val extra = rss.filter { it.kind == 0 && it.id !in ids && it.ts >= cutoff }
        return (fixed + extra).sortedByDescending { it.ts }
    }

    fun feed(subs: List<NpItem>, force: Boolean = false, staleOk: Boolean = false): YtRes {
        if (staleOk && !force) cachedFeed(subs)?.let { return it }
        return feedLocked(subs, force, staleOk)
    }
    private fun feedLocked(subs: List<NpItem>, force: Boolean, staleOk: Boolean): YtRes = synchronized(feedLock) {   // (v354) طلب واحد في المرة: فحص العدّاد ما بيتخانقش مع فتح الاشتراكات (كان بيعمل ضغط ويوتيوب بيرفض)
        loadDisk()
        fbBudget.set(20)   // (v863) كان 5: القنوات الزيادة كانت بتتسكّت عنها   // أقصى عدد قنوات نرجع فيها للطريقة البطيئة (NewPipe) في الطلب الواحد
        val list = subs.take(MAX_CH)
        val pool = Executors.newFixedThreadPool(8)
        try {
            val fs = list.map { s ->
                pool.submit(Callable<List<NpItem>> {
                    val cid = chanId(s.channelUrl)
                    try {
                        if (cid != null) fetchOne(cid, s.channelUrl, force, staleOk)
                        else fbCached(s.channelUrl) ?: (if (fbBudget.getAndDecrement() > 0) fbFetch(s.channelUrl) else emptyList())
                    } catch (_: Throwable) {
                        if (cid != null) (fbCached(s.channelUrl) ?: (if (fbBudget.getAndDecrement() > 0) try { fbFetch(s.channelUrl) } catch (_: Throwable) { emptyList() } else emptyList())) else emptyList()
                    }
                })
            }
            val all = ArrayList<NpItem>()
            val dl = System.currentTimeMillis() + 40000L
            for (f in fs) try { all.addAll(f.get(maxOf(1L, dl - System.currentTimeMillis()), java.util.concurrent.TimeUnit.MILLISECONDS)) } catch (_: Throwable) {}
            // العمر بيتحسب من جديد (الكاش ممكن يكون قديم)
            val fresh = all.distinctBy { it.id }.map { if (it.ts > 0L) NpItem(it.id, it.title, it.channel, it.channelUrl, it.thumb, it.dur, it.count, ageOf(it.ts), it.kind, it.url, it.ts, it.avatar, it.channelId) else it }
            saveDisk(list.mapNotNull { chanId(it.channelUrl) }.toSet())
            saveValid(list.mapNotNull { chanId(it.channelUrl) }.toSet())
            YtRes(fresh.sortedByDescending { it.ts }.take(600), null)
        } finally { pool.shutdown() }
    }
}

/** (v327) إشعارات الفيديوهات الجديدة من الاشتراكات (فحص كل ساعة بـ JobScheduler، من غير مكتبات زيادة) */
object YtNotify {
    const val KEY = "yt_notif"          // الإعداد: شغّال افتراضيًا
    private const val SEEN = "ytp_seen" // سطر لكل قناة: معرّف=آخر وقت رفع شافه
    private const val CH = "yt_new"
    private const val JOB = 32700
    private const val MAX_SINGLE = 4

    fun enabled() = Cfg.bool(KEY, true)

    // (v403) إشعار لكل قناة: القنوات اللي قفلت إشعاراتها (الباقي شغّال لو الإشعارات العامة شغّالة)
    private const val OFF = "ytp_notif_off"
    private fun offSet(): HashSet<String> = HashSet(Cfg.str(OFF, "").split("\n").filter { it.isNotBlank() })
    fun chanOn(url: String): Boolean { val id = YtRss.chanId(url) ?: return true; return !offSet().contains(id) }
    fun setChanOn(url: String, on: Boolean) {
        val id = YtRss.chanId(url) ?: return
        val s = offSet(); if (on) s.remove(id) else s.add(id)
        Cfg.put(OFF, s.joinToString("\n"))
    }

    // ───────── (v350) عدّاد الفيديوهات الجديدة على أيقونة يوتيوب ─────────
    private const val OPENED = "ytp_opened"      // آخر مرة فتحت فيها الاشتراكات
    private const val BADGE = "ytp_badge"
    private const val BADGE_AT = "ytp_badge_at"
    @Volatile var badge = -1
    fun badgeCount(): Int { if (badge < 0) badge = Cfg.str(BADGE, "0").toIntOrNull() ?: 0; return badge }
    private fun storeBadge(n: Int) { badge = n; Cfg.put(BADGE, n.toString()) }
    /** فتحت الاشتراكات: العدّاد يتصفّر وبنبدأ العدّ من دلوقتي */
    fun markOpened(c: Context) { Cfg.put(OPENED, System.currentTimeMillis().toString()); storeBadge(0); try { (c as? MainActivity)?.let { m -> m.runOnUiThread { m.updateYtBadge() } } } catch (_: Throwable) {} }
    // ───────── (v1107) عدّاد «الاشتراكات» لحساب الكود (محرك MeeTube) ─────────
    // «جديد» = فيديو في أول صفحة اشتراكات مش موجود في آخر قايمة اشتراكات اتعرضت عليك. مش مربوط بالمشاهدة: فتح الاشتراكات = كل اللي ظهر فيها اتشاف.
    private const val MT_BASE = "ytp_subs_base"
    private val mtLock = Any()
    @Volatile private var mtPeekAt = 0L
    fun mtBaseKnown(): Boolean = Cfg.str(MT_BASE, "").isNotEmpty()
    private fun mtBase(): List<String> = Cfg.str(MT_BASE, "").split('\n').filter { it.isNotBlank() }
    // (v1144) علامة «جديد» على الكروت: بتتحسب قبل ما الأساس/السجل يتحدّث، وبتتمسح لما تطلع من الاشتراكات
    private val newSet = java.util.Collections.synchronizedSet(HashSet<String>())
    fun isNew(id: String) = newSet.contains(id)
    fun clearNew() { newSet.clear() }
    fun noteNewMt(ids: List<String>) { try { val b = mtBase().toHashSet(); if (b.isNotEmpty()) for (x in ids) if (x !in b) newSet.add(x) } catch (_: Throwable) {} }
    fun noteNewTs(items: List<NpItem>) { try { val m = readSeen(); if (m.isNotEmpty()) for (it in items) { val cid = YtRss.chanId(it.channelUrl) ?: continue; val sv = m[cid] ?: continue; if (it.ts > sv) newSet.add(it.id) } } catch (_: Throwable) {} }
    /** القايمة اللي اتعرضت دلوقتي بتتضاف للأساس (آخر 300 معرّف) */
    fun mtMarkSubs(ids: List<String>) {
        synchronized(mtLock) {
            val s = LinkedHashSet<String>()
            for (x in ids) { if (s.size >= 300) break; s.add(x) }
            for (x in mtBase()) { if (s.size >= 300) break; s.add(x) }
            Cfg.put(MT_BASE, s.joinToString("\n"))
        }
    }
    /** أول مرة = أساس من غير عدّاد */
    private fun mtCountNew(ids: List<String>): Int = synchronized(mtLock) {
        val base = mtBase().toHashSet()
        if (base.isEmpty()) { Cfg.put(MT_BASE, ids.take(300).joinToString("\n")); storeBadge(0); 0 }
        else { val n = ids.count { it !in base }; storeBadge(n); n }
    }
    /** فحص خلفي (كل 3 دقايق بالكتير) لأول صفحة اشتراكات؛ لازم تكون فتحت الاشتراكات مرة بحساب الكود الأول */
    fun mtPeek(c: Context, force: Boolean = false) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && mtPeekAt != 0L && now - mtPeekAt < 3 * 60_000L) return
        try { Cfg.ensure(c) } catch (_: Throwable) {}
        if (!mtBaseKnown()) return
        mtPeekAt = now
        Thread {
            try {
                Cfg.ensure(c); YtMtFeed.attach(c)
                if (!YtMtFeed.usable()) return@Thread
                val ids = YtMtFeed.subsIds() ?: return@Thread
                mtCountNew(ids)
                (c as? MainActivity)?.let { m -> m.runOnUiThread { m.updateYtBadge() } }
            } catch (_: Throwable) {}
        }.apply { isDaemon = true; start() }
    }
    private fun countNew(items: List<NpItem>): Int {
        val t = Cfg.str(OPENED, "").toLongOrNull() ?: 0L
        if (t == 0L) { Cfg.put(OPENED, System.currentTimeMillis().toString()); return 0 }   // أول مرة: خط أساس
        return items.count { it.ts > t }
    }
    /** بيحدّث العدّاد من الفيد (كاش 15 دقيقة) في خيط خلفي؛ بيستدعي done على نفس الخيط */
    fun refreshBadge(c: Context, force: Boolean = false, done: (Int) -> Unit) {
        val now = System.currentTimeMillis()
        if (mtBaseKnown()) { done(badgeCount()); return }   // (v1107) حساب الكود: العدّاد من محرك MeeTube (mtPeek)
        if (!force && now - (Cfg.str(BADGE_AT, "0").toLongOrNull() ?: 0L) < 5 * 60 * 1000L) return
        Cfg.put(BADGE_AT, now.toString())
        Thread {
            try {
                Cfg.ensure(c); YtRss.attach(c)
                val subs = YtStore.read(YtStore.SUBS); if (subs.isEmpty()) return@Thread
                val n = countNew(YtRss.feed(subs, false).items)
                storeBadge(n); done(n)
            } catch (_: Throwable) {}
        }.apply { isDaemon = true; start() }
    }

    fun schedule(c: Context) {
        try {
            val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            if (!enabled() || YtStore.read(YtStore.SUBS).isEmpty()) { js.cancel(JOB); return }
            if (js.getPendingJob(JOB) != null) return
            val ji = JobInfo.Builder(JOB, ComponentName(c, YtFeedJob::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(60L * 60L * 1000L)
                .build()
            js.schedule(ji)
        } catch (e: Throwable) { try { LogStore.err("YtNotify:schedule", e) } catch (_: Throwable) {} }
    }

    fun setEnabled(c: Context, on: Boolean) {
        Cfg.put(KEY, if (on) "1" else "0")
        try { (c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler).cancel(JOB) } catch (_: Throwable) {}
        if (on) schedule(c)
    }

    private fun readSeen(): HashMap<String, Long> {
        val m = HashMap<String, Long>()
        for (l in Cfg.str(SEEN, "").lineSequence()) { val i = l.indexOf('='); if (i > 0) m[l.substring(0, i)] = l.substring(i + 1).toLongOrNull() ?: 0L }
        return m
    }
    private fun writeSeen(m: Map<String, Long>) = Cfg.put(SEEN, m.entries.joinToString("\n") { it.key + "=" + it.value })

    /** بيحدّث «آخر ما اتشاف» لكل القنوات للوقت الحالي من الفيد (بعد ما اليوزر يفتح الاشتراكات) عشان ما يجيش إشعار على حاجة شافها */
    fun markSeen(items: List<NpItem>) {
        try {
            val m = readSeen()
            for (it in items) { val cid = YtRss.chanId(it.channelUrl) ?: continue; if (it.ts > (m[cid] ?: 0L)) m[cid] = it.ts }
            writeSeen(m)
        } catch (_: Throwable) {}
    }

    /** الفحص نفسه. بيرجّع عدد الإشعارات اللي اتبعتت */
    fun check(c: Context): Int {
        Cfg.ensure(c); YtRss.attach(c)
        if (!enabled()) return 0
        val subs = YtStore.read(YtStore.SUBS); if (subs.isEmpty()) return 0
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val feed = YtRss.feed(subs, true).items
        if (!mtBaseKnown()) try { storeBadge(countNew(feed)) } catch (_: Throwable) {}   // (v350) العدّاد بيتحدّث مع الفحص الدوري كمان
        val seen = readSeen(); val fresh = ArrayList<NpItem>()
        val firstRun = seen.isEmpty()
        val newest = HashMap<String, Long>()
        val off = offSet()
        for (it in feed) {
            val cid = YtRss.chanId(it.channelUrl) ?: continue
            if (it.ts > (newest[cid] ?: 0L)) newest[cid] = it.ts
            val last = seen[cid]
            if (last != null && it.ts > last && !off.contains(cid)) fresh.add(it)   // قناة جديدة على الإشعارات (من غير سجل) = خط أساس من غير إشعار
        }
        for ((k, v) in newest) if (v > (seen[k] ?: 0L)) seen[k] = v
        writeSeen(seen)
        if (firstRun || fresh.isEmpty()) return 0
        try { inboxAdd(fresh.sortedByDescending { it.ts }) } catch (_: Throwable) {}   // (v1304) صندوق الإشعارات بيتسجّل حتى لو إذن الإشعارات مقفول
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) return 0
        if (!nm.areNotificationsEnabled()) return 0
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "فيديوهات جديدة من اشتراكاتي", NotificationManager.IMPORTANCE_DEFAULT))
        val list = fresh.sortedByDescending { it.ts }
        val pf = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        fun open(vid: String?, rc: Int): PendingIntent {
            val i = Intent(c, MainActivity::class.java).putExtra("tab", "youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            if (vid != null) i.putExtra("yt_open", vid)
            return PendingIntent.getActivity(c, rc, i, pf)
        }
        var n = 0
        if (list.size <= MAX_SINGLE) {
            for (v in list) {
                val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else @Suppress("DEPRECATION") Notification.Builder(c)
                nb.setSmallIcon(android.R.drawable.stat_notify_more).setContentTitle(v.channel.ifBlank { "فيديو جديد" }).setContentText(v.title)
                    .setStyle(Notification.BigTextStyle().bigText(v.title)).setContentIntent(open(v.id, v.id.hashCode())).setAutoCancel(true)
                nm.notify(("yt:" + v.id).hashCode(), nb.build()); n++
            }
        } else {
            val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CH) else @Suppress("DEPRECATION") Notification.Builder(c)
            val chs = list.map { it.channel }.filter { it.isNotBlank() }.distinct().take(3).joinToString("، ")
            nb.setSmallIcon(android.R.drawable.stat_notify_more).setContentTitle("📺 " + list.size + " فيديو جديد من اشتراكاتك").setContentText(chs)
                .setStyle(Notification.BigTextStyle().bigText(list.take(6).joinToString("\n") { "• " + it.channel + ": " + it.title }))
                .setContentIntent(open(null, 7)).setAutoCancel(true)
            nm.notify(32701, nb.build()); n = 1
        }
        return n
    }

    // ───────── (v1304) صندوق الإشعارات: كل فيديو جديد من الاشتراكات بيتسجّل هنا (آخر 60) ─────────
    data class InboxItem(val ts: Long, val id: String, val channel: String, val channelUrl: String, val title: String)
    private const val INBOX = "ytp_inbox"
    private const val INBOX_SEEN = "ytp_inbox_seen"
    private const val INBOX_MAX = 60
    fun inbox(): List<InboxItem> {
        val out = ArrayList<InboxItem>()
        for (l in Cfg.str(INBOX, "").lineSequence()) {
            val p = l.split("|")
            if (p.size >= 5) { val t = p[0].toLongOrNull() ?: continue; out.add(InboxItem(t, p[1], p[2], p[3], p.subList(4, p.size).joinToString("|"))) }
        }
        return out
    }
    private fun inboxAdd(items: List<NpItem>) {
        if (items.isEmpty()) return
        val sb = StringBuilder()
        for (it in items) sb.append(it.ts).append('|').append(it.id).append('|').append(it.channel.replace("|", " ").replace("\n", " ")).append('|').append(it.channelUrl.replace("|", " ")).append('|').append(it.title.replace("|", " ").replace("\n", " ")).append('\n')
        val merged = (sb.toString() + Cfg.str(INBOX, "")).lineSequence().filter { it.isNotBlank() }.take(INBOX_MAX).joinToString("\n")
        Cfg.put(INBOX, merged)
    }
    fun inboxUnread(): Int { val s = Cfg.str(INBOX_SEEN, "0").toLongOrNull() ?: 0L; return inbox().count { it.ts > s } }
    fun inboxMarkRead() = Cfg.put(INBOX_SEEN, System.currentTimeMillis().toString())
}

class YtFeedJob : JobService() {
    @Volatile private var t: Thread? = null
    override fun onStartJob(p: JobParameters): Boolean {
        t = Thread {
            try { YtNotify.check(applicationContext) } catch (e: Throwable) { try { LogStore.err("YtFeedJob", e) } catch (_: Throwable) {} }
            try { jobFinished(p, false) } catch (_: Throwable) {}
        }.apply { isDaemon = true; start() }
        return true
    }
    override fun onStopJob(p: JobParameters): Boolean { t?.interrupt(); return true }
}
