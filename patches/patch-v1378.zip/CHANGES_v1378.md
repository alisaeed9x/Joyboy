# التغييرات في v1378

1. [إصلاح] إصلاح بيلد v1377 الفاشل: مهمة pruneStaleKt (v398) بتمسح أي ملف .kt مش مسجّل في app/kt_manifest.txt قبل الكومبايل — ملف Onboarding.kt الجديد اتشاف «قديم» واتمسح من شجرة البيلد فظهر خطأ «Unresolved reference 'Onboarding'» في Main.kt. اتسجّل في المانيفست، ومفيش أي تغيير كود تاني
