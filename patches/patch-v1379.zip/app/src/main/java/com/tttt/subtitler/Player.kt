@file:OptIn(UnstableApi::class)
package com.tttt.subtitler

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.*
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import java.io.File
import com.bumptech.glide.Glide
import android.content.pm.ActivityInfo
import android.view.ViewGroup
import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.util.Rational

/** مشغّل الفيديو والترجمة (اتنقل من Main.kt في v100 — من غير أي تغيير في الكود) */
open class PlayerActivity : Activity(), Host {
    @Volatile private var panicShut = false   // (v1016) 🚨 قفل المشغّل: ماتحفظش في آخر المشغّلة
    private var gone = false   // (v923) (v1105 Y5: مفيش تحويل لمشغّل ميتيوب — بيفضل false)
    // (v507) ريزوليوشن ديناميك لوضع التلفزيون
    override fun attachBaseContext(newBase: android.content.Context) { super.attachBaseContext(TvScale.wrap(newBase)) }
    companion object {
        private val liveList = ArrayList<java.lang.ref.WeakReference<PlayerActivity>>()
        /** (v518) ريموت الموبايل: تشغيل/إيقاف المشغّل الشغّال. بيرجّع false لو مفيش مشغّل فيديو مفتوح */
        fun remoteToggle(): Boolean {
            val o = synchronized(liveList) { liveList.mapNotNull { it.get() }.lastOrNull { !it.isFinishing && !it.isDestroyed } } ?: return false
            try { o.runOnUiThread { try { o.togglePlay() } catch (_: Throwable) {} } } catch (_: Throwable) { return false }
            return true
        }

        /** (v1010) تحذير الداتا: وقّف مشغّل Joyboy لو شغّال (محلي مش على التلفزيون)؛ true = إحنا اللي وقّفناه */
        fun pauseForGuard(): Boolean {
            val o = live() ?: return false
            return try { if (!o.player.isRemote && o.player.isPlaying) { o.player.pause(); true } else false } catch (_: Throwable) { false }
        }
        fun resumeForGuard() { val o = live() ?: return; try { o.player.play() } catch (_: Throwable) {} }

        /** (v531) في مشغّل فيديو (برنامج) مفتوح دلوقتي؟ */
        fun hasLive(): Boolean = live() != null

        /** (v1016) 🚨 الطوارئ: اقفل أي مشغّل Joyboy شغّال من غير ما يحفظ في «آخر المشغّلة» (بيتنادى قبل مسح السجل) */
        fun panicClose(): Boolean {
            val list = synchronized(liveList) { liveList.mapNotNull { it.get() }.filter { !it.isFinishing && !it.isDestroyed } }
            for (o in list) {
                o.panicShut = true
                try { o.runOnUiThread { try { o.player.pause() } catch (_: Throwable) {}; if (!o.isFinishing) o.finish() } } catch (_: Throwable) {}
            }
            return list.isNotEmpty()
        }

        private fun live(): PlayerActivity? = synchronized(liveList) { liveList.mapNotNull { it.get() }.lastOrNull { !it.isFinishing && !it.isDestroyed } }

        private fun <T> onUi(o: PlayerActivity, ms: Long = 900L, f: () -> T): T? {
            val box = arrayOfNulls<Any>(1)
            val latch = java.util.concurrent.CountDownLatch(1)
            try { o.runOnUiThread { try { box[0] = f() } catch (e: Throwable) { LogStore.err("Player:remote", e) }; latch.countDown() } } catch (_: Throwable) { return null }
            @Suppress("UNCHECKED_CAST")
            return if (latch.await(ms, java.util.concurrent.TimeUnit.MILLISECONDS)) box[0] as T? else null
        }

        /** (v520) حالة المشغّل للموبايل: عنوان · مكان · مدة · تشغيل · سرعة · احتواء · ترجمة · حجم/إزاحة الترجمة · صوت/جودة. null = مفيش مشغّل */
        /** (v596) الملف المحلي اللي المشغّل شغّاله (للسماعة الخاصة على الموبايل) */
        fun curUri(): Uri? = live()?.uri

        fun remoteState(): org.json.JSONObject? { val o = live() ?: return null; return onUi(o) { o.rState() } }

        /** (v520) أوامر المشغّل من الموبايل. v = قيمة (مللي ثانية / اتجاه) */
        fun remoteAct(a: String, v: Long): Boolean {
            val o = live() ?: return false
            // (v799) إشعارات الأمر دي (ضغطة من ريموت الموبايل) ما تظهرش على التلفزيون — بتتجمّع وبتترجع للموبايل (lastRemoteNote)
            return onUi(o) { Notice.beginCapture(); try { o.rAct(a, v) } finally { lastRemoteNote = Notice.endCapture() } } == true
        }
        /** (v799) آخر رسالة اتجمّعت من أمر ريموت (للموبايل) — بتتسحب مرة واحدة */
        @Volatile private var lastRemoteNote = ""
        fun takeRemoteNote(): String { val n = lastRemoteNote; lastRemoteNote = ""; return n }
        /** (v1044) قايمة اختيار اتجمّعت من أمر ريموت (بتتعرض على الموبايل) — بتتسحب مرة واحدة */
        fun takePm(): org.json.JSONObject? { val o = live() ?: return null; val p = o.rcPm; o.rcPm = null; return p }

        /** (v684) ملف ترجمة جه من الموبايل (TvLink /subup): بيتحفظ ويستنى أمر «ترجم» من الموبايل. false = مفيش مشغّل فيديو شغّال */
        fun remoteSubImport(f: java.io.File, name: String, cues: Int, show: Boolean = false): Boolean { val o = live() ?: return false; return onUi(o) { o.subImported(f, name, cues, show) } == true }

        /** (v694) وصف الفيديو الشغّال (ref/title/pos…) لتحويله للموبايل. null = مفيش مشغّل شغّال */
        fun remoteHandoff(): org.json.JSONObject? { val o = live() ?: return null; return onUi(o) { o.handoffInfo() } }

        /** (v779) ➕ من ريموت الموبايل: وصف الفيديو الشغّال للليستة (ref/title) من غير ما يوقّفه. null = مفيش مشغّل */
        fun remoteQueueCur(): org.json.JSONObject? { val o = live() ?: return null; return onUi(o) { o.queueInfo() } }

        /** (v688) جمل مترجمة وصلت من الموبايل (ترجمة مزدوجة). 0 = اتطبّقت · 1 = مفيش مشغّل · 2 = مفيش شغلانة مطابقة · 3 = التلفزيون كسب الأول. من خيط الطلب (مش الـUI) */
        fun remoteSubTr(jid: String, texts: List<String>, failed: Int, eng: String): Int { val o = live() ?: return 1; return o.subFromPhone(jid, texts, failed, eng) }

        /** (v542) م1: RPC للتلفزيون-المخ. عمليات engine.* بتتنفّذ على خيط الطلب (مش الـUI)، والباقي على الـUI بمهلة 3 ثواني. null = مفيش مشغّل */
        fun brain(op: String, a: org.json.JSONObject): org.json.JSONObject? {
            val o = live() ?: return null
            return if (op.startsWith("engine.")) o.rpcBg(op, a) else onUi(o, 3000L) { o.rpc(op, a) }
        }

        /** (v542) لقطة حية من الفيديو كـJPEG (بتتنادى من خيط خلفي). null = مفيش لقطة (DRM/أسود/مفيش مشغّل) */
        fun brainFrame(maxDim: Int, q: Int): ByteArray? { val o = live() ?: return null; return o.frameJpeg(maxDim, q) }
    }

    private fun rState(): org.json.JSONObject {
        val j = org.json.JSONObject()
        j.put("title", try { notifTitle() } catch (_: Throwable) { "" })
        j.put("pos", try { player.currentPosition } catch (_: Throwable) { 0L })
        j.put("dur", durMs)
        j.put("playing", try { player.isPlaying } catch (_: Throwable) { false })
        j.put("speed", PlayerLogic.speedLabel(speed))
        j.put("wtr", try { wTr() } catch (_: Throwable) { "free" })   // (v712) مترجم وضع وشبر الحالي
        j.put("fit", fitNameOf(curFit()))
        j.put("cc", ccOn)
        j.put("scale", Cfg.int("sub_scale", 100))
        j.put("vol", try { volTotal() } catch (_: Throwable) { -1 })   // (v568) صوت التلفزيون الحالي (0..200) — المتحكم على الموبايل يعرضه ويغيّره
        j.put("shift", offsetMs)
        j.put("audio", aTracks.size > 1)
        j.put("quality", qualPopFn != null && (qOpts.size > 1 || uri == null))
        j.put("tr", tvTrLabel())
        j.put("sf_side", sfSideName()); j.put("sf_nat", sfNativeCount()); j.put("sf_live", sfLive); j.put("sf_busy", sfBusy); j.put("tpart", try { ::engine.isInitialized && !engineStarted && engine.subs.isNotEmpty() && !engine.fullyDone() } catch (_: Throwable) { false }); j.put("sf_mob", try { mobileSub?.takeIf { it.exists() }?.name ?: "" } catch (_: Throwable) { "" })   // (v529) (v684 sf_mob)
        // (v531) شاشة «مشغّل الفيديو» في الريموت = نفس تقسيمة مشغّل الموبايل: كل حالة الأزرار والكبسولات
        j.put("kind", "player")
        j.put("net_busy", netBusy); j.put("net_more", netSess?.remaining() ?: 0)   // (v746)
        try { j.put("net_v", NetUse.trVideo()); j.put("net_d", NetUse.trToday()) } catch (_: Throwable) {}   // (v759) استهلاك نت الترجمة: الفيديو ده / النهارده
        try { val u = android.os.Process.myUid(); val rx = android.net.TrafficStats.getUidRxBytes(u); val tx = android.net.TrafficStats.getUidTxBytes(u); if (rx >= 0L && tx >= 0L) j.put("net_tv", rx + tx) } catch (_: Throwable) {}   // (v810) إجمالي نت التطبيق على التلفزيون (الريموت بيطرح منه أساس الفيديو)
        try { j.put("sblur", Cfg.int("sub_blur", 0)); j.put("suni_on", Cfg.str("sub_uni_on", "0") == "1"); j.put("suni", Cfg.str("sub_uni_color", "#FFFFFF")) } catch (_: Throwable) {}   // (v759) حالة استوديو الترجمة على الموبايل
        try { val vn = vidNamesCached(); j.put("vname", vn.first); j.put("vfolder", vn.second) } catch (_: Throwable) {}
        // (v596) مصدر الصوت للسماعة الخاصة: لينك http (مع الهيدرز) أو "local" = ملف على التلفزيون بيتقدّم من /file/cur
        try {
            val au = aurl ?: url ?: uri?.toString()?.takeIf { it.startsWith("http") }
            if (au != null && au.startsWith("http")) { j.put("src", au); j.put("hdr", org.json.JSONObject(HashMap<String, String>(hdr) as Map<*, *>)) }
            else if (uri != null) j.put("src", "local")
        } catch (_: Throwable) {}
        j.put("vw", vidW); j.put("vh", vidH)   // (v546)
        j.put("loop", Cfg.str("loop", "0") == "1")
        j.put("lm", loopMode())   // (v781) 0 عادي · 1 نفس الفيديو · 2 كل فيديوهات الفولدر
        j.put("dual", try { SubStyle.load { k, d -> Cfg.str(k, d) }.dual } catch (_: Throwable) { 0 })
        j.put("bgon", Cfg.bool("ask_bg_exit", true))
        j.put("nots", try { NoticeLog.list().size } catch (_: Throwable) { 0 })
        j.put("locked", uiLocked)
        j.put("font", try { val f0 = SubStyle.load { k, d -> Cfg.str(k, d) }.font; SubStyle.fonts.firstOrNull { it.id == f0 }?.label ?: f0 } catch (_: Throwable) { "" })
        j.put("eng", try { TrWizard.summaryLine() } catch (_: Throwable) { "" })
        j.put("cnt", try { covPct().toString() + "% · " + list.size.toString() + " جملة" } catch (_: Throwable) { "" })
        j.put("trcolor", try { tvTrColor() } catch (_: Throwable) { 0xFFE53935.toInt() })
        // (v682) صفحة «المشغّل» في الريموت: وضع الترجمة · حالة المحرك · عدد جمل الوضع البصري · شفافية الخلفية
        j.put("mode", modeLabelNow())
        j.put("tstart", engineStarted)
        j.put("tpause", try { ::engine.isInitialized && engine.userPaused } catch (_: Throwable) { false })
        j.put("vcnt", try { if (::visual.isInitialized) visual.count else 0 } catch (_: Throwable) { 0 })
        j.put("bgopa", try { if (Cfg.str("sub_nobg", "0") == "1") 0 else Cfg.int("sub_bgopa", 45) } catch (_: Throwable) { 45 })
        // (v683) كبسولة وضع يوتيوب · حلقة A-B · موضع الترجمة · أزرار صف الترجمة (إعادة/لهجة)
        j.put("ytmode", try { if (::modePill.isInitialized && modePill.visibility == View.VISIBLE) modePill.text.toString() else "" } catch (_: Throwable) { "" })
        j.put("ab", if (abA < 0L) "" else if (abB <= abA) "A " + PlayerLogic.clock(abA) else "A " + PlayerLogic.clock(abA) + " ← B " + PlayerLogic.clock(abB))
        j.put("posy", Cfg.int("sub_posy", 0))
        try { j.put("sf_done", !engineStarted && sfDoneUri.isNotEmpty() && sfDoneUri == (uri?.toString() ?: "")); j.put("sf_n", if (::engine.isInitialized) engine.subs.size else 0) } catch (_: Throwable) {}   // (v765) ترجمة داخلية/ملف اتترجمت: عدّاد الريموت يعرض «تمت» بدل عدّادات جيميناي
        // (v762) حالة ورقة ⚙ إعدادات الترجمة على الموبايل (بدل ما كانت بتفتح على التلفزيون)
        try {
            j.put("ms_mk", curModeKey()); j.put("ms_lang", Offline.lang()); j.put("ms_model", Offline.model().id)
            j.put("ms_wav", AudioEnc.preset() == AudioEnc.NORMAL); j.put("ms_dual", Cfg.int("dual_listen", 1))
            j.put("ms_swap", Cfg.str("tr_autoswap", "on") != "off"); j.put("ms_term", TermNotes.enabled())
            j.put("ms_keys", Cfg.keys("keys").size + Cfg.keys("extra").size + Cfg.keys("backup").size)
        } catch (_: Throwable) {}
        j.put("hsub", try { hasSubsNow() } catch (_: Throwable) { false })
        j.put("cdial", try { caps().dialect } catch (_: Throwable) { false })
        try { val ts = if (::engine.isInitialized) (engine as? LocalEngine)?.e?.toolState() ?: Pair("", 0f) else Pair("", 0f); j.put("tool", ts.first); j.put("toolp", (ts.second * 100f).toInt().coerceIn(0, 100)) } catch (_: Throwable) {}   // (v709) تأثير «الكوباية» على أزرار الريموت
        // (v532) قوايم الجودة ولغة الصوت كنصوص + الحالي: الريموت بيعرضها على الموبايل ويختار منها من غير ما يفتح قايمة على شاشة التلفزيون
        try { val (ql, qc) = rQuals(); j.put("ql", org.json.JSONArray(ql)); j.put("qc", qc) } catch (_: Throwable) {}
        try {
            if (aTracks.size > 1 || !audLocalMode()) { j.put("al", org.json.JSONArray(aTracks.map { it.name })); j.put("ac", aCur) }
            else { val la = localAud(); val ca = try { player.currentAudio() } catch (_: Throwable) { -1 }; j.put("al", org.json.JSONArray(la.map { it.name })); j.put("ac", la.indexOfFirst { it.idx == ca }.coerceAtLeast(0)) }
        } catch (_: Throwable) {}
        return j
    }

    // ===== (v542) م1: التلفزيون = المخ — نشر الحالة + أوامر RPC =====
    private var brainAt = 0L
    private var brainSubsRef: List<Sub>? = null
    private var brainEngAt = 0L
    private val brainEngBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private val brainBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    /** بتتنادى من الـtick (200ms). مفيش شغل خالص لو مفيش ريموت بيسأل (/sync). الحساب التقيل للترجمة على خيط خلفي */
    private fun brainTick() {
        if (!BrainBus.active()) return
        val now = android.os.SystemClock.uptimeMillis()
        if (now - brainAt < 500L) return
        brainAt = now
        try {
            val st = rState()
            st.put("vid", vid); st.put("ready", engineReady); st.put("started", engineStarted)
            BrainBus.setState(st.toString())
        } catch (_: Throwable) {}
        try {
            if (::engine.isInitialized) {
                val sr = engine.subs
                if (sr !== brainSubsRef && brainBusy.compareAndSet(false, true)) {
                    brainSubsRef = sr
                    Thread {
                        try { BrainBus.updateSubs(sr) } catch (e: Throwable) { LogStore.err("Player:brainSubs", e) } finally { brainBusy.set(false) }
                    }.start()
                }
            }
        } catch (_: Throwable) {}
        try {
            if (::engine.isInitialized && now - brainEngAt >= 1500L && brainEngBusy.compareAndSet(false, true)) {
                brainEngAt = now
                val e = engine
                Thread {
                    try {
                        val snap = BrainEngineJson.Snap(
                            e.coverageSegs(), e.pendingSegs(), e.refiningSegs.toList(), e.batches(), e.problems(), e.batchRows(),
                            e.failedCount(), e.fullyDone(), e.offlineBrief(), e.offlineDetail(),
                            covered = e.coveredSec(), pendingCount = e.pendingCount(), userPaused = e.userPaused, paused = e.paused,
                            transOnly = e.transOnly, keepGoing = e.keepGoing, convDialect = e.convDialect, toneStyle = e.toneStyle,
                            toneStrength = e.toneStrength, titleHint = e.titleHint, skipIfBaseLang = e.skipIfBaseLang,
                            baseSkipped = e.baseSkipped, baseLangCode = e.baseLangCode,
                            versions = e.versions.map { VerRow(it.name, it.dialect, it.subs.size) }, chars = e.charactersNow()
                        )
                        if (engine === e) BrainBus.setEngine(BrainEngineJson.encode(snap))
                    } catch (ex: Throwable) { LogStore.err("Player:brainEng", ex) } finally { brainEngBusy.set(false) }
                }.start()
            }
        } catch (_: Throwable) {}
    }

    // ===== (v546 م2-ج) وضع المتحكم: التشغيل والمحرك والترجمة على التلفزيون، والموبايل واجهة المشغّل الكاملة =====
    // قاعدة ب-1: مفيش شبكة على الـUI. الحالة من LinkSession.mirror، والأوامر async، واللقطة الحية من خيط خلفي.
    @Volatile private var rmFrames = false
    private var rmLsn: (() -> Unit)? = null
    private var rmPlaying = false
    private var rmLiveSeen = false
    private var rmLostAt = 0L
    private var rmDownAt = 0L
    private var rmOpenAt = 0L
    private var rmBeginAt = 0L
    private var rmTitle = ""
    private var rmFrameErr = 0
    private var mirror: MirrorPreview? = null   // (v570) فيديو من الموبايل نفسه على التلفزيون: الموبايل بيشغّل نفس الملف بكتم بدل لقطات JPEG

    /** الوضع البصري على الموبايل متعطّل في وضع المتحكم (بيشتغل على التلفزيون) */
    private fun visualStart() {
        if (remote) { Notice.show(this, "📺 الوضع البصري شغّال على التلفزيون", 2200L); return }
        visual.start()
    }

    private fun buildRemotePlayer() {
        handedOff = false
        player = RemotePlayback()
        rmOpenAt = android.os.SystemClock.uptimeMillis()
        status = "📺 متحكم في التلفزيون"
        try { LinkSession.start(this) } catch (e: Throwable) { LogStore.err("Player:remoteStart", e) }
        if (rmLsn == null) { val l: () -> Unit = { onRemoteChange() }; rmLsn = l; LinkSession.addListener(l) }
        // (v570) لو الفيديو ملف على الموبايل نفسه: نشغّله عندنا بنفس جودته الأصلية وبسلاسة (متزامن مع التلفزيون)؛ غير كده لقطات التلفزيون زي الأول
        val mu = intent.getStringExtra("mirror_uri") ?: ""
        var mirrored = false
        if (mu.isNotEmpty() && ::svRef.isInitialized) {
            try {
                val mp = MirrorPreview(this) { w, hh -> applyRemoteSize(w, hh) }
                mp.start(svRef, if (mu.startsWith("/")) Uri.fromFile(File(mu)) else Uri.parse(mu))
                mirror = mp; mirrored = true
            } catch (e: Throwable) { LogStore.err("Player:mirror", e); try { mirror?.release() } catch (_: Throwable) {}; mirror = null }
        }
        if (!mirrored) startRemoteFrames()
        h.post { onRemoteChange() }
    }

    private fun initRemoteEngine() {
        vid = LinkSession.mirror.st.optString("vid", "")
        engineReady = false; pendingBegin = false; engineStarted = false
        engine = RemoteEngine()
        visual = VisualMode({ visConfNow() }, { cur / 1000.0 }, { makeRetriever() }, { m -> visLog(m) }, { }, { grabSurface() }, log = { m -> visLog(m) })
        status = "📺 متحكم في التلفزيون"
        h.post { onRemoteChange() }
    }

    /** بتتنادى على الـUI كل ما /sync يجيب تغيير: تحديث زرار التشغيل والعنوان والسرعة وحالة الترجمة */
    private fun onRemoteChange() {
        if (!remote || isFinishing || isDestroyed || !::player.isInitialized || !::ctl.isInitialized) return
        val m = LinkSession.mirror; val st = m.st
        dirty = true
        if (m.gotFirst && m.live) { rmLiveSeen = true; rmLostAt = 0L }
        val ready = m.gotFirst && m.live && st.optLong("dur", 0L) > 0L
        if (ready && !engineReady) { engineReady = true; vid = st.optString("vid", vid) }
        val tt = st.optString("title", "")
        if (tt.isNotEmpty() && tt != rmTitle) { rmTitle = tt; notifTitleOv = tt; try { applyChromeFn() } catch (_: Throwable) {} }
        val tvVol = st.optInt("vol", -1)
        if (tvVol >= 0 && System.currentTimeMillis() - rmVolAt > 1500L) { rmVolP = tvVol; try { if (ctl.vol.progress != tvVol) ctl.vol.progress = tvVol } catch (_: Throwable) {} }
        val sp = PosExtrap.speedOf(st.optString("speed", "1")).toFloat()
        if (Math.abs(sp - speed) > 0.01f) { speed = sp; speedBRef?.text = "⏩ " + PlayerLogic.speedLabel(speed) }
        val started = st.optBoolean("started", false)
        if (started != engineStarted && System.currentTimeMillis() - rmBeginAt > 3000L) { engineStarted = started; updateTr() }
        setBuffering(!ready)
        val pl = player.isPlaying
        if (pl != rmPlaying) {
            rmPlaying = pl
            val tx = if (pl) "⏸" else "▶"
            if (!buffering) { ctl.play.text = tx; morphText(fsPlayB, tx); if (::centerPlay.isInitialized) morphText(centerPlay, tx) }
        }
    }

    /** من الـtick (200ms): انقطاع الاتصال، أو التلفزيون قفل الفيديو، أو التلفزيون ما فتحش الفيديو أصلًا */
    private fun remoteWatch() {
        mirror?.tick(resumedNow && !pipNow())   // (v570)
        val now = android.os.SystemClock.uptimeMillis()
        val m = LinkSession.mirror
        if (!LinkSession.connected) {
            if (rmDownAt == 0L) rmDownAt = now
            if (now - rmDownAt > 2500L) status = "📺 التلفزيون مش متصل — بحاول أوصّل تاني…"
            if (!rmLiveSeen && now - rmOpenAt > 30000L && !isFinishing) { Notice.show(this, "📺 ما قدرتش أوصل للتلفزيون", 2800L); finish() }
            return
        }
        if (rmDownAt != 0L) { rmDownAt = 0L; status = "📺 متحكم في التلفزيون" }
        if (m.gotFirst && !m.live) {
            if (rmLiveSeen) {
                if (rmLostAt == 0L) rmLostAt = now
                else if (now - rmLostAt > 4000L && !isFinishing) { Notice.show(this, "📺 التلفزيون قفل الفيديو", 2500L); finish() }
            } else if (now - rmOpenAt > 30000L && !isFinishing) { Notice.show(this, "📺 التلفزيون ما فتحش الفيديو", 2800L); finish() }
        } else rmLostAt = 0L
    }

    /** لقطة حية من التلفزيون (/frame) — خيط خلفي واحد. بتبطّأ لوحدها لو الشبكة بطيئة، وواقف = لقطة كل 6ث أو بعد seek */
    private fun startRemoteFrames() {
        if (rmFrames) return
        rmFrames = true
        Thread {
            var lastSig = ""; var lastAt = 0L; var fails = 0
            while (rmFrames && !isFinishing && !isDestroyed) {
                try {
                    val m = LinkSession.mirror
                    val now = System.currentTimeMillis()
                    if (!resumedNow || !m.live || !LinkSession.connected || pipNow()) { Thread.sleep(500L); continue }
                    val playing = m.st.optBoolean("playing", false)
                    val sig = m.st.optString("vid", "") + ":" + (m.position(now) / 1500L)
                    val due = if (rmFrameForce) { rmFrameForce = false; true } else if (playing) now - lastAt >= 600L else ((sig != lastSig && now - lastAt >= 350L) || now - lastAt >= 6000L)
                    if (!due) { Thread.sleep(120L); continue }
                    lastAt = now; lastSig = sig
                    val (c, b) = RemoteClient.getBytes("/frame?w=480&q=60", 6000)
                    if (c == 200 && b.isNotEmpty()) {
                        fails = 0
                        val bmp = android.graphics.BitmapFactory.decodeByteArray(b, 0, b.size)
                        if (bmp != null) runOnUiThread { drawRemoteFrame(bmp) }
                    } else if (c == 204) {
                        Thread.sleep(700L)
                    } else {
                        fails += 1; Thread.sleep(minOf(400L * fails, 4000L))
                    }
                } catch (_: InterruptedException) { break }
                catch (e: Throwable) { try { Thread.sleep(800L) } catch (_: InterruptedException) { break } }
            }
        }.also { it.isDaemon = true; it.name = "RemoteFrames" }.start()
    }

    /** بيرسم اللقطة على نفس SurfaceView (من غير ExoPlayer) — مقاس السطح من مقاس اللقطة عشان الشكل يبقى زي التلفزيون */
    private var rmLastBmp: android.graphics.Bitmap? = null
    @Volatile private var rmFrameForce = false
    /** (v604) بعد التدوير السطح بيتعمل من جديد فاضي؛ والفيديو لو واقف مفيش فريم جديد جاي — فبنرسم آخر فريم تاني */
    private fun redrawLastRemoteFrame() {
        try {
            val b = rmLastBmp ?: return
            if (!remote || b.isRecycled || !::svRef.isInitialized) return
            val hd = svRef.holder; if (!hd.surface.isValid) return
            val cv = hd.lockCanvas() ?: return
            try { cv.drawBitmap(b, null, android.graphics.Rect(0, 0, cv.width, cv.height), null) } finally { hd.unlockCanvasAndPost(cv) }
        } catch (_: Throwable) {}
    }
    private fun drawRemoteFrame(bmp: android.graphics.Bitmap) {
        try {
            if (!remote || isFinishing || isDestroyed || !::svRef.isInitialized) return
            val oldB = rmLastBmp; rmLastBmp = bmp; if (oldB != null && oldB !== bmp) { try { oldB.recycle() } catch (_: Throwable) {} }
            if (bmp.width != vidW || bmp.height != vidH) {
                vidW = bmp.width; vidH = bmp.height; applyFit(svRef, videoBoxRef)
                // (v551) المتحكّم على الموبايل: الشاشة تتبع شكل فيديو التلفزيون — لاندسكيب لو الفيديو عريض، بورتريه لو طولي (مرة واحدة لكل فيديو، ومالهاش دعوة لو بدّلت بإيدك)
                if (!userRot && !autoRotDone && bmp.width > 0 && bmp.height > 0) {
                    autoRotDone = true
                    val wantLand = bmp.width >= bmp.height
                    runOnUiThread { try {
                        val isLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                        if (wantLand != isLand) requestedOrientation = if (wantLand) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    } catch (_: Throwable) {} }
                }
            }
            val hd = svRef.holder
            if (!hd.surface.isValid) return
            val cv = hd.lockCanvas() ?: return
            try { cv.drawBitmap(bmp, null, android.graphics.Rect(0, 0, cv.width, cv.height), null) } finally { hd.unlockCanvasAndPost(cv) }
            ytBusy(false)
        } catch (e: Throwable) { if (rmFrameErr++ < 3) LogStore.err("Player:remoteFrame", e) }
        finally { if (rmLastBmp !== bmp) { try { bmp.recycle() } catch (_: Throwable) {} } }
    }

    /** (v570) نفس منطق مقاس/اتجاه الشاشة بتاع drawRemoteFrame بس لمعاينة الفيديو المحلي (ExoPlayer) */
    private fun applyRemoteSize(w: Int, hh: Int) {
        try {
            if (!remote || isFinishing || isDestroyed || !::svRef.isInitialized || w <= 0 || hh <= 0) return
            if (w != vidW || hh != vidH) {
                vidW = w; vidH = hh; applyFit(svRef, videoBoxRef)
                if (!userRot && !autoRotDone) {
                    autoRotDone = true
                    val wantLand = w >= hh
                    val isLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                    if (wantLand != isLand) requestedOrientation = if (wantLand) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                }
            }
            ytBusy(false)
        } catch (e: Throwable) { LogStore.err("Player:mirrorSize", e) }
    }

    /** «▶ ترجمة» في وضع المتحكم = تستأنف/تبدأ ترجمة التلفزيون */
    private fun remoteBegin(auto: Boolean) {
        if (auto) return
        try { if (engine.fullyDone()) { Notice.show(this, "✓ الفيديو ده مترجم 100% على التلفزيون", 3000L); return } } catch (_: Throwable) {}
        dismissStrip()
        if (noSub) { noSub = false; if (!ccOn) ccToggleFn() }
        rmBeginAt = System.currentTimeMillis()
        engineStarted = true
        LinkSession.send("engine.resume")
        updateTr()
    }

    /** أوامر على الـUI thread (سريعة). النتيجة JSON صغير */
    private fun rpc(op: String, a: org.json.JSONObject): org.json.JSONObject {
        val res = org.json.JSONObject()
        when (op) {
            "state" -> res.put("st", rState())
            "act" -> res.put("handled", rAct(a.optString("a"), a.optLong("v")))
            "play" -> { if (!player.isPlaying) player.play() }
            "pause" -> player.pause()
            "seekto" -> player.seekTo(a.optLong("ms").coerceIn(0L, if (durMs > 0) durMs else Long.MAX_VALUE))
            "volume" -> player.volume = a.optDouble("v", 1.0).toFloat().coerceIn(0f, 1f)
            "speed.set" -> setSpeedFull(a.optDouble("v", 1.0).toFloat())
            "volume.set" -> applyVolumeP(a.optInt("p", 50))   // (v568) صوت التلفزيون من الموبايل
            "link.ack" -> phoneAck = true                                    // (v820) الموبايل استلم وبيشتغل
            "link.cancel" -> { phoneAck = true; refreshAsked = false }       // (v820) الموبايل: لغيت
            "link.fail" -> { if (!phoneAck) { phoneAck = true; refreshAsked = false; a.optString("page").takeIf { it.startsWith("http") }?.let { startLinkRefresh(it) } } }   // (v820) الموبايل مش قدّامه شاشة: كمّل على التلفزيون
            "link.apply" -> { phoneAck = true; refreshAsked = false; val nu = a.optString("url"); if (nu.startsWith("http")) { applyNewLink(LinkRefresh.Res(nu, true, a.optString("cookie"), a.optString("ua"))); Notice.show(this, "✓ اتحدّث لينك الفيديو (من الموبايل)", 2500L) } }
            "dl.info" -> res.put("info", dlInfo())   // (v804) زرار ⬇ في الريموت: وصف الفيديو الشغّال (ملف محلي / لينك + جودات)
            "dl.start" -> res.put("started", dlStart(a))   // (v804) الريموت اختار «حمّل على التلفزيون»
            "track.audio" -> switchAudio(a.optInt("i"))
            "track.quality" -> rSetQ(a.optInt("i"))
            "conf.reload" -> {
                val nc = Cfg.snapshot(); conf = nc
                runOnUiThread { try { fit = Cfg.int("fit", fit).coerceIn(0, 3); fsFit = Cfg.int("fs_fit", fsFit).coerceIn(0, 3); if (::svRef.isInitialized) applyFit(svRef, videoBoxRef) } catch (_: Throwable) {} }   // (v568) ملاءمة الصورة من الموبايل
                runOnUiThread { try { if (::sub.isInitialized) { sub.style = natStyle(SubStyle.load { k, d -> Cfg.str(k, d) }); curIdx = -2 } } catch (_: Throwable) {} }
                runOnUiThread { try { applyChromeFn() } catch (_: Throwable) {} }   // (v604) sub_posy (ارتفاع الترجمة) كان بيتخزّن على التلفزيون من غير ما يتطبّق   // (v551) شكل الترجمة (خط/حجم/شفافية الخلفية) يتطبّق فورًا على شاشة التلفزيون
                if (::engine.isInitialized) {
                    engine.applyConf(nc)
                    engine.toneStyle = Cfg.str("tone_style", ""); engine.toneStrength = Cfg.str("tone_strength", "متوسطة")
                    val cd = Cfg.str("conv_dialect", "")
                    if (cd != engine.convDialect && !(cd.isNotEmpty() && cd == nc.lang)) engine.setConvDialect(cd, false)
                }
            }
            else -> res.put("unknown", true)
        }
        return res
    }

    /** أوامر المحرك: بتتنفّذ على خيط الطلب (مش الـUI). اللي محتاج الـUI بيتبعت بـrunOnUiThread من غير انتظار */
    private fun rpcBg(op: String, a: org.json.JSONObject): org.json.JSONObject {
        val res = org.json.JSONObject()
        if (!::engine.isInitialized) return res.put("err", "noengine")
        val e = engine
        val rep = { m: String -> BrainBus.post("opreport", op + "|" + m) }
        when (op) {
            "engine.get" -> {
                res.put("userPaused", e.userPaused).put("paused", e.paused).put("transOnly", e.transOnly)
                res.put("convDialect", e.convDialect).put("toneStyle", e.toneStyle).put("toneStrength", e.toneStrength)
                res.put("covered", e.coveredSec()).put("pending", e.pendingCount()).put("failed", e.failedCount()).put("fullyDone", e.fullyDone())
                res.put("subs", e.subs.size)
            }
            "engine.set" -> {
                val k = a.optString("name")
                when (k) {
                    "transOnly" -> e.transOnly = a.optBoolean("value")
                    "keepGoing" -> e.keepGoing = a.optBoolean("value")
                    "toneStyle" -> e.toneStyle = a.optString("value")
                    "toneStrength" -> e.toneStrength = a.optString("value")
                    "convDialect" -> e.convDialect = a.optString("value")
                    "titleHint" -> e.titleHint = a.optString("value")
                    "paused" -> e.paused = a.optBoolean("value")
                    "skipIfBaseLang" -> e.skipIfBaseLang = a.optBoolean("value")
                    "baseSkipped" -> e.baseSkipped = a.optBoolean("value")
                    "baseLangCode" -> e.baseLangCode = a.optString("value")
                    else -> res.put("unknown", true)
                }
            }
            "engine.characters" -> res.put("chars", BrainChars.encode(e.charactersNow()))
            "engine.analyzeChars" -> e.analyzeCharsNow(rep) { l -> BrainBus.post("opdone", op + "|" + BrainChars.encode(l).toString()) }
            "engine.pause" -> runOnUiThread { pauseTranslate() }
            "engine.resume" -> runOnUiThread { trAsked = true; beginTranslate() }
            "engine.translateFrom" -> { e.translateFrom(a.optDouble("sec", 0.0)); runOnUiThread { engineKick() } }
            "engine.translateFromStart" -> { e.translateFromStart(); runOnUiThread { engineKick() } }
            "engine.redoAll" -> { e.redoAll(a.optBoolean("keep", true)); runOnUiThread { engineKick() } }
            "engine.redoFrom" -> { e.redoFrom(a.optInt("i"), a.optBoolean("keep", true)); runOnUiThread { engineKick() } }
            "engine.redoOnly" -> { e.redoOnly(a.optInt("i"), a.optBoolean("keep", true)); runOnUiThread { engineKick() } }
            "engine.retryProblems" -> { res.put("n", e.retryProblems()); runOnUiThread { engineKick() } }
            "engine.retryFailed" -> { e.retryFailed(); runOnUiThread { engineKick() } }
            "engine.removeDuplicates" -> res.put("n", e.removeDuplicates())
            "engine.saveVersion" -> e.saveVersion(a.optString("name", "نسخة"), a.optString("dialect", ""))
            "engine.applyVersion" -> res.put("n", e.applyVersion(a.optInt("i")))
            "engine.setConvDialect" -> e.setConvDialect(a.optString("d"), a.optBoolean("existing", true))
            "engine.adoptDialect" -> e.adoptDialect(a.optString("d"))
            "engine.langChanged" -> e.langChanged(a.optString("lang"), a.optDouble("pos", 0.0))
            "engine.saveNow" -> e.saveNow()
            "engine.importSubs" -> e.importSubs(SubCodec.arrayFromJson(a.optJSONArray("subs")))
            "engine.markAllDone" -> e.markAllDone(a.optDouble("lastEnd", 0.0))   // (v686)
            "engine.versions" -> {
                val arr = org.json.JSONArray()
                for (v in e.versions) arr.put(org.json.JSONObject().put("name", v.name).put("dialect", v.dialect).put("count", v.subs.size))
                res.put("versions", arr)
            }
            "engine.recap" -> e.recap(a.optDouble("upToSec", 0.0), rep) { txt -> BrainBus.post("opdone", op + "|" + txt) }
            "engine.rewriteAll" -> e.rewriteAll(a.optString("label"), a.optString("instruction"), a.optDouble("fromSec", 0.0), rep) { n -> BrainBus.post("opdone", op + "|" + n) }
            "engine.refineWholeNow" -> e.refineWholeNow(rep) { n -> BrainBus.post("opdone", op + "|" + n) }
            "engine.correctPronounsNow" -> e.correctPronounsNow(rep) { n -> BrainBus.post("opdone", op + "|" + n) }
            "engine.googleTranslateAll" -> e.googleTranslateAll(rep) { n -> BrainBus.post("opdone", op + "|" + n) }
            else -> res.put("unknown", true)
        }
        return res
    }

    /** لقطة حية JPEG للموبايل (من خيط خلفي — grabSurface بتستنى PixelCopy لحد 1.5ث) */
    fun frameJpeg(maxDim: Int, q: Int): ByteArray? {
        val b = try { grabSurface(maxDim) } catch (_: Throwable) { null } ?: return null
        return try {
            val bo = java.io.ByteArrayOutputStream()
            b.compress(android.graphics.Bitmap.CompressFormat.JPEG, q.coerceIn(30, 90), bo)
            bo.toByteArray()
        } catch (_: Throwable) { null } finally { try { b.recycle() } catch (_: Throwable) {} }
    }

    /** (v532) مسارات HLS/DASH بأعلى bitrate لكل ارتفاع (نفس منطق قايمة 🎞 في المشغّل) */
    private fun rHls(): List<Triple<Int, androidx.media3.common.Tracks.Group, Int>> {
        val tg = ArrayList<Triple<Int, androidx.media3.common.Tracks.Group, Int>>()
        for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) if (g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO)
            for (ti in 0 until g.length) if (g.isTrackSupported(ti)) tg.add(Triple(g.getTrackFormat(ti).height, g, ti))
        return tg.filter { it.first > 0 }
            .sortedWith(compareByDescending<Triple<Int, androidx.media3.common.Tracks.Group, Int>> { it.first }.thenByDescending { it.second.getTrackFormat(it.third).bitrate })
            .distinctBy { it.first }
    }
    /** (v532) الجودات المتاحة كنصوص + رقم الحالية (يوتيوب بقايمة جوداته، أو HLS: «تلقائي» ثم الارتفاعات) */
    private fun rQuals(): Pair<List<String>, Int> {
        if (qOpts.size > 1) return qOpts.map { it.label } to qCur
        val hs = rHls()
        if (hs.size <= 1) return emptyList<String>() to 0
        val labels = listOf("تلقائي") + hs.map { it.first.toString() + "p" }
        val cur = if (hlsH == 0) 0 else 1 + hs.indexOfFirst { it.first == hlsH }.coerceAtLeast(0)
        return labels to cur
    }
    /** (v532) اختيار جودة برقمها في القايمة (من ريموت الموبايل) */
    private fun rSetQ(i: Int) {
        if (qOpts.size > 1) { switchYt(i); return }
        if (i == 0) { hlsAuto(); return }
        val q = rHls().getOrNull(i - 1) ?: return
        hlsPick(q.second, q.third, q.first)
    }

    /** (v531) مراجع أزرار شريط المشغّل (بتتسجّل وقت بناء الشريط) عشان ريموت الموبايل يدوس نفس الزرار */
    private val rcViews = HashMap<String, View>()
    private fun rcClick(k: String) { try { rcViews[k]?.performClick() } catch (e: Throwable) { LogStore.err("Player:rc:" + k, e) } }

    // (v1044) قوايم التلفزيون اللي بتتفتح من ريموت الموبايل بتتعرض على الموبايل: بنلتقط القايمة (RcCapture) ونبعتها، والموبايل بيرجّع رقم الاختيار (pick)
    @Volatile var rcPm: org.json.JSONObject? = null
    private var rcPmActs: List<() -> Unit> = emptyList()
    private var tvMenuCol: LinearLayout? = null
    private var tvToolsCol: LinearLayout? = null
    private fun rcPmRun(block: () -> Unit) {
        RcCapture.captured = null; RcCapture.active = true
        try { block() } catch (e: Throwable) { LogStore.err("Player:pm", e) } finally { RcCapture.active = false }
        val c = RcCapture.captured; RcCapture.captured = null
        if (c != null) {
            val lst = ArrayList<() -> Unit>()
            for (i in c.labels.indices) lst.add { try { c.cb?.onClick(RcCapture.noopDi, i) } catch (e: Throwable) { LogStore.err("Player:pmcb", e) }; Unit }
            rcPmActs = lst
            rcPm = org.json.JSONObject().put("t", c.title).put("l", org.json.JSONArray(c.labels))
        }
    }
    private fun rcPmCol(col: LinearLayout?, title: String) {
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        if (col != null) for (i in 0 until col.childCount) {
            val ch = col.getChildAt(i)
            val t = (ch as? TextView)?.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty() && ch.hasOnClickListeners()) { labels.add(t); acts.add { try { ch.performClick() } catch (e: Throwable) { LogStore.err("Player:pmcol", e) }; Unit } }
        }
        if (labels.isEmpty()) return
        rcPmActs = acts
        rcPm = org.json.JSONObject().put("t", title).put("l", org.json.JSONArray(labels))
    }
    /** (v1051) قايمة جاهزة (عنوان + صفوف) تتبعت للموبايل بدل ما تتعرض على التلفزيون */
    private fun rcPmList(title: String, items: List<Pair<String, () -> Unit>>) {
        if (items.isEmpty()) return
        rcPmActs = items.map { it.second }
        rcPm = org.json.JSONObject().put("t", title).put("l", org.json.JSONArray(items.map { it.first }))
    }
    private fun rcPmOpen(kind: String, anchor: View) {
        when (kind) {
            "voice" -> rcPmRun { voiceMenu() }            // (v1051) 🎙 فصل صوت الكلام
            "notice" -> rcPmRun { noticePopup(anchor) }   // (v1051) 🔔 الإشعارات
            "chap" -> rcPmRun { chaptersSheet() }         // (v1051) 📑 فصول الفيديو
            "lang" -> rcPmRun { langPopup(anchor) }       // (v1051) 🌐 لهجة الترجمة
            "whisper" -> { trAsked = true; h.postDelayed({ trAsked = false }, 1500L); rcPmRun { whisperStart() } }   // (v1051) 📴 وشبر: اختيار لغة الكلام على الموبايل
            "subs" -> rcPmRun { tvSubTracksDialog(anchor) }
            "more" -> rcPmRun { tvMoreDialog(anchor) }
            "wiz" -> rcPmRun { translateMenu(anchor) }
            "menu" -> rcPmCol(tvMenuCol, "☰ القايمة")
            "tools" -> rcPmCol(tvToolsCol, "⬇ مركز التحميل والليستة")
        }
    }
    private fun rcPmPick(i: Int) {
        val a = rcPmActs.getOrNull(i) ?: return
        rcPmActs = emptyList()
        rcPmRun { a() }
    }

    private fun rAct(a: String, v: Long): Boolean {
        val anchor = window.decorView
        if (a.startsWith("pm_")) { rcPmOpen(a.removePrefix("pm_"), anchor); return true }
        if (a == "pick") { rcPmPick(v.toInt()); return true }
        if (a.startsWith("tr_")) { trAsked = true; h.postDelayed({ trAsked = false }, 1500L) }   // (v685) الأوامر من الموبايل ما تفتحش سؤال على شاشة التلفزيون
        when (a) {
            "tr_cont" -> { trAsked = true; beginTranslate() }
            "tr_here" -> { trAsked = true; trHere = true; beginTranslate() }
            "tr_fresh" -> trFresh()
            "toggle" -> togglePlay()
            "seek" -> tvSeek(v)
            "seekto" -> player.seekTo(v.coerceIn(0L, if (durMs > 0) durMs else Long.MAX_VALUE))
            "prev" -> stepEpisode(-1)
            "next" -> stepEpisode(1)
            "speed" -> tvCycleSpeed()
            "fit" -> runOnUiThread { try { cycleFitNow() } catch (e: Throwable) { LogStore.err("Player:fit", e) } }   // (v707) الأمر بييجي من خيط الشبكة: تغيير حجم السطح لازم على خيط الواجهة
            "rotate" -> runOnUiThread { rotateVideoNow() }   // (v604) تدوير صورة الفيديو من الموبايل
            "cc" -> { ccOn = !ccOn; if (!ccOn) sub.show(null) else curIdx = -2 }
            "scale" -> tvSubScale(v.toInt())
            "shift" -> tvSubShift(v)
            "audio" -> audPopFn?.invoke(anchor)
            "quality" -> qualPopFn?.invoke(anchor)
            "qset" -> rSetQ(v.toInt())     // (v532) اختيار الجودة من قايمة الموبايل
            "aset" -> switchAudio(v.toInt())   // (v532) اختيار لغة الصوت من قايمة الموبايل
            "translate" -> translateMenu(anchor)
            "more" -> tvMoreDialog(anchor)
            "subs" -> tvSubTracksDialog(anchor)
            // (v531) أزرار الشريط الكامل اللي في مشغّل الموبايل
            "loop" -> loopCycle()   // (v781) عادي ← نفس الفيديو ← كل الفولدر
            "loopset" -> loopSet(v.toInt())   // (v787) زرار «تكرار واحد» (1) / «تكرار الكل» (2) في الريموت: دوسة تانية على نفس الوضع = يقفله
            "log" -> toggleLog()
            "sent" -> { try { if (::sentDlg.isInitialized) sentDlg.show() } catch (_: Throwable) {} }
            "chars" -> showChars()
            "dual" -> rcClick("dual")
            "dualset" -> {   // (v695) وضع عرض الترجمة من ريموت الموبايل: 0 ترجمة فقط · 1 ترجمة+أصلي · 2 إنجليزي · 3 أصلي فقط · 4 أصلي+ترجمة
                val n = v.toInt().coerceIn(0, 4); Cfg.put("sub_dual", n.toString()); try { restyleFn() } catch (_: Throwable) {}; curIdx = -2
                say("🔀 " + kotlin.collections.listOf("ترجمة فقط", "ترجمة + الأصلي", "الإنجليزي تحت", "الأصلي فقط", "الأصلي + الترجمة")[n])
            }
            "bgon" -> rcClick("bgon")
            "ai" -> rcClick("ai")
            "lock" -> setLock(!uiLocked)
            "close" -> { try { player.pause() } catch (_: Throwable) {}; try { saveRecent() } catch (_: Throwable) {}; try { retireEngine() } catch (_: Throwable) {}; finish() }   // (v560) كبسولة «✕» على الموبايل: اقفل الفيديو على التلفزيون
            "notice" -> noticePopup(anchor)
            "visual" -> visualSnap()
            "vsnap" -> visualSnapBack(1500L)   // (v676) 👁 من ريموت الموبايل: يرجع 1.5ث ويترجم
            "menu" -> tvMenuFn?.invoke(anchor)
            "tools" -> tvToolsFn?.invoke(anchor)
            // (v682) أوامر صفحة «المشغّل» في الريموت (PlayerPad): مباشرة من غير قوايم على شاشة التلفزيون
            "speedset" -> tvSetSpeed((v / 100f).coerceIn(0.25f, 4f))
            "fontprev" -> {
                val fs = SubStyle.fonts; val cf = SubStyle.load { k, d -> Cfg.str(k, d) }.font
                val n = fs[(fs.indexOfFirst { it.id == cf } - 1 + fs.size) % fs.size]
                Cfg.put("sub_font", n.id); try { restyleFn() } catch (_: Throwable) {}; say("🔤 " + n.label)
            }
            "bgopa" -> { val n = v.toInt().coerceIn(0, 100); Cfg.put("sub_bgopa", n.toString()); Cfg.put("sub_nobg", if (n == 0) "1" else "0"); try { restyleFn() } catch (_: Throwable) {}; say("◼ شفافية الخلفية: $n%") }
            "visdlg" -> visualDialog()
            "netdlg" -> netDialog()
            "ytmode" -> toggleYtMode()
            "studio" -> subStudio()
            "syncstrip" -> toggleSyncStrip()
            "shift0" -> tvSubShift(-offsetMs)
            "ab_a" -> abSet(0)
            "ab_b" -> abSet(1)
            "ab_x" -> abClear()
            "redo" -> trStartSheet(anchor)   // (v1379) شيت الإعادة القديم اتشال — الشيت الجديد بالـ٤ زراير
            "modeset" -> trSettings(anchor)
            "posy" -> { val n = (Cfg.int("sub_posy", 0) + v.toInt()).coerceIn(-60, 240); Cfg.put("sub_posy", n.toString()); runOnUiThread { try { restyleFn(); applyChromeFn() } catch (_: Throwable) {}; curIdx = -2 }; say("↕ موضع الترجمة: $n") }   // (v759) كان بيحفظ القيمة من غير ما يطبّق الهامش (applyChromeFn) — ودلوقتي بينزل تحت كمان (-60)
            "pip" -> runOnUiThread { try { enterPip() } catch (e: Throwable) { LogStore.err("Player:rpip", e) } }   // (v712) نافذة صغيرة من الريموت
            "voice" -> runOnUiThread { try { voiceMenu() } catch (e: Throwable) { LogStore.err("Player:rvoice", e) } }   // (v712) فصل صوت الكلام
            "nextlist" -> runOnUiThread { try { openNextSheet() } catch (e: Throwable) { LogStore.err("Player:rnext", e) } }   // (v712) 📃 التالي (يوتيوب)
            "tr_free", "tr_gem" -> remoteTrGuarded { geminiAsk() }   // (v743) FreeLLM اتشال — الزرارين القدام بيفتحوا اختيار جيميناي
            "tr_gem_acc" -> remoteTrGuarded { trAsked = true; h.post { Cfg.put("tr_bal", "0"); Cfg.put("tr_one", "0"); Cfg.put("dual_listen", "2"); Cfg.put("fastmode", "0"); geminiStart() } }   // (v1043) الاختيار اتعمل على الموبايل — من غير نافذة على التلفزيون
            "tr_gem_fast" -> remoteTrGuarded { trAsked = true; h.post { Cfg.put("tr_bal", "0"); Cfg.put("tr_one", "0"); Cfg.put("dual_listen", "0"); Cfg.put("fastmode", "0"); geminiStart() } }
            "tr_gem_quick" -> remoteTrGuarded { trAsked = true; h.post { Cfg.put("tr_bal", "0"); Cfg.put("tr_one", "0"); Cfg.put("fastmode", "1"); geminiStart() } }
            "tr_gem_bal" -> remoteTrGuarded { trAsked = true; h.post { Cfg.put("tr_bal", "1"); Cfg.put("tr_one", "0"); geminiStart() } }   // (دمج v1090) ⚖ متوازن   // (v1068) ⚡ سريع
            "tr_whisper" -> whisperStart()
            "tr_gtx" -> startGeminiTranscribe()
            "tr_wtx" -> offlineQuick(true)
            "tr_pause" -> pauseTranslate()
            "tr_cancel" -> runOnUiThread { try { cancelTranslate() } catch (e: Throwable) { LogStore.err("Player:rcancel", e) } }   // (v759) إلغاء الترجمة (مش مؤقت) من الريموت — التأكيد بيتعمل على الموبايل
            "tr_resume" -> { trAsked = true; beginTranslate() }
            "tr_bg" -> translateInBackground()
            "tr_wiz" -> translateMenu(anchor)   // (v743) المعالج القديم اتشال
            "subdlg" -> tvSubDialog(v.toInt())
            "font" -> {
                val fs = SubStyle.fonts; val cf = SubStyle.load { k, d -> Cfg.str(k, d) }.font
                val n = fs[(fs.indexOfFirst { it.id == cf } + 1) % fs.size]
                Cfg.put("sub_font", n.id); try { restyleFn() } catch (_: Throwable) {}; say("🔤 " + n.label)
            }
            else -> {   // (v529) 📄 ترجمة ملف الترجمة من الموبايل · (v682) لهجة / أسلوب / أدوات الذكاء من صفحة المشغّل
                if (a.startsWith("cfgset:")) {   // (v759) استوديو الترجمة على الموبايل: «cfgset:المفتاح|القيمة» — بيتطبّق على الفور على التلفزيون
                    val kv = a.substring(7); val ix = kv.indexOf('|')
                    if (ix > 0) {
                        val k = kv.substring(0, ix); val vv = kv.substring(ix + 1)
                        val fixed: String? = when (k) {
                            "sub_scale" -> (vv.toIntOrNull() ?: 100).coerceIn(60, 200).toString()
                            "sub_blur" -> (vv.toIntOrNull() ?: 0).coerceIn(0, 20).toString()
                            "sub_posy" -> (vv.toIntOrNull() ?: 0).coerceIn(-60, 240).toString()
                            "sub_uni_on" -> if (vv == "1") "1" else "0"
                            "sub_uni_color" -> if (Regex("#[0-9A-Fa-f]{6}").matches(vv)) vv else null
                            "sub_font" -> if (SubStyle.fonts.any { it.id == vv }) vv else null
                            "sub_fontstyle" -> if (SubStyle.fontStyles.any { it.first == vv }) vv else null
                            else -> null
                        }
                        if (fixed != null) {
                            Cfg.put(k, fixed)
                            if (k == "sub_uni_color") Cfg.put("sub_uni_on", "1")
                            runOnUiThread { try { restyleFn(); applyChromeFn() } catch (_: Throwable) {}; curIdx = -2 }
                        }
                    }
                }
                else if (a.startsWith("mset:")) runOnUiThread { try { remoteMset(a.substring(5)) } catch (e: Throwable) { LogStore.err("Player:rmset", e) } }   // (v762) ⚙ إعدادات الترجمة من الموبايل: «mset:lang:en» / model / aud / dual / swap / term
                else if (a.startsWith("subnet:")) subNet(a.substring(7))   // (v746)
                else if (a.startsWith("subhunt:")) subHunt(a.substring(8).toIntOrNull() ?: 0)
                else if (a == "subalign") subAlignRun(false)
                else if (a.startsWith("wtr:")) runOnUiThread { try { setWhisperTr(a.substring(4)) } catch (e: Throwable) { LogStore.err("Player:rwtr", e) } }   // (v712) اختيار مترجم وضع وشبر من الريموت (free / google)
                else if (a.startsWith("subfile:")) sfRemote(a)
                else if (a.startsWith("sfgo:")) sfGo(a)
                else if (a.startsWith("dialect:") || a.startsWith("tone:") || a.startsWith("ai:")) {
                    if (!(::engine.isInitialized && engineStarted)) say("✨ ابدأ الترجمة الأول")
                    else if (a.startsWith("dialect:")) dialectPick(a.substring(8))
                    else if (a.startsWith("ai:")) applyAiOptions(listOf(a.substring(3)))
                    else {
                        val p = a.substring(5).split("|")
                        val lbl = (p.getOrNull(0) ?: "").ifBlank { "تلقائي" }; val dg = (p.getOrNull(1) ?: "").ifBlank { "متوسطة" }; val ap = p.getOrNull(2) ?: ""
                        val sv = if (lbl == "تلقائي") "" else lbl
                        Cfg.put("tone_style", sv); Cfg.put("tone_strength", dg); engine.toneStyle = sv; engine.toneStrength = dg
                        if (ap.isNotEmpty()) runTool("أسلوب $lbl ($dg)", toneInstrOf(lbl, dg), ap == "all")
                    }
                }
                else return false
            }
        }
        return true
    }

    // ===== (v461) ريموت التلفزيون (وضع 📺 بس): يمين/شمال = تقديم/ترجيع 10ث · فوق/تحت = حجم الترجمة ·
    // أرقام = قفز بالوقت (آخر رقمين ثواني، اللي قبلهم دقايق — دوس OK أو استنى ثانيتين) · OK/تشغيل = تشغيل/إيقاف
    private val tvH = android.os.Handler(android.os.Looper.getMainLooper())
    private var tvDigits = ""
    private var tvBar: TvPlayerBar? = null
    /** (v477 م4) بناء شريط التحكم وربطه بدوال المشغّل (تلفزيون بس) */
    private fun tvInitBar(frame: FrameLayout) {
        val self = this
        val b = TvPlayerBar(this, ui, th, object : TvPlayerBar.Actions {
            override fun pos(): Long = try { player.currentPosition } catch (_: Throwable) { 0L }
            override fun dur(): Long = durMs
            override fun playing(): Boolean = try { player.isPlaying } catch (_: Throwable) { false }
            override fun covSegs(): List<DoubleArray> = segCov   // (v693) خطوط الترجمة على شريط التلفزيون
            override fun pendSegs(): List<DoubleArray> = segPend
            override fun refineSegs(): List<DoubleArray> = try { engine.refiningSegs } catch (_: Throwable) { emptyList() }
            override fun sentSegs(): List<DoubleArray> = allSentSegs()   // (دمج v1081) شريط التلفزيون
            override fun toggle() { togglePlay() }
            override fun seekBy(ms: Long) { tvSeek(ms) }
            override fun seekTo(ms: Long) { try { player.seekTo(ms.coerceIn(0L, if (durMs > 0) durMs else Long.MAX_VALUE)) } catch (_: Throwable) {} }
            override fun prev() { stepOrSeek(-1) }
            override fun next() { stepOrSeek(1) }
            override fun speedLabel(): String = PlayerLogic.speedLabel(speed)
            override fun cycleSpeed() { tvCycleSpeed() }
            override fun fitLabel(): String = fitNameOf(curFit())
            override fun cycleFit() { cycleFitNow() }
            override fun ccOn(): Boolean = ccOn
            override fun toggleCc() { ccOn = !ccOn; if (!ccOn) sub.show(null) else curIdx = -2 }
            override fun subScale(d: Int) { tvSubScale(d) }
            override fun subShift(dMs: Long) { tvSubShift(dMs) }
            override fun hasAudio(): Boolean = aTracks.size > 1 || audLocalMode()
            override fun audio(anchor: View) { audPopFn?.invoke(anchor) }
            // (v517) الشريط المبسّط (تلفزيون بس — التابلت شريطه القديم زي ما هو)
            override fun slim(): Boolean = DeviceUi.isTv(self)
            override fun trLabel(): String = tvTrLabel()
            override fun trColor(): Int = tvTrColor()
            override fun translate(anchor: View) { translateMenu(anchor) }
            override fun hasQuality(): Boolean = qualPopFn != null && (qOpts.size > 1 || uri == null)
            override fun quality(anchor: View) { qualPopFn?.invoke(anchor) }
            override fun subDialog() { tvSubDialog() }
            override fun more(anchor: View) { tvMoreDialog(anchor) }
            override fun subTracks(anchor: View) { tvSubTracksDialog(anchor) }
            override fun scrubPos(): Long = tvScrubTo
            // (v640) شريط التلفزيون الذكي
            override fun hasPrevNext(): Boolean = true   // (v749) كانت بتختفي لو المكتبة مش متحمّلة؛ ⏮⏭ بيرجعوا لتقديم/ترجيع لو مفيش حلقة
            override fun pickSpeed(anchor: View) { tvSpeedDialog() }
            override fun subsAvailable(): Boolean = tvSubsAvailable()
            override fun subSourcesMulti(): Boolean = tvSubSourcesMulti()
            override fun subSources(anchor: View) { tvSubTracksDialog(anchor) }
            override fun hasSentences(): Boolean = tvHasSentences()
            override fun sentences() { try { if (::sentDlg.isInitialized) sentDlg.show() } catch (_: Throwable) {} }
            override fun sleepLabel(): String = tvSleepLabel()
            override fun sleepPick(anchor: View) { tvSleepDialog() }
            override fun subPage() { tvSubPage() }
        })
        frame.addView(b.view, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        val sv = TvScrubOverlay(this, ui, th.primary)   // (v569) شريط التقديم بالأسهم (والشريط الكبير مخفي)
        frame.addView(sv.view, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(ui.dp(64), 0, ui.dp(64), ui.dp(36)) })
        tvScrubOv = sv
        b.onVis = { tvChromeGate() }
        tvBar = b
    }
    // ===== (v517) شريط التلفزيون المبسّط: دوال الأزرار =====
    private var tvMenuFn: ((View) -> Unit)? = null
    private var tvToolsFn: ((View) -> Unit)? = null
    private fun tvSetSpeed(s: Float) {
        speed = s; try { player.setPlaybackSpeed(speed) } catch (_: Throwable) {}
        Cfg.p.edit().putString("speed", speed.toString()).putString("speed:$vid", speed.toString()).apply()
        speedBRef?.text = "⏩ " + PlayerLogic.speedLabel(speed)
    }
    private fun tvCycleSpeed() { tvSetSpeed(PlayerLogic.nextSpeed(speed)) }
    /** (v640) ⏩ دوسة واحدة = قايمة السرعات (بدل 6 دوسات لف) */
    private fun tvSpeedDialog() {
        val sp = PlayerLogic.speeds
        val labels = sp.map { (if (Math.abs(it - speed) < 0.01f) "✓ " else "") + "⏩ " + PlayerLogic.speedLabel(it) }.toTypedArray()
        GAlert(this).setTitle("⏩ سرعة التشغيل").setItems(labels) { _, w ->
            if (w in sp.indices) { tvSetSpeed(sp[w]); Notice.show(this, "⏩ " + PlayerLogic.speedLabel(speed), 1100L); tvBar?.refresh() }
        }.show()
    }
    // ===== (v640) شريط التلفزيون الذكي: شروط ظهور الأزرار =====
    private var tvPnUri = ""; private var tvPnVal = false
    /** ⏮ ⏭ بس لو الفيديو من مكتبة الجهاز وفي فولدره أكتر من فيديو (بيتخزّن لكل فيديو عشان الفرز مايتكررش كل 400ms) */
    private fun tvHasPrevNext(): Boolean = try {
        val u = uri?.toString() ?: ""
        if (u.isNotEmpty() && u == tvPnUri) tvPnVal
        else {
            val p = libSibs()
            if (p == null) { tvPnUri = ""; tvPnVal = false; false }
            else { tvPnUri = u; tvPnVal = p.first.size > 1; tvPnVal }
        }
    } catch (_: Throwable) { false }
    /** مسارات الترجمة الأصلية جوه الفيديو (سوفت صب) */
    private fun tvNativeTexts(): List<androidx.media3.common.Tracks.Group> = try {
        val tc = androidx.media3.common.C.TRACK_TYPE_TEXT
        (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>()).filter { it.type == tc && it.length > 0 && it.isSupported }
    } catch (_: Throwable) { emptyList() }
    /** ترجمة البرنامج: بدأت أو فيها جمل */
    private fun tvProgTr(): Boolean = try { ::engine.isInitialized && (engineStarted || engine.subs.isNotEmpty()) } catch (_: Throwable) { false }
    private fun tvHasVersions(): Boolean = try { ::engine.isInitialized && engine.versions.isNotEmpty() } catch (_: Throwable) { false }
    private fun tvSubsAvailable(): Boolean = try { tvProgTr() || tvNativeTexts().isNotEmpty() || tvHasVersions() } catch (_: Throwable) { false }
    private fun tvSubSourcesMulti(): Boolean = try {
        tvNativeTexts().size + (if (tvProgTr()) 1 else 0) + (if (tvHasVersions()) 1 else 0) >= 2
    } catch (_: Throwable) { false }
    private fun tvHasSentences(): Boolean = try { ::sentDlg.isInitialized && ::engine.isInitialized && engine.subs.isNotEmpty() } catch (_: Throwable) { false }
    private fun tvSleepLeftMin(): Int = if (sleepAtMs > 0L) ((sleepAtMs - System.currentTimeMillis() + 59_999L) / 60_000L).toInt().coerceAtLeast(1) else 0
    private fun tvSleepLabel(): String = if (sleepAtMs > 0L) "😴 " + tvSleepLeftMin() else if (sleepEndOfVideo) "😴 آخر" else ""
    /** (v640) 😴 مؤقت النوم على التلفزيون: قايمة (إلغاء / 15 / 30 / 45 / 60 / 90 / لما الفيديو يخلص) */
    private fun tvSleepDialog() {
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        if (sleepAtMs > 0L || sleepEndOfVideo) add("🚫 إلغاء المؤقت" + (if (sleepAtMs > 0L) " (فاضل " + tvSleepLeftMin() + " د)" else "")) { setSleepTimer(0); say("المؤقت اتلغى") }
        for (m in intArrayOf(15, 30, 45, 60, 90)) add("😴 بعد $m دقيقة") { setSleepTimer(m); say("😴 الفيديو هيقف بعد $m دقيقة (والصوت بينزل بهدوء)") }
        add("🎬 لما الفيديو ده يخلص") { setSleepTimer(-1); say("😴 الفيديو هيقف في آخره") }
        GAlert(this).setTitle("😴 مؤقت النوم").setItems(labels.toTypedArray()) { _, w -> if (w in acts.indices) { acts[w](); tvBar?.refresh() } }.show()
    }
    private fun tvSubShift(dMs: Long) {
        offsetMs = (offsetMs + dMs).coerceIn(-10000L, 10000L)
        Cfg.p.edit().putString("sub_offset_ms:$vid", offsetMs.toString()).apply(); srtSoon(); curIdx = -2
        Notice.show(this, String.format("⏱ إزاحة الترجمة: %+.2fs", offsetMs / 1000.0), 1100L)
    }
    /** (v641) ترجمة السوفت صب شغّالة (sfRun): الشريط كان فاضل «▶ ترجم» طول ما بتترجم فكان باين إنها ما بدأتش */
    private fun sfPct(): Int { val m = Regex("(\\d+)/(\\d+)").find(sfBusy) ?: return 0; val d = m.groupValues[1].toIntOrNull() ?: 0; val n = m.groupValues[2].toIntOrNull() ?: 0; return if (n > 0) (d * 100 / n).coerceIn(0, 100) else 0 }
    /** (v661) نسبة ترجمة السوفت صب بدل «جاري الترجمة…» الثابتة: ⏳ ترجمة السوفت 37% (وفي مرحلة التنقيح: 🧹 تنقيح 12%) */
    private fun sfChip(): String = (if (sfBusy.startsWith("🧹")) "🧹 تنقيح " else "⏳ ترجمة السوفت ") + sfPct() + "%"
    private fun tvSfShort(): String = (if (sfBusy.startsWith("🧹")) "🧹 " else "⏳ سوفت ") + sfPct() + "%"
    @Volatile private var sfDoneUri = ""
    /** (v703) وصف اللي اترجم بيه ملف الترجمة فعلًا (مترجم · لهجة · أسلوب) — بيتعرض مكان «وشبر + LibreTranslate» (ده وضع محرك الصوت المحفوظ مش ملف الترجمة) */
    @Volatile private var sfDoneLabel = ""
    @Volatile private var sfShown = false
    private var sfOffKey = ""
    @Volatile private var sfBatchFresh = false
    private fun hasSoftSubNow(): Boolean {
        val u = uri?.toString() ?: ""
        if (u.isNotEmpty() && sfDoneUri == u) return true
        return try {
            val sc = sfSidecar()
            val ours = sc != null && SrtWriter.isOurs(this, sc)
            val realSide = if (sc == null) false else if (!ours) true else subCands().any { f -> !SrtWriter.isOurs(this, f) }
            realSide || castSubFile?.exists() == true || mobileSub?.exists() == true || (sfNativeCount() - (if (ours) 1 else 0)) > 0
        } catch (_: Throwable) { false }
    }
    private fun modeLabelNow(): String = try {
        if (!engineStarted && sfDoneLabel.isNotEmpty() && sfDoneUri.isNotEmpty() && sfDoneUri == (uri?.toString() ?: "")) sfDoneLabel else modeName()
    } catch (_: Throwable) { "" }
    // (v1119) عدّاد الجمل المترجمة/المفرّغة — نفس قيمة «جمل_المحرك» في سطر التشخيص
    private fun subCountNow(): Int = try { if (::engine.isInitialized) engine.subs.size else 0 } catch (_: Throwable) { 0 }
    // (v1126) نقط حالة المفاتيح (🔵🟢🔴🟠) بره اللوج: جنب عدّاد الجمل في زرار/شارة الترجمة
    private fun dotsNow(): String = try { val d = if (trIsTx() && Cfg.groqTx() && ::engine.isInitialized) engine.keyDots() else fastTr?.keyDots() ?: engine.keyDots(); if (d.isBlank()) "" else " $d" } catch (_: Throwable) { "" }   // (v1376) في تفريغ جروك: نقطة جروك الحقيقية — fastTr الباقي من جلسة متوازنة قديمة كان بيسرّب نقط مسبح جيميناي
    private var lastDotsShown = ""
    // (v1126) كشف النت البطيء: باتشات متبعتة ومفيش ولا جملة/نسبة اتحرّكت بقالها 35ث ← إشعار (مرة/90ث) وسطر في اللوج، وإشعار تاني لما يرجع يتحرّك
    private var progKey = ""; private var progAt = 0L; private var stallNotedAt = 0L; private var stallActive = false
    private fun netStallWatch() {
        try {
            if (!engineStarted || !::engine.isInitialized || engine.userPaused || remote) { progAt = 0L; return }
            val now = System.currentTimeMillis()
            val k = subCountNow().toString() + "/" + trPct
            if (k != progKey || progAt == 0L) {
                progKey = k; progAt = now
                if (stallActive) { stallActive = false; Notice.show(this, "✅ النت رجع — الترجمة بتكمّل", 2600L); LogStore.add("✅ النت رجع — الباتشات بتتحرّك تاني") }
                return
            }
            if (now - progAt < 35_000L || now - stallNotedAt < 90_000L) return
            if (allSentSegs().isEmpty()) return   // مفيش باتشات متبعتة: مفيش حاجة مستنية رد
            stallNotedAt = now; stallActive = true
            val sec = (now - progAt) / 1000
            if (Overload.active()) {
                LogStore.add("🔥 جيميناي عليه ضغط (503) — مفيش رد بقالها " + sec + "ث · المفاتيح:" + dotsNow())
                Notice.show(this, "🔥 جيميناي عليه ضغط دلوقتي (مش النت بتاعك)\nالترجمة بتعيد لوحدها وهتكمّل أول ما يهدى", 5000L)
                return
            }
            LogStore.add("🐌 النت بطيء — باتشات متبعتة ومفيش رد بقالها " + sec + "ث (الرفع أو الرد متأخر) · المفاتيح:" + dotsNow())
            Notice.show(this, "🐌 النت بطيء — الباتشات اتبعتت ومفيش رد بقالها " + sec + " ث\nالترجمة هتكمّل لوحدها أول ما النت يتحسّن", 5000L)
        } catch (_: Throwable) {}
    }
    private fun tvTrLabel(): String = try {
        if (!engineStarted && sfBusy.isNotEmpty()) tvSfShort()
        else if (!engineStarted && sfLive.isNotEmpty()) "💬 لحظية"
        else if (!engineStarted && sfDoneUri.isNotEmpty() && sfDoneUri == (uri?.toString() ?: "")) "✅ مترجم"
        else if (!engineStarted && hasSoftSubNow()) "💬 سوفت سب"
        else if (!engineStarted) (if (trIsTx()) "✍ تفريغ" else "▶ ترجم")
        // (v1119) عدّاد الجمل في زرار الترجمة على التلفزيون: «⏳ 19% · 42 جملة»
        else (if (::engine.isInitialized && engine.userPaused) "⏸ " else if (trPct >= 100) "✅ " else "⏳ ") + trPct + "%" + " · " + subCountNow() + " جملة" + dotsNow()
    } catch (_: Throwable) { "▶ ترجم" }
    private fun tvTrColor(): Int = try {
        if (!engineStarted && sfBusy.isNotEmpty()) 0xFF2A8C8C.toInt()
        else if (!engineStarted && sfDoneUri.isNotEmpty() && sfDoneUri == (uri?.toString() ?: "")) 0xFF2E7D32.toInt()
        else if (!engineStarted && hasSoftSubNow()) 0xFF2E7D32.toInt()
        else if (!engineStarted) (if (trIsTx()) 0xFF2A8C8C.toInt() else 0xFFE53935.toInt())
        else if (::engine.isInitialized && engine.userPaused) 0xFF8D6E00.toInt() else if (trPct >= 100) 0xFF2E7D32.toInt() else 0xFF2A8C8C.toInt()
    } catch (_: Throwable) { 0xFFE53935.toInt() }
    /** (v639) لوحة Aa⏱ بتبويبين: 🔤 الشكل (حجم/توقيت/خط/خلفية) · ✨ الذكاء (لهجات/أسلوب/أدوات/شخصيات). يمين/شمال بيبدّل التبويب، ودوسة واحدة على أي أداة بتشغّلها */
    private fun tvSubDialog(startTab: Int = 0) {
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(26), ui.dp(18), ui.dp(26), ui.dp(18)); background = ui.box(0xF2181B20.toInt(), 0x33FFFFFF, 20)
        }
        val engOk = ::engine.isInitialized && engineStarted
        val aiWhy = when { !engOk -> "ابدأ الترجمة الأول"; !caps().dialect -> "الوضع ده مفيهوش لهجات"; else -> "" }
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER }
        val bodyHolder = android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        val tabViews = ArrayList<TextView>()
        fun btn(t: String, sp: Float = 18f, on: Boolean = true, f: (TextView) -> Unit): TextView = TextView(this).apply {
            text = t; textSize = sp; gravity = Gravity.CENTER; setTextColor(Color.WHITE); typeface = android.graphics.Typeface.DEFAULT_BOLD
            background = ui.box(0x33FFFFFF, 0x22FFFFFF, 12); isFocusable = true; isClickable = true; alpha = if (on) 1f else 0.45f
            setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8))
            setOnClickListener { f(this) }
        }
        fun lp(m: Int = 4) = LinearLayout.LayoutParams(-2, -2).apply { setMargins(ui.dp(m), ui.dp(m), ui.dp(m), ui.dp(m)) }
        fun flpm() = ViewGroup.MarginLayoutParams(-2, -2).apply { setMargins(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(4)) }
        fun note(t: String) = TextView(this).apply { text = t; textSize = 14f; setTextColor(0xFF9AA0A6.toInt()); gravity = Gravity.CENTER; setPadding(ui.dp(8), ui.dp(2), ui.dp(8), ui.dp(2)) }

        // ± سطر: − label +  (LTR عشان − شمال و+ يمين)
        fun stepLine(col: LinearLayout, text: () -> String, minus: () -> Unit, plus: () -> Unit) {
            val lbl = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
            fun paint() { lbl.text = text() }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
            r.addView(btn("−", 24f) { minus(); paint() }, LinearLayout.LayoutParams(-2, -2))
            r.addView(lbl, LinearLayout.LayoutParams(ui.dp(360), -2))
            r.addView(btn("+", 24f) { plus(); paint() }, LinearLayout.LayoutParams(-2, -2))
            paint()
            col.addView(r, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, ui.dp(5), 0, ui.dp(5)) })
        }

        fun buildLook(): View {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_HORIZONTAL }
            stepLine(col, { "🔤 حجم الترجمة: " + Cfg.int("sub_scale", 100) + "%" }, { tvSubScale(-10) }, { tvSubScale(10) })
            stepLine(col, { String.format("⏱ توقيت الترجمة: %+.2f ث", offsetMs / 1000.0) }, { tvSubShift(-250L) }, { tvSubShift(250L) })
            stepLine(col, {
                val fs = SubStyle.fonts; val cf = SubStyle.load { k, dd -> Cfg.str(k, dd) }.font
                "🔠 الخط: " + (fs.firstOrNull { it.id == cf }?.label ?: "—")
            }, {
                val fs = SubStyle.fonts; val cf = SubStyle.load { k, dd -> Cfg.str(k, dd) }.font
                val n = fs[(fs.indexOfFirst { it.id == cf } - 1 + fs.size) % fs.size]; Cfg.put("sub_font", n.id); try { restyleFn() } catch (_: Throwable) {}
            }, {
                val fs = SubStyle.fonts; val cf = SubStyle.load { k, dd -> Cfg.str(k, dd) }.font
                val n = fs[(fs.indexOfFirst { it.id == cf } + 1) % fs.size]; Cfg.put("sub_font", n.id); try { restyleFn() } catch (_: Throwable) {}
            })
            fun bgNow() = if (Cfg.str("sub_nobg", "0") == "1") 0 else Cfg.int("sub_bgopa", 45)
            fun bgSet(v: Int) { val n = v.coerceIn(0, 100); Cfg.put("sub_bgopa", n.toString()); Cfg.put("sub_nobg", if (n == 0) "1" else "0"); try { restyleFn() } catch (_: Throwable) {} }
            stepLine(col, { "◼ شفافية الخلفية: " + bgNow() + "%" }, { bgSet(bgNow() - 10) }, { bgSet(bgNow() + 10) })
            return col
        }

        fun buildAi(): View {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_HORIZONTAL }
            if (aiWhy.isNotEmpty()) { col.addView(note("⚠ $aiWhy"), LinearLayout.LayoutParams(-2, -2)) }
            val on = aiWhy.isEmpty()
            fun flow() = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
            fun guard(f: () -> Unit): (TextView) -> Unit = { _ -> if (!on) say("✨ $aiWhy") else f() }
            // اللهجات: دوسة واحدة تحوّل
            val curL = Cfg.str("conv_dialect", "").ifBlank { "فصحى" }
            col.addView(note("لهجة الترجمة"), LinearLayout.LayoutParams(-2, -2))
            val rowL = flow()
            for (l in listOf("فصحى", "مصري"))
                rowL.addView(btn((if (l == curL) "✓ " else "") + l, 16f, on, guard { d.dismiss(); dialectPick(l) }), flpm())
            col.addView(rowL, LinearLayout.LayoutParams(ui.dp(640), -2))
            // (v1199) الأسلوب: زرارين بس — حرفي · مناسب للمشاهدة العائلية (الشدة اتشالت)
            val styles = listOf("حرفي", "عائلي"); val styleLabels = listOf("حرفي", "مناسب للمشاهدة العائلية")
            fun stI() = styles.indexOf(Cfg.str("tone_style", "")).coerceAtLeast(0)
            col.addView(note("أسلوب الترجمة"), LinearLayout.LayoutParams(-2, -2))
            val rowS = flow()
            for ((si, sl) in styleLabels.withIndex())
                rowS.addView(btn((if (si == stI()) "✓ " else "") + sl, 16f, on, guard { d.dismiss(); Cfg.put("tone_style", styles[si]); engine.toneStyle = styles[si]; say("الأسلوب: " + sl + " — الباتشات الجاية هتتترجم بيه. لو عايزه على اللي اتترجم دوس «طبّق»") }), flpm())
            col.addView(rowS, LinearLayout.LayoutParams(ui.dp(640), -2))
            val rowA = flow()
            rowA.addView(btn("🔁 طبّق من هنا للآخر", 16f, on, guard { d.dismiss(); val ins = toneInstrOf(styles[stI()], ""); runTool("أسلوب " + styleLabels[stI()], ins, false) }), flpm())
            rowA.addView(btn("🔁 طبّق على الفيديو كله", 16f, on, guard { d.dismiss(); val ins = toneInstrOf(styles[stI()], ""); runTool("أسلوب " + styleLabels[stI()], ins, true) }), flpm())
            col.addView(rowA, LinearLayout.LayoutParams(ui.dp(640), -2))
            // أدوات الذكاء: دوسة واحدة = تشتغل على طول (التقدم في الإشعار اللي فوق)
            col.addView(note("أدوات الذكاء (دوسة واحدة)"), LinearLayout.LayoutParams(-2, -2))
            val rowT = flow()
            for ((id, label) in listOf("refine" to "✍ تنقيح", "dial" to "🔥 لهجة +", "family" to "🧹 عائلي", "pron" to "🔧 ضمائر", "dedup" to "🧠 دمج مكرر"))
                rowT.addView(btn(label, 16f, on, guard { d.dismiss(); applyAiOptions(listOf(id)) }), flpm())
            rowT.addView(btn("🧑 الشخصيات", 16f, engOk) { _ -> if (engOk) { d.dismiss(); showChars() } else say("✨ ابدأ الترجمة الأول") }, flpm())
            col.addView(rowT, LinearLayout.LayoutParams(ui.dp(640), -2))
            return col
        }

        var cur = -1
        fun show(i: Int) {
            if (i == cur) return
            cur = i
            for ((k, t) in tabViews.withIndex()) t.background = ui.box(if (k == i) 0xFF8B6B50.toInt() else 0x33FFFFFF, 0x22FFFFFF, 12)
            bodyHolder.removeAllViews()
            bodyHolder.addView(if (i == 0) buildLook() else buildAi())
            bodyHolder.layoutParams?.let { it.height = if (i == 0) -2 else ui.dp(330); bodyHolder.layoutParams = it }
        }
        for ((i, t) in listOf("🔤 الشكل", "✨ الذكاء").let { if (Strict.hideTrOpts()) it.take(1) else it }.withIndex()) {   // (v699) أوفلاين كامل: تبويب اللهجة/الأسلوب/الأدوات يختفي
            val tv = btn(t, 20f, i == 0 || aiWhy.isEmpty()) { _ -> show(i) }
            tv.setOnFocusChangeListener { _, f -> if (f) show(i) }   // يمين/شمال بيبدّل
            tabViews.add(tv); tabRow.addView(tv, lp(6))
        }
        box.addView(tabRow, LinearLayout.LayoutParams(-1, -2))
        box.addView(bodyHolder, LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, ui.dp(8), 0, 0) })
        show(startTab.coerceIn(0, (tabViews.size - 1).coerceAtLeast(0)))
        d.setContentView(box)
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0)); setGravity(Gravity.BOTTOM); setLayout(-2, -2); attributes = attributes.apply { y = ui.dp(90) } }
        try { TvFocus.attachDialog(this, d, th.primary) } catch (_: Throwable) {}
        d.show()
    }
    /** (v639) تحويل لهجة بدوسة واحدة (مشترك بين 🌐 الموبايل وتبويب ✨ على التلفزيون) */
    private fun dialectBtn(formal: Boolean) {
        if (!::engine.isInitialized) { say("استنى لحظة — الفيديو لسه بيتحمّل"); return }
        if (!caps().dialect) { say("🗣 اللهجة مش شغّالة في «" + modeName() + "» — اختار وضع فيه لهجات"); return }
        dialectPick(if (formal) "فصحى" else I18n.dialectName())
    }
    private fun dialectPick(l: String) {
        val v = if (l == "فصحى") "" else l
        Cfg.p.edit().putString("conv_dialect", v).apply()
        TrWizard.syncSaved("conv_dialect", v)
        engine.setConvDialect(v, true)
        if (v.isNotEmpty() && v == conf.lang) { say("لهجة الترجمة في الإعدادات أصلًا $v — مفيش تحويل مطلوب"); touchSubs(); return }
        say(if (l == "فصحى") "الترجمة بالفصحى الحرفية" else "هحوّل للهجة $l من الباتش اللي إنت فيه وللقدّام، وبعدين اللي قبله — والباتشات الجديدة هتيجي باللهجة دي (النسخة القديمة اتحفظت في 🗂)")
        touchSubs()
    }
    private fun toneInstrOf(st: String, dg: String): String =   // (v1199) حرفي · عائلي بس
        if (TrNorm.style(st) == TrNorm.FAMILY) "أعد صياغة كل جملة بأسلوب «مناسب للمشاهدة العائلية»: خفّف أي ألفاظ خارجة أو شتايم أو إيحاءات جنسية لألفاظ مهذّبة أو خفيفة (مثلًا «ثدي» بدل اللفظ الصريح، و«يا ابن الكلب» بدل الشتيمة الثقيلة) مع الحفاظ الكامل على المعنى والجنس، من غير حذف أو إضافة."
        else "رجّع كل جملة لترجمة حرفية بالملي زي ما اتقالت في الأصل: نفس الألفاظ والشتايم والإيحاءات بنفس حدّتها، من غير تخفيف ولا تنميق ولا مبالغة."
    /** ⋯ المزيد: الأدوات اللي مش لازمة على الشريط الأساسي */
    /** (v521) لو اتختار مسار ترجمة أصلي من الفيديو: يتعرض هو حتى لو المحرك عنده ترجمة (لحد ما يرجّع ترجمة البرنامج أو الفيديو يتغيّر) */
    @Volatile private var preferNative = false
    /** (v521) زرار 🌐 في شريط التلفزيون: مسارات الترجمة الأصلية في الفيديو (سوفت سب) + لغة/لهجة ترجمة البرنامج + إعداداتها */
    private fun tvSubTracksDialog(anchor: View) {
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        val tc = androidx.media3.common.C.TRACK_TYPE_TEXT
        val groups = try { (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>()).filter { it.type == tc && it.length > 0 && it.isSupported } } catch (_: Throwable) { emptyList() }
        val textOff = try { (player.exo()?.trackSelectionParameters?.disabledTrackTypes?.contains(tc) ?: false) } catch (_: Throwable) { false }
        groups.forEachIndexed { i, g ->
            val f = g.getTrackFormat(0)
            val lang = (f.language ?: "").let { l -> if (l.isBlank() || l == "und") "" else try { java.util.Locale(l).getDisplayLanguage(java.util.Locale("ar")).ifBlank { l } } catch (_: Throwable) { l } }
            val name = listOf(f.label ?: "", lang).filter { it.isNotBlank() }.distinct().joinToString(" · ").ifBlank { "مسار " + (i + 1) }
            val on = g.isSelected && !textOff && preferNative
            add((if (on) "✓ " else "") + "💬 " + name + " (من الفيديو)") {
                try {
                    player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(tc, false)
                        .setOverrideForType(androidx.media3.common.TrackSelectionOverride(g.mediaTrackGroup, 0)).build() }
                    sfHideNative = false; preferNative = true; ccOn = true; curIdx = -2   // (v762) اختيار مسار أصلي بإيدك = يفتح الأصلية تاني
                    Notice.show(this, "💬 " + name, 1500L)
                } catch (e: Throwable) { LogStore.err("Player:pickText", e) }
            }
        }
        // (v640) 🌐 قايمة واحدة بكل مصادر الترجمة: مسارات الفيديو · ترجمة البرنامج · النسخ المحفوظة 🗂 (والـ ✓ على اللي شغّال دلوقتي)
        val prog = tvProgTr()
        if (prog) add((if (!preferNative && !textOff) "✓ " else "") + "💬 ترجمة البرنامج") { preferNative = false; ccOn = true; curIdx = -2; Notice.show(this, "💬 ترجمة البرنامج", 1300L) }
        try {
            if (::engine.isInitialized) {
                val vs = engine.versions.toList()
                vs.forEachIndexed { i, v -> add("🗂 " + v.name + " — " + v.subs.size + " جملة (" + v.dialect.ifBlank { "فصحى" } + ")") { preferNative = false; restoreVersion(i) } }
                if (engine.subs.isNotEmpty()) add("💾 احفظ النسخة الحالية") { engine.saveVersion("نسخة " + PlayerLogic.clock(player.currentPosition)); say("💾 اتحفظت نسخة") }
            }
        } catch (e: Throwable) { LogStore.err("Tv:versions", e) }
        add("📝 ترجمات الفيديو (قديم + جديد)") { sfTranslationsDialog(anchor) }
        if (!Strict.hideTrOpts()) add("🌐 لغة / لهجة ترجمة البرنامج") { preferNative = false; tvSubDialog(1) }   // (v696) أوفلاين كامل: فصحى بس
        // (v552) «ترجمة ملف الترجمة» اتشالت — السؤال بقى جوه ▶ ترجم لما الفيديو يبقى فيه سوفت صب
        add("⚙ إعدادات الترجمة") { trSettings(anchor) }
        if (groups.isEmpty() && !prog) add("ℹ مفيش ترجمة أصلية في الفيديو ده (السوفت صب والهارد صب بيتترجموا أوتوماتيك)") { }
        GAlert(this).setTitle("🌐 مصادر الترجمة").setItems(labels.toTypedArray()) { _, w -> if (w in acts.indices) acts[w]() }.show()
    }
    // ===== (v529) 📄 ترجمة ملف الترجمة: سوفت سب (ملف جنب الفيديو / ملف تختاره / مسار جوه الفيديو) أو هارد سب (محروق على الصورة) — بجوجل أو جيميناي =====
    @Volatile private var sfBusy = ""
    @Volatile private var sfLive = ""   // "" | google | gemini: ترجمة مسار الفيديو الأصلي لحظيًا (لما مفيش استخراج كامل)
    @Volatile private var sfLiveGen = 0
    @Volatile private var sfPickEng = "google"
    private val sfLiveCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val sfLiveAsk = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    private val sfLiveCtx = java.util.ArrayDeque<String>()
    private var sfSideKey = ""; private var sfSideNm = ""
    /** (v676) ترجمة جاية من الموبايل مع فيديو الكاست (ملف جنب الفيديو على الموبايل أو مسار جواه اتطلّع هناك) */
    @Volatile private var castSubFile: java.io.File? = null
    private fun sfSidecar(): java.io.File? = try { castSubFile?.takeIf { it.exists() } ?: run { val u = uri; if (u == null) null else findSidecar(u) } } catch (_: Throwable) { null }
    /** اسم ملف الترجمة اللي جنب الفيديو (متخزّن لكل فيديو عشان الريموت بيسأل كل ثانية) */
    private fun sfSideName(): String {
        val k = (uri?.toString() ?: "") + "|" + (castSubFile?.name ?: "")
        if (k != sfSideKey) { sfSideKey = k; sfSideNm = try { sfSidecar()?.name ?: "" } catch (_: Throwable) { "" } }
        return sfSideNm
    }
    private fun sfNativeCountNow(): Int = try { (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>()).count { it.type == androidx.media3.common.C.TRACK_TYPE_TEXT && it.length > 0 && it.isSupported } } catch (_: Throwable) { 0 }
    /** (v670) ExoPlayer بيرمي استثناء لو اتسأل من خيط تاني — فالنسخة القديمة كانت بترجّع 0 دايمًا لما تتنادى من خيط خلفية (softAuto / sfRun) وده كان بيخلي الترجمة الأصلية «مش موجودة». دلوقتي بنسأل على خيط الواجهة ونستنى الرد */
    private fun sfNativeCount(): Int {
        if (Looper.myLooper() == Looper.getMainLooper()) return sfNativeCountNow()
        val out = java.util.concurrent.atomic.AtomicInteger(0)
        val latch = java.util.concurrent.CountDownLatch(1)
        try { runOnUiThread { try { out.set(sfNativeCountNow()) } finally { latch.countDown() } } } catch (_: Throwable) { return 0 }
        try { latch.await(1500L, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
        return out.get()
    }

    private fun sfLiveText(t: String): String {
        if (sfLive.isEmpty()) return t
        sfLiveCache[t]?.let { return it }
        if (sfLiveAsk.putIfAbsent(t, true) == null) {
            val eng = sfLive
            val ctx = synchronized(sfLiveCtx) { val c = sfLiveCtx.joinToString("\n"); sfLiveCtx.addLast(t.replace("\n", " ")); while (sfLiveCtx.size > 3) sfLiveCtx.removeFirst(); c }
            Thread {
                try {
                    val r = if (eng == "gemini") SubFileTr.geminiOne(t, ctx) else SubFileTr.googleOne(t)
                    if (!r.isNullOrBlank() && sfLive == eng) { if (sfLiveCache.size > 3000) sfLiveCache.clear(); sfLiveCache[t] = r; sfLiveGen++ }
                } catch (e: Throwable) { LogStore.err("Player:sfLive", e) }
                finally { sfLiveAsk.remove(t) }
            }.also { it.isDaemon = true }.start()
        }
        return t
    }
    private fun sfStartLive(eng: String) {
        sfLive = eng; sfLiveCache.clear(); sfLiveAsk.clear(); synchronized(sfLiveCtx) { sfLiveCtx.clear() }
        try { player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false).build() } } catch (_: Throwable) {}
        sfHideNative = false; preferNative = true; ccOn = true; curIdx = -2   // (v762)
        sfNote("💬 بترجم ترجمة الفيديو الأصلية لحظيًا بـ " + (if (eng == "gemini") "جيميناي" else "جوجل") + " — ممكن تتأخر ثانية عن الصوت", 5000L)
    }
    private fun sfStopLive() { sfLive = ""; preferNative = false; curIdx = -2 }

    private fun sfEngineChoice(what: String, then: (String) -> Unit) {
        val lang = Cfg.str("lang", "فصحى").ifBlank { "فصحى" }
        val labels = arrayOf("🌐 جوجل ترجمة — من غير مفتاح، سريع (فصحى)", "✨ جيميناي — بمفاتيحك، أدق بالسياق (لهجة $lang)")
        GAlert(this).setTitle("ترجم $what بإيه؟").setItems(labels) { _, w -> then(if (w == 0) "google" else "gemini") }.show()
    }

    private fun subFileDialog(anchor: View? = null) {
        val side = sfSidecar(); val nat = sfNativeCount()
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        add("💬 ترجمة السوفت سب" + (if (side != null) " — ملف «" + side.name + "»" else if (nat > 0) " — $nat مسار جوه الفيديو" else " (لو موجودة)")) { sfEngineChoice("السوفت سب") { e -> sfRun("soft", e) } }
        add("📂 اختار ملف ترجمة من الجهاز (SRT / ASS / VTT)") { sfEngineChoice("الملف") { e -> sfPickFile(e) } }
        add("🔤 ترجمة الهارد سب (المحروقة على الصورة) — بجيميناي") { sfHard() }
        if (sfLive.isNotEmpty()) add("⏹ وقّف الترجمة اللحظية للمسار الأصلي") { sfStopLive(); say("⏹ اتوقفت") }
        netEntries { l, a -> add(l, a) }   // (v746)
        add("ℹ الهارد سب بيتقرا من الصورة فمحتاج جيميناي (مفتاح الوضع البصري)؛ جوجل مابيقرأش صور") { }
        GAlert(this).setTitle("📄 ترجمة ملف الترجمة").setItems(labels.toTypedArray()) { _, w -> if (w in acts.indices) acts[w]() }.show()
    }

    // ===== (v746) ترجمة أونلاين + صيد من المتصفح + ضبط توقيت تلقائي =====
    @Volatile private var netBusy = ""
    @Volatile private var netSess: SubOnline.Session? = null
    @Volatile private var alignBusy = false
    private var vnKey = ""; private var vnVal = Pair("", "")

    /** (اسم الفيديو، اسم الفولدر) من الملف/الـURI؛ للنت العنوان بس */
    private fun vidNames(): Pair<String, String> {
        var name = ""; var folder = ""
        try {
            val u = uri
            if (u != null) {
                if (u.scheme == "file") { val f = java.io.File(u.path ?: ""); name = f.name; folder = f.parentFile?.name ?: "" }
                else if (u.scheme == "content") {
                    try { contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) name = c.getString(0) ?: "" } } catch (_: Throwable) {}
                    try { contentResolver.query(u, arrayOf(android.provider.MediaStore.MediaColumns.DATA), null, null, null)?.use { c -> if (c.moveToFirst()) { val pth = c.getString(0); if (!pth.isNullOrBlank()) folder = java.io.File(pth).parentFile?.name ?: "" } } } catch (_: Throwable) {}
                    if (folder.isBlank()) try {
                        val parts = android.provider.DocumentsContract.getDocumentId(u).substringAfter(':').split('/')
                        if (parts.size >= 2) { folder = parts[parts.size - 2]; if (name.isBlank()) name = parts.last() }
                    } catch (_: Throwable) {}
                    if (name.isBlank()) name = u.lastPathSegment?.substringAfterLast('/') ?: ""
                }
            }
        } catch (_: Throwable) {}
        if (name.isBlank()) name = notifTitle()
        return Pair(name, folder)
    }
    private fun vidNamesCached(): Pair<String, String> {
        val k = uri?.toString() ?: ("t:" + notifTitle())
        if (k != vnKey) { vnKey = k; vnVal = vidNames() }
        return vnVal
    }

    private fun netEntries(add: (String, () -> Unit) -> Unit) {
        add("🌍 جيب ترجمة أونلاين تلقائي (باسم الفيديو/الفولدر)") { subNet("auto") }
        if ((netSess?.remaining() ?: 0) > 0) add("⏭ جرّب نتيجة تانية (" + netSess!!.remaining() + " متبقية)") { subNet("next") }
        add("🌐 افتح المتصفح على موقع ترجمة (بيبحث + sub file ويضيف أول تحميل)") {
            GAlert(this).setTitle("🌐 اختار الموقع").setItems(SubHunt.siteNames.toTypedArray()) { _, w -> subHunt(w) }.show()
        }
        add("🎯 ضبط توقيت الترجمة تلقائي (بسمع الفيديو بجيميناي)") { subAlignRun(false) }
    }

    /** ترجمة جاهزة (أونلاين / متصفح / موبايل) ← تتحط على الفيديو زي ملف ترجمة مستورد، وتفضل «المرفقة» عشان تتترجم بعدها */
    private fun subAddGot(g: SubOnline.Got, how: String): Boolean {
        val f = try {
            val dir = java.io.File(cacheDir, "net_sub"); dir.mkdirs()
            dir.listFiles()?.forEach { try { it.delete() } catch (_: Throwable) {} }
            val ext = g.fileName.substringAfterLast('.', "srt").lowercase().let { if (it == "ass" || it == "ssa" || it == "vtt") it else "srt" }
            java.io.File(dir, "net_sub.$ext").also { it.writeText(g.text, Charsets.UTF_8) }
        } catch (e: Throwable) { LogStore.err("Player:subAddGot", e); return false }
        castSubFile = f
        val subs = g.cues.map { c -> Sub(c.start, c.end, c.text, c.text, "male", "unknown", "none", emptyList(), emptyList(), false, false) }
        runOnUiThread {
            try {
                if (!::engine.isInitialized || !engineReady) { say("المحرك لسه بيحمّل — جرّب تاني بعد ثواني"); return@runOnUiThread }
                if (engineStarted && !engine.userPaused) pauseTranslate()
                if (engine.subs.isNotEmpty()) engine.saveVersion("قبل إضافة ترجمة أونلاين")
                engine.importSubs(subs)
                try { engine.markAllDone(g.cues.maxOfOrNull { it.end } ?: 0.0) } catch (_: Throwable) {}
                sfLive = ""; preferNative = false; ccOn = true; dirty = true; curIdx = -2
                sfHideNative = true; sfKillNative()   // (v762)
                nativeCue = ""
                sfDoneUri = uri?.toString() ?: ""
                sfShown = true
                sfDoneLabel = "🌍 ترجمة أونلاين · " + g.source.take(40)
                Thread { try { engine.saveNow() } catch (e: Throwable) { LogStore.err("Player:subAddSave", e) } }.start()
                val lgN = if (g.lang == "ar") "عربي" else g.lang
                sfNote("✅ اتضافت ترجمة ($lgN) — " + g.cues.size + " جملة · " + g.source.take(40) + (if (g.lang != "ar") " — لو عايزها عربي: «ترجم ملف الترجمة المرفق»" else ""), 7000L)
                if (Cfg.bool("subnet_autosync", true)) subAlignRun(true)
            } catch (e: Throwable) { LogStore.err("Player:subAddGot2", e); say("⚠ مقدرتش أطبّق الترجمة") }
        }
        return true
    }

    /** mode: auto (كاش ← بحث ← أحسن نتيجة) · next (النتيجة اللي بعدها) */
    private fun subNet(mode: String) {
        if (netBusy.isNotEmpty()) { say("⏳ $netBusy"); return }
        val nm = vidNames(); val info = SubName.build(nm.first, nm.second); val langs = SubOnline.prefLangs()
        netBusy = "بدوّر على ترجمة…"
        Thread {
            try {
                val rep: (String) -> Unit = { m -> netBusy = m; sfNote(m, 2500L) }
                var got: SubOnline.Got? = null
                if (mode == "next") {
                    val s = netSess
                    if (s == null || s.remaining() <= 0) { sfNote("مفيش نتايج تانية — ادوس «جيب ترجمة» تاني أو افتح المتصفح", 5000L); return@Thread }
                    got = SubOnline.fetchNext(applicationContext, s, rep)
                } else {
                    val cached = SubOnline.cacheFind(applicationContext, info, langs)
                    if (cached != null && cached.lang == langs[0]) got = cached
                    else {
                        val hits = SubOnline.search(info, langs, rep)
                        val s = SubOnline.Session(info, langs, hits); netSess = s
                        if (hits.isNotEmpty()) got = SubOnline.fetchNext(applicationContext, s, rep)
                        if (got == null) got = cached
                        if (hits.isEmpty() && got == null) { sfNote("🌍 مفيش نتايج لـ «" + info.label() + "» — جرّب المتصفح (🌐) أو اسم تاني", 7000L); return@Thread }
                    }
                }
                if (got == null) { sfNote("⚠ ما قدرتش أنزّل ترجمة مناسبة — جرّب «⏭ نتيجة تانية» أو المتصفح", 7000L); return@Thread }
                subAddGot(got, "online")
            } catch (e: Throwable) { LogStore.err("Player:subNet", e); sfNote("⚠ فشل جلب الترجمة: " + (e.message ?: "").take(60), 6000L) }
            finally { netBusy = "" }
        }.also { it.isDaemon = true }.start()
    }

    private fun subHunt(site: Int) {
        val nm = vidNames(); val info = SubName.build(nm.first, nm.second)
        runOnUiThread {
            try { SubHunt.start(this, info, site.coerceIn(0, SubHunt.siteNames.size - 1)) { g -> subAddGot(g, "browser") } }
            catch (e: Throwable) { LogStore.err("Player:subHunt", e); say("⚠ مقدرتش أفتح المتصفح") }
        }
    }

    /** ضبط توقيت الترجمة الحالية على صوت الفيديو (جيميناي) — auto = من غير شكوى لو مفيش حاجة */
    private fun subAlignRun(auto: Boolean) {
        if (alignBusy) { if (!auto) say("⏳ بضبط التوقيت دلوقتي"); return }
        val sp = spec
        if (sp == null || !::engine.isInitialized || engine.subs.isEmpty()) { if (!auto) say("مفيش ترجمة على الفيديو لضبط توقيتها"); return }
        if (engineStarted && !engine.fullyDone()) { if (!auto) say("الترجمة دي بتتعمل من الصوت نفسه — مش محتاجة ضبط"); return }
        val snap = engine.subs.toList()
        val cues = snap.map { SubFileTr.Cue(it.start, it.end, if (it.original.isNotBlank()) it.original else it.translated) }
        val dur = durMs / 1000.0
        alignBusy = true; netBusy = "🎯 ضبط التوقيت…"
        Thread {
            var src: AudioSource? = null
            try {
                val s2 = makeSource(sp); src = s2
                val out = SubAlign.run(s2, dur, cues, { m -> netBusy = m; sfNote(m, 3000L) }, { isFinishing || isDestroyed })
                val f = out.fit
                if (f == null) { if (!auto || out.windows > 0) sfNote("🎯 ضبط التوقيت: " + out.msg, 7000L); return@Thread }
                if (SubAlign.isNoop(f)) { sfNote("🎯 توقيت الترجمة سليم ✓ (" + f.inliers + " جملة متطابقة)", 5000L); return@Thread }
                runOnUiThread {
                    try {
                        if (engine.subs.size != snap.size) { say("الترجمة اتغيّرت أثناء الضبط — جرّب تاني"); return@runOnUiThread }
                        engine.saveVersion("قبل ضبط التوقيت التلقائي")
                        engine.importSubs(SubAlign.shiftSubs(engine.subs, f))
                        try { engine.markAllDone(engine.subs.maxOfOrNull { it.end } ?: 0.0) } catch (_: Throwable) {}
                        dirty = true; curIdx = -2
                        try {   // ملف «المرفقة» كمان يتظبط عشان الترجمة منه تطلع بنفس التوقيت
                            val cf = castSubFile
                            if (cf != null && cf.exists()) {
                                val sc = SubAlign.shiftCues(SubFileTr.parse(SubFileTr.decode(cf.readBytes())), f)
                                java.io.File(cf.parentFile, "net_sub_synced.srt").also { it.writeText(SubSidecar.toSrt(sc), Charsets.UTF_8); castSubFile = it }
                            }
                        } catch (_: Throwable) {}
                        Thread { try { engine.saveNow() } catch (e: Throwable) { LogStore.err("Player:alignSave", e) } }.start()
                        sfNote("✅ اتظبط توقيت الترجمة: " + SubAlign.describe(f) + " — " + f.inliers + " جملة متطابقة من " + out.windows + " عينة (النسخة القديمة محفوظة في «النسخ»)", 9000L)
                    } catch (e: Throwable) { LogStore.err("Player:align", e); say("⚠ مقدرتش أطبّق التوقيت") }
                }
            } catch (e: Throwable) { LogStore.err("Player:subAlign", e); sfNote("⚠ فشل ضبط التوقيت: " + (e.message ?: "").take(60), 6000L) }
            finally { try { src?.close() } catch (_: Throwable) {}; alignBusy = false; netBusy = "" }
        }.also { it.isDaemon = true }.start()
    }

    /** (v684) ملف ترجمة مستورد من الموبايل — بيستنى أمر sfgo (ترجم) بعد ما تظبط الإعدادات */
    @Volatile private var mobileSub: java.io.File? = null
    private fun subImported(f: java.io.File, nm: String, cues: Int, show: Boolean = false): Boolean {
        if (show) {   // (v746) ترجمة جاية من بحث الموبايل أونلاين: تتضاف علطول
            return try {
                val txt = f.readText(Charsets.UTF_8); val cs = SubFileTr.parse(txt)
                subAddGot(SubOnline.Got(nm, txt, cs, if (SubFileTr.mostlyArabic(cs)) "ar" else "en", "الموبايل", 1), "phone")
            } catch (e: Throwable) { LogStore.err("Player:subShow", e); false }
        }
        mobileSub = f
        sfNote("📄 وصل ملف ترجمة من الموبايل: «$nm» ($cues جملة) — ظبّط الإعدادات من الموبايل واضغط «▶ ترجم»", 6000L)
        return true
    }

    /** (v684) sfgo:<src>:<eng>:<لهجة>:<أسلوب>:<شدة> — src = side (الملف اللي جنب الفيديو / جواه) أو mobile (الملف المستورد). الإعدادات بتتحفظ وبعدين الترجمة تبدأ */
    private fun sfGo(a: String) {
        val p = a.split(":")
        val src = if (p.getOrNull(1) == "mobile") "mobile" else "side"
        val eng = if (p.getOrNull(2) == "gemini") "gemini" else "google"
        if (eng == "gemini") {
            val dia = (p.getOrNull(3) ?: "").let { if (it == "فصحى") "" else it }
            val sty = (p.getOrNull(4) ?: "").let { if (it == "تلقائي") "" else it }
            val str = (p.getOrNull(5) ?: "").ifBlank { "متوسطة" }
            try {
                Cfg.put("conv_dialect", dia); TrWizard.syncSaved("conv_dialect", dia)
                Cfg.put("tone_style", sty); Cfg.put("tone_strength", str)
                if (::engine.isInitialized) { engine.convDialect = dia; engine.toneStyle = sty; engine.toneStrength = str }
            } catch (e: Throwable) { LogStore.err("Player:sfGo", e) }
        }
        LogStore.add("💬 سوفت صب: sfgo eng=$eng لهجة=" + (p.getOrNull(3) ?: "") + " أسلوب=" + (p.getOrNull(4) ?: "") + " شدة=" + (p.getOrNull(5) ?: ""))
        sfRun("soft", eng, null, -1, src == "mobile", src == "mobile", p.getOrNull(6) ?: "")   // (v688) p[6] = jid بتاع الترجمة المزدوجة (تلفزيون + موبايل)
    }

    private fun sfRemote(a: String) {
        val p = a.split(":")
        val eng = if (p.getOrNull(2) == "gemini") "gemini" else "google"
        when (p.getOrNull(1)) {
            "soft" -> sfRun("soft", eng)
            "pick" -> sfPickFile(eng)
            "hard" -> sfHard()
            "off" -> { sfStopLive(); say("⏹ اتوقفت") }
            "dlg" -> subFileDialog(window.decorView)
        }
    }

    private fun sfPickFile(eng: String) {
        sfPickEng = eng
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }, 41) }
        catch (e: Throwable) { LogStore.err("Player:sfPick", e); say("مش قادر أفتح اختيار الملف") }
    }

    /** هارد سب: نفس بريست «ترجمة الهارد سب» (الوضع البصري بيقرا الترجمة المحروقة ويترجمها بجيميناي) */
    private fun sfHard() {
        try {
            if (!::visual.isInitialized) { say("الوضع البصري مش جاهز لسه — جرّب بعد ثواني"); return }
            val pr = TrPresets.byId(TrPresets.HARD_ID) ?: return
            applyPreset(pr, false, false, true)
        } catch (e: Throwable) { LogStore.err("Player:sfHard", e); say("⚠ تعذّر تشغيل ترجمة الهارد سب") }
    }

    private fun sfRun(kind: String, engIn: String, picked: Uri? = null, track: Int = -1, auto: Boolean = false, useMobile: Boolean = false, jid: String = "") {
        if (kind == "hard") { sfHard(); return }
        // (v661) جيميناي من غير مفتاح كان بيفشل بتنبيه سريع ويختفي (باين إن مفيش ترجمة) ← بنحوّل لجوجل ونقولك
        var eng = engIn
        if (eng == "gemini" && !SubFileTr.hasGemKeys()) { sfNote("⚠ مفيش مفتاح جيميناي على التلفزيون — ضيفه من الإعدادات أو اختار جوجل (ما حوّلتش لجوجل لوحدي عشان اللهجة)", 8000L); return }   // (v703) كان بيحوّل لجوجل بصمت فتطلع فصحى
        if (sfBusy.isNotEmpty()) { say("⏳ بترجم دلوقتي: $sfBusy"); return }
        val myJid = jid.ifBlank { java.util.UUID.randomUUID().toString() }; SfJob.begin(myJid)   // (v688) شغلانة جديدة — الموبايل (لو شغّال) بيتعرّف عليها بنفس الـjid
        LogStore.add("💬 سوفت صب: بدأ sfRun kind=$kind eng=$eng track=$track"); sfBusy = "بقرا الترجمة…"; runOnUiThread { updateTr(); try { tvBar?.refresh() } catch (_: Throwable) {} }
        say("⏳ بدأت ترجمة السوفت صب — " + (if (eng == "gemini") "جيميناي" else "جوجل") + " (الشريط هيعرض التقدم)")
        val engName = if (eng == "gemini") "جيميناي" else "جوجل"
        val vu = uri
        Thread {
            try {
                var cues: List<SubFileTr.Cue> = emptyList(); var label = ""
                if (useMobile && mobileSub?.exists() != true) { sfNote("⚠ ملف الترجمة اللي بعتّه من الموبايل مش موجود — ابعته تاني", 5000L); return@Thread }
                if (picked != null) {
                    val b = contentResolver.openInputStream(picked)?.use { it.readBytes() } ?: ByteArray(0)
                    cues = SubFileTr.parse(SubFileTr.decode(b)); label = "الملف اللي اخترته"
                    if (cues.isEmpty()) { say("الملف ده مش ترجمة صالحة (SRT / ASS / VTT)"); return@Thread }
                } else {
                    val sc = if (track >= 0) null else if (useMobile) mobileSub?.takeIf { it.exists() } else sfSidecar()
                    if (sc != null) {
                        // (v1137) لو الملف ده ترجمة كتبها البرنامج وليها نسخة أصلية مخفية ← نترجم من الأصلي مش من العربي
                        val srcF = (if (useMobile) null else SrtWriter.origFor(sc)) ?: sc
                        cues = SubFileTr.parse(SubFileTr.decode(srcF.readBytes())); label = sc.name + (if (srcF !== sc) " (النص الأصلي)" else "")
                    }
                    if (track >= 0 && vu != null) {
                        SubFileTr.readEmbeddedTrack(applicationContext, vu, track)?.let { cues = it.second; label = it.first + " من الفيديو" }
                        // (v667) أوتوماتيك: المسار فاضي أو عربي أصلًا ← نترجم ملف الترجمة اللي جنب الفيديو
                        if (auto && (cues.isEmpty() || SubFileTr.mostlyArabic(cues))) { sfSidecar()?.let { sc2 -> val c2 = SubFileTr.parse(SubFileTr.decode((SrtWriter.origFor(sc2) ?: sc2).readBytes())); if (c2.isNotEmpty()) { cues = c2; label = sc2.name } } }
                    }
                    else if (cues.isEmpty() && vu != null && (vu.scheme == "file" || vu.scheme == "content")) {
                        SubFileTr.readEmbedded(applicationContext, vu)?.let { cues = it.second; label = "مسار " + it.first + " من الفيديو" }
                    }
                }
                if (cues.isEmpty()) {
                    if (sfNativeCount() > 0 || nativeCue.isNotEmpty()) { LogStore.add("💬 سوفت صب: المسار مش بيتقري كامل — ترجمة لحظية"); runOnUiThread { sfStartLive(eng) }; return@Thread }   // مش قادر أطلّع المسار كله: ترجمة لحظية
                    sfNote("مفيش سوفت سب في الفيديو ده (لا ملف جنبه ولا مسار جواه) — لو الترجمة محروقة على الصورة استخدم «ترجمة الهارد سب»", 5000L)
                    return@Thread
                }
                if (!auto && SubFileTr.mostlyArabic(cues)) { say("💬 الترجمة دي عربي أصلًا"); return@Thread }
                SfJob.cues = cues   // (v688) الموبايل يقدر يسحبها ويترجمها بالتوازي
                sfBusy = "بترجم 0/" + cues.size; runOnUiThread { updateTr(); try { tvBar?.refresh() } catch (_: Throwable) {} }
                say("📄 بترجم " + cues.size + " جملة من «" + label + "» بـ " + engName + (if (eng == "gemini") sfPlanNote() else "") + "…")
                var lastP = 0L
                val out = SubFileTr.translate(cues, eng, { pr -> sfBusy = pr; runOnUiThread { updateTr(); try { tvBar?.refresh() } catch (_: Throwable) {} }; val n = System.currentTimeMillis(); if (n - lastP > 1500L) { lastP = n; say(pr) } }, { isFinishing || isDestroyed || SfJob.winner == "phone" })
                if (isFinishing || isDestroyed) return@Thread
                if (SfJob.winner == "phone") return@Thread   // (v688) الموبايل خلّص الأول وطبّق ترجمته
                if ((out.error.isNotEmpty() || out.failed * 2 > cues.size) && SfJob.phoneAlive()) {
                    // (v688) التلفزيون مفيهوش نت (أو أغلب الجمل فشلت) والموبايل شغّال ← نستنى الموبايل بدل ما نعرض الأصلي من غير ترجمة
                    SfJob.tvFailed = true
                    sfNote("📡 مفيش نت على التلفزيون — مستني الموبايل يكمّل الترجمة", 6000L)
                    var wl = 0; var lastLn = ""
                    while (SfJob.winner.isEmpty() && SfJob.phoneAlive() && !isFinishing && !isDestroyed && wl++ < 7200) {
                        val ln = "📱 الموبايل " + SfJob.phoneLine
                        if (ln != lastLn) { lastLn = ln; sfBusy = ln; runOnUiThread { updateTr(); try { tvBar?.refresh() } catch (_: Throwable) {} } }
                        try { Thread.sleep(500L) } catch (_: InterruptedException) {}
                    }
                    if (SfJob.winner != "phone") sfNote("⚠ الترجمة فشلت على التلفزيون والموبايل اتقطع — جرّب تاني", 6000L)
                    return@Thread
                }
                if (out.error.isNotEmpty()) { sfNote("⚠ " + out.error, 6000L); return@Thread }
                // (v711) أغلب الجمل فشلت: ما نطبّقش (الجمل الفاشلة بتتعرض بنصها الأصلي فبيبان إن مفيش ترجمة)
                if (out.failed * 2 > cues.size) { LogStore.add("💬 سوفت صب: فشل " + out.failed + "/" + cues.size + " على التلفزيون (" + eng + ")"); sfNote("⚠ أغلب الجمل فشلت (" + out.failed + "/" + cues.size + ") — ما طبّقتش الترجمة عشان ماتظهرش بلغتها الأصلية. جرّب تاني", 7000L); return@Thread }
                if (!SfJob.claim(myJid, "tv")) return@Thread   // (v688) الموبايل سبقنا في آخر لحظة
                var w = 0
                while ((!::engine.isInitialized || !engineReady) && w++ < 40) { try { Thread.sleep(250L) } catch (_: InterruptedException) {} }
                sfApply(cues, out, engName)
            } catch (e: Throwable) { LogStore.err("Player:sfRun", e); sfNote("⚠ فشلت الترجمة: " + (e.message ?: e.javaClass.simpleName).take(80), 6000L) }
            finally { sfBusy = ""; runOnUiThread { updateTr(); try { tvBar?.refresh() } catch (_: Throwable) {} } }
        }.also { it.isDaemon = true }.start()
    }

    /** (v694) يضيف الفيديو الشغّال للطابور: يوتيوب ← لينك المشاهدة · لينك ← نفسه · ملف ← مساره */
    private fun queueCurrent() {
        val ytid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 }
        val ttl = intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)
        val u0 = url
        val ref = when {
            ytid != null -> YtHistory.watchUrl(ytid)
            !u0.isNullOrEmpty() -> u0
            else -> uri?.toString() ?: ""
        }
        if (ref.isEmpty()) { say("مفيش فيديو شغّال"); return }
        PlayQueueUi.add(this, ref, ttl)
    }

    /** (v694) «كمّل على الموبايل»: وصف الفيديو الحالي — يوتيوب ← لينك المشاهدة · لينك/كاست ← اللينك نفسه · ملف جوه التلفزيون ← ref فاضي (مش ينفع يتنقل). بيوقّف التشغيل لو ينفع يتنقل */
    /** (v779) نفس مرجع queueCurrent() بس بيرجّعه للريموت (من غير توقيف) */
    private fun queueInfo(): org.json.JSONObject {
        val ytid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 }
        val ttl = intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)
        val u0 = url
        val ref = when {
            ytid != null -> YtHistory.watchUrl(ytid)
            !u0.isNullOrEmpty() -> u0
            else -> uri?.toString() ?: ""
        }
        return org.json.JSONObject().put("ref", ref).put("title", ttl)
    }

    private fun handoffInfo(): org.json.JSONObject {
        val ytid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 }
        val ttl = intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)
        val pos = try { player.currentPosition.coerceAtLeast(0L) } catch (_: Throwable) { 0L }
        val u0 = url
        val ref = when {
            ytid != null -> YtHistory.watchUrl(ytid)
            !u0.isNullOrEmpty() && u0.startsWith("http", true) -> u0
            else -> ""
        }
        if (ref.isNotEmpty()) { try { player.pause() } catch (_: Throwable) {} }
        return org.json.JSONObject().put("ref", ref).put("title", ttl).put("pos", pos)
            .put("hdr_ref", intent.getStringExtra("ref") ?: "").put("hdr_ua", intent.getStringExtra("ua") ?: "").put("hdr_cookie", intent.getStringExtra("cookie") ?: "")
    }

    /** (v688) الموبايل خلّص ترجمته قبل التلفزيون ← نطبّقها (التلفزيون يوقف ترجمته لوحده من SfJob.winner) */
    private fun subFromPhone(jid: String, texts: List<String>, failed: Int, eng: String): Int {
        val cs = SfJob.cues
        if (SfJob.id != jid || cs == null || texts.size != cs.size) return 2
        if (failed * 2 > cs.size) { LogStore.add("💬 سوفت صب: رفضت نتيجة الموبايل — فشل " + failed + "/" + cs.size); return 2 }   // (v711)
        if (!SfJob.claim(jid, "phone")) return 3
        try {
            var w = 0
            while ((!::engine.isInitialized || !engineReady) && w++ < 40) { try { Thread.sleep(250L) } catch (_: InterruptedException) {} }
            sfApply(cs, SubFileTr.Out(texts, failed, ""), "الموبايل (" + (if (eng == "gemini") "جيميناي" else "جوجل") + ")")
        } catch (e: Throwable) { LogStore.err("Player:subFromPhone", e); return 2 }
        return 0
    }

    private fun sfApply(cues: List<SubFileTr.Cue>, out: SubFileTr.Out, engName: String) {
        val subs = cues.mapIndexed { i, c ->
            val tr = out.texts.getOrNull(i) ?: ""
            Sub(c.start, c.end, c.text, if (tr.isBlank()) c.text else tr, "male", "unknown", "none", emptyList(), emptyList(), false, false)
        }
        runOnUiThread {
            try {
                if (!::engine.isInitialized || !engineReady) { say("المحرك لسه بيحمّل — جرّب تاني بعد ثواني"); return@runOnUiThread }
                if (engineStarted && !engine.userPaused) pauseTranslate()
                if (engine.subs.isNotEmpty()) engine.saveVersion("قبل ترجمة ملف الترجمة")
                engine.importSubs(subs)
                try { engine.markAllDone(cues.maxOfOrNull { it.end } ?: 0.0) } catch (_: Throwable) {}   // (v685)
                sfLive = ""; preferNative = false; ccOn = true; dirty = true; curIdx = -2
                sfHideNative = true; sfKillNative()   // (v762)   // (v667) ملف الترجمة الأصلي يتفصل والمترجم هو اللي يظهر
                nativeCue = ""
                sfDoneUri = uri?.toString() ?: ""
                sfShown = true
                sfDoneLabel = try {
                    if (engName.contains("جيميناي")) {
                        val d = Cfg.str("conv_dialect", "").ifBlank { "فصحى" }; val sy = Cfg.str("tone_style", "").ifBlank { "تلقائي" }; val st = Cfg.str("tone_strength", "متوسطة")
                        "📄 ملف ترجمة · ✨ جيميناي · " + d + " · " + sy + (if (sy != "تلقائي") " · " + st else "")
                    } else "📄 ملف ترجمة · 🌐 جوجل (فصحى)"
                } catch (_: Throwable) { "📄 ملف ترجمة · " + engName }
                Thread { try { engine.saveNow() } catch (e: Throwable) { LogStore.err("Player:sfSave", e) } }.start()
                sfNote("✅ خلصت ترجمة السوفت صب — " + subs.size + " جملة بـ " + engName + (if (out.failed > 0) " — " + out.failed + " جملة فضلت بنصها الأصلي" else ""), 6000L)   // (v670) إشعار أطول
            } catch (e: Throwable) { LogStore.err("Player:sfApply", e); say("⚠ مقدرتش أطبّق الترجمة") }
        }
    }

    /** (v676) صفحة واحدة لكل أدوات الترجمة (كانت 🌐 و🔤⏱ و📝 على الشريط + نص قايمة ⋯ مفرّق) */
    private fun tvSubPage() {
        val anchor = window.decorView
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        val tr = tvProgTr(); val hasSubs = tvHasSentences()
        add(if (Strict.hideTrOpts()) "🌐 مصادر الترجمة (مسارات · نسخ محفوظة)" else "🌐 مصادر الترجمة (مسارات · نسخ محفوظة · لغة/لهجة)") { tvSubTracksDialog(anchor) }
        netEntries { l, a -> add(l, a) }   // (v746) جلب ترجمة أونلاين + متصفح + ضبط توقيت
        add("🔤⏱ شكل وتوقيت الترجمة") { tvSubDialog() }
        if (hasSubs) add("📝 الجمل المترجمة") { try { if (::sentDlg.isInitialized) sentDlg.show() } catch (_: Throwable) {} }
        add("📝 ترجمات الفيديو (قديم + جديد)") { sfTranslationsDialog(anchor) }
        add("🎧 باتش الصوت للترجمة بره (على الموبايل)") { ghUpload() }   // (v1361) محلي بدل الريبو: فصل الصوت + برومبت في التنزيلات (بطلب علي)
        add("📋 نسخ برومبت باتش الصوت") { GhAudio.copyLast(this) }
        if (tr) {
            add("🔄 إعادة / تقدم الباتشات") { batchDialog() }
            add("⚙ إعدادات الترجمة") { trSettings(anchor) }
            add("🌙 كمّل الترجمة في الخلفية") { translateInBackground() }
            add("📜 اللوج") { toggleLog() }
        }
        if (hasSubs) {
            add("📜 ذكّرني (ملخص اللي فات)") { recapDialog() }
        }
        GAlert(this).setTitle("🔤 الترجمة").setItems(labels.toTypedArray()) { _, w -> if (w in acts.indices) acts[w]() }.show()
    }
    private fun tvMoreDialog(anchor: View) {
        val labels = ArrayList<String>(); val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) { labels.add(l); acts.add(a) }
        val tr = tvProgTr(); val hasSubs = tvHasSentences(); val c = caps()
        val u = uri
        // (v662) ⬛ حجم الشاشة على الشريط، و👁 الوضع البصري اتشال من هنا. (v640) ⏩ و💬 و🌐 و🔤⏱ و📝 و😴 على الشريط نفسه؛ هنا الباقي مرتب حسب الحالة (الشخصيات واللهجات جوه لوحة 🔤⏱ ← ✨)
        add("🔂 تكرار الفيديو: " + (if (Cfg.str("loop", "0") == "1") "شغّال" else "مقفول")) {
            val on = Cfg.str("loop", "0") != "1"; Cfg.put("loop", if (on) "1" else "0"); Notice.show(this, if (on) "🔂 تكرار الفيديو: شغّال" else "🔂 تكرار الفيديو: مقفول", 1300L)
        }
        // A-B: زرار واحد بيتقلّب (أ ← ب ← إلغاء)
        if (abA < 0L) add("🅰 ابدأ حلقة A-B (نقطة أ هنا)") { abSet(0) }
        else if (abB <= abA) add("🅱 نقطة ب هنا (أ = " + PlayerLogic.clock(abA) + ")") { abSet(1) }
        else add("✖ إلغاء حلقة A-B (" + PlayerLogic.clock(abA) + " ← " + PlayerLogic.clock(abB) + ")") { abClear() }
        if (chapters.isNotEmpty()) add("📑 فصول الفيديو (" + chapters.size + ")") { chaptersSheet() }
        add("📸 لقطة إطار") { snapFrame() }
        add("😴 مؤقت النوم" + (if (tvSleepLabel().isNotEmpty()) " (" + tvSleepLabel().removePrefix("😴 ") + ")" else "")) { tvSleepDialog() }
        add("⏭ التالي تلقائي: " + (if (Cfg.str("autoplay_next", "1") == "1") "شغّال" else "مقفول")) {
            val on = Cfg.str("autoplay_next", "1") != "1"; Cfg.put("autoplay_next", if (on) "1" else "0"); Notice.show(this, "⏭ التالي تلقائي: " + (if (on) "شغّال" else "مقفول"), 1300L)
        }
        if (intent.getStringExtra("ytid") != null) add("📃 الفيديوهات الجاية") { openNextSheet() }
        // (v676) أدوات الترجمة (باتشات · إعدادات · خلفية · لوج · ذكّرني · دبلجة) اتنقلت لصفحة «🔤 الترجمة» على الشريط
        if (u != null && (u.scheme == "file" || u.scheme == "content")) add("🎙 فصل صوت الكلام") { voiceMenu() }
        add("☰ القائمة الكاملة") { tvMenuFn?.invoke(anchor) }
        add("⋯ مركز التحميل والليستة") { tvToolsFn?.invoke(anchor) }
        GAlert(this).setTitle("المزيد").setItems(labels.toTypedArray()) { _, w -> if (w in acts.indices) acts[w]() }.show()
    }
    private var tvDigitRun: Runnable? = null
    // (v569) تقديم/تأخير بالريموت العادي: كل دوسة بتحرّك مؤشر (target) بس وبيظهر شريط فيه الدقيقة اللي هتروحلها + مدة الفيديو،
    // والـ seek الفعلي بيتنفّذ لما تسيب الزرار ~0.8 ثانية أو تدوس OK. Back = إلغاء.
    private var tvScrubTo = -1L
    private var tvScrubOrigin = 0L
    private var tvScrubOv: TvScrubOverlay? = null
    private val tvScrubCommit = Runnable { tvScrubDone(true) }
    private fun tvSeek(dMs: Long) {
        try {
            val dur = if (durMs > 0) durMs else Long.MAX_VALUE
            if (tvScrubTo < 0) { tvScrubOrigin = player.currentPosition; tvScrubTo = tvScrubOrigin }
            tvScrubTo = (tvScrubTo + dMs).coerceIn(0L, dur)
            if (tvBar?.visible == true) tvBar?.refresh()   // الشريط الكبير ظاهر: هو اللي بيعرض المؤشر
            else tvScrubOv?.show(tvScrubTo, tvScrubOrigin, durMs)
            tvH.removeCallbacks(tvScrubCommit); tvH.postDelayed(tvScrubCommit, 800L)
        } catch (e: Exception) { LogStore.err("Tv:seek", e) }
    }
    private fun tvScrubDone(commit: Boolean) {
        tvH.removeCallbacks(tvScrubCommit)
        val t = tvScrubTo; tvScrubTo = -1L
        tvScrubOv?.hide()
        try {
            if (commit && t >= 0) {
                // (v576) فيديو نت/مبعوت من الموبايل: السبينر يظهر فورًا مع القفزة (مش بعد ما يتأخر)؛ المحلي من غير سبينر
                if (tvSrcIsNet() && Math.abs(t - player.currentPosition) > 1500L) setBuffering(true)
                player.seekTo(t)
                if (tvSrcIsNet()) tvH.postDelayed({ try { if (buffering && player.exo()?.playbackState == Player.STATE_READY) setBuffering(false) } catch (_: Throwable) {} }, 700L)
            }
            tvBar?.let { if (it.visible) it.refresh() }
        } catch (e: Exception) { LogStore.err("Tv:seek", e) }
    }
    private fun tvSubScale(d: Int) {
        val n = (Cfg.int("sub_scale", 100) + d).coerceIn(50, 250)
        Cfg.put("sub_scale", n.toString()); try { restyleFn() } catch (_: Exception) {}
        Notice.show(this, "🔤 حجم الترجمة: $n%", 1100L)
    }
    private fun tvJump() {
        val buf = tvDigits; tvDigits = ""; tvDigitRun?.let { tvH.removeCallbacks(it) }; tvDigitRun = null
        if (buf.isEmpty()) return
        val sec = if (buf.length <= 2) buf.toIntOrNull() ?: 0 else (buf.dropLast(2).toIntOrNull() ?: 0) * 60 + (buf.takeLast(2).toIntOrNull() ?: 0)
        try { player.seekTo((sec * 1000L).coerceIn(0L, if (durMs > 0) durMs else Long.MAX_VALUE)); Notice.show(this, "⏱ " + PlayerLogic.clock(sec * 1000L), 1100L) } catch (e: Exception) { LogStore.err("Tv:jump", e) }
    }
    private fun tvDigit(d: Int) {
        if (tvDigits.length >= 4) tvDigits = ""
        tvDigits += d.toString()
        Notice.show(this, "⏱ روح لوقت: $tvDigits (آخر رقمين = ثواني)", 1500L)
        tvDigitRun?.let { tvH.removeCallbacks(it) }
        val r = Runnable { tvJump() }; tvDigitRun = r; tvH.postDelayed(r, 2200)
    }
    // (v462) الدفء الليلي في المشغّل (وضع TV + إعداد tv_warm من شاشة التلفزيون): طبقة برتقالية خفيفة فوق كل حاجة
    private var tvWarmV: View? = null
    private fun tvWarmApply() {
        try {
            val on = DeviceUi.isTv(this) && Cfg.str("tv_warm", "0") == "1"
            val decor = window.decorView as? android.view.ViewGroup ?: return
            if (on && tvWarmV == null) {
                val v = View(this).apply { setBackgroundColor(0x2EFF8C1A); isClickable = false; isFocusable = false }
                decor.addView(v, android.widget.FrameLayout.LayoutParams(-1, -1)); tvWarmV = v
            } else if (!on && tvWarmV != null) { decor.removeView(tvWarmV); tvWarmV = null }
        } catch (_: Exception) {}
    }

    // ===== (v463) لوحة نص الترجمة الجانبية (وضع التابلت): قايمة جمل list — دوسة تقفز، والحالية بتتلوّن وبتتابع =====
    private var trPanel: android.widget.LinearLayout? = null
    private var trBtn: android.widget.TextView? = null
    private var trScroll: android.widget.ScrollView? = null
    private var trListBox: android.widget.LinearLayout? = null
    private var trRows: ArrayList<android.widget.TextView> = ArrayList()
    private var trCur = -1
    private val trTick = object : Runnable { override fun run() { trRefresh(); if (trPanel?.visibility == View.VISIBLE) tvH.postDelayed(this, 600) } }
    private fun trDp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun trEnsureBtn() {
        try {
            if (!DeviceUi.isTablet(this) || trBtn != null) return
            val decor = window.decorView as? android.view.ViewGroup ?: return
            val b = android.widget.TextView(this).apply {
                text = "📜"; textSize = 20f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt())
                background = android.graphics.drawable.GradientDrawable().apply { shape = android.graphics.drawable.GradientDrawable.OVAL; setColor(0xB32C2C2C.toInt()) }
                setOnClickListener { trToggle() }
            }
            decor.addView(b, android.widget.FrameLayout.LayoutParams(trDp(52), trDp(52), Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, trDp(16), trDp(96)) })
            trBtn = b
        } catch (_: Exception) {}
    }
    private fun trToggle() {
        try {
            val decor = window.decorView as? android.view.ViewGroup ?: return
            if (trPanel == null) {
                val panel = android.widget.LinearLayout(this).apply {
                    orientation = android.widget.LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                    setBackgroundColor(0xF2141210.toInt()); setPadding(trDp(12), trDp(12), trDp(12), trDp(12)); elevation = trDp(12).toFloat()
                }
                val head = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                head.addView(android.widget.TextView(this).apply { text = "📜 نص الترجمة"; textSize = 15f; setTextColor(0xFFFFB340.toInt()); setTypeface(typeface, android.graphics.Typeface.BOLD) }, android.widget.LinearLayout.LayoutParams(0, -2, 1f))
                head.addView(android.widget.TextView(this).apply { text = "✕"; textSize = 16f; setTextColor(0xFFFFFFFF.toInt()); setPadding(trDp(10), trDp(4), trDp(10), trDp(4)); setOnClickListener { trToggle() } })
                panel.addView(head)
                val sc = android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false }
                val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                sc.addView(box); panel.addView(sc, android.widget.LinearLayout.LayoutParams(-1, 0, 1f))
                decor.addView(panel, android.widget.FrameLayout.LayoutParams(trDp(360), -1, Gravity.END))
                trPanel = panel; trScroll = sc; trListBox = box
            }
            val p = trPanel!!
            if (p.visibility == View.VISIBLE) { p.visibility = View.GONE; tvH.removeCallbacks(trTick) }
            else { p.visibility = View.VISIBLE; trBuild(); trCur = -1; trRefresh(); tvH.removeCallbacks(trTick); tvH.post(trTick) }
        } catch (e: Exception) { LogStore.err("Tr:toggle", e) }
    }
    private fun trBuild() {
        val box = trListBox ?: return
        box.removeAllViews(); trRows.clear()
        if (list.isEmpty()) {
            box.addView(android.widget.TextView(this).apply { text = "الترجمة لسه ما اتعملتش — دوس «ترجم» الأول"; textSize = 13f; setTextColor(0xFFBBBBBB.toInt()); setPadding(0, trDp(14), 0, 0) })
            return
        }
        for ((i, sub) in list.withIndex()) {
            val main = if (sub.translated.isNotEmpty()) sub.translated else sub.original
            val tv = android.widget.TextView(this).apply {
                text = PlayerLogic.clock((sub.start * 1000).toLong()) + "  " + main + if (sub.translated.isNotEmpty() && sub.original.isNotEmpty() && sub.original != sub.translated) "\n" + sub.original else ""
                textSize = 13f; setTextColor(0xFFEEEEEE.toInt()); setPadding(trDp(8), trDp(7), trDp(8), trDp(7))
                setOnClickListener {
                    try { player.seekTo((sub.start * 1000).toLong()); if (!player.isPlaying) player.play() } catch (_: Exception) {}
                }
            }
            trRows.add(tv); box.addView(tv)
            if (i >= 4000) break   // حماية من قوائم ضخمة جدًا
        }
    }
    private fun trRefresh() {
        try {
            if (trPanel?.visibility != View.VISIBLE || list.isEmpty() || !::player.isInitialized) return
            val pos = player.currentPosition
            var lo = 0; var hi = list.size - 1; var idx = -1
            while (lo <= hi) { val mid = (lo + hi) / 2; if ((list[mid].start * 1000).toLong() <= pos) { idx = mid; lo = mid + 1 } else hi = mid - 1 }
            if (idx == trCur || idx < 0) return
            trRows.getOrNull(trCur)?.apply { setBackgroundColor(0x00000000); setTextColor(0xFFEEEEEE.toInt()) }
            trCur = idx
            val row = trRows.getOrNull(idx) ?: return
            row.setBackgroundColor(0x55FFB340); row.setTextColor(0xFFFFFFFF.toInt())
            trScroll?.smoothScrollTo(0, (row.top - trDp(120)).coerceAtLeast(0))
        } catch (_: Exception) {}
    }

    override fun dispatchKeyEvent(ev: android.view.KeyEvent): Boolean {
        if (gone) return super.dispatchKeyEvent(ev)
        TvKill.watch(this, ev)   // (v486) 0 لمدة 5 ثواني = إلغاء تثبيت
        // (v469) والقفل شغّال: مفاتيح الصوت الجانبية كمان تتبلع (حماية جيب/أطفال كاملة — اللمس كان محجوب أصلًا)
        if (remote && !DeviceUi.isRemote(this) && (ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN || ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_MUTE)) {
            if (ev.action == android.view.KeyEvent.ACTION_DOWN && !uiLocked) rmVolumeKey(ev.keyCode)   // (v568) زراير صوت الموبايل = صوت التلفزيون
            return true
        }
        if (uiLocked && (ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP || ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN || ev.keyCode == android.view.KeyEvent.KEYCODE_VOLUME_MUTE)) return true
        // (v477 م4) تلفزيون: شريط تحكم بنمط MX/VLC. الشريط مخفي: ←/→ تقديم وتأخير · OK/↑/↓/Menu = إظهار الشريط. ظاهر: الأسهم بتتنقل بين الأزرار.
        // (v506) عدّاد «الحلقة الجاية»: بالريموت OK = شغّلها دلوقتي، رجوع = ألغي التشغيل التلقائي
        if (nextUpAt > 0L && DeviceUi.isRemote(this) && (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK || ev.keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER || ev.keyCode == android.view.KeyEvent.KEYCODE_ENTER)) {
            if (ev.action == android.view.KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                if (ev.keyCode == android.view.KeyEvent.KEYCODE_BACK) { cancelNextUp(); say("⏹ اتلغى التشغيل التلقائي") }
                else { val g = nextUpGo; cancelNextUp(); try { g?.invoke() } catch (e: Throwable) { LogStore.err("Player:nextNow", e) } }
            }
            return true
        }
        if (DeviceUi.isRemote(this)) {
            val bar = tvBar; val k = ev.keyCode; val down = ev.action == android.view.KeyEvent.ACTION_DOWN
            // (v569) تقديم معلّق: OK = نفّذ دلوقتي · Back = إلغاء (من غير ما يقفل المشغّل)
            if (tvScrubTo >= 0L && (k == android.view.KeyEvent.KEYCODE_DPAD_CENTER || k == android.view.KeyEvent.KEYCODE_ENTER || k == android.view.KeyEvent.KEYCODE_BACK)) {
                if (down && ev.repeatCount == 0) tvScrubDone(k != android.view.KeyEvent.KEYCODE_BACK)
                return true
            }
            // (v569) زراير التقديم/الترجيع في الريموت (⏩ ⏪) بنفس شريط التقديم
            if (k == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || k == android.view.KeyEvent.KEYCODE_MEDIA_REWIND || k == android.view.KeyEvent.KEYCODE_MEDIA_STEP_FORWARD || k == android.view.KeyEvent.KEYCODE_MEDIA_STEP_BACKWARD) {
                if (down) { val step = if (ev.repeatCount > 12) 60_000L else if (ev.repeatCount > 4) 30_000L else 10_000L; tvSeek(if (k == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || k == android.view.KeyEvent.KEYCODE_MEDIA_STEP_FORWARD) step else -step) }
                return true
            }
            if (k == android.view.KeyEvent.KEYCODE_VOLUME_UP || k == android.view.KeyEvent.KEYCODE_VOLUME_DOWN || k == android.view.KeyEvent.KEYCODE_VOLUME_MUTE) {
                if (down) tvVolume(k)
                return true
            }
            val media = k == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE || k == android.view.KeyEvent.KEYCODE_MEDIA_PLAY || k == android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
            if (media || k == android.view.KeyEvent.KEYCODE_MEDIA_NEXT || k == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
                k in android.view.KeyEvent.KEYCODE_0..android.view.KeyEvent.KEYCODE_9) {
                if (down) {
                    when {
                        media -> togglePlay()
                        k == android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> stepEpisode(1)
                        k == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> stepEpisode(-1)
                        else -> tvDigit(k - android.view.KeyEvent.KEYCODE_0)
                    }
                }
                return true
            }
            if (bar != null && bar.visible && (k == android.view.KeyEvent.KEYCODE_DPAD_UP || k == android.view.KeyEvent.KEYCODE_DPAD_DOWN) &&
                currentFocus.let { f0 -> f0 == null || tvInBadges(f0) || tvInside(f0, bar.view) }) {
                // (v569) من فوق لتحت: العدّادات ← شريط التقدم (يمين/شمال = سحب) ← أزرار التحكم. فوق من الأزرار = شريط التقدم
                val f = currentFocus
                val inB = tvInBadges(f); val onT = bar.onTrack(f)
                if (k == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                    if (inB) return true
                    if (!onT) { if (down) { bar.focusTrack(); bar.poke() }; return true }
                    if (::badgeRowV.isInitialized) {
                        val l = ArrayList<View>(); badgeRowV.addFocusables(l, View.FOCUS_DOWN)
                        val t = l.firstOrNull { it.isShown }
                        if (t != null) { if (down) { t.requestFocus(); bar.poke() }; return true }
                    }
                    return true
                } else {
                    if (inB) { if (down) { bar.focusTrack(); bar.poke() }; return true }
                    if (onT) { if (down) { bar.focusMain(); bar.poke() }; return true }
                    return true
                }
            }
            if (bar != null && bar.visible) { bar.poke() }
            else if (tvOverlayFocused()) { /* (v500) في عنصر مفتوح في لوحة/قايمة جوه المشغّل: سيب الأسهم وOK توصله بدل ما نبلعها */ }   // والشريط ظاهر: الأسهم/OK بتتعامل عادي مع التركيز على الأزرار
            else when (k) {
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT, android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                    if (down) {
                        // (v636) أول ضغطة يمين/شمال بتظهر شريط التحريك بس (من غير ما تحرّك)، والضغطات اللي بعدها هي اللي بتحرّك
                        if (bar != null && !bar.visible) { bar.show(); bar.focusTrack() }
                        else { val step = if (ev.repeatCount > 12) 60_000L else if (ev.repeatCount > 4) 30_000L else 10_000L; tvSeek(if (k == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) step else -step) }
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_CENTER, android.view.KeyEvent.KEYCODE_ENTER -> {
                    if (down) { if (tvDigits.isNotEmpty()) tvJump() else bar?.show() }   // (v509) OK = يظهر الأزرار المخفية (التشغيل/الإيقاف من زرار ▶ في الشريط)
                    return true
                }
                android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN, android.view.KeyEvent.KEYCODE_MENU -> {
                    if (down) bar?.show()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(ev)
    }
    /** (v509) الأزرار العايمة الدايمة فوق الفيديو (عدّاد الترجمة، 👁، الكبسولات...) مش «لوحة مفتوحة» — كانت بتاخد التركيز وتبلع OK والأسهم */
    private var tvChrome: Set<View> = emptySet()
    private fun tvSnapChrome() { try { val b = videoBoxRef; tvChrome = (0 until b.childCount).map { b.getChildAt(it) }.filter { it.tag != "chromeFrame" }.toSet() } catch (_: Throwable) {} }
    /** (v509) تلفزيون: عدّاد الجمل/النت واللوج مخفيين تمامًا (ولا بياخدوا تركيز) إلا لما شريط التحكم يظهر بـ OK */
    private fun tvGateClosed(): Boolean = DeviceUi.isRemote(this) && tvBar?.visible != true
    private fun tvChromeGate() {
        try {
            if (!DeviceUi.isRemote(this)) return
            val on = !tvGateClosed()
            applyBadgeAlpha()
            if (::leftCol.isInitialized) { leftCol.visibility = if (on) View.VISIBLE else View.INVISIBLE; if (!on) leftCol.clearFocus() }
            if (::badgeRowV.isInitialized && !on) badgeRowV.clearFocus()
            try { applyChromeFn() } catch (_: Throwable) {}   // (v636) يحدّث ظهور 👁 و⛶ مع الشريط
        } catch (e: Throwable) { LogStore.err("Tv:gate", e) }
    }
    private fun tvInside(v: View?, root: View): Boolean { var x = v; while (x != null) { if (x === root) return true; x = x.parent as? View }; return false }
    private fun tvInBadges(v: View?): Boolean { var x = v; while (x != null) { if (::badgeRowV.isInitialized && x === badgeRowV) return true; x = x.parent as? View }; return false }
    private fun tvIsChrome(v: View): Boolean { var x: View? = v; while (x != null) { if (x in tvChrome) return true; x = x.parent as? View }; return false }
    private fun tvOverlayFocused(): Boolean = try { val f = currentFocus; f != null && f.isShown && (f.isClickable || f is android.widget.EditText) && !tvIsChrome(f) } catch (_: Throwable) { false }
    /** (v568) على التلفزيون: يطبّق صوت جاي من الموبايل (0..100 صوت النظام، 101..200 تضخيم). لو الصوت ثابت (isVolumeFixed) يغيّر صوت المشغّل نفسه */
    private fun applyVolumeP(p0: Int) {
        val p = p0.coerceIn(0, 200)
        try {
            val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
            if (am.isVolumeFixed) {   // (v604) التلفزيون صوته ثابت: العادي بصوت المشغّل نفسه، والتضخيم لسه شغّال (كان بيتقصّ عند 100)
                if (p <= 100) { player.volume = p / 100f; if ((Cfg.str("vol_boost", "0").toIntOrNull() ?: 0) != 0) setBoostPct(0) }
                else { player.volume = 1f; setBoostPct(p - 100) }
            } else {
                player.volume = 1f
                if (p <= 100) { SysVol.set(this, p); if ((Cfg.str("vol_boost", "0").toIntOrNull() ?: 0) != 0) setBoostPct(0) }
                else { SysVol.set(this, 100); setBoostPct(p - 100) }
            }
            try { if (::ctl.isInitialized) ctl.vol.progress = p } catch (_: Throwable) {}
            giShowFn(if (p <= 100) "🔊 $p%" else "🔊 $p%  تضخيم ${boostDbText(p - 100)}")
        } catch (e: Throwable) { LogStore.err("Player:applyVolumeP", e) }
    }
    // ===== (v568) وضع المتحكم: الصوت بيتغيّر على التلفزيون (مش على الموبايل) =====
    private var rmVolP = -1
    private var rmVolAt = 0L
    private var rmMuteBack = -1
    private fun rmSendVolume(p0: Int) {
        val p = p0.coerceIn(0, 200); rmVolP = p; rmVolAt = System.currentTimeMillis()
        LinkSession.send("volume.set", org.json.JSONObject().put("p", p))
        try { giShowFn(if (p <= 100) "📺 🔊 $p%" else "📺 🔊 $p%  تضخيم ${boostDbText(p - 100)}") } catch (_: Throwable) {}
    }
    private fun rmVolumeKey(k: Int) {
        val cur = if (rmVolP >= 0) rmVolP else LinkSession.mirror.st.optInt("vol", 50).let { if (it < 0) 50 else it }
        when (k) {
            android.view.KeyEvent.KEYCODE_VOLUME_MUTE -> { if (cur > 0) { rmMuteBack = cur; rmSendVolume(0) } else rmSendVolume(if (rmMuteBack > 0) rmMuteBack else 50) }
            android.view.KeyEvent.KEYCODE_VOLUME_UP -> rmSendVolume(TvVolume.next(cur, +1))   // (v624) زرار الصوت = خطوة واحدة وبحد 100 (التضخيم من السلايدر بس)
            else -> rmSendVolume(TvVolume.next(cur, -1))
        }
    }
    /** (v509) الصوت بالريموت: صوت النظام، ولو التلفزيون صوته ثابت نغيّر صوت المشغّل نفسه */
    private fun tvVolume(k: Int) {
        try {
            val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
            if (k == android.view.KeyEvent.KEYCODE_VOLUME_MUTE) { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_TOGGLE_MUTE, android.media.AudioManager.FLAG_SHOW_UI); return }
            val up = k == android.view.KeyEvent.KEYCODE_VOLUME_UP
            if (am.isVolumeFixed) {
                val v = ((player.volume + if (up) 0.1f else -0.1f).coerceIn(0f, 1f)); player.volume = v
                if ((Cfg.str("vol_boost", "0").toIntOrNull() ?: 0) != 0) setBoostPct(0)   // (v604) نزّل الصوت = التضخيم يتصفّر
                try { if (::ctl.isInitialized) ctl.vol.progress = Math.round(v * 100) } catch (_: Throwable) {}
                Notice.show(this, "🔊 " + (v * 100).toInt() + "%", 900L)
            } else am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER, android.media.AudioManager.FLAG_SHOW_UI)
        } catch (e: Throwable) { LogStore.err("Tv:vol", e) }
    }
    @Volatile private var replacedByNew = false   // (v1147) اتقفل لأن فيديو جديد فتح مكانه: لازم حركة القفل تساعد حركة الدخول (من تحت لفوق) مش تلغيها
    override fun finish() { super.finish(); if (dockedAway) { try { overridePendingTransition(0, 0) } catch (_: Throwable) {}; return }; if (gone) { try { overridePendingTransition(0, 0) } catch (_: Throwable) {}; return }; try { if (ytPage) overridePendingTransition(0, 0) else if (MtLook.playerAnim()) overridePendingTransition(R.anim.player_close_enter, R.anim.player_close_exit) else overridePendingTransition(R.anim.act_stay, R.anim.act_exit) } catch (e: Exception) { LogStore.err("Main:725", e) } }   // (v1347) يوتيوب: قفل فوري (بطلب علي)
    @Volatile var cur = 0L
    @Volatile var durMs = 0L
    @Volatile var status = ""
    @Volatile var dirty = true
    private var lastBatch = 0L
    lateinit var player: PlaybackBackend
    /** (v546 م2-ج) وضع المتحكم: التشغيل والمحرك والترجمة على التلفزيون، والموبايل واجهة بس (intent extra remote=true) */
    @Volatile var remote = false
    lateinit var sub: SubtitleView
    lateinit var visual: VisualMode
    lateinit var visOv: VisualOverlay
    lateinit var miniBar: DualProgress
    lateinit var st: TextView
    lateinit var floatBar: View
    lateinit var batchTv: TextView
    lateinit var logDrawer: LinearLayout
    lateinit var logHandle: TextView
    private lateinit var leftCol: LinearLayout
    /** الأزرار العايمة وإنت بتتفرج: شبه شفافة (75% شفافية)، ولما تدوس عليها بتبقى 100% وبترجع شفافة لما تتقفل */
    private val REST_A = 0.25f
    private val PROB_A = 0.45f
    private fun fadeTo(v: View, a: Float) { try { v.animate().alpha(a).setDuration(180).start() } catch (e: Exception) { LogStore.err("Main:744", e) } }
    private val floatFades = HashMap<View, Runnable>()
    private fun flashFloat(v: View, ms: Long = 3500L) {
        fadeTo(v, 1f); floatFades[v]?.let { h.removeCallbacks(it) }
        val r = Runnable { fadeTo(v, REST_A) }; floatFades[v] = r; h.postDelayed(r, ms)
    }
    /** (v95) زرار الروتيشن العايم (فوق 👁) + دالة بتحسب مكان الاتنين من ارتفاع الشريط السفلي عشان ما يدخلوش على شريحة الترجمة */
    lateinit var rotBtn: View
    var placeFloatFn: () -> Unit = {}
    var logOn = false   // اللوج مخفي افتراضيًا — اللسان ▸ بيفرده
    lateinit var logTv: TextView
    lateinit var logSv: ScrollView
    // (v541) م0-أ: المشغّل بيكلّم واجهة EngineBackend؛ الـ Engine الحقيقي محفوظ في realEngine ويُستخدم جوه initEngine/startEngine/retireEngine/Live بس
    lateinit var engine: EngineBackend
    private lateinit var realEngine: Engine
    lateinit var th: Theme
    lateinit var ui: Ui
    val logBuf = StringBuilder()
    // (v1167) سجل اللوجات: arcRun = تشغيلة الفيديو الحالية (لوجها + ترجماتها بتتحفظ في LogArchive) · logArcPlay = id لوج محفوظ بنشغّل الفيديو بجمله (عرض بس: من غير حفظ ولا ترجمة)
    @Volatile private var arcRun: LogArchive.Run? = null
    @Volatile private var logArcPlay: String? = null
    private var logArcPlayVid = ""
    private fun archiveNow() {
        val r = arcRun ?: return
        try { LogArchive.save(applicationContext, r, if (::realEngine.isInitialized) realEngine.subs else emptyList()) } catch (e: Throwable) { LogStore.err("Player:archive", e) }
    }
    /** «ترجم من الأول» على فيديو ليه ترجمة: التشغيلة الحالية بترجماتها بتتحفظ كنسخة، وبيبدأ لوج جديد للترجمة الجديدة */
    private fun archiveRotate() {
        val r = arcRun ?: return
        try {
            val cur0 = if (::realEngine.isInitialized) realEngine.subs else emptyList()
            if (LogArchive.translatedCount(cur0) <= 0) { LogArchive.append(r, fmtMs(cur) + "  🔁 ترجمة من الأول"); return }
            LogArchive.save(applicationContext, r, cur0)
            val n = LogArchive.start(applicationContext, r.vid, r.title, r.uri, r.url)
            LogArchive.append(n, fmtMs(cur) + "  🔁 ترجمة من أول وجديد — لوج جديد (اللوج اللي قبله اتحفظ بترجماته في سجل اللوجات)")
            arcRun = n
        } catch (e: Throwable) { LogStore.err("Player:archiveRotate", e) }
    }
    val h = Handler(Looper.getMainLooper())
    var url: String? = null
    var aurl: String? = null
    private var qOpts: List<YtExtract.Opt> = emptyList()   // (v118) جودات يوتيوب
        set(v) {   // (v713) أي ما تتحمّل جودات يوتيوب (غالبًا في الخلفية بعد رسم الشريط) زرار الجودة يتعاد رسمه — كان بيفضل مخفي
            field = v
            try { window.decorView.post { try { setQualLabel(qOpts.getOrNull(qCur)?.h ?: 0) } catch (_: Throwable) {} } } catch (_: Throwable) {}
        }
    private var qCur = -1
    private var hlsH = 0                                   // جودة HLS المثبّتة (0 = تلقائي)
    private var qualBRef: TextView? = null
    private val qualRowRefs = ArrayList<TextView>()          // (v120) زرار «🎞 الجودة» اللي جنب زرار الترجمة (في الشريط السفلي والواسع)
    private var qualPopFn: ((View) -> Unit)? = null
    // (v388) لغات الصوت (يوتيوب بأكتر من مسار صوت): مربع 🔊 جنب الجودة يبدّل اللغة في نفس الفيديو
    private class ATrack(val name: String, val lang: String, val url: String, val cur: Boolean)
    private var aTracks: List<ATrack> = emptyList()
    private var aCur = 0
    private var aOverride: String? = null
    private val audRowRefs = ArrayList<TextView>()
    private var audPopFn: ((View) -> Unit)? = null
    private fun parseATracks(sj: String) {
        try {
            val at = org.json.JSONArray(sj).optJSONObject(0)?.optJSONArray("at")
            aTracks = if (at == null) emptyList() else (0 until at.length()).map { k -> val o = at.getJSONObject(k); ATrack(o.optString("n"), o.optString("l"), o.optString("u"), o.optInt("c") == 1) }.filter { it.url.isNotEmpty() }
            aCur = aTracks.indexOfFirst { it.cur }.coerceAtLeast(0); aOverride = null
        } catch (e: Exception) { aTracks = emptyList(); LogStore.err("Player:atracks", e) }
        paintAud()
    }
    // (v661) لغات صوت الفيديو المحلي (مسارات صوت جوه الملف): زرار 🔊 بيظهر لما يبقى فيه أكتر من مسار، والتبديل في نفس الفيديو (الموبايل والتلفزيون)
    private class LAud(val idx: Int, val name: String)
    private val audPills = ArrayList<TextView>()
    private fun localAud(): List<LAud> {
        val out = ArrayList<LAud>()
        try {
            if (player.exo() == null) {   // وضع المتحكم: القايمة جاية من التلفزيون (al/ac) والتبديل بيتبعت له بنفس الرقم
                player.audioTracks().forEachIndexed { k, nm -> out.add(LAud(k, nm.ifBlank { "مسار صوت " + (k + 1) })) }
                return out
            }
            var n = 0
            for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) {
                if (g.type != androidx.media3.common.C.TRACK_TYPE_AUDIO) continue
                for (i in 0 until g.length) {
                    if (g.isTrackSupported(i)) {
                        val f = g.getTrackFormat(i)
                        val lg = f.language ?: ""
                        val ln = if (lg.isBlank() || lg == "und") "" else try { java.util.Locale(lg).getDisplayLanguage(java.util.Locale("ar")).ifBlank { lg } } catch (_: Throwable) { lg }
                        val ch = when (f.channelCount) { 1 -> "مونو"; 2 -> "ستيريو"; 6 -> "5.1"; 8 -> "7.1"; else -> "" }
                        val nm = listOf(f.label?.trim().orEmpty().ifBlank { ln }, ch).filter { it.isNotBlank() }.joinToString(" · ")
                        out.add(LAud(n, nm.ifBlank { "مسار صوت " + (out.size + 1) }))
                    }
                    n += 1   // العدّ بيشمل المسارات غير المدعومة عشان يطابق PlaybackBackend.selectAudio
                }
            }
        } catch (_: Throwable) {}
        return out
    }
    private fun audLocalMode(): Boolean = aTracks.size <= 1 && localAud().size > 1
    private fun switchLocalAudio(t: LAud) {
        try { player.selectAudio(t.idx); Notice.show(this, "🔊 لغة الصوت: " + t.name, 2000L) } catch (e: Throwable) { LogStore.err("Player:selectAudio", e) }
        paintAud()
    }
    private fun paintAud() {
        val loc = audLocalMode()
        val multi = aTracks.size > 1 || loc
        val lbl = if (loc) "🔊 ▾" else "🔊 " + (aTracks.getOrNull(aCur)?.lang?.uppercase() ?: "") + " ▾"
        for (v in audRowRefs) { v.text = lbl; v.setTextColor(0xFF6FCF8A.toInt()); v.visibility = if (multi) View.VISIBLE else View.GONE }
        for (v in audPills) v.visibility = if (multi) View.VISIBLE else View.GONE
    }
    private fun switchAudio(i: Int) {
        if (aTracks.size <= 1) { localAud().getOrNull(i)?.let { switchLocalAudio(it); return } }
        val t = aTracks.getOrNull(i) ?: return
        if (i == aCur) return
        val o = qOpts.getOrNull(qCur)
        if (o == null || o.audio == null) { Notice.show(this, "الجودة دي مدمجة بصوت واحد — اختار جودة تانية الأول", 2600L); return }
        aOverride = t.url; aCur = i
        switchYt(qCur, true)
        paintAud()
        Notice.show(this, "🔊 لغة الصوت: " + t.name, 2000L)
    }
    // (v188) زرار «⏳ مركز التحميل» جنب زرار الترجمة: عداد أحمر + قايمة ⋯ بتنزل لفوق
    private var tasksPopFn: ((View) -> Unit)? = null
    private val taskBadges = ArrayList<TextView>()
    private fun taskCount(): Int = TaskCenter.active()   // (v1038) تحميلات بس
    private val taskListener: () -> Unit = {
        val n = taskCount()
        for (bd in taskBadges) { bd.text = if (n > 99) "99+" else n.toString(); bd.visibility = if (n > 0) View.VISIBLE else View.GONE }
    }
    private fun setQualLabel(h: Int) {
        qualBRef?.text = if (h > 0) h.toString() else "HD"
        for (v in qualRowRefs) v.text = if (h > 0) "${h}p ▾" else if (vidW > 0 && vidH > 0) "${minOf(vidW, vidH)}p ▾" else "الجودة ▾"
        paintQual()
    }
    /** (v134) عدد الجودات المتاحة للفيديو: يوتيوب (قايمة الجودات) أو مسارات HLS/DASH بارتفاعات مختلفة */
    private fun qualCount(): Int {
        if (qOpts.size > 1) return qOpts.size
        return try {
            val hs = HashSet<Int>()
            for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) if (g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO)
                for (ti in 0 until g.length) if (g.isTrackSupported(ti)) { val ht = g.getTrackFormat(ti).height; if (ht > 0) hs.add(ht) }
            hs.size
        } catch (_: Throwable) { 0 }
    }
    /** (v134) رقم الجودة: أخضر هادي لو الفيديو له أكتر من جودة تختار منها، أحمر لو جودة واحدة بس */
    private fun paintQual() {
        val multi = qualCount() > 1
        val col = if (multi) 0xFF6FCF8A.toInt() else 0xFFFF6B6B.toInt()
        qualBRef?.setTextColor(col)
        // (v134) أكتر من جودة → زرار الجودة بيظهر؛ جودة واحدة → علامة صغيرة (الجودة + الحجم) فوق زرار الترجمة بدل الزرار
        qualBRef?.visibility = if (uri == null && multi) View.VISIBLE else View.GONE
        for (v in qualRowRefs) { v.setTextColor(col); v.visibility = if (multi) View.VISIBLE else View.GONE }
        val ht = qOpts.getOrNull(qCur)?.h?.takeIf { it > 0 } ?: if (vidW > 0 && vidH > 0) minOf(vidW, vidH) else 0
        for (b in qBadges) {
            b.text = "🎞 " + (if (ht > 0) "${ht}p" else "—") + (if (sizeTxt.isNotEmpty()) "  ·  $sizeTxt" else "")
            b.visibility = if (!multi && uri == null && url != null) View.VISIBLE else View.GONE
        }
    }
    private val qBadges = ArrayList<TextView>()
    private var sizeTxt = ""
    private var sizeBusy = false
    private var dlRunning = false
    private var dlDlg: android.app.Dialog? = null
    private fun isHlsUrl(): Boolean = (url ?: "").contains(".m3u8", true)
    private fun dlName(): String = (intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)).substringBeforeLast('.', "").ifBlank { intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid) }

    /** (v134) حجم الفيديو الحالي: HEAD للينك المباشر/اليوتيوب (صورة+صوت)، وتقدير bitrate×المدة لـ HLS */
    fun refreshSize(show: Boolean = false) {
        if (uri != null || url == null || sizeBusy) return
        sizeBusy = true
        val o = qOpts.getOrNull(qCur); val u = o?.url ?: url!!; val au = o?.audio ?: aurl; val hs = HashMap(hdr)
        val hlsNow = o == null && isHlsUrl()
        val brEst = try { player.exo()?.videoFormat?.bitrate ?: -1 } catch (_: Throwable) { -1 }; val dur = durMs
        Thread {
            var n = -1L; var approx = false
            try {
                if (hlsNow) { if (brEst > 0 && dur > 0) { n = brEst / 8L * (dur / 1000L); approx = true } }
                else {
                    val a = Downloader.sizeOf(u, hs)
                    if (a > 0) { n = a; if (au != null) { val b = Downloader.sizeOf(au, hs); if (b > 0) n += b } }
                }
            } catch (_: Throwable) {}
            val txt = if (n > 0) (if (approx) "≈" else "") + Sniff.fmtSize(n) else ""
            runOnUiThread {
                sizeBusy = false; sizeTxt = txt; paintQual()
                if (show) Notice.show(this, if (txt.isNotEmpty()) "📦 حجم الفيديو: $txt" else "حجم الفيديو مش معروف من السيرفر", 2600L)
            }
        }.start()
    }
    /** (v804) وصف الفيديو الشغّال للريموت: kind = local (ملف على التلفزيون) · net (لينك / يوتيوب / HLS) · none */
    private fun dlInfo(): org.json.JSONObject {
        val j = org.json.JSONObject()
        val nm = try { dlName() } catch (_: Throwable) { "video" }
        j.put("name", nm).put("dur", durMs).put("kind", "none")
        try { j.put("hdr", org.json.JSONObject(HashMap<String, String>(hdr) as Map<*, *>)) } catch (_: Throwable) {}
        val u0 = url ?: uri?.toString()?.takeIf { it.startsWith("http", true) }
        if (qOpts.isNotEmpty()) {
            val arr = org.json.JSONArray()
            for (o in qOpts) arr.put(org.json.JSONObject().put("l", o.label).put("u", o.url).put("a", o.audio ?: "").put("h", o.h))
            j.put("kind", "net").put("qlist", arr)
        } else if (u0 != null && u0.startsWith("http", true)) {
            j.put("kind", "net").put("url", u0).put("aurl", aurl ?: "")
            if (isHlsUrl()) {
                j.put("hls", true)
                val arr = org.json.JSONArray(); val seen = HashSet<Int>()
                try {
                    for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) if (g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO)
                        for (ti in 0 until g.length) if (g.isTrackSupported(ti)) { val f = g.getTrackFormat(ti); if (f.height > 0 && seen.add(f.height)) arr.put(org.json.JSONObject().put("h", f.height).put("br", f.bitrate)) }
                } catch (_: Throwable) {}
                j.put("hlsq", arr)
            } else j.put("ht", if (vidW > 0 && vidH > 0) minOf(vidW, vidH) else 0)
        } else {
            val u = uri
            if (u != null) {
                val fn = (u.lastPathSegment ?: "video.mp4").substringAfterLast('/')
                val sz = try { Xfer.sizeOf(this, u) } catch (_: Throwable) { -1L }
                j.put("kind", "local").put("file", fn).put("size", sz)
            }
        }
        return j
    }
    /** (v804) تحميل على التلفزيون نفسه بطلب من الريموت (نفس مهمة «⬇» في المشغّل) */
    private fun dlStart(a: org.json.JSONObject): Boolean {
        val u = a.optString("url")
        if (!u.startsWith("http", true)) return false
        val hm = HashMap<String, String>()
        a.optJSONObject("hdr")?.let { hj -> for (k in hj.keys()) hm[k] = hj.optString(k) }
        val au = a.optString("audio").ifEmpty { null }
        startDownload(Downloader.Job(a.optString("name", "video").ifBlank { "video" }, u, au, a.optBoolean("hls"), a.optInt("h"), hm, a.optBoolean("audioOnly")))
        return true
    }
    private fun startDownload(job: Downloader.Job) {
        val app = applicationContext
        // (v137) التحميل بقى مهمة في تبويب «المهام»: إيقاف مؤقت / استكمال / إلغاء / إعادة، وممكن أكتر من تحميل ورا بعض
        TaskCenter.add(app, "download", (if (job.audioOnly) "🎧 " else "⬇ ") + job.name) { t ->
            job.ctl.cancelled = false; job.ctl.paused = false
            job.ctl.ext = { t.cancelled }
            t.onCancel = { job.ctl.cancelled = true }
            t.onPause = { p -> job.ctl.paused = p }
            val res = Downloader.run(app, job) { what, pct -> t.pct = pct.coerceIn(0, 99); t.msg = what; TaskCenter.changed() }
            if (!res.first) throw java.io.IOException(res.second)
            t.msg = ""; t.outPath = res.second
        }
        try { Notice.show(this, "⬇ اتضاف للتحميل — تابعه من «مركز التحميل» (إيقاف · استكمال · إلغاء)", 3200L) } catch (_: Throwable) {}
    }
    /** (v134) زرار ⬇: قايمة الجودات (بحجم كل واحدة) — الاختيار بيبدأ التحميل */
    fun downloadPopup(anchor: View) {
        dlDlg?.let { if (it.isShowing) { it.dismiss(); dlDlg = null; return } }
        val u0 = url ?: return
        val hs = HashMap(hdr); val nm = dlName()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2))
        }
        col.addView(ui.text("🎬 الفيديو — الجودة والحجم", 13f, th.muted, true).apply { setPadding(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(4)) })
        fun addItem(label: String, job: Downloader.Job, sizeFn: (() -> Long)?) {
            val b = ui.button(label) { dlDlg?.dismiss(); startDownload(job) }
            col.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, ui.dp(3), 0, ui.dp(3)) })
            if (sizeFn != null) Thread {
                val n = try { sizeFn() } catch (_: Throwable) { -1L }
                if (n > 0) runOnUiThread { b.text = label + "  ·  " + Sniff.fmtSize(n) }
            }.start()
        }
        if (qOpts.isNotEmpty()) {
            for (o in qOpts) addItem(o.label, Downloader.Job(nm, o.url, o.audio, false, o.h, hs)) {
                val a = Downloader.sizeOf(o.url, hs); if (a > 0 && o.audio != null) a + maxOf(0L, Downloader.sizeOf(o.audio, hs)) else a
            }
        } else if (isHlsUrl()) {
            val seen = HashSet<Int>(); val tl = ArrayList<Pair<Int, Int>>()   // (الارتفاع، bitrate)
            for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) if (g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO)
                for (ti in 0 until g.length) if (g.isTrackSupported(ti)) { val f = g.getTrackFormat(ti); if (f.height > 0 && seen.add(f.height)) tl.add(Pair(f.height, f.bitrate)) }
            if (tl.isEmpty()) addItem("أعلى جودة متاحة", Downloader.Job(nm, u0, null, true, 0, hs), null)
            else for ((hh, br) in tl.sortedByDescending { it.first })
                addItem("${hh}p", Downloader.Job(nm, u0, null, true, hh, hs), if (br > 0 && durMs > 0) ({ br / 8L * (durMs / 1000L) }) else null)
            col.addView(ui.text("HLS: بيتحمّل ملف .ts (مقاطع من غير تشفير بس)", 11f, th.muted).apply { setPadding(ui.dp(4), ui.dp(4), ui.dp(4), ui.dp(2)) })
        } else {
            val ht = if (vidW > 0 && vidH > 0) minOf(vidW, vidH) else 0
            addItem("الفيديو بالجودة الحالية" + (if (ht > 0) " (${ht}p)" else ""), Downloader.Job(nm, u0, aurl, false, ht, hs)) {
                val a = Downloader.sizeOf(u0, hs); if (a > 0 && aurl != null) a + maxOf(0L, Downloader.sizeOf(aurl!!, hs)) else a
            }
        }
        // (v134) صوت فقط: M4A (AAC) — لو الصوت لينك لوحده (يوتيوب) بيتحمّل هو بس، وإلا بيتحمّل الفيديو ويتستخرج منه الصوت (أقل جودة عشان الحجم)
        col.addView(ui.text("🎧 الصوت", 13f, th.muted, true).apply { setPadding(ui.dp(4), ui.dp(10), ui.dp(4), ui.dp(4)) })
        val aOpt = qOpts.firstOrNull { it.audio != null }
        val loOpt = qOpts.filter { it.h > 0 }.minByOrNull { it.h } ?: qOpts.lastOrNull()
        val aJob: Downloader.Job = when {
            aOpt != null -> Downloader.Job(nm, aOpt.url, aOpt.audio, false, 1, hs, true)
            loOpt != null -> Downloader.Job(nm, loOpt.url, null, false, 1, hs, true)
            isHlsUrl() -> Downloader.Job(nm, u0, null, true, 1, hs, true)
            else -> Downloader.Job(nm, u0, aurl, false, 0, hs, true)
        }
        val aSrc = aJob.audio
        // (v1121) الصوت لوحده تحت الفيديوهات: الجودة (kbps) والحجم جنب الصف
        run {
            val lab0 = "🎧 تحميل كصوت (M4A)"
            val b = ui.button(lab0) { dlDlg?.dismiss(); startDownload(aJob) }
            col.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, ui.dp(3), 0, ui.dp(3)) })
            if (aSrc != null) Thread {
                val n = try { Downloader.sizeOf(aSrc, hs) } catch (_: Throwable) { -1L }
                if (n > 0) runOnUiThread {
                    val kb = if (durMs > 0) n * 8L / (durMs / 1000L).coerceAtLeast(1L) / 1000L else 0L
                    b.text = lab0 + (if (kb in 16..640) "  ·  $kb kbps" else "") + "  ·  " + Sniff.fmtSize(n)
                }
            }.start()
        }
        h.removeCallbacks(hideChrome); showChrome()
        dlDlg = GAlert(this).setTitle("⬇ تحميل").setView(col).setNegativeButton("إغلاق", null).show().also { d -> d.setOnDismissListener { if (dlDlg === d) dlDlg = null; showChrome() } }
    }
    var uri: Uri? = null
    private var httpDsf: DefaultHttpDataSource.Factory? = null
    /** (v1249) كل مصادر الإنترنت (تبديل الجودة/الصوت، دمج فيديو+صوت يوتيوب) بتعدّي على كاش القرص: الرجوع في الجزء المتحمّل (الخط الأزرق) بيتقرا من الكاش حتى لو النت قطع، مش من الشبكة */
    private fun cachedDsf(f: androidx.media3.datasource.DataSource.Factory): androidx.media3.datasource.DataSource.Factory = try { NetCache.factory(this, f) } catch (_: Throwable) { f }
    val hdr = HashMap<String, String>()
    var touching = false
    lateinit var conf: Conf
    // قايمة الجمل (نسخة مرتبة + مصفوفات للبحث الثنائي)
    var list: List<Sub> = emptyList()
    var starts = LongArray(0); var ends = LongArray(0)
    private var hideTicks = 0
    private val seenKeys = HashSet<String>(); private val warnedKeys = HashSet<String>(); private var lastChkT = -1L
    private fun sentKey(q: Sub) = "${q.start}|${q.end}|${q.translated.hashCode()}"
    // الحوار والأصوات الخلفية بيتفصلوا: الحوار تحت، وصف الصوت (همهمة/موسيقى…) فوق الفيديو
    var spMap = IntArray(0); var spStarts = LongArray(0); var spEnds = LongArray(0)
    var sdMap = IntArray(0); var sdStarts = LongArray(0); var sdEnds = LongArray(0)
    lateinit var soundTv: TextView; var soundKey = ""
    var termFull = ""   // (v134) شرح المصطلح الظاهر فوق دلوقتي (بصيغة «المصطلح»: الشرح)
    private fun termName(t: String): String { val a = t.indexOf('«'); val b = t.indexOf('»'); return if (a >= 0 && b > a) t.substring(a + 1, b).trim() else t.trim().take(24) }
    /** (v134) دوس على ⓘ: الفيديو يقف ويظهر معنى المصطلح / المقصود منه في المشهد، وبيكمّل لما تقفل */
    fun showTermCard() {
        val full = termFull; if (full.isEmpty()) return
        val was = try { player.isPlaying } catch (_: Throwable) { false }
        try { player.pause() } catch (_: Throwable) {}
        val body = full.substringAfter('»', full).trimStart(':', '：', ' ', '\n').trim().ifBlank { full }
        fun resume() { if (was) { try { player.play() } catch (_: Throwable) {} } }
        GAlert(this).setTitle("ⓘ " + termName(full)).setMessage(body)
            .setPositiveButton("تمام") { _, _ -> resume() }
            .setOnCancelListener { resume() }
            .show()
    }
    var curIdx = -1; var curKey = ""; var lastRefresh = 0L
    // (v515) ترجمة الفيديو الأصلية (سوفت صب جوه الملف أو ملف ترجمة جنبه): بتظهر بنفس ستايل المشغّل بلون أبيض لما مفيش ترجمة من المحرك
    @Volatile private var nativeCue = ""
    /** (v762) ترجمة ملف الترجمة (سوفت/هارد) خلصت واتطبّقت: مسار الترجمة الأصلي بتاع الفيديو/الملف المرفق يتقفل خالص ومايظهرش — اللي يظهر ترجمة البرنامج بس. بيتفتح تاني لو اخترت مسار أصلي بإيدك أو ترجمة لحظية */
    @Volatile private var sfHideNative = false
    private fun sfKillNative() {
        nativeCue = ""
        try { player.exo()?.let { xp -> if (!xp.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_TEXT)) xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true).build() } } catch (_: Throwable) {}
    }
    private var natShown = false
    private var natGapSince = 0L
    private var textPicked = false
    private var natStart = 0.0
    private var natLast = ""
    private var natWaitCue = ""; private var natWaitSince = 0L   // (v703) استنى الترجمة اللحظية بدل ما تعرض الأصل ثانية
    private fun natSub(t: String): Sub {
        if (t != natLast) { natLast = t; natStart = cur / 1000.0 }
        val tr = sfLiveText(t)   // (v529) ترجمة لحظية لو اتفعّلت من «📄 ترجمة ملف الترجمة»
        return Sub(natStart, natStart + 3.0, t, tr, "", "", "", emptyList(), emptyList(), false, false)
    }
    private fun natStyle(base: SubStyle): SubStyle = if (natShown) base.copy(uniOn = true, uniColor = "#FFFFFF") else base
    /** ملف ترجمة جنب الفيديو المحلي (نفس الاسم .srt/.ass/.ssa/.vtt/.ttml، أو name.ar.srt)؛ العربي أولًا */
    private fun findSidecar(u: Uri): java.io.File? = SubSidecar.find(this, u)   // (v676) المنطق اتنقل لـ SubSidecar (CastServer.kt) عشان الموبايل يلاقي نفس ملف الترجمة ويبعته للتلفزيون
    private fun mediaItemFor(u: Uri): MediaItem {
        val sc = findSidecar(u) ?: return MediaItem.fromUri(u)
        return try {
            val mime = when (sc.extension.lowercase()) { "ass", "ssa" -> androidx.media3.common.MimeTypes.TEXT_SSA; "vtt" -> androidx.media3.common.MimeTypes.TEXT_VTT; "ttml" -> androidx.media3.common.MimeTypes.APPLICATION_TTML; else -> androidx.media3.common.MimeTypes.APPLICATION_SUBRIP }
            val cfg = MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(sc)).setMimeType(mime).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
            log("💬 لقيت ملف ترجمة جنب الفيديو: ${sc.name}")
            MediaItem.Builder().setUri(u).setSubtitleConfigurations(listOf(cfg)).build()
        } catch (e: Throwable) { LogStore.err("Player:sidecar2", e); MediaItem.fromUri(u) }
    }
    var offsetMs = 0L; var speed = 1f; var fit = 0; var fsFit = 2; var fitFsB: TextView? = null
    var ccSync: (() -> Unit)? = null   // (v1138) أي تغيير في ccOn (من أي مكان في الكود) بيحدّث شكل زرار CC
    var ccOn = true
        set(v) { field = v; try { ccSync?.invoke() } catch (_: Throwable) {} }
    fun isLandNow() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    /** أفقي: وضع الشاشة الكاملة (الافتراضي تمديد) — رأسي: وضع منفصل (الافتراضي احتواء) */
    fun curFit(): Int { val m = if (isLandNow()) fsFit else fit; return if (m == 2) 2 else 0 }   // (v1020) احتواء / ملء الشاشة بس (القديم 1 و3 بيتحوّلوا لاحتواء)   // (v707) «100%» محتاج قرص بصباعين — مش بيشتغل بالريموت فعلى التلفزيون متشال
    lateinit var svRef: android.view.SurfaceView
    @Volatile var visNow = 0.0
    var vidW = 0; var vidH = 0
    lateinit var listView: ListView
    lateinit var counters: TextView
    lateinit var adapter: BaseAdapter
    lateinit var extras: View
    lateinit var videoBoxRef: FrameLayout
    lateinit var sentCap: LinearLayout   // (v322) كبسولة موحّدة: 🔊 صوتي | 👁 بصري
    lateinit var sentDiv: View
    lateinit var fsBadge: TransBadge
    lateinit var noticeBtn: TextView   // (v217) مثلث ▲ الإشعارات (v224: جنب زرار لاندسكيب/بورتريت)
    private var voice: VoiceClean.Playback? = null   // (v334) 🎙 صوت الكلام النضيف شغّال جنب الفيديو
    private var voiceBtnRef: TextView? = null
    private var trLgB: TextView? = null   // (v224) 🌐 و🔑 بقوا أيقونات صغيرة جنب زرار 🗣 في الشريط السفلي
    private var trKmB: TextView? = null
    lateinit var visBadge: TransBadge   // (v182) عدّاد جمل الوضع البصري — (v249) جنب كبسولة الصوت شمال فوق
    lateinit var netBadge: NetBadge   // (v249) كبسولة سحب النت — منفصلة، نفس مكان الكبسولتين
    private var badgeHotUntil = 0L   // (v249) لما تدوس كبسولة بتبقى 100% لحد الوقت ده، وبعدها ترجع للشفافية المضبوطة من الإعدادات
    private fun badgeHot() { badgeHotUntil = System.currentTimeMillis() + 4000; applyBadgeAlpha() }
    private lateinit var badgeRowV: LinearLayout
    /** (v323) العدّادات (صوتي/بصري/نت) مخفية خالص والشاشة نضيفة؛ لما أزرار المشغّل تظهر (لمسة) بتظهر 100%. BADGE_IDLE_A لو عايزها باهتة بدل مخفية (مثلًا 0.3f) */
    private val BADGE_IDLE_A = 0.3f   // (v432) عدّاد الجمل باهت 30% حتى والأزرار مخفية (كان 0.5)
    private fun applyBadgeAlpha() {
        if (!::sentCap.isInitialized || !::netBadge.isInitialized || !::badgeRowV.isInitialized) return
        val a = if (tvGateClosed()) 0f else if (chromeShown || (DeviceUi.isRemote(this) && tvBar?.visible == true) || System.currentTimeMillis() < badgeHotUntil) 1f else BADGE_IDLE_A   // (v509) تلفزيون: العدّادات مخفية خالص لحد ما OK يظهر الشريط
        if (badgeRowV.alpha != a) badgeRowV.alpha = a
        val v = if (a <= 0.01f) View.INVISIBLE else View.VISIBLE   // INVISIBLE = مايستقبلش لمس
        if (badgeRowV.visibility != v) badgeRowV.visibility = v
    }
    lateinit var fsBtnV: TextView
    lateinit var fsBarFs: TextView
    lateinit var fsBtnLp: FrameLayout.LayoutParams
    lateinit var centerPlay: TextView
    lateinit var ctl: Ctl
    lateinit var mem: MemRow
    lateinit var fsProgV: DualProgress
    // أشرطة التقدم: كاش مجالات التغطية والجمل المستنية (بيتحدّث لما الجمل أو عدد المستني يتغيّر بس)
    private var segSubsRef: List<Sub>? = null; private var segPendN = -1
    private var segCov: List<DoubleArray> = emptyList(); private var segPend: List<DoubleArray> = emptyList()
    private var segVis: List<DoubleArray> = emptyList(); private var segVisN = -1   // (v226) علامات الوضع البصري على الشريط
    private var visList: List<VisEntry> = emptyList()   // (v226) جمل الوضع البصري في قايمة 📝
    private fun updVis() { visList = try { if (::visual.isInitialized) visual.entries().sortedBy { it.start } else emptyList() } catch (_: Throwable) { emptyList() } }
    /** (v160) الأجزاء المحمّلة من الفيديو الأونلاين (بتتراكم أثناء المشاهدة وبتتدمج) */
    private val bufSegs = ArrayList<DoubleArray>()
    // ===== (v736) تشغيل فيديو لسه بيتحمّل (من صفحة المهام): خط على الجزء المحمّل + الشريط بيتحدّث مع نزول الملف =====
    private var partTask: TaskItem? = null
    private var partLenAtPrep = 0L; private var partFracAtPrep = 0.0; private var partLastPrep = 0L
    private var partBuf: List<DoubleArray> = emptyList()
    private fun partFrac(pt: TaskItem): Double = if (pt.dlTotal > 0L) (pt.dlDone.toDouble() / pt.dlTotal).coerceIn(0.0, 1.0) else 0.0
    private fun partReprepare(u: Uri) {
        val xp = player.exo() ?: return
        val pos = xp.currentPosition.coerceAtLeast(0L); val pw = xp.playWhenReady
        xp.setMediaItem(mediaItemFor(u), pos); xp.prepare(); xp.playWhenReady = pw
        partLastPrep = System.currentTimeMillis()
    }
    private fun partTick(d: Long) {
        val pt = partTask ?: return
        try {
            val xp = player.exo() ?: return
            val now = System.currentTimeMillis()
            if (pt.state != 1 && pt.state != 6) {
                // التحميل خلص (أو وقف): لو خلص بدّل للملف النهائي من نفس المكان (الملف الجزئي بيتمسح)
                partTask = null; partBuf = emptyList()
                val fin = pt.outUri ?: (if (pt.outPath.startsWith("/") && java.io.File(pt.outPath).isFile) Uri.fromFile(java.io.File(pt.outPath)) else null)
                if (pt.state == 2 && fin != null) { uri = fin; partReprepare(fin) }
                return
            }
            val f = java.io.File(pt.partPath)
            val len = if (f.isFile) f.length() else 0L
            val frac = partFrac(pt)
            // HLS (.ts): مدة المشغّل بتبقى مدة الجزء اللي كان موجود وقت الفتح بس ← نقدّر المدة الكاملة منها ومن نسبة التحميل وقتها
            if (pt.partPath.endsWith(".ts", true) && d > 0 && partFracAtPrep > 0.01) durMs = (d / partFracAtPrep).toLong()
            val dur = if (durMs > 0) durMs else d
            partBuf = if (dur > 0 && frac > 0.0) listOf(doubleArrayOf(0.0, dur / 1000.0 * frac)) else emptyList()
            // الملف كبر: ملف المشغّل اتفتح بطوله القديم، فنعيد التحضير (من نفس الثانية) لما المشاهدة توصل لحد المتاح أو الملف يكبر كتير
            val grew = len - partLenAtPrep
            val st = xp.playbackState
            val atEdge = st == Player.STATE_ENDED || st == Player.STATE_BUFFERING
            if (now - partLastPrep > 3000L && grew > 0L && ((atEdge && grew > 64_000L) || (grew > 1_000_000L && len >= partLenAtPrep * 5 / 4))) {
                partLenAtPrep = len; partFracAtPrep = frac
                partReprepare(Uri.fromFile(f))
            }
        } catch (_: Throwable) {}
    }
    private fun addBuf(a: Double, b: Double) {
        if (b - a < 0.5) return
        var s = a; var e = b
        val it = bufSegs.iterator()
        while (it.hasNext()) { val x = it.next(); if (x[1] >= s - 1.0 && x[0] <= e + 1.0) { s = minOf(s, x[0]); e = maxOf(e, x[1]); it.remove() } }
        bufSegs.add(doubleArrayOf(s, e))
    }
    lateinit var fsEl: TextView
    lateinit var fsDu: TextView
    lateinit var fsPlayB: TextView
    lateinit var sentDlg: android.app.Dialog
    lateinit var logDlg: android.app.Dialog
    var chromeShown = false
    var fsOnly: List<View> = emptyList()
    private lateinit var topTitle: TextView   // (v330) اسم الفيديو الشغّال (فوق شمال، جنب كبسولات العدّ)
    private var fixTopRowFn: () -> Unit = {}
    private var tbView: View? = null   // (v265) الشريط العلوي (أزرار المشغّل)
    var lastMem = 0L
    var applyChromeFn: () -> Unit = {}
    var nextPanel: NextPanel? = null   // (v378) لوحة «التالي» تحت أزرار المشغّل (يوتيوب)
    var dismissPopFn: () -> Unit = {}
    var restyleFn: () -> Unit = {}
    private var resumeAfterSettings = false
    val hideChrome = Runnable { chromeShown = false; applyChromeFn() }
    var fullMode = false
    private var uiLocked = false
    private lateinit var lockOv: TextView
    private val hideLockOv = Runnable { if (::lockOv.isInitialized) lockOv.visibility = View.GONE }
    private var askSaved = false
    private var autoTr = false
    private var stripV: View? = null
    private val hideStrip = Runnable { dismissStrip() }
    fun dismissStrip() { h.removeCallbacks(hideStrip); stripV?.let { try { (it.parent as? ViewGroup)?.removeView(it) } catch (e: Exception) { LogStore.err("Main:823", e) } }; stripV = null }
    // (v91) شريط «كمّل / من الأول / بدون ترجمة» اتمسح بالكامل
    fun setLock(b: Boolean) {
        uiLocked = b
        if (b) { h.removeCallbacks(hideChrome); chromeShown = false; applyChromeFn(); say("🔒 الشاشة مقفولة — المس الشاشة واضغط على القفل لفتحها") }
        else { lockOv.visibility = View.GONE; showChrome() }
    }
    // ===== إشعار التحكم (v87): الحالة بتتبعت للخدمة، والأوامر بترجع من الإشعار على remote() =====
    private var lastNotifAt = 0L
    private var notifTitleOv: String? = null
    fun notifTitle(): String {
        val t = notifTitleOv ?: intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)
        return t.substringBeforeLast('.', t)
    }
    /** (v360) اسم الفيديو + تحته سطر صغير بملخص إعداد الترجمة المحفوظ (بيفضل مع أي فيديو) */
    private fun titleWithSummary(): CharSequence {
        val t = notifTitle(); if (t.isBlank()) return ""
        val s = try { listOf(TrWizard.summaryLine(), TrWizard.langLine()).filter { it.isNotBlank() }.joinToString("\n") } catch (_: Throwable) { "" }   // (v413) + سطر كشف اللغة
        if (s.isBlank()) return t
        val sb = android.text.SpannableStringBuilder(t); val st = sb.length
        sb.append("\n").append(s)
        sb.setSpan(android.text.style.RelativeSizeSpan(0.85f), st, sb.length, 0)
        sb.setSpan(android.text.style.ForegroundColorSpan(0xFFE6D8C5.toInt()), st, sb.length, 0)
        return sb
    }
    fun pushNotif() {
        try {
            val st = NotifState
            st.title = notifTitle(); st.posMs = player.currentPosition.coerceAtLeast(0); st.durMs = if (durMs > 0) durMs else 0L
            st.playing = player.isPlaying
            st.trState = if (!::engine.isInitialized || !engineStarted) 0 else if (engine.userPaused) 2 else 1
            st.trPct = if (durMs > 0 && ::engine.isInitialized) covPct() else (fastTr?.takeIf { it.total > 0 }?.pct ?: 0)
            KeepAliveService.refresh()
        } catch (e: Throwable) { LogStore.err("pushNotif", e) }
    }
    fun exitAll() {
        if (remote) { rmFrames = false; finishAndRemoveTask(); return }   // (v568) إشعار التحكم: اقفل شاشة التحكم بس، التلفزيون يكمّل
        try { player.pause() } catch (e: Exception) { LogStore.err("exitAll", e) }
        saveRecent(); Thread { try { engine.saveNow() } catch (e: Exception) { LogStore.err("Player:exitSave", e) } }.start()   // (v287) فشل الحفظ كان صامت
        finishAndRemoveTask()
    }
    /** أوامر الإشعار: toggle / prev / next / seek / tr / exit */
    fun remote(cmd: String, arg: Long = 0L) {
        runOnUiThread {
            try {
                when (cmd) {
                    "toggle" -> togglePlay()
                    "prev" -> stepEpisode(-1)
                    "next" -> stepEpisode(1)
                    "seek" -> if (durMs > 0) player.seekTo(arg.coerceIn(0L, durMs))
                    "tr" -> if (engineStarted && !engine.userPaused) pauseTranslate() else beginTranslate()   // (v228) من غير translateFrom بعدها: كان بيلغي إعداد «ترجم من الأول» ويبدأ من مكان التشغيل
                    "exit" -> exitAll()
                }
                lastNotifAt = System.currentTimeMillis(); pushNotif()
            } catch (e: Throwable) { LogStore.err("remote:$cmd", e) }
        }
    }
    // (v469) أسماء أوضاع العرض: الثلاثة الأصلية من PlayerLogic + وضع رابع «100%» (حجم طبيعي 1:1 مع زوم بالقرص) بيتحسب هنا
    private var vidZoomF = 1f
    fun fitNameOf(m: Int): String = if (m == 2) "ملء الشاشة" else "احتواء"   // (v1020) وضعين بس
    fun cycleFitNow() {
        if (remote && !rmFitSkip) {   // (v604) الاحتواء/التكبير: موبايل ولا تلفزيون؟
            rmChoose("📐 شكل الصورة", "📱 على الموبايل بس", "📺 على التلفزيون", { rmFitSkip = true; try { cycleFitNow() } finally { rmFitSkip = false } }, {
                LinkSession.send("act", org.json.JSONObject().put("a", "fit"))
            })
            return
        }
        if (isLandNow()) { fsFit = if (curFit() == 2) 0 else 2; Cfg.p.edit().putString("fs_fit", fsFit.toString()).apply() }   // (v1020) وضعين بس
        else { fit = if (curFit() == 2) 0 else 2; Cfg.p.edit().putString("fit", fit.toString()).apply() }
        fitFsB?.text = "⬛ " + fitNameOf(curFit()); applyFit(svRef, videoBoxRef)
        say("⬛ " + fitNameOf(curFit()))
    }
    var vid = ""
    // ===== استكمال/إعادة ترجمة + ترجمة في الخلفية =====
    lateinit var resumeCard: LinearLayout
    lateinit var resumeTv: TextView
    private var resumePending = false
    private var handedOff = false
    @Volatile private var ffShown = false
    fun applyCard() { if (::resumeCard.isInitialized) resumeCard.visibility = if (resumePending && !pipNow()) View.VISIBLE else View.GONE }
    private fun placeCard() {
        if (!::resumeCard.isInitialized) return
        val lp = resumeCard.layoutParams as FrameLayout.LayoutParams
        lp.topMargin = ui.dp(if (fullMode) 96 else 6); resumeCard.layoutParams = lp
    }
    /** الاختيار (كمّل / من الأول) بيتعمل قبل دخول الفيديو من المكتبة — هنا الترجمة بتكمّل تلقائي من غير كارت ولا وقفة */
    private fun maybePrompt(wasBg: Boolean) {
        engine.keepGoing = Cfg.bool("keepgoing", true)
        engine.paused = false
        resumePending = false; applyCard()
        status = "دوس «ترجمة» لما تحب تبدأ"
        if (wasBg) say("🌙 كان بيترجم في الخلفية — دوس «ترجمة» تكمّل من مكانه")
    }

    // ===== الترجمة بإيد المستخدم: مفيش بداية تلقائية. زرار «ترجمة» أحمر ← بيتبدّل بـ ⏸ إيقاف مؤقت / ▶ إلغاء الإيقاف =====
    private var engineStarted = false
    private var noSub = false                     // دخلت بـ «فرجة من غير ترجمة»: الترجمة مخفية والمحرك واقف لحد ما تدوس «ترجمة»
    // (v999 ملاحظة 4) ترجمة الاستوديو للفيديو ده: مصدرها + حالة سؤال الاختيار
    @Volatile private var studioLabel = ""
    @Volatile private var studioAskOpen = false
    private var studioAskedVid = ""
    private var studioApplied = false
    private var studioAppliedN = 0
    var ccToggleFn: () -> Unit = {}
    private val trUpdaters = ArrayList<() -> Unit>()
    var tbCollapseFn: () -> Unit = {}
    private var lastWp = -2
    var trPct = 0   // نسبة الترجمة (بتتحدّث كل 200ms) — للشريحة الصغيرة في الشريط السفلي
    private val logAuto = Runnable { if (logOn) toggleLog() }     // لوحة الباتشات بتتلم لوحدها
    private val probAuto = Runnable { if (probOn) toggleProb() }  // كبسولة الباتش الفاشل بتتلم لوحدها
    fun updateTr() { applyModeCaps(); trUpdaters.forEach { try { it() } catch (e: Exception) { LogStore.err("Main:866", e) } } }
    // (v552) سوفت صب: لما تدوس «ترجم» (جيميناي/ويسبر/أي محرك) والفيديو فيه ترجمة جاهزة، بنسألك تترجمها بدل الصوت وتختار المسار — بدل زرار «ترجمة السوفت صب» القديم
    /** (v638) سطر بيشرح خطة الترجمة بجيميناي حسب عدد المفاتيح اللي عندك */
    private fun sfPlanNote(): String = try {
        val k = (Cfg.allMainKeys() + Cfg.keys("viskeys")).distinct().filter { it.length > 10 }.size
        val (t, r) = SubFileTr.multiPlan(k)
        if (k >= 2) " · $t يترجموا الملف كامل + $r ينقّحوا" else ""
    } catch (_: Throwable) { "" }
    @Volatile private var autoSubKey = ""
    private fun autoEng(): String = try { TrWizard.savedPlan()?.let { if (it.offline) "google" else "gemini" } } catch (_: Throwable) { null } ?: if (TrWizard.hasGeminiKey()) "gemini" else "google"
    /** (v667) أول ما الفيديو يفتح وملوش ترجمة محفوظة: يدوّر على سوفت صب (جوه الفيديو أو ملف جنبه) ويترجمه لوحده؛ مفيش ← هارد صب (بصري بجيميناي). لغة الأصل مش فارقة حتى لو عربي. إيقاف: Cfg auto_sub=0 */
    private fun autoSub() {
        try {
            if (studioAskOpen) return
            val vu = uri ?: return
            val key = vu.toString()
            if (remote || logArcPlay != null || autoSubKey == key || noSub || askSaved || Cfg.str("auto_sub", "1") == "0") return
            if (engineStarted || engine.subs.isNotEmpty() || sfBusy.isNotEmpty()) return
            autoSubKey = key; softAskedFor = key
            // (v1137) اختيار ملف الترجمة: «بدون ترجمة» محفوظ ← مفيش ترجمة تلقائية · أكتر من ملف ومفيش اختيار ← شاشة اختيار صريحة (مفيش اختيار صامت)
            if (SubSel.choice(this, vu) == SubSel.NONE) return
            if (SubSel.needsChoice(this, vu, subCands(true))) {
                h.postDelayed({ try { if (!isFinishing && !isDestroyed && !engineStarted && engine.subs.isEmpty() && sfBusy.isEmpty() && uri?.toString() == key) subSelectSheet(window.decorView, true) } catch (e: Throwable) { LogStore.err("Player:subSel0", e) } }, 900L)
                return
            }
            h.postDelayed({
                try {
                    if (isFinishing || isDestroyed || engineStarted || engine.subs.isNotEmpty() || sfBusy.isNotEmpty() || uri?.toString() != key) return@postDelayed
                    softAuto(vu, 4000L) { if (onNoneIsHard()) sfHard() }
                } catch (e: Throwable) { LogStore.err("Player:autoSub2", e) }
            }, 1800L)
        } catch (e: Throwable) { LogStore.err("Player:autoSub", e) }
    }
    /** (v676) فيديو جاي من الموبايل (كاست): الموبايل بيجهّز ترجمته (ملف جنب الفيديو أو سوفت صب جواه) على سيرفر الكاست — نسحبها ونترجمها أوتوماتيك زي الفيديو المحلي.
     *  مفيش ملف ← لو المشغّل شايف مسار ترجمة جوه الفيديو يترجمه لحظيًا. (الهارد صب مش أوتوماتيك للكاست) */
    @Volatile private var castSubTried = false
    private fun castSubAuto() {
        try {
            val u = url ?: return
            if (remote || uri != null || !CastCache.isCast(u) || castSubTried || Cfg.str("auto_sub", "1") == "0") return
            castSubTried = true
            val subUrl = u.substringBefore('?').substringBeforeLast('/') + "/sub.srt"
            Thread {
                try {
                    var txt: String? = null
                    try {
                        val c = java.net.URL(subUrl).openConnection() as java.net.HttpURLConnection
                        c.connectTimeout = 5000; c.readTimeout = 70000
                        if (c.responseCode == 200) txt = c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }
                        c.disconnect()
                    } catch (e: Throwable) { LogStore.add("💬 كاست: مفيش ترجمة جاية من الموبايل (" + (e.message ?: e.javaClass.simpleName).take(60) + ")") }
                    val got = txt
                    if (!got.isNullOrBlank()) {
                        val f = java.io.File(cacheDir, "cast_sub.srt"); f.writeText(got, Charsets.UTF_8); castSubFile = f
                        LogStore.add("💬 كاست: ترجمة الموبايل وصلت (" + got.length + " حرف)")
                    } else {
                        var nat = sfNativeCount(); var waited = 0L
                        while (nat == 0 && waited < 4000L && !isFinishing && !isDestroyed) { try { Thread.sleep(500L) } catch (_: InterruptedException) { break }; waited += 500L; nat = sfNativeCount() }
                        if (nat == 0) { LogStore.add("💬 كاست: مفيش ترجمة (لا ملف ولا مسار)"); return@Thread }
                    }
                    val hasFile = castSubFile != null
                    runOnUiThread {
                        try {
                            if (isFinishing || isDestroyed || !::engine.isInitialized || engineStarted || engine.subs.isNotEmpty() || sfBusy.isNotEmpty()) return@runOnUiThread
                            noSub = false
                            sfNote(if (hasFile) "💬 لقيت ترجمة الفيديو من الموبايل — بترجمها تلقائي دلوقتي" else "💬 لقيت مسار ترجمة جوه الفيديو — بترجمه تلقائي دلوقتي")
                            sfRun("soft", autoEng(), null, if (hasFile) -2 else -1, true)
                        } catch (e: Throwable) { LogStore.err("Player:castSub2", e) }
                    }
                } catch (e: Throwable) { LogStore.err("Player:castSub", e) }
            }.also { it.isDaemon = true }.start()
        } catch (e: Throwable) { LogStore.err("Player:castSub0", e) }
    }
    @Volatile private var softAskedFor = ""
    private fun softGate(): Boolean {
        val vu = uri ?: return false
        val key = vu.toString()
        if (softAskedFor == key || !::engine.isInitialized || engineStarted || engine.subs.isNotEmpty() || sfBusy.isNotEmpty()) return false
        if (!hasSoftSubNow()) return false
        softAskedFor = key
        sfChoiceDialog(window.decorView)
        return true
    }
    /** (v670) أوتوماتيك لقى ترجمة مفيش حاجة تتعمل بيها لسه (المشغّل لسه بيحمّل مساراته): لما المسار يظهر نرجع نجرّب تاني مرة واحدة */
    @Volatile private var softLateKey = ""
    /** (v670) إشعار أطول من say() (2.3 ث) عشان تلحق تقراه على التلفزيون */
    private fun sfNote(m: String, ms: Long = 4500L) = runOnUiThread { try { Notice.show(this, m, ms) } catch (_: Throwable) {} }
    /** (v667) من غير أسئلة: فيه سوفت صب (مسار جوه الفيديو) يترجمه، مفيش ← يترجم ملف الترجمة اللي جنب الفيديو، مفيش خالص ← onNone (ترجمة الصوت)
     *  (v670) waitMs: لو مفيش حاجة لسه، نستنى المشغّل يخلّص تحميل مساراته (بيتأخر في الملفات الكبيرة/الشبكة) قبل ما نقول «مفيش» */
    private fun softAuto(vu: Uri, waitMs: Long = 0L, onNone: () -> Unit) {
        say("⏳ بفحص ترجمة الفيديو…")
        Thread {
            try {
                val side = sfSidecar()
                val emb = if (vu.scheme == "file" || vu.scheme == "content") SubFileTr.embeddedTracks(applicationContext, vu) else emptyList()
                var nat = if (emb.isEmpty()) sfNativeCount() else 0
                var waited = 0L
                while (side == null && emb.isEmpty() && nat == 0 && waited < waitMs && !isFinishing && !isDestroyed) {
                    try { Thread.sleep(500L) } catch (_: InterruptedException) { break }
                    waited += 500L
                    nat = sfNativeCount()
                }
                LogStore.add("💬 سوفت صب (أوتوماتيك): ملف جنب الفيديو=" + (side?.name ?: "لا") + " · مسارات جوه=" + emb.size + " · مسارات المشغّل=" + nat + (if (waited > 0) " · استنيت ${waited}ms" else ""))
                if (side == null && emb.isEmpty() && nat == 0) {
                    softLateKey = vu.toString()   // لو المسار ظهر بعد كده (onTracksChanged) هنجرّب تاني
                    sfNote("ℹ مفيش سوفت صب ولا ملف ترجمة للفيديو ده" + (if (onNoneIsHard()) " — هجرّب الهارد صب" else ""), 3800L)
                    runOnUiThread { onNone() }; return@Thread
                }
                val eng = try { TrWizard.savedPlan()?.let { if (it.offline) "google" else "gemini" } } catch (_: Throwable) { null } ?: if (TrWizard.hasGeminiKey()) "gemini" else "google"
                val what = if (side != null) "ملف الترجمة «" + side.name + "»" else if (emb.isNotEmpty()) "سوفت صب جوه الفيديو" else "ترجمة الفيديو الأصلية"
                sfNote("💬 لقيت $what — بترجمه تلقائي دلوقتي")
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (waited > 0L && engineStarted) return@runOnUiThread   // (v670) استنينا ومعاد ما إنت بدأت ترجمة الصوت بإيدك: ما نلخبطش
                    if (side != null) sfRun("soft", eng, null, -2, true)                     // (v676) ملف الترجمة اللي في الفولدر الأول (أي لغة) — بيترجم بس
                    else if (emb.isNotEmpty()) sfRun("soft", eng, null, emb[0].first, true)   // سوفت صب جوه الفيديو
                    else sfRun("soft", eng, null, -1, true)                                  // مسار المشغّل (لحظي لو مش بيتقري)
                }
            } catch (e: Throwable) { LogStore.err("Player:softAuto", e); runOnUiThread { onNone() } }
        }.also { it.isDaemon = true }.start()
    }
    private fun onNoneIsHard(): Boolean = Cfg.str("auto_hard", "1") != "0" && (try { TrWizard.hasGeminiKey() } catch (_: Throwable) { false })

    /** (v685) الأمر جه بعد اختيار «كمّل / من هنا / من الأول» (أو من الموبايل) — ما نسألش تاني */
    @Volatile private var trAsked = false
    @Volatile private var trHere = false
    private fun trChoiceDialog() {
        val n = try { engine.subs.size } catch (_: Throwable) { 0 }
        shDialog(320) { col, close ->   // (v1326) نفس شيت قايمة «ترجم» بدل الدايلوج القديم (GAlert) — آخر مسار كان بيفتح الشكل القديم
            col.addView(shHead("فيه ترجمة محفوظة للفيديو ده ($n جملة)", "اختار تكمّل إزاي"))
            col.addView(shRow("▶ كمّل الباقي (بيتخطّى المترجم)", "") { close(); trAsked = true; beginTranslate() })
            col.addView(shRow("📍 كمّل من مكان التشغيل الحالي", "") { close(); trAsked = true; trHere = true; beginTranslate() })
            col.addView(shRow("🔁 ترجم من الأول وجديد", "القديمة تتحفظ في 🗂") { close(); trFresh() })
        }
    }
    private fun studioAsk(vidNow: String) { studioAskOpen = false }   // (v1037) الاستوديو اتمسح — ما بقاش فيه مصدر ترجمة تاني يتسأل عليه
    /** (v1171) النوع المحفوظ (⚙ تفريغ/ترجمة) هو المرجع قبل أي «من الأول»: بيظبط علم التفريغ في المحركين لو اتلخبط (كان «من الأول وجديد» بيشغّل ترجمة والنوع تفريغ) وبيكتب النتيجة في اللوج */
    private fun syncTxFlag(why: String) {
        try {
            if (!::engine.isInitialized) return
            val want = trIsTx(); val had = engine.transOnly
            val keepSkip = !want && engine.baseSkipped   // «لغة الفيديو هي لغتك»: الأصل بيتعرض لوحده — ماننطّش عليه
            if (want != had && !keepSkip) {
                engine.transOnly = want
                try { fastTr?.transOnly = want } catch (_: Throwable) {}
                if (!want) try { if (::realEngine.isInitialized && !remote) realEngine.origView = false } catch (_: Throwable) {}
            }
            log("🧭 " + why + ": النوع المحفوظ=" + (if (want) "تفريغ" else "ترجمة") + " · علم التفريغ كان=" + had + (if (want != had && !keepSkip) " ← اتظبط" else "") + " · " + SongHint.state())
        } catch (e: Throwable) { LogStore.err("Player:syncTx", e) }
    }
    private fun trFresh() {
        if (!::engine.isInitialized) return
        resumePending = false; applyCard()
        Notice.show(this, "🔄 بترجم من الأول…", 2300L)
        engine.paused = true
        Thread {
            try { syncTxFlag("من الأول وجديد"); engine.redoAll(true) } catch (e: Throwable) { val m = "⚠ " + (e.message ?: e.toString()).take(120); log(m); runOnUiThread { say(m) }; engine.paused = false }
            dirty = true; curIdx = -2
            runOnUiThread { try { player.seekTo(0) } catch (_: Throwable) {}; trAsked = true; beginTranslate() }
        }.apply { isDaemon = true }.start()
    }
    private fun sfClearForBatch() {
        val u = uri?.toString() ?: ""
        try { if (::engine.isInitialized && engine.subs.isNotEmpty()) engine.saveVersion("ترجمة السوفت سب") } catch (_: Throwable) {}
        sfDoneUri = ""
        sfDoneLabel = ""
        sfShown = false
        try { sfStopLive() } catch (_: Throwable) {}
        sfHideNative = false
        preferNative = false
        nativeCue = ""
        curIdx = -2
        sfOffKey = u
        if (sfBatchFresh) {
            sfBatchFresh = false
            try { engine.redoAll(true) } catch (_: Throwable) {}
            trAsked = true
        }
        updateTr()
    }
    fun beginTranslate(auto: Boolean = false) {
        if (remote) { remoteBegin(auto); return }
        if (logArcPlay != null) { if (!auto) say("🗂 إنت بتشوف ترجمات لوج محفوظ — افتح الفيديو عادي لو عايز تترجم من جديد"); return }   // (v1167)
        val asked = trAsked; trAsked = false
        if (!auto && softGate()) return
        if (Cfg.str("mt_tr_mode", "") == "groq" && Cfg.str("groq_key", "").isBlank()) { Notice.show(this, "⚡ مفتاح Groq ناقص — ضيفه من الإعدادات ← 🔑 المفاتيح", 3600L); return }   // (v1369) بلوك التفريغ ⚡ جروك محتاج مفتاحه
        if (::engine.isInitialized && (sfShown || (sfDoneUri.isNotEmpty() && sfDoneUri == (uri?.toString() ?: "")))) sfClearForBatch() else sfBatchFresh = false
        if (Cfg.str("hard_mode", "0") == "1" && !SourceMode.keepHard()) {   // (v291) الهجين بهارد سب محتاج hard_mode=1 والصوت شغّال
            Cfg.put("hard_mode", "0")   // (v240) أي ترجمة صوتية بتطلّعك من وضع الهارد سب
            // (v261) ووقّف الوضع البصري بتاع الهارد سب كمان، وإلا بيفضل شغّال جنب الترجمة الصوتية
            try { if (::visual.isInitialized && visual.running) { visual.stop(); visOv.showBoxes(emptyList()); visAutoRun = false; visLog("👁 اتقفل — بدأت ترجمة صوتية") } } catch (_: Throwable) {}
        }
        try { val st = Throwable().stackTrace; LogStore.add("▶ طلب بدء الترجمة ← " + (st.getOrNull(1)?.let { it.methodName + ":" + it.lineNumber } ?: "?") + (if (autoTr) " (autotr)" else "")) } catch (_: Throwable) {}
        // (v467) اللغة الأساسية: البدء التلقائي بيحترمها، واليدوي (زرار «ترجم») بيفرض الترجمة ويلغي أي تخطي حصل في نفس الجلسة
        if (::engine.isInitialized) { engine.baseLangCode = Cfg.str("base_lang", "ar"); if (auto) engine.skipIfBaseLang = true else { engine.skipIfBaseLang = false; if (engine.baseSkipped) { engine.baseSkipped = false; engine.transOnly = false } } }
        if (::engine.isInitialized && !engineReady) { pendingBegin = true; LogStore.add("⏳ بدء الترجمة/التفريغ مؤجّل — بيانات الفيديو المحفوظة لسه بتتحمّل (هيبدأ لوحده)"); return }   // البيانات المحفوظة لسه بتتحمّل: هتبدأ لوحدها أول ما تخلص
        // (v1379 — بطلب علي: «عند ضغطة ترجم/تفريغ القديم يتفصل ومتظهرش متداخل مع الجديد») ترجمة مستوردة من ملف SRT جنب الفيديو مابتدمجش مع التفريغ/الترجمة الجديدة: نسخة تتحفظ في 🗂 والقايمة ترجع فاضية للجديد
        if (!auto && ::engine.isInitialized && !engineStarted && engine.imported && engine.subs.isNotEmpty()) {
            try {
                LogStore.add("🔀 ترجمة مستوردة من ملف — انفصلت قبل البدء (محفوظة في 🗂)")
                engine.saveVersion("قبل ترجمة جديدة — فصل الترجمة المستوردة من الملف")
                engine.redoAll(keep = false); engine.imported = false
                Notice.show(this, "🔀 الترجمة القديمة بتاعة الملف اتفصلت واتحفظت في 🗂 — الجديد هيشتغل لوحده", 3000L)
            } catch (e: Throwable) { LogStore.err("Player:detachImp", e) }
        }
        // (v203) لو الفيديو مترجم 100% (مثلًا بعد تحديث لينكه): مفيش ترجمة تاني، الترجمة المحفوظة شغّالة. ولو ناقص بيكمّل الباقي بس (المخلّص بيتخطّى)
        if (::engine.isInitialized && !engineStarted && !freshOnce && (try { engine.fullyDone() } catch (_: Throwable) { false })) {
            dismissStrip()
            if (noSub) { noSub = false; if (!ccOn) ccToggleFn() }
            // (v1126) تفريغ على فيديو متفرّغ/مترجم بالكامل: كان بيطلع «مترجم 100%» ويقف من غير ما يبان إنه بدأ — دلوقتي بيعرض النص الأصلي ويقول السبب صراحة
            if (engine.transOnly) {
                try { if (::realEngine.isInitialized && !remote) realEngine.origView = true } catch (_: Throwable) {}
                touchSubs()
                LogStore.add("✍ تفريغ: الفيديو متفرّغ بالكامل — اتعرض النص الأصلي واتفتح شيت الإعادة")
                Notice.show(this, "✍ الفيديو ده متفرّغ بالفعل 100% — عرضت النص الأصلي، اختار تعيد من فين", 4200L)
                if (!auto && !asked && !remote) h.post { try { trStartSheet(window.decorView) } catch (_: Throwable) {} }   // (v1379) الشيت الجديد   // (v1374 — بطلب علي) الإعادة متاحة في التفريغ برضه
                return
            }
            Notice.show(this, "✓ الفيديو ده مترجم 100% — اختار تعيد من فين", 3600L)
            if (!auto && !asked && !remote) h.post { try { trStartSheet(window.decorView) } catch (_: Throwable) {} }   // (v1379) الشيت الجديد   // (v1374 — بطلب علي) كانت بتتجاهل الدايلوج في التصميم الجديد فمابيحصلش حاجة
            return
        }
        // (v685) فيه ترجمة محفوظة ناقصة: اسأل (كمّل الباقي / من مكان التشغيل / من الأول وجديد) بدل ما يكمّل لوحده
        if (!auto && !asked && ::engine.isInitialized && !engineStarted && !freshOnce && engine.subs.isNotEmpty()) { LogStore.add("❔ فيه ترجمة محفوظة ناقصة — بسأل (كمّل/من مكان التشغيل/من الأول)"); trChoiceDialog(); return }
        dismissStrip()
        if (noSub) { noSub = false; if (!ccOn) ccToggleFn() }   // بدأت ترجمة: رجّع إظهار الترجمة
        // (v134) الترجمة تبدأ من المكان اللي واقف فيه في الفيديو (مش من الأول): المؤشر بيتحط على باتش الوقت الحالي، واللي اتترجم قبل كده بيتخطّى
        try { SongHint.begin(vid, notifTitle()) } catch (_: Throwable) {}   // (v1171) 🎵 كشف الأغنية من العنوان
        log("🧭 بدء: النوع المحفوظ=" + (if (trIsTx()) "تفريغ" else "ترجمة") + " · علم التفريغ في المحرك=" + (try { engine.transOnly } catch (_: Throwable) { false }) + " · " + SongHint.state())   // (v1171) عشان اللوج يقول أنهي نوع اشتغل فعلًا
        val wasFresh = freshOnce
        val posNow = try { player.currentPosition } catch (_: Throwable) { cur }
        if (posNow > 0) cur = posNow
        // (v228) المؤشر (من الأول / من مكان التشغيل) بيتظبط **قبل** ما خيط المحرك يشتغل — قبل كده كان بيتظبط بعده فالمحرك يلحق يبعت باتشات مكان التشغيل (30 و31 و32) وبعدين يرجع يبعت 1 و2 و3
        if (!wasFresh) {
            // (v224) الافتراضي: الترجمة بتبدأ من أول باتش ناقص في الفيديو من الأول (مش من مكان التشغيل اللي اتكمّل تلقائيًا). ممكن تتغيّر من قايمة 🔑
            if (trHere) { trHere = false; try { engine.translateFrom(posNow / 1000.0); log("▶ الترجمة من " + fmtMs(posNow)) } catch (e: Throwable) { LogStore.err("Player:trHere", e); say("⚠ تعذّر البدء من مكان التشغيل") } }
            else if (Cfg.str("trstart", "1") != "0") { try { engine.translateFromStart(); log("▶ الترجمة من أول الفيديو (أول جزء ناقص)") } catch (e: Throwable) { LogStore.err("Player:translateFromStart", e); say("⚠ تعذّر بدء الترجمة من أول الفيديو — جرّب ▶ ترجمة تاني") } }   // (v287)
            else if (posNow > 2000L) { try { engine.translateFrom(posNow / 1000.0); log("▶ الترجمة من " + fmtMs(posNow)) } catch (e: Throwable) { LogStore.err("Player:translateFrom", e); say("⚠ تعذّر بدء الترجمة من مكان التشغيل — جرّب ▶ ترجمة تاني") } }   // (v287)
        }
        studioLabel = ""
        // (v1139) ترجمة بالباتشات (من الصوت) بدأت: ملف الترجمة القديم / المسار الجاهز يتخفّى — كان بيظهر في أي لحظة الجملة الجديدة لسه ما وصلتش فيها. بيرجع لو اخترت الملف تاني من زرار الملفات
        if (!engineStarted && sfBusy.isEmpty() && !sfShown && uri != null) { sfHideNative = true; preferNative = false; sfKillNative(); curIdx = -2 }
        val bal = balancedPath()   // (دمج v1090) ⚖ المتوازن = المحرك البسيط FastTr
        if (!engineStarted) { engineStarted = true; engine.userPaused = false; if (!(bal && startBalanced())) startEngine() }
        else if (fastTr != null) {
            engine.userPaused = false
            val ft = fastTr
            if (!bal) { try { ft?.stop() } catch (_: Throwable) {}; fastTr = null; startEngine(); say("🔄 المحرك القديم كمّل بالوضع الجديد") }
            else if (ft != null) { ft.paused = false; if (!ft.running) ft.start() }
        }
        else {
            // (v399) استئناف: لو الوضع المحفوظ اتغيّر من ⚙/الإعدادات بعد الإيقاف بنطبّقه على المحرك قبل ما نكمّل (كان بيكمّل بالوضع القديم)
            try { TrWizard.savedPlan()?.let { sp -> if (appliedSig.isNotEmpty() && planSig(sp) != appliedSig) { LogStore.add("🔄 الوضع المحفوظ اختلف عن اللي شغّال — بطبّقه قبل الاستئناف"); runPlanCore(sp, false) } } } catch (e: Throwable) { LogStore.err("Player:resumeSync", e) }
            engine.userPaused = false
            engineKick()
        }
        updateTr()
    }
    @Volatile private var appliedSig = ""
    /** (v399) بصمة الخطة (الوضع + تفريغ بس + المحرك + الطريقة + البريست) عشان نعرف لو اتغيّرت */
    private fun planSig(pl: TrWizard.Plan) = listOf(pl.mode, pl.only, pl.engine, pl.method, pl.onlineId, pl.lang, pl.model, pl.dialect, pl.dia ?: "-", Cfg.str("tr_mode_id", "")).joinToString("|")
    /** (v399) لو المحرك كان خلّص ووقف (مثلًا «تفريغ بس» خلص) والوضع اتغيّر: يبدأ الحلقة من جديد عشان الباقي يتترجم */
    private fun engineKick() {
        if (logArcPlay != null) return   // (v1167) عرض لوج محفوظ: مفيش تشغيل للمحرك
        try { if (engineStarted && ::engine.isInitialized && engine.reopen()) { LogStore.add("♻ المحرك كان واقف — بشغّله تاني بالوضع الجديد"); startEngine() } } catch (e: Throwable) { LogStore.err("Player:engineKick", e) }
    }
    private var trChipV: View? = null
    private var trChipDismissed = false
    private fun updateTrChip() { trChipV?.visibility = if (engineStarted || trChipDismissed || pipNow()) View.GONE else View.VISIBLE }
    /** (v438) اسم موديل FreeLLM الشغّال على شريحة الترجمة */
    private fun modeChipTag(): String = if (Strict.freeText() || Strict.freeGem()) "🆓 " + FreeLlm.liveName().take(20) + " · " else ""
    fun pauseTranslate() { if (engineStarted) { engine.userPaused = true; try { fastTr?.paused = true } catch (_: Throwable) {}; updateTr() } }   // (دمج v1090)

    // ===== (دمج v1090) ⚖ متوازن = المحرك البسيط FastTr: كل مفتاح باتش، يفرّغه فيظهر على طول ثم يترجمه =====
    /** (v1141) نسبة الترجمة الحقيقية في كل الأوضاع: تغطية المحرك الأساسي، أو باتشات المتوازن (FastTr)، أو الباتشات اللي فيها جمل مترجمة فعلًا (الدقيق/المتوازن كانوا بيظهروا 0% رغم إن الجمل بتتعد) */
    private var covCacheAt = 0L
    private var covCacheV = 0
    private fun covPct(): Int {
        val now = System.currentTimeMillis()
        if (now - covCacheAt < 400L) return covCacheV
        val dur = durMs / 1000.0
        var v = try { PlayerLogic.percent(engine.coveredSec(), dur) } catch (_: Throwable) { 0 }
        try { fastTr?.takeIf { it.total > 0 }?.let { v = maxOf(v, it.pct) } } catch (_: Throwable) {}
        try {
            if (dur > 0 && v < 100) {
                val seen = HashSet<Int>()
                for (sb in engine.subs) if (sb.chunk >= 0 && sb.translated.isNotBlank() && sb.translated != sb.original) seen.add(sb.chunk)
                var sec = 0.0
                for (c in seen) { val a = engine.chunkStartSec(c); val b = minOf(engine.chunkStartSec(c + 1), dur); if (b > a) sec += b - a }
                v = maxOf(v, PlayerLogic.percent(sec, dur))
            }
        } catch (_: Throwable) {}
        covCacheAt = now; covCacheV = v
        return v
    }
    private var fastTr: FastTr? = null
    /** (دمج v1081) أزرق في شريط التقدم لكل الأوضاع: المحرك القديم (سريع/٧٥/٢٥/الأدق) + المحرك البسيط (متوازن) */
    private fun allSentSegs(): List<DoubleArray> {
        val a = try { engine.inflightSegs() } catch (_: Throwable) { emptyList() }
        val b = try { fastTr?.inflightSegs() ?: emptyList() } catch (_: Throwable) { emptyList() }
        return if (b.isEmpty()) a else if (a.isEmpty()) b else a + b
    }
    private fun balancedWanted(): Boolean = Cfg.bool("tr_bal", false)
    /** المتوازن على ترجمة جيميناي الصوتية العادية بس؛ باقي الأوضاع (٧٥/٢٥ · الأدق · ⚡ سريع · وشبر · تفريغ · سوفت صب · FreeLLM) على المحرك القديم زي ما هي */
    private fun balancedPath(): Boolean = try {
        !remote && balancedWanted() && Cfg.str("tr_engine", "gem") != "off" && !Offline.on() &&
            (Strict.id() == "g_wav" || Strict.id() == "g_aac") && SourceMode.get() == SourceMode.AUDIO && conf.keys.isNotEmpty()
    } catch (_: Throwable) { false }
    private fun startBalanced(): Boolean {
        val sp = spec ?: return false
        val hst: Host = guard ?: this
        val ft = FastTr(conf, { makeSource(sp) }, engine, hst, Cfg.str("conv_dialect", ""))
        // (v1119) تفريغ بس: المحرك البسيط بياخد العلم من الخطة اللي شغّلتها runPlanCore
        try { ft.transOnly = engine.transOnly } catch (_: Throwable) {}
        ft.oneKey = false   // (v1199) وضع «مفتاح واحد» اتشال من الواجهة — أي قيمة tr_one قديمة بتتجاهل
        ft.onState = { runOnUiThread { try { updateTr() } catch (_: Throwable) {} } }
        fastTr = ft
        val fresh = freshOnce; freshOnce = false
        if (fresh) { try { player.seekTo(0) } catch (_: Throwable) {}; cur = 0L }
        val balNote = if (ft.transOnly) "تفريغ بس — من غير ترجمة" else "تفريغ ثم ترجمة"
        log("⚖ متوازن — المحرك البسيط (كل مفتاح باتش: " + balNote + ")")
        Thread {
            if (fresh) try { engine.redoAll() } catch (e: Throwable) { val m = "⚠ " + (e.message ?: e.toString()).take(120); log(m); runOnUiThread { say(m) } }
            ft.start()
        }.apply { isDaemon = true }.start()
        return true
    }
    /** (v427) فيه محرك شغّال أو ترجمة موجودة؟ (الإعادة ملهاش معنى قبل كده) */
    private fun hasSubsNow(): Boolean = try { ::engine.isInitialized && (engineStarted || engine.subs.isNotEmpty()) } catch (_: Throwable) { false }
    /** صف الأزرار: [▶ ترجمة] (أحمر) قبل البداية — وبعد الضغط يختفي ويظهر مكانه [⏸ إيقاف مؤقت] [▶ إلغاء الإيقاف] */
    private fun makeTrRow(compact: Boolean): ViewGroup {
        // (v144) الشريط السفلي: صف بيلفّ لوحده (FlowRow) والعلامة جواه — مفيش عمود رأسي ولا عرض ثابت يخلي الأزرار تتقص أو الشريحة تعلق
        val row: ViewGroup = if (compact) FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
            else LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER }
        fun b(t: String, fill: Int, f: () -> Unit) = IconTextView(this).apply {
            text = t; textSize = if (compact) 12f else 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(ui.dp(if (compact) 10 else 8), 0, ui.dp(if (compact) 10 else 8), 0)
            background = ui.box(fill, 0x33FFFFFF, if (compact) 8 else 10); setOnClickListener { f() }
        }
        val hh = ui.dp(if (compact) 40 else 44); val m = ui.dp(if (compact) 3 else 4)
        fun lp(w: Int) = LinearLayout.LayoutParams(w, hh).apply { setMargins(m, m, m, m) }
        fun sq() = LinearLayout.LayoutParams(hh, hh).apply { setMargins(m, m, m, m) }   // (v440) زراير الأيقونة (⚙ 🔁 ⬇) مربعة بنفس الارتفاع بدل عرض بيتقص
        fun tidy(v: TextView) { v.setSingleLine(); v.includeFontPadding = false }
        val webVid = uri == null && (url != null || intent.getStringExtra("ytid") != null)   // (v378) يوتيوب: اللينك بيتجاب بعد بناء الشريط، فزرار الجودة كان بيختفي
        var dlRef: TextView? = null
        val dlB = b("⬇", 0xFF363636.toInt()) { dlRef?.let { downloadPopup(it) } }
        dlRef = dlB
        if (MtGlass.on() && MtLook.hideDl()) dlB.visibility = View.GONE   // (v899) إعداد MeeTube: إخفاء الزرار
        var trRef: TextView? = null
        val tr = b("▶ ترجم ▾", 0xFFE53935.toInt()) { trRef?.let { trMainClick(it) } }   // (v254) قبل البداية: الإعداد المحفوظ أو شاشة «طريقة الترجمة»
        trRef = tr
        tr.setOnLongClickListener { v -> translateMenu(v); true }   // (v1326) ضغطة مطوّلة على «ترجم»: شيت اختيار النظام
        var gearRef: TextView? = null
        val gearB = b("⚙", 0xFF363636.toInt()) { gearRef?.let { trSettings(it) } }   // (v1097) T2: إعدادات الترجمة + سلايدر سريع↔دقيق
        gearRef = gearB
        // (v1138) CC إظهار/إخفاء الترجمة — اتنقل هنا جنب زراير الترجمة: منوّر = الترجمة ظاهرة · خط مايل = مخفية
        val ccV = CcToggleView(this).apply {
            background = ui.box(0xFF363636.toInt(), 0x33FFFFFF, if (compact) 8 else 10); isClickable = true; isFocusable = true
            contentDescription = "إظهار/إخفاء الترجمة"; on = ccOn
        }
        ccV.setOnClickListener { ccToggleFn(); ccV.on = ccOn }
        val prevSync = ccSync
        ccSync = { prevSync?.invoke(); ccV.on = ccOn }
        // (v1137) ➕ استيراد ملف ترجمة من بره + CC برقم عدد ملفات الترجمة المتاحة (مرسومين باليد) — جنب زرار الترجمة/الإعدادات
        val plusB = PlusView(this).apply {
            background = ui.box(0xFF363636.toInt(), 0x33FFFFFF, if (compact) 8 else 10); isClickable = true; isFocusable = true
            contentDescription = "إضافة ملف ترجمة من بره"; setOnClickListener { subImport() }
        }
        val subB = SubBadgeView(this).apply {
            background = ui.box(0xFF363636.toInt(), 0x33FFFFFF, if (compact) 8 else 10); isClickable = true; isFocusable = true
            contentDescription = "ملفات الترجمة المتاحة"; visibility = View.GONE
        }
        subB.setOnClickListener { subSelectSheet(subB) }
        fun paintSub() {
            val n = if (uri != null) subCands().size else 0
            subB.count = n; subB.off = (uri?.let { SubSel.choice(this, it) == SubSel.NONE } ?: false) || sfHideNative
            subB.visibility = if (n > 0) View.VISIBLE else View.GONE
            ccV.on = ccOn   // (v1138)
            plusB.visibility = if (uri != null && !webVid) View.VISIBLE else View.GONE
        }
        var lgRef: TextView? = null
        val lgB = b("🌐", 0xFF363636.toInt()) { lgRef?.let { langPopup(it) } }
        lgRef = lgB
        trLgB = lgB
        fun qBtn(): TextView {
            val cur = qOpts.getOrNull(qCur)?.h ?: 0
            val v = b(if (cur > 0) "${cur}p ▾" else "الجودة ▾", 0xFF363636.toInt()) { }
            v.setOnClickListener { qualPopFn?.invoke(v) }
            qualRowRefs.add(v); return v
        }
        fun aBtn(): TextView {   // (v388) مربع لغة الصوت: بيظهر بس لو الفيديو له أكتر من لغة
            val v = b("🔊 ▾", 0xFF363636.toInt()) { }
            v.setOnClickListener { audPopFn?.invoke(v) }
            audRowRefs.add(v); v.visibility = View.GONE; paintAud(); return v
        }
        if (compact) {
            // الشريط السفلي: شريحة صغيرة بنسبة الترجمة (⏳ 19%) — دوس عليها تتفرد: إيقاف/استئناف + اللغة، وبتتلم لوحدها بعد 5 ثواني
            var chipRef: TextView? = null
            val chipB = b("▶ ترجم ▾", 0xFFE53935.toInt()) { chipRef?.let { trMainClick(it) } }   // (v415) زرار واحد بقايمة منسدلة
            chipRef = chipB
            chipB.setOnLongClickListener { v -> translateMenu(v); true }   // (v1326) ضغطة مطوّلة على «ترجم»: شيت اختيار النظام
            // (v1137) ⏸/▶ مرسوم باليد (PausePlayView) — الإيموجي/الأيقونة كانت بتظهر شفافة فاضية
            val pz = PausePlayView(this).apply { playing = true; background = ui.box(0xFF454545.toInt(), 0x33FFFFFF, 8); isClickable = true; isFocusable = true; contentDescription = "إيقاف مؤقت للترجمة"
                setOnClickListener { if (::engine.isInitialized && engine.userPaused) beginTranslate() else pauseTranslate() } }   // (v438) إيقاف مؤقت / كمّل ظاهر جنب «ترجم» (كان جوه القايمة بس)
            val cx = stopBtn(8)   // (v741) مربع أبيض مرسوم باليد جوه الأحمر (كان بيختفي)
            tidy(chipB); dlB.setPadding(0, 0, 0, 0)
            // (v1097) T2: «ترجم/النسبة» و⚙ جوه حاوية واحدة — الصف بيلفّ (FlowRow) فمنع ⚙ إنه ينزل سطر لوحده لما نص الشريحة يطول وهي شغّالة
            val chipGear = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            chipGear.addView(chipB, lp(-2))   // (v415) زرار «ترجم» الواحد
            gearB.setPadding(0, 0, 0, 0); gearB.textSize = 17f; chipGear.addView(gearB, sq())
            chipGear.addView(ccV, sq()); chipGear.addView(plusB, sq()); chipGear.addView(subB, sq())   // (v1137) (v1138) CC
            row.addView(chipGear, LinearLayout.LayoutParams(-2, -2))
            row.addView(pz, sq())
            row.addView(cx, sq())
            if (webVid) { row.addView(qBtn(), lp(-2)); row.addView(aBtn(), lp(-2)); row.addView(dlB, sq()) }
            trUpdaters.add {
                val paused = ::engine.isInitialized && engine.userPaused
                val started = engineStarted
                pz.visibility = if (started) View.VISIBLE else View.GONE
                cx.visibility = if (started) View.VISIBLE else View.GONE
                pz.playing = !paused
                pz.background = ui.box(if (paused) 0xFF2E7D32.toInt() else 0xFF454545.toInt(), 0x33FFFFFF, 8)
                paintSub()   // (v1137)
                gearB.visibility = View.VISIBLE   // (v1097) ⚙ ظاهر دايمًا جنب «ترجم» حتى والترجمة شغّالة
                lgB.visibility = if (caps().dialect) View.VISIBLE else View.GONE   // (v444) بس في الأوضاع اللي فيها لهجات
                if (!started) {
                    val tx = trIsTx()
                    val soft = hasSoftSubNow()
                    chipB.text = if (sfBusy.isNotEmpty()) sfChip() else if (sfLive.isNotEmpty()) "💬 ترجمة لحظية ▾" else if (soft) "💬 سوفت سب · " + modeShort() + " ▾" else (if (tx) "" else "▶ ترجم · ") + modeShort() + " ▾"   // (v1376) modeShort في التفريغ بيبدأ بـ«✍ تفريغ» أصلًا — كانت بتطلع «تفريغ · تفريغ»
                    val aur = Design.isNew() && !soft && !tx
                    chipB.background = if (aur) auroraPill(12) else ui.box(if (soft) 0xFF2E7D32.toInt() else if (tx) 0xFF2A8C8C.toInt() else 0xFFE53935.toInt(), 0x33FFFFFF, 12)
                    if (Design.isNew()) chipB.setTextColor(if (aur && !ui.th.isLight) 0xFF0B0A18.toInt() else Color.WHITE)
                }
                else {
                    LoadUi.set(chipB, (Offline.liveShort()?.let { "$it · " } ?: modeChipTag()) + (if (paused) "⏸ " else if (trPct >= 100) "✅ " else "⏳ ") + trPct + "%" + dotsNow() + " ▾")
                    chipB.background = ui.box(if (paused) 0xFF8D6E00.toInt() else if (trPct >= 100) 0xFF2E7D32.toInt() else 0xFF2A8C8C.toInt(), 0x33FFFFFF, 12)
                    if (Design.isNew()) chipB.setTextColor(Color.WHITE)
                }
            }
        } else {
            val pz2 = PausePlayView(this).apply { playing = true; background = ui.box(0xFF454545.toInt(), 0x33FFFFFF, 10); isClickable = true; isFocusable = true; contentDescription = "إيقاف مؤقت للترجمة"
                setOnClickListener { if (::engine.isInitialized && engine.userPaused) beginTranslate() else pauseTranslate() } }   // (v438) (v1137) مرسوم باليد
            val cx2 = stopBtn(10)   // (v741)
            tidy(tr); dlB.setPadding(0, 0, 0, 0)
            row.addView(tr, lp(0).apply { width = 0; weight = 3.6f })   // (v415) زرار «ترجم» الواحد
            gearB.setPadding(0, 0, 0, 0); gearB.textSize = 19f; row.addView(gearB, sq())   // (v1097) T2
            row.addView(ccV, sq()); row.addView(plusB, sq()); row.addView(subB, sq())   // (v1137) (v1138) CC
            row.addView(pz2, sq())
            row.addView(cx2, sq())
            if (webVid) { row.addView(qBtn(), lp(0).apply { width = 0; weight = 1.2f }); row.addView(aBtn(), lp(0).apply { width = 0; weight = 0.9f }); row.addView(dlB, sq()) }
            trUpdaters.add {
                val paused = ::engine.isInitialized && engine.userPaused
                tr.visibility = View.VISIBLE; gearB.visibility = View.VISIBLE   // (v1097)
                val tx = trIsTx()
                val soft = hasSoftSubNow()
                LoadUi.set(tr, if (!engineStarted) (if (sfBusy.isNotEmpty()) sfChip() else if (sfLive.isNotEmpty()) "💬 ترجمة لحظية ▾" else if (soft) "💬 سوفت سب · " + modeShort() + " ▾" else (if (tx) "" else "▶ ترجم · ") + modeShort() + " ▾") else (Offline.liveShort()?.let { "$it · " } ?: modeChipTag()) + (if (paused) "⏸ " else if (trPct >= 100) "✅ " else "⏳ ") + trPct + "%" + dotsNow() + " ▾")   // (v1376) نفس إصلاح تكرار «تفريغ · تفريغ»
                val aur2 = Design.isNew() && !engineStarted && !soft && !tx
                tr.background = if (aur2) auroraPill(10) else ui.box(if (!engineStarted) (if (soft) 0xFF2E7D32.toInt() else if (tx) 0xFF2A8C8C.toInt() else 0xFFE53935.toInt()) else (if (paused) 0xFF8D6E00.toInt() else if (trPct >= 100) 0xFF2E7D32.toInt() else 0xFF2A8C8C.toInt()), 0x33FFFFFF, 10)
                if (Design.isNew()) tr.setTextColor(if (aur2 && !ui.th.isLight) 0xFF0B0A18.toInt() else Color.WHITE)
                pz2.visibility = if (engineStarted) View.VISIBLE else View.GONE
                cx2.visibility = if (engineStarted) View.VISIBLE else View.GONE
                pz2.playing = !paused
                paintSub()   // (v1137)
                pz2.background = ui.box(if (paused) 0xFF2E7D32.toInt() else 0xFF454545.toInt(), 0x33FFFFFF, 10)
            }
        }
        updateTr()
        if (!webVid) return row
        // (v134) علامة صغيرة فوق زرار الترجمة: الجودة + الحجم (بتظهر لما الفيديو له جودة واحدة بس) — دوس عليها تعرف الحجم
        val badge = IconTextView(this).apply {
            textSize = 10.5f; setTextColor(0xFFFF6B6B.toInt()); gravity = Gravity.CENTER; visibility = View.GONE
            setPadding(ui.dp(10), ui.dp(2), ui.dp(10), ui.dp(2)); background = ui.box(0xCC141418.toInt(), 0x33FFFFFF, 10)
            setOnClickListener { refreshSize(true) }
        }
        qBadges.add(badge)
        if (compact) {
            // (v144) في الشريط السفلي العلامة بقت آخر عنصر في نفس الصف (مش فوق الشريحة) — فضغطة الشريحة بتفرد إعادة/اللغة عادي
            row.addView(badge, LinearLayout.LayoutParams(-2, ui.dp(28)).apply { setMargins(m, m, m, m) })
            paintQual()
            return row
        }
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_HORIZONTAL }
        wrap.addView(badge, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, ui.dp(2), 0, 0) })
        wrap.addView(row, LinearLayout.LayoutParams(-1, -2))
        paintQual()
        return wrap
    }
    private val hideCard = Runnable { resumePending = false; applyCard() }
    private fun fmtMS(sec: Double): String { val s = sec.toInt(); return "%d:%02d".format(s / 60, s % 60) }

    private var batchPanel: View? = null
    lateinit var batchBtn: View
    lateinit var tvBtn: TextView   // (v619) 📺 ابعت الفيديو للتلفزيون القريب من نفس الثانية — بيظهر مع الشريط (زي 👁) لو في تلفزيون قريب ومش متصل
    private val tvNearCb: () -> Unit = { try { applyChromeFn() } catch (_: Throwable) {} }
    private lateinit var audBtn: View   // (v343) 🎧 حوّل لصوت
    private lateinit var modePill: TextView   // (v459) كبسولة عريضة لليوتيوب: «🎧 وضع الصوت / 🎬 وضع الفيديو» — تبديل جوه المشغّل نفسه · (v467) مكانها بقى جوّه صف الكبسولات جنب 👁 مش عايمة لوحدها
    private var badgeRowRef: LinearLayout? = null   // (v467) صف الكبسولات (🔊/👁/النت) — الكبسولة بتتنقل له أول ما يتبني
    private var ytAudioOnly = false
    private var ytMerged: Boolean? = null   // (v1150) المصدر الحالي = فيديو + صوت منفصلين (Merging)؟ null = مش معروف (بنستنتج من aurl)
    private var audioHandoff: Intent? = null
    fun closeBatchPanel() {
        batchPanel?.let { p -> try { (p.parent as? ViewGroup)?.removeView(p) } catch (e: Exception) { LogStore.err("Main:938", e) } }
        batchPanel = null
        if (::batchBtn.isInitialized) fadeTo(batchBtn, REST_A)
    }
    /** زرار 🔄 العايم: لوحة صغيرة فوق الفيديو — «من الأول خالص» + باتشات الفيديو (📍 يوديك للباتش) + «ابدأ من هنا» / «ده بس» */
    fun batchDialog() {
        if (batchPanel != null) { closeBatchPanel(); return }
        val bl = engine.batches()
        if (bl.isEmpty()) { Notice.show(this, ("مدة الفيديو لسه مش معروفة — استنى ثانية وجرّب تاني").toString(), 2300L); return }
        val curC = try { engine.chunkOfSec(player.currentPosition / 1000.0) } catch (_: Exception) { 0 }
        var sel = curC
        val rows = ArrayList<Pair<Int, LinearLayout>>()
        val selTv = ui.text("", 12f, th.primary, true)
        // الشغل التقيل (مسح + حفظ على القرص) بعيد عن الـ UI thread — ده اللي كان بيهنّج ويقفل البرنامج
        fun go(label: String, work: () -> Unit) {
            closeBatchPanel(); resumePending = false; applyCard()
            Notice.show(this, (label).toString(), 2300L)
            engine.paused = true
            Thread {
                try { work() } catch (e: Throwable) { val m = "⚠ " + (e.message ?: e.toString()).take(120); log(m); runOnUiThread { say(m) }; engine.paused = false }
                dirty = true; curIdx = -2
                runOnUiThread { trAsked = true; beginTranslate() }
            }.apply { isDaemon = true }.start()
        }
        fun paint() {
            rows.forEach { (i, r) -> r.background = ui.box(if (i == sel) (th.primary and 0x00FFFFFF) or 0x33000000 else th.card, th.border, 8) }
            selTv.text = "المختار: باتش ${sel + 1}  (${fmtMS(bl[sel.coerceIn(0, bl.size - 1)].start)})"
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(10)); background = glassPanelBg(); elevation = ui.dp(10).toFloat()
            isClickable = true
        }
        val head = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ui.text("🔄 ترجم باتش معين", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(IconTextView(this).apply { text = "✕"; textSize = 18f; setTextColor(Color.WHITE); setPadding(ui.dp(10), ui.dp(2), ui.dp(4), ui.dp(2)); setOnClickListener { closeBatchPanel() } })
        col.addView(head)
        // (v468) فخ redoAll: اختيار صريح في لوحة الباتشات بدل الافتراضي الصامت keep=true — بيشارك redoKeep مع قايمة 🔁
        fun keepVal() = if (redoKeep) "✅ احتفظ" else "🗑 امسح"
        val kb = shRow("💾 القديمة (في 🗂)", keepVal()) { }
        kb.setOnClickListener { redoKeep = !redoKeep; (kb.getChildAt(1) as? TextView)?.text = keepVal() }
        col.addView(kb)
        col.addView(shBtn("🔁 ترجم من الأول خالص", SH_BLUE) { val k = redoKeep; player.seekTo(0); go("🔄 بترجم من الأول…") { syncTxFlag("ترجم من الأول خالص"); engine.redoAll(k) } }, LinearLayout.LayoutParams(-1, ui.dp(44)).apply { setMargins(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) })
        col.addView(ui.text("📍 دوس على الباتش يوديك له، وبعدين اختار ابدأ", 11f, th.muted))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        var curRow: View? = null
        for (b in bl) {
            val i = b.idx
            val row = LinearLayout(this).apply {
                layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(8), ui.dp(7), ui.dp(8), ui.dp(7))
                addView(IconTextView(this@PlayerActivity).apply { text = "📍"; textSize = 16f; setPadding(0, 0, ui.dp(8), 0) })
                addView(ui.text("باتش ${i + 1} · ${fmtMS(b.start)}–${fmtMS(b.end)} ${b.mark}" + (if (b.count > 0) " · ${b.count} جملة" else "") + (if (i == curC) "  ◀ هنا" else ""), 12f, th.text, i == curC), LinearLayout.LayoutParams(0, -2, 1f))
                setOnClickListener { sel = i; try { player.seekTo((engine.chunkStartSec(i) * 1000).toLong()) } catch (e: Exception) { LogStore.err("Main:985", e) }; paint() }
            }
            rows.add(i to row); list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(3) })
            if (i == curC) curRow = row
        }
        val content = findViewById<ViewGroup>(android.R.id.content)
        val maxH = (content.height * 0.26).toInt().coerceAtLeast(ui.dp(84))
        val sv = ScrollView(this).apply { addView(list) }
        col.addView(sv, LinearLayout.LayoutParams(-1, maxH))
        col.addView(selTv)
        col.addView(shDuo(
            shBtn("▶ ابدأ من الباتش ده", SH_BLUE) { val i = sel; val k = redoKeep; go("🔄 بترجم من باتش ${i + 1} وبعده…") { engine.redoFrom(i, k) } },
            shBtn("☝ ده بس", SH_GRAY) { val i = sel; val k = redoKeep; go("🔄 بترجم باتش ${i + 1} لوحده…") { engine.redoOnly(i, k) } }))
        paint()
        val w = minOf(ui.dp(250), content.width - ui.dp(24)).coerceAtLeast(ui.dp(200))
        // شفافة بتغطي الشاشة: أي ضغطة بره القايمة بتقفلها، والفيديو باين وراها. القايمة صغيرة على الحافة (مش نص الشاشة)
        val scrim = FrameLayout(this).apply { isClickable = true; setOnClickListener { closeBatchPanel() } }
        scrim.addView(col, FrameLayout.LayoutParams(w, -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { setMargins(0, ui.dp(8), ui.dp(70), ui.dp(8)) })   // RIGHT صريحة (END كانت بتتقلب لشمال جنب اللوج) + جنب زرار 🔄 مش فوقه
        content.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        batchPanel = scrim
        fadeTo(batchBtn, 1f)
        curRow?.let { r -> sv.post { sv.scrollTo(0, (r.top - ui.dp(40)).coerceAtLeast(0)) } }
    }

    /** نفس شغل «go» بتاع لوحة الباتشات: يمسح ويبدأ من جديد بعيد عن الـ UI thread */
    private fun redoGo(label: String, work: () -> Unit) {
        closeBatchPanel(); resumePending = false; applyCard()
        Notice.show(this, (label).toString(), 2300L)
        engine.paused = true
        Thread {
            try { work() } catch (e: Throwable) { val m = "⚠ " + (e.message ?: e.toString()).take(120); log(m); runOnUiThread { say(m) }; engine.paused = false }
            dirty = true; curIdx = -2
            runOnUiThread { trAsked = true; beginTranslate() }
        }.apply { isDaemon = true }.start()
    }
    private var trMenuPop: android.widget.PopupWindow? = null
    /** (v415) زرار «ترجم» الواحد: قايمة منسدلة بالخيارات حسب الحالة + تقدم Whisper الحقيقي فوقها */
    /** (v739) ⏹ إلغاء الترجمة خالص (مش إيقاف مؤقت): بيقفل المحرك واللي اتترجم قبل كده بيفضل محفوظ ومعروض، والشريحة ترجع «▶ ترجم» */
    fun cancelTranslate(onDone: (() -> Unit)? = null) {
        if (remote || !::engine.isInitialized || !engineStarted) return
        val eng = realEngine
        val ftWait = fastTr   // (دمج v1090)
        engineStarted = false; updateTr()
        say("⏹ بلغي الترجمة…")
        val pctAtCancel = trPct
        Thread {
            try { if (pctAtCancel < 100) eng.restoreBackup() } catch (_: Throwable) {}
            try { retireEngine() } catch (_: Throwable) {}
            try { ftWait?.awaitDone(4000L) } catch (_: Throwable) {}
            if (ftWait == null) try { eng.awaitStopped(4000L) } catch (_: Throwable) {}   // المحرك بيحفظ اللي اتترجم وهو بيقفل — نستنى يخلص قبل ما نحمّل المحفوظ تاني
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                try { initEngine() } catch (e: Throwable) { LogStore.err("Player:cancelTr", e) }
                engineStarted = false; updateTr()
                say("⏹ الترجمة اتلغت — اللي اتترجم محفوظ، و«▶ ترجم» تبدأ تاني")
                try { onDone?.invoke() } catch (e: Throwable) { LogStore.err("Player:cancelDone", e) }
            }
        }.apply { isDaemon = true }.start()
    }
    private fun cancelDialog() {
        shConfirm("⏹ إلغاء الترجمة؟", "هيوقف الترجمة خالص (مش مؤقت). اللي اتترجم لحد دلوقتي هيفضل محفوظ، وتقدر تبدأ تاني بـ «▶ ترجم».",
            listOf(ShBtn("⏹ إلغاء الترجمة", SH_RED) { cancelTranslate() }, ShBtn("لأ، كمّل", SH_GRAY) { }))
    }

    /** (v739) وشبر tiny/base ضعاف في الياباني/الكوري/الصيني (بيطلّع كلام غلط ويكرر نفس الكلمة) وفي العربي/الهندي/الفارسي/الأوردو، وكشف اللغة التلقائي معاهم بيغلط.
     *  بيرجّع (نص التحذير، id الموديل الأنسب) أو null لو الموديل مناسب للغة */
    private fun whisperAdvice(lang: String, m: Offline.Model = Offline.model()): Pair<String, String>? {
        val weak = m.id == "tiny" || m.id == "base"
        if (!weak) return null
        val nm = TrWizard.langLabel(lang)
        return when (lang) {
            "ja", "ko", "zh" -> "موديل " + m.id + " ضعيف جدًا في اللغة " + nm + " — بيسمع غلط وبيكرر نفس الكلمة (زي «يلا يلا يلا…»). الأنسب large-v3-turbo، وأقل حاجة small." to "turbo"
            "ar", "hi", "fa", "ur" -> "موديل " + m.id + " ضعيف في اللغة " + nm + " — الأنسب small أو أكبر." to "small"
            "" -> "اللغة «تلقائي» مع " + m.id + " بتغلط في كشف لغة الفيديو (ممكن يفهم الياباني إنجليزي ويهلوس). اختار لغة الفيديو بإيدك، أو استخدم small." to "small"
            else -> null
        }
    }
    private fun askWhisperAdvice(lang: String, m: Offline.Model, adv: Pair<String, String>, onKeep: () -> Unit, onSwitch: (Offline.Model) -> Unit, onCancel: () -> Unit = {}) {
        val rec = Offline.models.first { it.id == adv.second }
        val alt = Offline.models.first { it.id == "small" }
        val btns = ArrayList<ShBtn>()
        btns.add(ShBtn("غيّر لـ " + rec.label, SH_BLUE) { onSwitch(rec) })
        if (rec.id != "small" && m.id != "small") btns.add(ShBtn("small (أخف)", SH_GRAY) { onSwitch(alt) })
        btns.add(ShBtn("كمّل بـ " + m.label, SH_GRAY) { onKeep() })
        shConfirm("⚠ موديل وشبر مش مناسب للغة دي", adv.first + "\n\nالمقترح: " + rec.label + (if (Offline.downloaded(rec)) "" else " (⬇ ~" + rec.approxMb + " ميجا، مرة واحدة)"), btns, onCancel)
    }

    // ===================== (v740) نظام تصميم موحّد لقوايم الترجمة (شيت) =====================
    // كل القوايم (ترجم · الإعدادات · الإعادة) بتتبني من نفس القطع: عنوان · قسم · صف · زرار · شريحة، ونفس مكان/شكل الظهور
    /** (v749) تلفزيون: حلقة تركيز على العنصر بنفسه (من غير الاعتماد على مراقب التركيز العام) */
    private fun <T : View> tvRing(v: T): T {
        try {
            if (DeviceUi.isRemote(this)) TvFocus.selfRing(v, Glass.theme().primary, resources.displayMetrics.density)   // (v803) حلقة قوية + المراقب العام يسيبها
        } catch (_: Throwable) { }
        return v
    }
    private fun shHead(title: String, sub: String = ""): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(6))
        addView(ui.text(title, 14f, Color.WHITE, true))
        if (sub.isNotBlank()) addView(ui.text(sub, 11.5f, 0xFF9AA0A6.toInt()).apply { setPadding(0, ui.dp(2), 0, 0) })
    }
    private fun shSection(t: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        addView(View(this@PlayerActivity).apply { setBackgroundColor(0x22FFFFFF) }, LinearLayout.LayoutParams(-1, 1).apply { setMargins(ui.dp(8), ui.dp(8), ui.dp(8), 0) })
        addView(ui.text(t, 11.5f, 0xFF9AA0A6.toInt(), true).apply { setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(2)) })
    }
    private fun shNote(t: String, warn: Boolean = false): View = ui.text((if (warn) "⚠ " else "") + t, 11f, if (warn) 0xFFFFB74D.toInt() else 0xFF9AA0A6.toInt()).apply { setPadding(ui.dp(10), ui.dp(2), ui.dp(10), ui.dp(4)) }
    /** صف: العنوان يمين، القيمة الحالية (اختياري) وسهم ‹ شمال */
    private fun shRow(title: String, value: String = "", chev: Boolean = false, warn: Boolean = false, f: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(ui.dp(12), 0, ui.dp(12), 0); background = ui.box(0x14FFFFFF, 0x22FFFFFF, 12)
        addView(ui.text(title, 13.5f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (value.isNotBlank()) addView(ui.text(value, 12f, if (warn) 0xFFFFB74D.toInt() else 0xFF9AA0A6.toInt()).apply { setPadding(ui.dp(8), 0, 0, 0) })
        if (chev) addView(ui.text("‹", 18f, 0xFF9AA0A6.toInt()).apply { setPadding(ui.dp(8), 0, 0, 0) })
        isFocusable = true; setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, ui.dp(46)).apply { setMargins(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) }
        tvRing(this)
    }
    /** زرار إجراء ملوّن (بيتحط اتنين جنب بعض بـ shDuo) */
    private fun shBtn(t: String, fill: Int, f: () -> Unit): View = ui.text(t, 13.5f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; isFocusable = true; background = ui.box(fill, 0x33FFFFFF, 12); setOnClickListener { f() }
        tvRing(this)
    }
    private fun shDuo(a: View, b: View): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
        val lp = { LinearLayout.LayoutParams(0, ui.dp(46), 1f).apply { setMargins(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) } }
        addView(a, lp()); addView(b, lp())
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }
    /** شريحة اختيار: المختار أزرق */
    private fun shChip(label: String, on: Boolean = false, f: () -> Unit): View = ui.text(label, 12.5f, Color.WHITE, on).apply {
        gravity = Gravity.CENTER; isFocusable = true; setPadding(ui.dp(12), 0, ui.dp(12), 0)
        background = ui.box(if (on) 0xFF8B6B50.toInt() else 0x1AFFFFFF, if (on) 0x55FFFFFF else 0x22FFFFFF, 10); setOnClickListener { f() }
        tvRing(this)
    }
    private fun shChipLp() = ViewGroup.MarginLayoutParams(-2, ui.dp(36)).apply { setMargins(ui.dp(3), ui.dp(2), ui.dp(3), ui.dp(2)) }
    private fun shFlow() = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
    /** بيعرض الشيت فوق/تحت الزرار حسب المساحة (مكان واحد لكل القوايم). onDismiss بيتنادى بالنافذة عشان صاحبها يفضّي مرجعه */
    // (v999 ملاحظة 5) footer = صف ثابت برّه السكرول (زي صف «طبّق» في اللهجة والأسلوب) — بيتقاس وبيتخصم من الارتفاع المتاح؛ null = زي الأول بالظبط
    private fun showSheet(anchor: View, col: LinearLayout, maxDp: Int, tag: String, footer: View? = null, onDismiss: (android.widget.PopupWindow) -> Unit): android.widget.PopupWindow {
        col.orientation = LinearLayout.VERTICAL; col.layoutDirection = View.LAYOUT_DIRECTION_RTL
        col.setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6))
        // (v999 ملاحظة 5) مع فوتر: الخلفية على الحاوية الخارجية بس (لو فضلت على العمود كمان هيبقى فيه خط فاصل + استدارة في نص النافذة)
        if (footer == null) col.background = glassPanelBg()
        val scroll = android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = true; addView(col) }
        val popW = minOf(resources.displayMetrics.widthPixels - ui.dp(24), ui.dp(maxDp))
        col.measure(View.MeasureSpec.makeMeasureSpec(popW, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED)
        val footH = if (footer == null) {
            0
        } else {
            footer.measure(View.MeasureSpec.makeMeasureSpec(popW, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
            footer.measuredHeight
        }
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val up = loc[1] > resources.displayMetrics.heightPixels / 2
        val avail = (if (up) loc[1] - ui.dp(12) else resources.displayMetrics.heightPixels - loc[1] - anchor.height - ui.dp(12)).coerceAtLeast(ui.dp(120))
        val popH = minOf(col.measuredHeight + footH, avail)
        val content: View = if (footer == null) {
            scroll
        } else {
            LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = glassPanelBg()
                addView(scroll, LinearLayout.LayoutParams(-1, (popH - footH).coerceAtLeast(ui.dp(40))))
                addView(footer, LinearLayout.LayoutParams(-1, -2))
            }
        }
        val pw = TvFocus.pop(this@PlayerActivity, content, popW, popH, true)
        Motion.popIn(content, up)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
        pw.isOutsideTouchable = true
        pw.setOnDismissListener { onDismiss(pw); showChrome() }
        try { if (up) pw.showAsDropDown(anchor, 0, -(anchor.height + popH + ui.dp(2))) else pw.showAsDropDown(anchor, 0, ui.dp(2)) } catch (e: Throwable) { LogStore.err("Player:$tag", e) }
        h.removeCallbacks(hideChrome); showChrome(); h.removeCallbacks(hideChrome)
        return pw
    }

    // ===================== (v741) نوافذ حوار بنفس شكل الشيت (بدل AlertDialog القديم) =====================
    private val SH_BLUE = 0xFF8B6B50.toInt(); private val SH_RED = 0xFFB71C1C.toInt(); private val SH_GRAY = 0xFF454545.toInt()
    private class ShBtn(val t: String, val fill: Int, val f: () -> Unit)
    private fun shDialog(maxDp: Int = 330, onCancel: () -> Unit = {}, build: (LinearLayout, () -> Unit) -> Unit): android.app.Dialog {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(8), ui.dp(8), ui.dp(8), ui.dp(8)); background = glassPanelBg()
        }
        var done = false
        val close = { done = true; try { dlg.dismiss() } catch (_: Throwable) { } }
        build(col, close)
        dlg.setContentView(android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(col) })
        dlg.setOnCancelListener { if (!done) { done = true; try { onCancel() } catch (e: Throwable) { LogStore.err("Player:shDlgCancel", e) } } }
        val w = minOf(resources.displayMetrics.widthPixels - ui.dp(32), ui.dp(maxDp))
        dlg.window?.let { win ->
            win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
            win.setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            win.setDimAmount(0.55f)
            win.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        try { TvFocus.attachDialog(this, dlg, Glass.theme().primary) } catch (_: Throwable) { }   // (v749) تلفزيون: حلقة تركيز + أول زرار ياخد التركيز
        try { if (!isFinishing && !isDestroyed) dlg.show() } catch (e: Throwable) { LogStore.err("Player:shDialog", e) }
        return dlg
    }
    /** عنوان + رسالة + أزرار كبيرة تحت بعض (الزرار بيقفل النافذة وبعدين بينفّذ) */
    private fun shConfirm(title: String, msg: String, btns: List<ShBtn>, onCancel: () -> Unit = {}): android.app.Dialog =
        shDialog(330, onCancel) { col, close ->
            col.addView(shHead(title))
            if (msg.isNotBlank()) col.addView(ui.text(msg, 12.5f, 0xFFD0D4D9.toInt()).apply { setPadding(ui.dp(10), ui.dp(2), ui.dp(10), ui.dp(10)); setLineSpacing(0f, 1.15f) })
            for (bt in btns) col.addView(shBtn(bt.t, bt.fill) { close(); bt.f() }, LinearLayout.LayoutParams(-1, ui.dp(46)).apply { setMargins(ui.dp(4), ui.dp(3), ui.dp(4), ui.dp(3)) })
        }
    private fun shField(hint: String, value: String): android.widget.EditText = android.widget.EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine(true); textSize = 13f
        setTextColor(Color.WHITE); setHintTextColor(0xFF7F8790.toInt()); layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(ui.dp(12), 0, ui.dp(12), 0); background = ui.box(0x1AFFFFFF, 0x33FFFFFF, 10)
        layoutParams = LinearLayout.LayoutParams(-1, ui.dp(44)).apply { setMargins(ui.dp(4), ui.dp(3), ui.dp(4), ui.dp(3)) }
        tvRing(this)   // (v749)
    }
    /** (v741) زرار ⏹ مرسوم باليد (مربع أبيض على الأحمر) — مش بيعتمد على باك الأيقونات اللي كان بيطلّعه فاضي */
    private fun stopBtn(radius: Int): View = StopSquareView(this).apply {
        background = ui.box(0xFFB71C1C.toInt(), 0x33FFFFFF, radius); isClickable = true; isFocusable = true
        contentDescription = "إلغاء الترجمة"; setOnClickListener { cancelDialog() }
    }
    /** (v741) لغات الفيديو الأساسية بس ظاهرة — الباقي تحت «المزيد» (الكشف التلقائي بطيء وبيغلط فبقى آخر واحد) */
    private val MAIN_LANGS = listOf("ar", "en", "fr", "ja", "hi", "zh", "es")
    private fun shLangFlow(cur: String, onPick: (String) -> Unit): View {
        val fl = shFlow()
        fun lbl(id: String) = Offline.langLabels.getOrNull(Offline.langIds.indexOf(id)) ?: id
        fun chip(id: String) = shChip(lbl(id), id == cur) { onPick(id) }
        for (id in MAIN_LANGS) fl.addView(chip(id), shChipLp())
        val rest = Offline.langIds.filter { it.isNotEmpty() && it !in MAIN_LANGS }
        var more: View? = null
        fun expand() {
            more?.let { fl.removeView(it) }
            for (id in rest) fl.addView(chip(id), shChipLp())
            fl.addView(shChip("🔍 تلقائي (أبطأ وبيغلط)", cur.isEmpty()) { onPick("") }, shChipLp())
        }
        if (cur !in MAIN_LANGS) expand()
        else { val mc = shChip("➕ لغات تانية", false) { expand() }; more = mc; fl.addView(mc, shChipLp()) }
        return fl
    }
    /** (v741) قبل أي تفريغ بوشبر: اختار لغة كلام الفيديو من الأساسية — الكشف التلقائي بياخد وقت طويل */
    private fun askVideoLang(then: () -> Unit) {
        val cur = try { Offline.lang() } catch (_: Throwable) { "" }
        if (RcCapture.active) {   // (v1051) وشبر: اختيار لغة كلام الفيديو على الموبايل
            rcPmList("🌍 لغة كلام الفيديو", Offline.langIds.indices.map { i ->
                val id = Offline.langIds[i]
                ((if (id == cur) "✓ " else "") + (Offline.langLabels.getOrNull(i) ?: id).let { if (id.isEmpty()) "🔍 تلقائي (أبطأ وبيغلط)" else it }) to { Cfg.put("stt_lang", id); try { TrWizard.syncSaved("stt_lang", id) } catch (_: Throwable) { }; then() }
            })
            return
        }
        shDialog(330) { col, close ->
            col.addView(shHead("🌍 لغة كلام الفيديو", "اختارها بإيدك — الكشف التلقائي بياخد وقت طويل وبيغلط"))
            col.addView(shLangFlow(cur) { id -> close(); Cfg.put("stt_lang", id); try { TrWizard.syncSaved("stt_lang", id) } catch (_: Throwable) { }; then() }, LinearLayout.LayoutParams(-1, -2))
        }
    }

    // ===================== (v1137) اختيار ملف الترجمة + ➕ استيراد + زرار الرقم =====================
    private var subCandKey = ""; private var subCandAt = 0L; private var subCandList: List<java.io.File> = emptyList()
    /** كل ملفات الترجمة المتاحة للفيديو الحالي (كاش ٢٠ث عشان الشريط بيتحدّث كتير؛ القايمة والاستيراد بيفرضوا تحديث) */
    private fun subCands(force: Boolean = false): List<java.io.File> {
        val u = uri ?: return emptyList()
        val k = u.toString(); val now = System.currentTimeMillis()
        if (!force && k == subCandKey && now - subCandAt < 20000L) return subCandList
        subCandKey = k; subCandAt = now
        subCandList = try { SubSidecar.findAll(this, u) } catch (_: Throwable) { emptyList() }
        return subCandList
    }
    /** بعد تغيير الاختيار: نعيد تحميل المسار في المشغّل (الملف الجديد أو من غير ترجمة) ونصفّر كاش الاسم */
    private fun subApplied(u: Uri, f: java.io.File?) {
        try {
            sfSideKey = ""; subCands(true)
            softAskedFor = u.toString()
            sfHideNative = false; nativeCue = ""; curIdx = -2
            player.exo()?.let { xp ->
                val pos = xp.currentPosition.coerceAtLeast(0L); val pw = xp.playWhenReady
                xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, f == null).build()
                xp.setMediaItem(mediaItemFor(u), pos); xp.prepare(); xp.playWhenReady = pw
            }
            updateTr()
        } catch (e: Throwable) { LogStore.err("Player:subApplied", e) }
    }
    /** ➕ ملف ترجمة من بره (SRT / ASS / VTT): بيتنسخ لفولدر التطبيق وبيتحدد للفيديو ده */
    private fun subImport() {
        val u = uri ?: run { say("افتح فيديو الأول"); return }
        if (SubSel.videoPath(this, u) == null) { say("⚠ مسار الفيديو مش معروف — مش هقدر أربط ملف الترجمة بيه"); return }
        SubPick.pick(this) { src ->
            if (src == null) return@pick
            Thread {
                val f = SubSel.importFrom(this, u, src)
                runOnUiThread {
                    if (f == null) { say("الملف ده مش ترجمة صالحة (SRT / ASS / VTT)"); return@runOnUiThread }
                    SubSel.setChoice(this, u, f.absolutePath)
                    subApplied(u, f)
                    sfNote("➕ اتضاف «" + f.name + "» واتحدد للفيديو ده — دوس «📄 ترجمة ملف الترجمة» من «ترجم» لو عايز تترجمه", 6000L)
                }
            }.also { it.isDaemon = true }.start()
        }
    }
    /** شاشة اختيار ملف الترجمة: كل الملفات (الأحدث الأول) + بدون ترجمة + ترجمة بالباتشات + ➕ استيراد. fromOpen = أول ما الفيديو يفتح (الاختيار بيبدأ ترجمته) */
    private fun subSelectSheet(anchor: View, fromOpen: Boolean = false) {
        val u = uri ?: return
        trMenuPop?.let { if (it.isShowing) it.dismiss(); trMenuPop = null }
        val all = subCands(true)
        val cur = SubSel.chosen(this, u, all)
        val off = SubSel.choice(this, u) == SubSel.NONE
        val col = LinearLayout(this)
        fun close() { trMenuPop?.dismiss() }
        col.addView(shHead(if (all.size > 1) "📄 فيه " + all.size + " ملفات ترجمة للفيديو ده" else if (all.size == 1) "📄 ملف ترجمة للفيديو ده" else "📄 مفيش ملف ترجمة للفيديو ده", if (fromOpen) "اختار واحد (الأحدث فوق)" else "بدّل بينهم أو شغّل من غير ترجمة"))
        all.forEachIndexed { i, f ->
            val ours = SrtWriter.isOurs(this, f)
            val tag = (if (SubSel.isImported(this, u, f)) "➕ مستورد · " else "") + (if (ours) "🌐 مترجم بالبرنامج · " else "") + SubSel.whenOf(f)
            col.addView(shRow((if (!off && cur?.absolutePath == f.absolutePath) "✓ " else "") + (i + 1) + " · " + f.name, tag) {
                close()
                SubSel.setChoice(this, u, f.absolutePath); subApplied(u, f)
                if (fromOpen && Cfg.str("auto_sub", "1") != "0") { h.postDelayed({ try { if (!isFinishing && !isDestroyed && !engineStarted && sfBusy.isEmpty() && uri?.toString() == u.toString()) sfRun("soft", autoEng(), null, -2, true) } catch (e: Throwable) { LogStore.err("Player:subSel1", e) } }, 300L) }
                else say("📄 اتحدد: " + f.name)
            })
        }
        col.addView(shRow((if (off) "✓ " else "") + "🚫 بدون ترجمة", "الفيديو من غير ترجمة — وتقدر تترجم من «ترجم» عادي") {
            close(); SubSel.setChoice(this, u, SubSel.NONE); subApplied(u, null); say("🚫 من غير ترجمة")
        })
        col.addView(shRow("⚡ ترجمة بالباتشات", "من الصوت — دقيق / سريع / أسرع") {
            close(); SubSel.setChoice(this, u, SubSel.NONE); subApplied(u, null); sfBatchFresh = true; trAsked = true; h.post { translateMenu(anchor) }
        })
        col.addView(shRow("➕ إضافة ملف ترجمة من بره", "SRT / ASS / VTT") { close(); subImport() })
        trMenuPop = showSheet(anchor, col, 340, "subSel") { pw -> if (trMenuPop === pw) trMenuPop = null }
    }

    /** (v741) قايمة «ترجم»: قبل البداية = 3 أنظمة ترجمة + نظامين تفريغ · بعد البداية = تحكم (إيقاف/إلغاء) + أدوات + الإعدادات */
    private fun sfChoiceDialog(anchor: View) {
        val key = uri?.toString() ?: ""
        softAskedFor = key
        val col = LinearLayout(this)
        fun close() { trMenuPop?.dismiss() }
        col.addView(shHead("💬 فيه ترجمة جاهزة للفيديو ده", "سوفت سب — تترجم هي ولا تترجم الصوت بالباتشات؟"))
        col.addView(shRow("💬 ترجمة السوفت سب", sfSideName().ifBlank { "ملف الترجمة" }) { close(); sfEngineChoice("السوفت سب") { e -> sfRun("soft", e) } })
        col.addView(shRow("⚡ ترجمة بالباتشات زي زمان", "من الصوت — والسوفت سب بيتقفل") { close(); sfBatchFresh = true; trAsked = true; h.post { translateMenu(anchor) } })
        trMenuPop = showSheet(anchor, col, 320, "sfChoice") { pw -> if (trMenuPop === pw) trMenuPop = null }
    }

    /** (v1326) قسم اختيار نظام الترجمة — نفس الصفوف في دايلوج «ترجم» (الشاشة الموحدة) وفي شيت المحرك (ضغطة مطوّلة على «ترجم») */
    private fun trEngineRows(col: LinearLayout, closeSheet: () -> Unit, reopen: () -> Unit) {
        val mk = curModeKey()
        val whisperish = mk == "off" || mk == "txw"
        val setVal = try { if (whisperish) TrWizard.langLabel(Offline.lang()) + " · " + Offline.model().id else "" } catch (_: Throwable) { "" }
        // (v1137) لو فيه ملف ترجمة للفيديو: «ترجمة ملف الترجمة» فوق الخيارات الدقيقة (بيترجم النص الأصلي بس)
        sfSidecar()?.let { sc -> col.addView(shRow("📄 ترجمة ملف الترجمة", sc.name) { closeSheet(); h.post { sfEngineChoice("ملف الترجمة") { e -> sfRun("soft", e) } } }) }
        col.addView(shSection("🔤 نظام الترجمة"))
        // (v1136) 4 محطات في سلايدر واحد (أسرع · سريع · متوازن · دقيق) بدل أربع صفوف — وصف الحالي في العنوان
        val gemNow = mk == "gem"
        trSliderSection(col)
        col.addView(shRow("☁ ترجم بجيميناي", if (gemNow) "✓ الحالي" else TrSlider.title(TrSlider.pos())) { closeSheet(); h.post { geminiStart() } })
        col.addView(shNote("لهجات + أسلوب + بصري · محتاج نت"))
        col.addView(shRow("📴 ٢ · وشبر + ترجمة أوفلاين (HY-MT1.5)", if (mk == "off") "✓ الحالي" else setVal) { closeSheet(); whisperStart() })
        col.addView(shRow("✍ تفريغ بس", if (mk == "txg" || mk == "txw") "✓ الحالي" else "من غير ترجمة") { closeSheet(); h.post { if (TrProfile.engine() == "off") askVideoLang { offlineQuick(true) } else startGeminiTranscribe() } })
        col.addView(shSection("✍ التفريغ بـ:"))
        val engRow = shFlow()
        fun paintEngRow() {   // (v1374 — بطلب علي) التبديل بيحصل في مكانه من غير ما الشيت يقفل ويفتح
            engRow.removeAllViews()
            engRow.addView(shChip("☁ جيميناي", TrProfile.engine() != "off") { Cfg.put("tr_engine", "gem"); updateTr(); paintEngRow() }, shChipLp())
            engRow.addView(shChip("📴 وشبر", TrProfile.engine() == "off") { Cfg.put("tr_engine", "off"); updateTr(); paintEngRow() }, shChipLp())
        }
        paintEngRow()
        col.addView(engRow, LinearLayout.LayoutParams(-1, -2))
    }

    fun translateMenu(anchor: View) {
        trMenuPop?.let { if (it.isShowing) { it.dismiss(); trMenuPop = null; return } }
        val started = engineStarted
        val paused = ::engine.isInitialized && engine.userPaused
        val col = LinearLayout(this)
        fun close() { trMenuPop?.dismiss() }
        val mk = curModeKey()
        val whisperish = mk == "off" || mk == "txw"
        val setVal = try { if (whisperish) TrWizard.langLabel(Offline.lang()) + " · " + Offline.model().id else "" } catch (_: Throwable) { "" }
        if (!started) {
            col.addView(shHead(if (sfBusy.isNotEmpty()) "⏳ ترجمة السوفت صب " + sfPct() + "% — " + sfBusy else "ترجمة الفيديو", "اختار النظام"))
            // (v667) السوفت صب والهارد صب بيتترجموا أوتوماتيك أول ما الفيديو يفتح — مفيش زراير ليهم هنا
            trEngineRows(col, { close() }) { translateMenu(anchor) }   // (v1326) نفس قسم اختيار النظام الموحّد
        } else {
            col.addView(shHead(Offline.liveLine() ?: ("الترجمة: " + trPct + "% · " + subCountNow() + " جملة" + (if (paused) " (واقفة)" else "")), "الوضع: " + modeName() + (if (Strict.freeText() || Strict.freeGem()) " · 🆓 " + FreeLlm.liveName() else "")))
            col.addView(shDuo(
                shBtn(if (paused) "▶ كمّل" else "⏸ إيقاف مؤقت", if (paused) SH_BLUE else SH_GRAY) { close(); if (paused) beginTranslate() else pauseTranslate() },
                shBtn("⏹ إلغاء الترجمة", SH_RED) { close(); h.post { cancelDialog() } }))
            col.addView(shSection("🛠 أدوات"))
            col.addView(shRow("🔁 إعادة ترجمة", "", true) { close(); h.post { trStartSheet(anchor) } })   // (v1379) redoSheet اتشالت من كل الكود — الصف بيفتح الشيت الجديد
            col.addView(shRow("📊 تقدم الباتشات", "", true) { close(); batchDialog() })
            col.addView(shRow("🌙 كمّل في الخلفية") { close(); translateInBackground() })
        }
        col.addView(shSection("⚙ الإعدادات"))
        col.addView(shRow("⚙ إعدادات الترجمة", setVal, true) { close(); h.post { trSettings(anchor) } })   // (v1136) ورقة واحدة؛ «متقدم» جواها
        if (started) col.addView(shRow("🔀 غيّر النظام", "", true) {
            close()
            h.post { shConfirm("🔀 تغيير نظام الترجمة", "هوقف الترجمة الحالية (اللي اتترجم محفوظ) وتختار نظام تاني من القايمة.",
                listOf(ShBtn("أوقف واختار", SH_BLUE) { cancelTranslate { translateMenu(anchor) } }, ShBtn("لأ، كمّل", SH_GRAY) { })) }
        })
        trMenuPop = showSheet(anchor, col, 320, "trMenu") { pw -> if (trMenuPop === pw) trMenuPop = null }
    }

    // ===================== (v1097) T2: زرار «ترجم» على طول + ⚙ إعدادات الترجمة + سلايدر سريع ↔ دقيق =====================
    private fun trIsTx(): Boolean = TrProfile.kind() == "transcribe"
    /** قبل البداية: بيبدأ على طول بالنوع والمحرك المحفوظين (⚙). بعد البداية (أو سوفت صب شغّال): قايمة الأدوات زي الأول */
    private fun trMainClick(anchor: View, direct: Boolean = false) {
        if (Design.isNew() && !direct) { trStartSheet(anchor); return }   // (v1379 — بطلب علي) الشيت الجديد بالـ٤ زراير بدل قايمة الخيارات
        if (Design.isNew() && (engineStarted || sfBusy.isNotEmpty() || sfLive.isNotEmpty())) {   // (v1239) من غير أي صفحة قديمة
            say("⏳ الترجمة شغّالة بالفعل — التقدم في الشريط")
            return
        }
        if (engineStarted || sfBusy.isNotEmpty() || sfLive.isNotEmpty()) { translateMenu(anchor); return }
        val key = uri?.toString() ?: ""
        uri?.let { vu -> if (SubSel.needsChoice(this, vu, subCands(true))) { subSelectSheet(anchor); return } }   // (v1137) أكتر من ملف ترجمة ومفيش اختيار: نسأل
        if (hasSoftSubNow() && softAskedFor != key) { sfChoiceDialog(anchor); return }
        val tx = trIsTx(); val off = TrProfile.engine() == "off"
        LogStore.add("▶ زرار ترجم ← " + (if (tx) "تفريغ" else "ترجمة") + " · " + (if (off) "وشبر أوفلاين" else if (Cfg.str("mt_tr_mode", "") == "groq") "جروك ⚡" else "جيميناي"))   // (v1126) تشخيص: أنهي فرع اشتغل · (v1371) جروك باسمه
        val goTr = { here: Boolean ->
            if (here) trHere = true
            when {
                tx && off -> askVideoLang { offlineQuick(true) }
                tx -> startGeminiTranscribe()
                off -> whisperStart()
                else -> geminiStart()
            }
        }
        // (v1364 — بطلب علي) زرار بدء الترجمة يسأل: من الأول ولا من مكان التشغيل؟ (لو واقف بعد أول 10 ثواني وفيديو جديد مترجمش قبل كده)
        val pos0 = try { player.currentPosition } catch (_: Throwable) { 0L }
        val hasSaved = try { ::engine.isInitialized && engine.subs.isNotEmpty() } catch (_: Throwable) { false }   // الترجمة الناقصة/الكاملة ليها دايالوجها الخاص
        if (pos0 > 10_000L && !hasSaved) {
            shDialog(300) { col, close ->   // (v1376 — بطلب علي) توحيد شيت بدء الترجمة على ستايل شيت الإعادة: قسم + وصف تحت كل اختيار
                col.addView(shHead("▶ بدء الترجمة", "واقف عند " + fmtMs(pos0) + " — تبدأ منين؟"))
                col.addView(shSection("تبدأ من فين؟"))
                col.addView(shRow("📍 من مكان التشغيل (" + fmtMs(pos0) + ")", "يكمّل من اللحظة دي") { close(); h.post { goTr(true) } })
                col.addView(shRow("⏮ من أول الفيديو", "من الصفر خالص") { close(); h.post { goTr(false) } })
            }
        } else goTr(false)
    }

    /** (v1236) التصميم الجديد: دوسة على زرار ترجم/دبلج بتفتح خيارات في نص الشاشة: ترجم · كمّل · من الأول · إعادة الترجمة */
    /** (v1379 — بطلب علي في الفويس نوت) شيت «ترجم» الجديد: ٤ زراير بس (كمّل باسم المود · إعادة من الأول · إلغاء · الإعدادات) + سطر «الوضع الحالي» فوقهم، و«🚀 يلا ابدا» بيظهر بعد ما الإعدادات تتغيّر. مفيش أي حاجة تانية */
    private var trStartArmed = false
    private fun trStartSheet(anchor: View, armed: Boolean = false) {
        val armedNow = armed || trStartArmed; trStartArmed = false
        shDialog(320) { col, close ->
            val started = engineStarted
            val paused = ::engine.isInitialized && engine.userPaused
            val modeNow = modeName()
            col.addView(shHead("🌐 الترجمة", if (started) (trPct.toString() + "% · " + subCountNow() + " جملة") else "اختار وهيبدأ على طول"))
            col.addView(shNote("الوضع الحالي: " + modeNow))   // (v1379 — بطلب علي) سطر الوضع الحالي فوق الزراير
            val start = {   // كمّل ويلا ابدا نفس الإجراء: استكمال أو بدء بالمود الحالي
                if (trComplete()) say("✅ الترجمة كاملة 100%")
                else if (started && paused) beginTranslate()
                else if (started) say("⏳ الترجمة شغّالة بالفعل")
                else trMainClick(anchor, true)
            }
            col.addView(shRow("▶ كمّل " + modeNow, if (started && !paused) "شغّالة بالفعل" else "") { close(); h.post { start() } })   // (v1379 — بطلب علي) الكمّل باسم المود بالظبط (تفريغ / ترجمة فصحى / ترجمة لهجة)
            col.addView(shRow("🔁 إعادة من الأول", "القديمة تتحفظ في 🗂") { close(); h.post {
                if (::engine.isInitialized) { val k = redoKeep; player.seekTo(0); redoGo("🔄 بترجم من الأول…") { syncTxFlag("إعادة من الأول"); engine.redoAll(k) } }
                else say("المحرك لسه بيحمّل — جرّب كمان لحظة") } })
            if (started) col.addView(shRow("⏹ إلغاء", "إيقاف الترجمة الحالية خالص") { close(); h.post { cancelDialog() } })   // (v1379 — بطلب علي) ⏹ = إلغاء الترجمة الحالية
            col.addView(shRow("⚙ الإعدادات", "", true) { close(); h.post {
                val sk = listOf("lang", "style", "model", "conv_dialect", "tone_style", "tone_strength", "mt_tr_mode", "stt_offline", "tr_engine", "tr_method", "stt_lang", "groq_model", "fastmode", "tr_bal", "groq_chunk")
                fun snap() = sk.joinToString("|") { k -> try { Cfg.str(k, "�") } catch (_: Throwable) { "�" } }
                val before = snap()
                trSettings(anchor) {   // (v1379 — بطلب علي) الإعدادات اتغيّرت ← «🚀 يلا ابدا» يظهر في الشيت
                    if (snap() != before) { trStartArmed = true; Notice.show(this@PlayerActivity, "⚙ الإعدادات اتحفظت — دوس «ترجم» وهتلاقي 🚀 يلا ابدا", 3000L) }
                } } })
            if (armedNow) col.addView(shBtn("🚀 يلا ابدا", SH_BLUE) { close(); h.post { start() } })   // (v1379 — بطلب علي) زرار البدء بعد تغيير الإعدادات
        }
    }

    private fun remoteTrGuarded(run: () -> Unit) {
        val key = uri?.toString() ?: ""
        if (!engineStarted && hasSoftSubNow() && softAskedFor != key) {
            sfChoiceDialog(window.decorView)
            notice("💬 فيه سوفت سب — اختار من التلفزيون: ترجمته ولا الباتشات")
            return
        }
        run()
    }

    /** (v1376 — بطلب علي) اختيار لغة الكلام للويشبر من جوه شيت إعدادات الترجمة (كانت في تبويب الصوت في الإعدادات العامة بس) */
    private fun pickWhisperLang(onDone: () -> Unit) {
        shDialog(320) { col, close ->
            col.addView(shHead("🗣 لغة الكلام", "لو عارفها بتقلّل أخطاء الاكتشاف التلقائي"))
            val cur = try { Offline.lang() } catch (_: Throwable) { "" }
            for (ix in Offline.langLabels.indices) {
                val lid = Offline.langIds[ix]
                col.addView(shRow(Offline.langLabels[ix], if (lid == cur) "✓ الحالية" else "") { Cfg.put("stt_lang", lid); TrWizard.syncSaved("stt_lang", lid); close(); onDone() })
            }
            col.addView(shRow("إغلاق") { close(); onDone() })
        }
    }

    private fun trSettings(anchor: View, onClosed: (() -> Unit)? = null) {
        trAnchor = anchor   // (v1099) T4: بيستخدمه الرجوع من تفريغ لترجمة
        val d = shDialog(340) { col, close ->
            fun build() {
                col.removeAllViews()   // (v1374 — بطلب علي) إعادة بناء المحتوى في نفس الشيت من غير وميض قفل/فتح
                val off = TrProfile.engine() == "off"
                fun again() { build() }   // (v1374 — بطلب علي) التحديث بيحصل في مكانه — الشيت مابيقفلش ويفتح تاني مع كل اختيار
                fun engSync() { try { if (::engine.isInitialized) engine.convDialect = Cfg.str("conv_dialect", "") } catch (_: Throwable) {} }
                col.addView(shHead("⚙ إعدادات الترجمة", "زرار «ترجم» بيشتغل على طول بالإعدادات دي"))
                // (v1371 — بطلب علي) نظام البلوكات: سلايدر السرعة فوق (بيظهر مع جيميناي بس) ← سلايدر النوع (ظاهر دايمًا) ← 3 أعمدة جنب بعض: 🎙 تفريغ · 🌐 فصحى · 🗣 لهجة — الأعمدة اللي تحت موضع السلايدر رمادية بس قابلة للدوس (طريقة الخروج من «تفريغ»)
                fun pickStt(kind: String) {
                    when (kind) {
                        "whisper" -> {
                            Cfg.put("stt_offline", "1"); Cfg.put("mt_tr_mode", "whisper"); Cfg.put("tr_engine", "off")   // (v1375 — بطلب علي) مزامنة tr_engine مع البلوك — كانت بتفضل gem فيتفرّغ بجيميناي غلط
                            val rdy = try { Offline.engine().ready() || Offload.wanted() } catch (_: Throwable) { false }
                            if (!rdy) { close(); h.post { whisperModelPick { h.post { beginTranslate() } } }; return } else say("🎙 وشبر — التفريغ على الجهاز")   // (v1341) الدايلوج بيفتح بعد قفل الشيت — كان بيطلع وراها (بطلب علي)
                        }
                        "groq" -> {
                            Cfg.put("stt_offline", "0"); Cfg.put("mt_tr_mode", "groq"); Cfg.put("tr_engine", "gem"); say("⚡ جروك — تفريغ Whisper سحابي سريع")   // (v1375) جروك بيشتغل في الحارة الجيميناوية
                            if (Cfg.str("groq_key", "").isBlank()) Notice.show(this, "🔑 مفتاح Groq ناقص — ضيفه من الإعدادات ← 🔑 المفاتيح", 3400L)
                        }
                        else -> { Cfg.put("stt_offline", "0"); Cfg.put("mt_tr_mode", "gemini"); Cfg.put("tr_engine", "gem"); say("☁ جيميناي بيفرّغ الصوت") }
                    }
                    again()
                }
                fun pickMt(kind: String) {
                    when (kind) {
                        "none" -> TrProfile.setMode(TrProfile.TX)
                        "gemini" -> { Cfg.put("tr_method", "gemini"); if (TrProfile.uiMode() == TrProfile.TX) TrProfile.setMode(TrProfile.MSA) }
                        else -> {
                            Cfg.put("tr_method", "google")
                            if (TrProfile.uiMode() == TrProfile.TX) TrProfile.setMode(TrProfile.MSA)
                            if (Cfg.str("mt_tr_mode", "") == "groq") { say("🌐 جوجل ترانسليت بيترجم تفريغ جروك"); again(); return }   // (v1369) جوجل مابيحوّلش التفريغ لوشبر لو جروك مختار
                            Cfg.put("stt_offline", "1"); Cfg.put("mt_tr_mode", "whisper")
                            say("🌐 جوجل ترانسليت بيترجم تفريغ الويشبر — التفريغ اتحوّل لوشبر تلقائيًا")
                            val rdy = try { Offline.engine().ready() || Offload.wanted() } catch (_: Throwable) { false }
                            if (!rdy) { close(); h.post { whisperModelPick { } }; return }   // (v1341) نفس ترتيب الفتح فوق الشيت
                        }
                    }
                    again()
                }
                val sttSel = if (Cfg.bool("stt_offline", false)) "whisper" else if (Cfg.str("mt_tr_mode", "") == "groq") "groq" else "gemini"
                val mtSel = if (TrProfile.uiMode() == TrProfile.TX) "none" else if (TrWizard.method() == "google") "google" else "gemini"
                val diaSel = if (TrProfile.uiMode() == TrProfile.DIA) "gemini" else "none"
                val modeTitle = ui.text("", 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
                val diaBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                val qBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                val msaViews = ArrayList<View>()
                val diaViews = ArrayList<View>()
                fun paintSave() { try { TrProfile.save() } catch (_: Throwable) {} }   // (v1140) حفظ تلقائي: أي تغيير بيتحفظ لكل الفيديوهات على طول (مفيش زرار حفظ)
                fun paintDia() {
                    diaBox.removeAllViews()
                    val cd = TrProfile.dialect()
                    val dTitle = ui.text("🗣 اللهجة: " + cd, 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
                    diaBox.addView(dTitle, LinearLayout.LayoutParams(-1, -2))
                    diaBox.addView(shNote("اللهجة بتتبع لغة الكيبورد/النظام أوتوماتيك — عربي مصري = «مصري»، أي لغة تانية = فصحى"))   // (v1341) سلايدر اللهجة اتشال: كان بلا وظيفة (لهجة واحدة بس) — بطلب علي
                    diaBox.addView(shNote("الشدة"))
                    val rs = shFlow(); val cg = TrProfile.degree()
                    for (g in TrProfile.degrees) rs.addView(shChip(g, g == cg) { TrProfile.setDegree(g); try { if (::engine.isInitialized) engine.toneStrength = g } catch (_: Throwable) {}; paintDia(); paintSave(); if (g != cg) trLiveApply("deg", TrProfile.DIA) }, shChipLp())
                    diaBox.addView(rs, LinearLayout.LayoutParams(-1, -2))
                    if (TrProfile.styleIsLiteral()) diaBox.addView(shNote("الأسلوب حرفي — الشدة مش هتأثر (غيّره من 🌐 اللهجة والأسلوب)", true))
                }
                fun refresh() {
                    val m = TrProfile.uiMode()
                    val none = m == TrProfile.TX   // (v1332) «بدون ترجمة»: كل ما يخص الترجمة بيختفي
                    modeTitle.text = when (m) { TrProfile.TX -> "✍ تفريغ بس (من غير ترجمة)"; TrProfile.MSA -> "🔤 ترجمة فصحى"; else -> "🗣 ترجمة بلهجة" }
                    modeTitle.visibility = if (none) View.GONE else View.VISIBLE
                    diaBox.visibility = if (m == TrProfile.DIA && !off && !none) View.VISIBLE else View.GONE
                    val gem = sttSel == "gemini" || (m >= TrProfile.MSA && TrWizard.method() == "gemini")   // (v1371 — بطلب علي) السلايدر بيظهر بس لو جيميناي فعلًا في المسار (تفريغ ولا ترجمة)
                    qBox.visibility = if (gem && !off) View.VISIBLE else View.GONE   // (v1371) بيختفي بالكامل من غير بقايا نص
                    for (v in msaViews) { v.alpha = if (m >= TrProfile.MSA) 1f else 0.35f }   // (v1369) رمادي لحد ما السلايدر يوصله (بطلب علي) · (v1371) رمادي بس بيفضل شغّال — دي طريقة الخروج من «تفريغ»
                    for (v in diaViews) { v.alpha = if (m >= TrProfile.DIA) 1f else 0.35f }   // (v1371) نفس الفكرة
                }
                fun setModeChip(mm: Int) {   // (v1369) لازم تتعريف بعد paintSave/paintDia/refresh — الكوتلن مابيسمحش باستخدام فانكشن محلية قبل تعريفها
                    val prevM = TrProfile.uiMode(); if (mm == prevM) return
                    val pd = curEngDia(); TrProfile.setMode(mm); engSync(); updateTr(); paintDia(); refresh(); trLiveApply("mode", prevM, pd); paintSave()
                }
                // ⚡ سلايدر السرعة فوق — بيظهر مع جيميناي بس
                trSliderSection(qBox) { paintSave() }
                col.addView(qBox, LinearLayout.LayoutParams(-1, -2))
                col.addView(shSection("النوع"))
                col.addView(modeTitle, LinearLayout.LayoutParams(-1, -2))
                val mModes = if (off) listOf(TrProfile.TX, TrProfile.MSA) else listOf(TrProfile.TX, TrProfile.MSA, TrProfile.DIA)   // (v1358) موضع الدبلجة اتشال من السلايدر
                var lastM = TrProfile.uiMode().let { if (off && it == TrProfile.DIA) TrProfile.MSA else it }
                val msb = SeekBar(this).apply {
                    layoutDirection = View.LAYOUT_DIRECTION_LTR; max = mModes.size - 1; progress = mModes.indexOf(lastM).coerceAtLeast(0)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                            if (!u) return
                            val mm = mModes.getOrNull(p) ?: return
                            if (mm == lastM) return
                            val prevM = lastM; val pd = curEngDia(); lastM = mm; TrProfile.setMode(mm); engSync(); updateTr(); paintDia(); refresh(); trLiveApply("mode", prevM, pd); paintSave()   // (v1099) T4
                        }
                        override fun onStartTrackingTouch(s: SeekBar?) {}
                        override fun onStopTrackingTouch(s: SeekBar?) {}
                    })
                }
                col.addView(msb, LinearLayout.LayoutParams(-1, -2))
                val mends = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(ui.dp(10), 0, ui.dp(10), 0) }
                mends.addView(ui.text("✍ تفريغ", 11.5f, 0xFF9AA0A6.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
                mends.addView(ui.text("🔤 فصحى", 11.5f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
                if (!off) mends.addView(ui.text("🗣 لهجة", 11.5f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
                col.addView(mends, LinearLayout.LayoutParams(-1, -2))
                // (v1371 — بطلب علي) البلوكات 3 أعمدة جنب بعض مهما كان حجم الشاشة: 🎙 تفريغ (جيميناي/جروك/ويشبر) · 🌐 فصحى (جيميناي/جوجل ترانسليت/بدون) · 🗣 لهجة (جيميناي/بدون)
                fun colChip(label: String, on: Boolean, f: () -> Unit): View = ui.text(label, 11.5f, Color.WHITE, on).apply {
                    gravity = Gravity.CENTER; isFocusable = true; setPadding(ui.dp(3), 0, ui.dp(3), 0)
                    maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                    background = ui.box(if (on) 0xFF8B6B50.toInt() else 0x1AFFFFFF, if (on) 0x55FFFFFF else 0x22FFFFFF, 10); setOnClickListener { f() }
                    tvRing(this)
                }
                fun blkChip(cc: LinearLayout, label: String, on: Boolean, f: () -> Unit) { cc.addView(colChip(label, on, f), LinearLayout.LayoutParams(-1, ui.dp(38)).apply { setMargins(ui.dp(2), ui.dp(2), ui.dp(2), ui.dp(2)) }) }
                fun blkCol(title: String, chips: (LinearLayout) -> Unit): LinearLayout {
                    val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                    c.addView(ui.text(title, 12.5f, 0xFF9AA0A6.toInt(), true).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(6), 0, ui.dp(2)) }, LinearLayout.LayoutParams(-1, -2))
                    chips(c)
                    return c
                }
                val cols = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
                val sttCol = blkCol("🎙 تفريغ") { cc ->
                    blkChip(cc, "☁ جيميناي", sttSel == "gemini") { pickStt("gemini") }
                    blkChip(cc, "⚡ جروك", sttSel == "groq") { pickStt("groq") }
                    blkChip(cc, "🎙 ويشبر", sttSel == "whisper") { pickStt("whisper") }
                }
                cols.addView(sttCol, LinearLayout.LayoutParams(0, -2, 1f))
                val msaCol = blkCol("🌐 فصحى") { cc ->
                    blkChip(cc, "☁ جيميناي", mtSel == "gemini") { pickMt("gemini") }
                    blkChip(cc, "🌐 جوجل ترانسليت", mtSel == "google") { pickMt("google") }
                    blkChip(cc, "🚫 بدون", mtSel == "none") { pickMt("none") }
                }
                msaViews.add(msaCol)
                cols.addView(msaCol, LinearLayout.LayoutParams(0, -2, 1f))
                if (!off) {
                    val diaCol = blkCol("🗣 لهجة") { cc ->
                        blkChip(cc, "☁ جيميناي", diaSel == "gemini") { setModeChip(TrProfile.DIA); again() }
                        blkChip(cc, "🚫 بدون", diaSel == "none") { setModeChip(TrProfile.MSA); again() }
                    }
                    diaViews.add(diaCol)
                    cols.addView(diaCol, LinearLayout.LayoutParams(0, -2, 1f))
                }
                col.addView(cols, LinearLayout.LayoutParams(-1, -2))
                if (sttSel == "whisper") {
                    val wm = Offline.model(); val wdl = try { Offline.downloaded() } catch (_: Throwable) { false }
                    col.addView(shNote("الموديل: " + wm.label + " (~" + wm.approxMb + "MB) — " + (if (wdl) "✅ متنزّل" else "❌ مش متنزّل"), !wdl))
                    col.addView(shRow(if (wdl) "🎙 تغيير موديل الويشبر" else "⬇ تحميل موديل الويشبر", "اختار الموديل الأول (tiny/base/small/medium/turbo)، بعدين نزّله بروجرس أو في الخلفية") { close(); h.post { whisperModelPick { h.post { if (!wdl) beginTranslate() } } } })   // (v1341) اختيار الموديل قبل التحميل + الدايلوج فوق الشيت (بطلب علي)
                    col.addView(shRow("🗣 لغة الكلام", try { TrWizard.langLabel(Offline.lang()) } catch (_: Throwable) { "تلقائي" }) { close(); h.post { pickWhisperLang { h.post { trSettings(anchor) } } } })   // (v1376 — بطلب علي) خيارات الويشبر تظهر تحت شيبها مباشرة: اللغة جنب الموديل
                } else if (sttSel == "groq") {
                    val gk = Cfg.str("groq_key", "").isNotBlank()
                    col.addView(shNote("الموديل: " + Cfg.str("groq_model", "whisper-large-v3-turbo").ifBlank { "whisper-large-v3-turbo" } + " — المفتاح: " + (if (gk) "✅ محفوظ" else "❌ ناقص — ضيفه من الإعدادات ← 🔑 المفاتيح"), !gk))
                } else {
                    col.addView(shRow("🔄 جلب الموديلات واختيار واحد", "بيتطبّق على كل المفاتيح") { close(); h.post { modelsPick() } })
                }
                if (mtSel == "google") col.addView(shNote("جوجل ترانسليت بيترجم النص المفرّغ بس — التفريغ بيتم بالويشبر على الجهاز أو بجروك."))
                col.addView(diaBox, LinearLayout.LayoutParams(-1, -2))
                if (off) col.addView(shNote("الأوفلاين بيترجم فصحى بس — اللهجة والشدة محتاجين جيميناي"))
                paintDia()
                trSongSection(col)   // (v1171) 🎵 وضع الأغاني
                if (::realEngine.isInitialized && !remote && realEngine.applied.isNotEmpty())
                    col.addView(shRow("( ) شيل الأقواس من الجمل المتغيّرة", realEngine.applied.size.toString() + " جملة") { realEngine.clearMarks(); touchSubs(); again() })   // (v1099) T4
                // (v1098) حفظ: الإعدادات دي بتتطبّق تلقائي على أي فيديو تاني تفتحه بعد كده
                col.addView(shRow("إغلاق") { close() })
                refresh()
            }
            build()
        }
        if (onClosed != null) d.setOnDismissListener { onClosed.invoke() }   // (v1379) الشيت الجديد بيسنّد على قفل الإعدادات عشان يقارن قبل/بعد («🚀 يلا ابدا»)
    }

    // ===================== (v1099) T4: تطبيق فوري وبأثر رجعي من ⚙ الترجمة + الأقواس =====================
    private var trAnchor: View? = null
    private val liveKinds = HashSet<String>()
    private var liveFrom = -1
    private var liveFromDia = ""
    private val liveRun = Runnable { trLiveApplyNow() }
    /** لهجة المحرك دلوقتي («فصحى» لو مفيش) — بتتاخد قبل ما نغيّر الإعدادات عشان النسخة القديمة تتحفظ في 🗂 باسمها الصح */
    private fun curEngDia(): String = try { if (::engine.isInitialized) engine.convDialect.ifBlank { "فصحى" } else "" } catch (_: Throwable) { "" }
    /** أي تغيير في النوع/اللهجة/الشدة والترجمة شغّالة (أو فيه جمل) بيتطبّق بعد ~1.2ث من آخر لمسة (عشان السلايدر ما يبعتش طلب لكل خطوة) */
    private fun trLiveApply(kind: String, prevMode: Int, prevDia: String = "") {
        if (!::engine.isInitialized) return
        val has = try { engineStarted || engine.subs.isNotEmpty() } catch (_: Throwable) { false }
        if (!has) return
        if (liveKinds.isEmpty()) { liveFrom = prevMode; liveFromDia = prevDia }
        liveKinds.add(kind); h.removeCallbacks(liveRun); h.postDelayed(liveRun, 1200L)
    }
    private fun trLiveApplyNow() {
        val kinds = liveKinds.toSet(); val from = liveFrom; val fromDia = liveFromDia
        liveKinds.clear(); liveFrom = -1; liveFromDia = ""
        if (kinds.isEmpty() || !::engine.isInitialized) return
        val to = TrProfile.mode()
        val eng: Engine? = if (::realEngine.isInitialized && !remote) realEngine else null
        try {
            if (to == TrProfile.TX) {
                if (from == TrProfile.TX) return
                engine.transOnly = true; eng?.origView = true
                // (v1119) التبديل اللايف يوصل للمحرك البسيط كمان — مش للمحرك القديم بس
                try { fastTr?.transOnly = true } catch (_: Throwable) {}
                say("✍ تفريغ — اللي اتترجم بيتعرض بنصه الأصلي بين أقواس ( ) والباتشات الجاية من غير ترجمة"); touchSubs(); return
            }
            if (from == TrProfile.TX) {
                val viewOnly = eng?.origView == true
                eng?.origView = false
                if (engine.transOnly) {
                    engine.transOnly = false
                    // (v1119) الرجوع للترجمة يرجّع المحرك البسيط كمان
                    try { fastTr?.transOnly = false } catch (_: Throwable) {}
                    if (!viewOnly) { say("🔤 رجوع للترجمة — بتبدأ من الأول بالإعدادات الجديدة"); cancelTranslate { trAnchor?.let { trMainClick(it) } }; return }
                }
                touchSubs()
            }
            if (!engineStarted && engine.subs.isEmpty()) return
            fun armMark() { eng?.markRetro = true; h.postDelayed({ eng?.markRetro = false }, 5000L) }
            when {
                to == TrProfile.DIA && (from != TrProfile.DIA || "dia" in kinds) -> {
                    if (try { Strict.noGemKeys() } catch (_: Throwable) { false }) { say("🗣 تحويل اللهجة محتاج جيميناي — الترجمة فضلت فصحى"); return }
                    val d = TrProfile.dialect()
                    // engSync غيّرت لهجة المحرك قبل كده فـ setConvDialect مش هتحفظ النسخة القديمة لوحدها — بنحفظها هنا باللهجة اللي كانت فعلًا
                    val lb = fromDia.ifBlank { "فصحى" }
                    if (engine.subs.isNotEmpty() && lb != d) engine.saveVersion("ترجمة $lb", lb)
                    armMark(); engine.setConvDialect(d, true)
                    say("🗣 بحوّل اللي اتترجم للهجة $d — الجمل المتغيّرة بتظهر بين أقواس ( ) وبيبدأ من مكانك")
                }
                to == TrProfile.MSA && from == TrProfile.DIA -> {
                    val lb = fromDia.ifBlank { "فصحى" }
                    if (lb != "فصحى" && engine.subs.isNotEmpty()) engine.saveVersion("ترجمة $lb", lb)   // اللهجة الحالية في 🗂 قبل الرجوع
                    val vi = engine.versions.indexOfLast { it.dialect == "فصحى" }
                    if (vi >= 0) { restoreVersion(vi); eng?.markAllApplied(); say("🔤 رجعت الفصحى — الجمل بين أقواس ( ) (اللهجة محفوظة في 🗂)") }
                    else {
                        armMark()
                        engine.rewriteAll("فصحى", "حوّل كل جملة للعربية الفصحى المبسطة الأمينة للمعنى بدل العامية، من غير ما تغيّر المعنى.", 0.0, { m -> say(m) }) { n -> say(if (n > 0) "✅ فصحى: اتغيّرت $n جملة (بين أقواس ( ) — ترجع من 🗂)" else "فصحى: مفيش جمل اتغيّرت"); touchSubs() }
                    }
                    touchSubs()
                }
                "deg" in kinds && to == TrProfile.DIA -> {
                    val st = Cfg.str("tone_style", "").ifBlank { "تلقائي" }
                    if (st == "حرفي") { say("الأسلوب حرفي — الشدة مش هتأثر"); return }
                    val dg = TrProfile.degree(); val label = "شدة $dg"
                    armMark()
                    engine.rewriteAll(label, toneInstrOf(st, dg), 0.0, { m -> say(m) }) { n -> say(if (n > 0) "✅ $label: اتغيّرت $n جملة (بين أقواس ( ) — ترجع من 🗂)" else "$label: مفيش جمل اتغيّرت"); touchSubs() }
                }
            }
        } catch (e: Throwable) { LogStore.err("Player:liveApply", e) }
    }
    /** الجملة المعروضة بين أقواس لو اتغيّرت بأثر رجعي (أو التفريغ بأثر رجعي بيعرض الأصل) — عرض بس */
    private fun trMarkParens(s: Sub?, gs: List<Sub>): Sub? {
        if (s == null || gs.isEmpty() || s.isSound || !::realEngine.isInitialized || remote) return s
        val e = realEngine
        return try {
            val dual3 = sub.style.dual >= 3
            if (e.origView) { val o = s.original.ifBlank { s.translated }; if (o.isBlank()) s else s.copy(translated = "($o)", original = if (dual3) "($o)" else s.original) }
            else if (!dual3 && s.translated.isNotBlank() && gs.any { e.isApplied(it) }) s.copy(translated = "(" + s.translated + ")")
            else s
        } catch (_: Throwable) { s }
    }
    /** نص الجملة في قايمة الجمل (بين أقواس لو اتغيّرت بأثر رجعي) */
    private fun dispTr(q: Sub): String {
        val base = if (q.translated.isEmpty()) q.original else q.withSpeaker(q.translated)
        return try {
            if (!::realEngine.isInitialized || remote) base
            else if (realEngine.origView) { val o = q.original.ifBlank { base }; if (o.isBlank()) base else "($o)" }
            else if (q.translated.isNotEmpty() && realEngine.isApplied(q)) "($base)" else base
        } catch (_: Throwable) { base }
    }

    /** (v1374 — بطلب علي: «شيل زرار تلقائي خالص وخلي وضع الأغاني أون/أوف») زرار واحد: شغّال = أغنية + كلمات LRCLIB · مقفول = ترجمة/تفريغ مباشر */
    private fun trSongSection(col: LinearLayout) {
        col.addView(shSection("🎵 وضع الأغاني"))
        val row = shFlow()
        val note = shNote("")
        fun paint() {
            val on = SongHint.mode() == "on"
            row.removeAllViews()
            row.addView(shChip(if (on) "🎵 وضع الأغاني: شغّال (كلمات LRCLIB)" else "🎵 وضع الأغاني: مقفول", on) {
                SongHint.setMode(if (on) "off" else "on"); SongHint.setLyricsWanted(!on); paint()
            }, shChipLp())
            (note as? TextView)?.text = if (on) "شغّال: البرومبت الخفيف وتسريع الصوت متقفلين، قاعدة «تجاهل الموسيقى» ملغية، والكلمات المرجعية (للإملاء بس) بتتجاب من LRCLIB بإنترنت. بيتطبّق على الباتشات الجاية.\nدلوقتي: " + SongHint.state()
                else "مقفول: ترجمة/تفريغ مباشر من غير معاملة أغاني ولا كلمات مرجعية."
        }
        col.addView(row, LinearLayout.LayoutParams(-1, -2))
        col.addView(note)
        paint()
    }

    private fun trSliderSection(col: LinearLayout, onChanged: () -> Unit = {}) {
        col.addView(shSection("⚖ سريع ↔ دقيق"))
        val title = ui.text("", 14f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
        // (v1127) قايمة البلوكات (☑/☐) اتشالت — البلوكات بتتحدد لوحدها من موضع السلايدر (TrSlider.onAt) من غير عرض
        val balNote = shNote("⚖ المتوازن: المحرك البسيط — كل مفتاح ياخد باتش ويفرّغه (يظهر على طول) وبعدين يترجمه. من غير بلوكات سرعة/دقة. حرّك يمين للدقيق أو شمال للسريع.")
        val dualNote = shNote("⚡ ٧٥/٢٥ (سماع واحد) مختار من «🔧 إعدادات متقدمة» — تحريك السلايدر جوه الدقيق مش بيغيّره")
        fun paint(p: Int) {
            title.text = TrSlider.title(p)
            val bal = TrSlider.zone(p) == TrSlider.BAL
            balNote.visibility = if (bal) View.VISIBLE else View.GONE
            dualNote.visibility = if (TrSlider.zone(p) == TrSlider.ACC && Cfg.int("dual_listen", 1) == 0) View.VISIBLE else View.GONE
        }
        col.addView(title, LinearLayout.LayoutParams(-1, -2))
        val sb = SeekBar(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR; max = TrSlider.STATIONS - 1; progress = TrSlider.station(TrSlider.pos())   // (v1199) 3 محطات
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { val ip = TrSlider.posOf(p); TrSlider.setPos(ip); try { updateTr() } catch (_: Throwable) {}; paint(ip); onChanged() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { if (engineStarted) say("⚖ تغيير الوضع (سريع/متوازن/دقيق) بيبدأ من أول ترجمة جديدة — البلوكات لايف") }
            })
        }
        col.addView(sb, LinearLayout.LayoutParams(-1, -2))
        val ends = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; setPadding(ui.dp(10), 0, ui.dp(10), 0) }
        ends.addView(ui.text("⚡ سريع", 11.5f, 0xFF9AA0A6.toInt()), LinearLayout.LayoutParams(0, -2, 1f))
        ends.addView(ui.text("⚖ متوازن", 11.5f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        ends.addView(ui.text("🎯 دقيق", 11.5f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1f))
        col.addView(ends, LinearLayout.LayoutParams(-1, -2))
        col.addView(balNote); col.addView(dualNote)
        paint(TrSlider.pos())
    }

    private fun geminiAsk() {   // (v1136) مفيش قايمة اختيار: السلايدر (⚙ إعدادات الترجمة) هو اللي بيحدد الوضع، والزرار بيبدأ بيه على طول
        geminiStart()
    }

    /** (v741) ☁ ترجمة جيميناي لوحده: الصوت بيتبعت باتشات لجيميناي بإعداداته (WAV/AAC + مفاتيحك) — من غير FreeLLM ولا وشبر */
    private fun geminiStart() {
        if (logArcPlay != null) { say("🗂 إنت بتشوف ترجمات لوج محفوظ — افتح الفيديو عادي لو عايز تترجم"); return }   // (v1167)
        if (needGeminiKey { geminiStart() }) return   // (v1101)
        // (v1119) FIX قلب الوضع: التشغيل هنا ترجمة، بس من غير ما يكتب فوق اختيار التفريغ المحفوظ
        // tr_kind بيتكتب من اختيارك الصريح بس (الإعدادات/القايمة)، مش من كل ضغطة ترجمة
        Cfg.put("tr_engine", "gem")
        try {
            val dia = TrWizard.dialectWanted().ifBlank { "فصحى" }
            val mid = if (AudioEnc.preset() == AudioEnc.NORMAL) "g_wav" else "g_aac"
            val pl = TrWizard.Plan("online", TrWizard.CURRENT, "", "", "gemini", dia = dia)
            Cfg.put("tr_mode_id", mid); SourceMode.set(SourceMode.AUDIO)
            // (v1119) الحفظ بيحتفظ باختيار التفريغ المحفوظ — التشغيل نفسه ترجمة (pl.only=false)
            val prevOnly = try { TrWizard.savedPlan()?.only ?: false } catch (_: Throwable) { false }
            val savePl = TrWizard.Plan("online", TrWizard.CURRENT, "", "", "gemini", dia = dia, only = prevOnly)
            try { TrWizard.save(savePl) } catch (e: Throwable) { LogStore.err("Player:gemSave", e) }
            runPlan(pl)
            try { applyChromeFn() } catch (_: Throwable) {}
            say("☁ ترجمة جيميناي — الباتشات بتتبعت بإعداداته (" + (if (mid == "g_wav") "WAV" else "AAC") + ")")
        } catch (e: Throwable) { LogStore.err("Player:geminiStart", e); say("تعذّر بدء ترجمة جيميناي") }
    }

    /** (v440) 🆓 ترجمة FreeLLM الصوتية: زي جيميناي فلاش لايت — الصوت بيتبعت باتشات للموديلات المجانية وبترجع الترجمة جاهزة (من غير وشبر) */
    private fun freeGemStart() {
        if (logArcPlay != null) { say("🗂 إنت بتشوف ترجمات لوج محفوظ — افتح الفيديو عادي لو عايز تترجم"); return }   // (v1167)
        if (!FreeLlm.audioReady()) { if (!needGeminiKey { freeGemStart() }) say("🆓 ضيف مفتاح جيميناي من الإعدادات ← 🔑 المفاتيح (أو رابط سيرفر FreeLLM)"); return }   // (v1101)
        try {
            val dia = TrWizard.dialectWanted().ifBlank { "فصحى" }
            val pl = TrWizard.Plan("online", TrWizard.CURRENT, "", "", "gemini", dia = dia)
            Cfg.put("tr_mode_id", Strict.FREE_GEM); SourceMode.set(SourceMode.AUDIO)
            // (v1119) نفس إصلاح geminiStart: الحفظ بيحتفظ باختيار التفريغ المحفوظ
            val prevOnly = try { TrWizard.savedPlan()?.only ?: false } catch (_: Throwable) { false }
            val savePl = TrWizard.Plan("online", TrWizard.CURRENT, "", "", "gemini", dia = dia, only = prevOnly)
            try { TrWizard.save(savePl) } catch (e: Throwable) { LogStore.err("Player:freeGemSave", e) }
            runPlan(pl)
            try { applyChromeFn() } catch (_: Throwable) {}
            say("🆓 ترجمة FreeLLM — بيلف على كل مفاتيح جيميناي وكل موديلاتها، ولو موديل/مفتاح وقف بيكمّل بالتاني")
        } catch (e: Throwable) { LogStore.err("Player:freeGemStart", e); say("تعذّر بدء ترجمة FreeLLM") }
    }


    private fun freeDialog() {
        shDialog(340) { col, close ->
            col.addView(shHead("🆓 FreeLLM", "مفاتيح مجانية · سيرفر اختياري"))
            val eg = shField("مفتاح Gemini المجاني — لو فاضي بياخد أول مفتاح عندك", Cfg.str("fl_gem_key"))
            val er = shField("مفتاح Groq المجاني (console.groq.com/keys)", Cfg.str("fl_groq_key"))
            val eu = shField("اختياري: رابط سيرفر FreeLLM (http://192.168.1.5:3000/v1)", Cfg.str("fl_url"))
            val ek = shField("اختياري: مفتاح السيرفر (LITELLM_MASTER_KEY)", Cfg.str("fl_srv_key"))
            val em = shField("اختياري: جروب/موديل السيرفر (large أو flash)", Cfg.str("fl_srv_model"))
            for (e in listOf(eg, er, eu, ek, em)) col.addView(e)
            val res = ui.text(FreeLlm.statusText(), 11.5f, 0xFF9AA0A6.toInt()).apply { setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(6)) }
            col.addView(res)
            fun saveAll() {
                Cfg.put("fl_gem_key", eg.text.toString().trim()); Cfg.put("fl_groq_key", er.text.toString().trim())
                Cfg.put("fl_url", eu.text.toString().trim().trimEnd('/')); Cfg.put("fl_srv_key", ek.text.toString().trim()); Cfg.put("fl_srv_model", em.text.toString().trim())
                FreeLlm.resetAll()
            }
            col.addView(shDuo(
                shBtn("🧪 جرّب", SH_GRAY) {
                    saveAll(); LoadUi.set(res, "⏳ بيجرّب…")
                    Thread {
                        val r = FreeLlm.test()
                        runOnUiThread { res.text = (if (r.first) "✅ " else "❌ ") + r.second + "ms — " + r.third + "\n" + FreeLlm.statusText() }
                    }.start()
                },
                shBtn("حفظ", SH_BLUE) {
                    saveAll(); close()
                    say("🆓 FreeLLM اتحفظ" + (if (FreeLlm.ready()) "" else " — ناقص مفتاح أو رابط سيرفر، مش هيشتغل لحد ما تكتبه") + " — بيتطبّق على الباتشات الجاية")
                    try { applyChromeFn() } catch (_: Throwable) {}
                }))
            col.addView(shBtn("إلغاء", SH_GRAY) { close() }, LinearLayout.LayoutParams(-1, ui.dp(42)).apply { setMargins(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) })
        }
    }

    /** (v427) ✍ تفريغ بجيميناي: النص بلغته الأصلية من غير ترجمة */
    private fun startGeminiTranscribe() {
        if (needGeminiKey { startGeminiTranscribe() }) return   // (v1101)
        Cfg.put("tr_kind", "transcribe"); Cfg.put("tr_engine", "gem")   // (v1098) T3
        val pl = TrWizard.Plan("online", "transcript", "", "", "gemini", only = true)
        Cfg.put("tr_mode_id", "ai_only"); SourceMode.set(SourceMode.AUDIO)
        try { TrWizard.save(pl) } catch (e: Throwable) { LogStore.err("Player:onQuickSave", e) }
        runPlan(pl)
    }

    // ===================== (v427) ⚙ إعدادات الوضع الحالي (بتتطبّق لايف) =====================
    private var setPop: android.widget.PopupWindow? = null

    /** الوضع الحالي: gem = ترجمة جيميناي · off = وشبر + Libre · txg = تفريغ جيميناي · txw = تفريغ وشبر */
    // ===================== (v444) إمكانيات كل وضع: الزراير والإعدادات اللي مش شغّالة في الوضع الحالي بتختفي =====================
    /** dialect = لهجة/لغة الترجمة · tone = أسلوب وعائلي/صريح/ضمائر/تنقيح (🗣) · visual = الوضع البصري 👁 · translates = بيترجم أصلًا */
    private class Caps(val dialect: Boolean, val tone: Boolean, val visual: Boolean, val translates: Boolean)
    private fun caps(mk: String = curModeKey()): Caps = when (mk) {
        "gem" -> Caps(dialect = true, tone = true, visual = true, translates = true)      // (v741) جيميناي لوحده: كل حاجة شغّالة
        "fgem" -> Caps(dialect = true, tone = true, visual = true, translates = true)     // صوت ← جيميناي (FreeLLM): كل حاجة شغّالة
        "free" -> Caps(true, true, false, true)                                   // وشبر + مترجم LLM: لهجات وأسلوب
        "off" -> Caps(false, false, false, true)                                          // وشبر + LibreTranslate: فصحى حرفية بس
        else -> Caps(false, false, false, false)                                          // تفريغ بس: مفيش ترجمة
    }
    private fun modeName(mk: String = curModeKey()): String = when (mk) {
        "gem" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "⚡ جروك + جيميناي (" else "☁ جيميناي لوحده (") + (if (AudioEnc.preset() == AudioEnc.NORMAL) "WAV" else "AAC") + ")"; "fgem" -> "⭐ FreeLLM · صوت ← جيميناي"; "free" -> "🌗 وشبر + FreeLLM"   // (v1371) تفريغ جروك باسمه
        "off" -> "📴 وشبر + ترجمة أوفلاين (فصحى)"; "txg" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "✍ تفريغ بـ Groq ⚡" else "✍ تفريغ بجيميناي"); else -> "✍ تفريغ بوشبر"   // (v1371) جروك باسمه
    }
    private var trAiB: TextView? = null
    private var lastCapsSig = ""
    /** بيخفي/بيظهر الأزرار حسب الوضع (🌐 اللغة · 🗣 الأسلوب · 👁 البصري) — بيتنادى مع كل updateTr */
    private fun applyModeCaps() {
        try {
            val c = caps()
            trLgB?.visibility = if (c.dialect) View.VISIBLE else View.GONE
            trAiB?.visibility = if (c.tone) View.VISIBLE else View.GONE
            val sig = "" + c.dialect + c.tone + c.visual
            if (sig != lastCapsSig) { lastCapsSig = sig; try { applyChromeFn() } catch (_: Throwable) {} }
        } catch (_: Throwable) {}
    }
    /** المترجم المختار لوضع «وشبر»: free (لهجات) · google (LibreTranslate فصحى). الافتراضي أحسن واحد جاهز */
    private fun wTr(): String {
        val c = Cfg.str("wtr").trim()
        if (c == "free" && FreeLlm.ready()) return "free"
        if (c == "google") return "google"
        return if (FreeLlm.ready()) "free" else "google"
    }
    private fun wTrLabel(id: String = wTr()): String = when (id) { "free" -> "FreeLLM · لهجات"; else -> "LibreTranslate · فصحى" }
    private fun whisperStart() { askVideoLang { offlineQuick() } }
    /** تبديل مترجم وضع وشبر والمحرك شغّال: بيتطبّق على الباتشات الجاية بنفس لغة الفيديو وموديل وشبر */
    private fun setWhisperTr(kind: String) {
        if (kind == "free" && !FreeLlm.ready()) { say("🆓 FreeLLM محتاج مفتاح جيميناي (أو Groq) — ضيفه من الإعدادات ← 🔑 المفاتيح"); return }
        Cfg.put("wtr", kind)
        Cfg.put("tr_mode_id", when (kind) { "free" -> Strict.FREE_TXT; else -> Strict.SEMI })
        liveOffline(null, null)
        say("🌗 المترجم بقى " + wTrLabel(kind) + " — من الباتش الجاي")
        updateTr()
    }

    /** (v445) خلفية القوايم المنسدلة: زجاج غامق بتدرّج + حد فاتح ورفيع بدل المستطيل المسطّح */
    private fun glassPanelBg(): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, if (MtGlass.on()) intArrayOf(0xE62C2C2C.toInt(), 0xEB0C0C0C.toInt()) else intArrayOf(0xF2141414.toInt(), 0xF5101017.toInt())).apply {   // (v894) موبايل: زجاج MeeTube — استدارة 24 + حافة مضيئة
        cornerRadius = ui.dp(if (MtGlass.on()) 24 else 18).toFloat(); setStroke(maxOf(1, if (MtGlass.on()) MtGlass.hair(ui.ctx.resources.displayMetrics.density) else ui.dp(1)), if (MtGlass.on()) 0x3DFFFFFF else 0x33FFFFFF)
    }
    /** (v450) اسم الوضع الحالي مختصر على زرار «ترجم» عشان تعرف الوضع من غير ما تفتح القايمة */
    private fun modeShort(): String = when (curModeKey()) {
        "off" -> "🌗 وشبر"; "free" -> "🆓 وشبر+Free"; "gem" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "⚡ جروك+☁" else "☁ جيميناي"); "fgem" -> "🆓 FreeLLM"   // (v1371) جروك باسمه
        "txg" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "✍ تفريغ ⚡" else "✍ تفريغ ☁"); "txw" -> "✍ تفريغ وشبر"; else -> "تلقائي"   // (v1371) جروك باسمه
    }
    private fun curModeKey(): String {
        val id = Strict.id()
        if (id == "g_wav" || id == "g_aac") return "gem"   // (v741) جيميناي لوحده رجع نظام مستقل (v444 كان دمجه مع FreeLLM)
        if (id == Strict.SEMI || id == Strict.MT) return "off"
        if (id == "ai_only") return "txg"
        if (id == "w_only") return "txw"
        val sp = TrWizard.savedPlan()
        if (sp != null) return if (sp.offline) (if (sp.only) "txw" else "off") else (if (sp.only) "txg" else "gem")
        return if (Cfg.bool("stt_offline", false)) "off" else "gem"
    }

    /** يطبّق الإعدادات الحالية على المحرك الشغّال من غير ما يبدأ ولا يعيد حاجة */
    private fun liveConf() {
        try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:liveConf", e) }
    }

    /** لغة الفيديو / موديل وشبر بتتغيّر والمحرك شغّال: بتتحفظ وبتتطبّق على الباتشات الجاية (واللغة بتصلّح اللي اتفرّغ بلغة غلط) */
    private fun liveOffline(newLang: String?, newModel: String?) {
        val oldLang = Offline.lang()
        val lang = newLang ?: oldLang
        val mdl = newModel ?: Offline.model().id
        val only = curModeKey() == "txw"
        val freeMode = curModeKey() == "free"   // (v440) وضع وشبر + FreeLLM: نفس الكلام
        val pl = TrWizard.Plan("offline", "", lang, mdl, "google", "whisper", if (only) "" else if (freeMode) TrWizard.dialectWanted().ifBlank { "فصحى" } else "فصحى", false, free = if (only) "" else if (freeMode) "free" else "", only = only)
        try { TrWizard.save(pl) } catch (e: Throwable) { LogStore.err("Player:liveOffSave", e) }
        try { runPlanCore(pl, false) } catch (e: Throwable) { LogStore.err("Player:liveOff", e) }
        if (lang != oldLang) {
            try {
                if (::engine.isInitialized && (engineStarted || engine.subs.isNotEmpty())) {
                    engine.langChanged(lang, player.currentPosition.coerceAtLeast(0) / 1000.0)
                    say("🌐 لغة الفيديو بقت " + TrWizard.langLabel(lang) + " — بكمّل من مكانك وبعيد الباتشات اللي اتفرّغت بلغة غلط")
                } else say("🌐 لغة الفيديو بقت " + TrWizard.langLabel(lang))
            } catch (e: Throwable) { LogStore.err("Player:langChanged", e) }
        }
        try { applyChromeFn() } catch (_: Throwable) {}
    }

    private fun pickWhisperModel(m: Offline.Model) {
        if (!WhisperLib.loaded) { say("📴 الأوفلاين مش مدعوم على جهازك"); return }
        if (Offline.downloaded(m)) { liveOffline(null, m.id); say("🎧 موديل وشبر: " + m.label + " — بيتطبّق على الباتشات الجاية"); return }
        if (Offline.downloading()) { say("⬇ فيه تنزيل موديل شغّال — استنى يخلص وادوس تاني"); return }
        shConfirm("⬇ تنزيل موديل " + m.label, "الموديل ده مش نازل (~" + m.approxMb + " ميجا، مرة واحدة، محتاج نت). تنزّله وتطبّقه؟",
            listOf(ShBtn("⬇ نزّل وطبّق", SH_BLUE) {
                say("⬇ بنحمّل موديل " + m.label + "…")
                Offline.download(m, { a, t -> runOnUiThread { Notice.show(this, "⬇ موديل التفريغ: " + (a / 1048576) + " / " + (t / 1048576) + " ميجا", 900L) } }) { e ->
                    runOnUiThread { if (e != null) say("⚠ تنزيل الموديل فشل: $e") else { liveOffline(null, m.id); say("✅ موديل " + m.label + " نزل واتطبّق") } }
                }
            }, ShBtn("إلغاء", SH_GRAY) { }))
    }


    /** (v762) أوامر ورقة ⚙ إعدادات الترجمة اللي على الموبايل — بتتطبّق هنا من غير ما تفتح أي قايمة على شاشة التلفزيون */
    private fun remoteMset(c: String) {
        val k = c.substringBefore(':'); val v = c.substringAfter(':', "")
        when (k) {
            "lang" -> if (v in Offline.langIds && v != Offline.lang()) liveOffline(v, null)
            "model" -> Offline.models.firstOrNull { it.id == v }?.let { m -> if (m.id != Offline.model().id) pickWhisperModel(m) }
            "aud" -> {
                val wav = v == "wav"
                Cfg.put(AudioEnc.PRESET_KEY, if (wav) AudioEnc.NORMAL else AudioEnc.FAST)
                if (wav && Strict.id() == "g_aac") Cfg.put("tr_mode_id", "g_wav") else if (!wav && Strict.id() == "g_wav") Cfg.put("tr_mode_id", "g_aac")
                say("🎧 جودة الصوت: " + (if (wav) "WAV" else "AAC (داتا أقل)") + " — الباتشات الجاية")
            }
            "dual" -> { val n = (v.toIntOrNull() ?: 1).coerceIn(0, 2); Cfg.put("dual_listen", n.toString()); say("🎯 التسميع المزدوج: " + kotlin.collections.listOf("مقفول", "ذكي (غير الإنجليزي)", "دايمًا")[n]) }
            "swap" -> { val on = Cfg.str("tr_autoswap", "on") != "off"; Cfg.put("tr_autoswap", if (on) "off" else "on"); say("🔄 البديل التلقائي: " + (if (on) "اتقفل" else "اتفتح")) }
            "term" -> { val on = TermNotes.enabled(); Cfg.put("term_notes", if (on) "off" else "on"); say("📖 نبذة المصطلحات: " + (if (on) "اتقفلت" else "اتفتحت")) }
        }
    }

    /** (v740) ⚙ إعدادات الترجمة: صفحة رئيسية (صف لكل قسم بقيمته الحالية) + صفحة لكل قسم. كل تغيير بيتطبّق فورًا من غير إعادة */
    fun modeSettings(anchor: View, page: String? = null) {
        setPop?.let { if (it.isShowing) { it.dismiss(); setPop = null; return } }
        val mk = curModeKey()
        val col = LinearLayout(this)
        fun go(p: String?) { setPop?.dismiss(); h.post { modeSettings(anchor, p) } }
        fun cLp() = shChipLp()
        val keysN = try { Cfg.keys("keys").size + Cfg.keys("extra").size + Cfg.keys("backup").size } catch (_: Throwable) { 0 }

        fun audioSection() {
            col.addView(shHead("🎧 جودة الصوت المرفوع لجيميناي", "AAC بيوفّر داتا · WAV أدق"))
            val wavNow = AudioEnc.preset() == AudioEnc.NORMAL
            val r = shFlow()
            r.addView(shChip("🧠 عادي (WAV)", wavNow) {
                setPop?.dismiss(); Cfg.put(AudioEnc.PRESET_KEY, AudioEnc.NORMAL); if (Strict.id() == "g_aac") Cfg.put("tr_mode_id", "g_wav")
                say("🎧 جودة الصوت: WAV — الباتشات الجاية هتترفع بيها")
            }, cLp())
            r.addView(shChip("🧠 توفير داتا (AAC)", !wavNow) {
                setPop?.dismiss(); Cfg.put(AudioEnc.PRESET_KEY, AudioEnc.FAST); if (Strict.id() == "g_wav") Cfg.put("tr_mode_id", "g_aac")
                say("🎧 جودة الصوت: AAC (داتا أقل) — الباتشات الجاية هتترفع بيها")
            }, cLp())
            col.addView(r, LinearLayout.LayoutParams(-1, -2))
            // (v742) تسميع مزدوج: مفتاح تاني يسمع نفس الباتش وأي اختلاف يتحسم بسماع تالت على الجملة
            col.addView(shHead("🎯 تدقيق السماع بمفتاحين", "مفتاح تاني بيسمع نفس الباتش، والجمل اللي اختلفوا فيها بتتسمع تالت"))
            val dl = Cfg.int("dual_listen", 1)
            val r2 = shFlow()
            r2.addView(shChip("⛔ مقفول", dl == 0) { setPop?.dismiss(); Cfg.put("dual_listen", "0"); say("🎯 التسميع المزدوج: مقفول") }, cLp())
            r2.addView(shChip("🌍 ذكي (غير الإنجليزي)", dl == 1) { setPop?.dismiss(); Cfg.put("dual_listen", "1"); say("🎯 التسميع المزدوج: شغّال للغات غير الإنجليزي") }, cLp())
            r2.addView(shChip("🔁 دايمًا", dl == 2) { setPop?.dismiss(); Cfg.put("dual_listen", "2"); say("🎯 التسميع المزدوج: شغّال لكل الباتشات") }, cLp())
            col.addView(r2, LinearLayout.LayoutParams(-1, -2))
            col.addView(shNote("بيستهلك طلبات جيميناي أكتر (باتش واحد = طلبين + سماعات قصيرة للخلافات). محتاج مفتاحين على الأقل."))
        }
        fun keysSection() {
            col.addView(shHead("🔑 مفاتيح جيميناي", "$keysN مفتاح" + (if (mk == "fgem") " · كل مفتاح بيلف على كل الموديلات · ٧٥٪ بتنسخ و٢٥٪ بتترجم بالسياق" else if (mk == "gem") " · ٧٥٪ بتنسخ و٢٥٪ بتترجم بالسياق" else "")))
            col.addView(shRow("➕ ضيف مفتاح جيميناي") {
                setPop?.dismiss()
                showKeyGuide { k ->
                    val cur = Cfg.keys("keys")
                    if (k in cur || k in Cfg.keys("extra") || k in Cfg.keys("backup")) Notice.show(this, "⚠ المفتاح ده موجود قبل كده", 2600L)
                    else { Cfg.p.edit().putString("keys", (cur + k).joinToString("\n")).apply(); Notice.show(this, "✓ اتحفظ المفتاح وبقى شغّال", 2200L); liveConf() }
                }
            })
        }
        fun langSection() {
            val curL = Offline.lang()
            col.addView(shHead("🌍 لغة كلام الفيديو", "بتتفرّغ بيها — لو غلط الترجمة هتطلع غلط"))
            whisperAdvice(curL)?.let { col.addView(shNote(it.first, true)) }   // (v739)
            col.addView(shLangFlow(curL) { id ->
                setPop?.dismiss()
                if (id != curL) {
                    liveOffline(id, null)
                    // (v739) اللغة الجديدة مع موديل ضعيف: اسأل يغيّر الموديل بدل ما يسكت
                    whisperAdvice(id)?.let { a -> h.post { askWhisperAdvice(id, Offline.model(), a, { }, { r -> pickWhisperModel(r) }) } }
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }
        fun modelSection() {
            val curM = Offline.model()
            val adv = whisperAdvice(Offline.lang())
            col.addView(shHead("🎧 موديل وشبر", "الأكبر أدق وأبطأ · ⬇ = مش نازل · ⭐ = المقترح للغة"))
            adv?.let { col.addView(shNote(it.first, true)) }   // (v739)
            val rm = shFlow()
            for (m in Offline.models) rm.addView(shChip(m.label + (if (adv != null && m.id == adv.second) " ⭐" else "") + (if (Offline.downloaded(m)) "" else " ⬇"), m.id == curM.id) { setPop?.dismiss(); if (m.id != curM.id) pickWhisperModel(m) }, cLp())
            col.addView(rm, LinearLayout.LayoutParams(-1, -2))
            col.addView(shNote(curM.note))
        }
        fun translatorSection() {
            col.addView(shHead("🔤 المترجم (بعد تفريغ وشبر)", "FreeLLM بيدّي لهجات · Libre فصحى حرفية"))
            val r = shFlow()
            for ((id, lb) in listOf("free" to "🆓 FreeLLM · لهجات", "google" to "🌐 LibreTranslate · فصحى")) {
                val on = (mk == "free" && id == "free") || (mk == "off" && id == "google")
                r.addView(shChip(lb, on) { setPop?.dismiss(); if (!on) setWhisperTr(id) }, cLp())
            }
            col.addView(r, LinearLayout.LayoutParams(-1, -2))
        }
        fun freeSection() {
            col.addView(shHead("🆓 FreeLLM", "الشغّال دلوقتي: " + FreeLlm.liveName()))
            col.addView(shNote(if (curModeKey() == "fgem" && FreeLlm.serverUrl().isEmpty()) FreeLlm.rotationText() else FreeLlm.statusText()))
            col.addView(shRow("🆓 إعدادات FreeLLM (مفاتيح · سيرفر · تجربة)", "", true) { setPop?.dismiss(); freeDialog() })
        }
        fun termRow() {
            val tnOn = TermNotes.enabled()
            col.addView(shRow("📖 نبذة المصطلحات الطبية", if (tnOn) "✅ شغّال" else "⏸ مقفول") {
                setPop?.dismiss(); Cfg.put("term_notes", if (tnOn) "off" else "on"); say("📖 نبذة المصطلحات: " + (if (tnOn) "اتقفلت" else "اتفتحت"))
            })
        }

        if (page == null) {
            // ---- الصفحة الرئيسية: صف لكل قسم بقيمته ----
            val head = when (mk) { "gem" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "⚡ جروك + جيميناي" else "☁ جيميناي لوحده"); "off" -> "🌗 وشبر + LibreTranslate"; "free" -> "🆓 وشبر + FreeLLM"; "fgem" -> "⭐ FreeLLM · صوت ← جيميناي"; "txg" -> (if (Cfg.str("mt_tr_mode", "") == "groq") "⚡ تفريغ Groq" else "☁ تفريغ جيميناي"); else -> "📴 تفريغ وشبر" }   // (v1371) جروك باسمه
            col.addView(shHead("🔧 متقدم", head + " · بتتطبّق فورًا وانت شغّال"))
            col.addView(shRow("→ رجوع لإعدادات الترجمة") { setPop?.dismiss(); h.post { trSettings(anchor) } })
            val warnLang = try { whisperAdvice(Offline.lang()) != null } catch (_: Throwable) { false }
            if (caps(mk).dialect) col.addView(shRow("🌐 اللهجة والأسلوب", Cfg.str("conv_dialect", "").ifBlank { "فصحى" }, true) { setPop?.dismiss(); langPopup(anchor) })
            else col.addView(shNote(if (caps(mk).translates) "الوضع ده بيترجم فصحى حرفية بس — للهجات اختار مترجم FreeLLM" else "مفيش ترجمة في الوضع ده (تفريغ بس)"))
            fun hLang() = col.addView(shRow("🌍 لغة الفيديو", TrWizard.langLabel(Offline.lang()) + (if (warnLang) " ⚠" else ""), true, warnLang) { go("lang") })
            fun hModel() = col.addView(shRow("🎧 موديل وشبر", Offline.model().label + (if (warnLang) " ⚠" else ""), true, warnLang) { go("model") })
            fun hTr() = col.addView(shRow("🔤 المترجم", wTrLabel(if (mk == "free") "free" else "google"), true) { go("tr") })
            fun hAudio() = col.addView(shRow("🎧 جودة الصوت", if (AudioEnc.preset() == AudioEnc.NORMAL) "WAV" else "AAC", true) { go("audio") })
            fun hKeys() = col.addView(shRow("🔑 مفاتيح جيميناي", "$keysN", true) { go("keys") })
            fun hFree() = col.addView(shRow("🆓 FreeLLM", FreeLlm.liveName().take(20), true) { go("free") })
            fun swapRow() {
                val swapOn = Cfg.str("tr_autoswap", "on") != "off"
                col.addView(shRow("🔄 بديل تلقائي لو جيميناي وقف", if (swapOn) "✅ شغّال" else "⏸ مقفول") {
                    setPop?.dismiss(); Cfg.put("tr_autoswap", if (swapOn) "off" else "on"); say("🔄 البديل التلقائي: " + (if (swapOn) "اتقفل" else "اتفتح"))
                })
            }
            when (mk) {
                "gem" -> {
                    hAudio(); hKeys(); swapRow()
                    col.addView(shNote("🧠 الموديل: " + Cfg.str("model", Models.DEFAULT).ifBlank { Models.DEFAULT } + " (ثابت)"))
                    termRow()
                }
                "fgem" -> { hAudio(); hKeys(); hFree(); swapRow() }
                "free" -> { hTr(); hLang(); hModel(); hFree(); termRow() }
                "off" -> {
                    hLang(); hModel()
                    col.addView(shSection("📴 موديل الترجمة الأوفلاين (للعربي بس)"))
                    col.addView(shNote(LocalMt.status()))
                    if (!LocalMt.downloaded()) col.addView(shRow("⬇ نزّل موديل الترجمة", "~" + LocalMt.model().approxMb + " ميجا") { setPop?.dismiss(); mtDownload { } })
                }
                "txg" -> { hAudio(); hKeys() }
                else -> { hLang(); hModel() }
            }
        } else {
            // ---- صفحة قسم واحد ----
            col.addView(shRow("→ رجوع للإعدادات") { go(null) })
            when (page) {
                "lang" -> langSection()
                "model" -> modelSection()
                "tr" -> translatorSection()
                "audio" -> audioSection()
                "keys" -> keysSection()
                "free" -> freeSection()
            }
        }
        setPop = showSheet(anchor, col, 340, "modeSettings") { pw -> if (setPop === pw) setPop = null }
    }

    private var redoKeep = true
    /** (v740) 🔁 إعادة الترجمة: من الأول / من الباتش ده وبعده / الباتش ده بس / باتش معين — مع اختيار نحتفظ بالقديمة (🗂) ولا نمسحها */
    /** (v1374 — بطلب علي: «امسحها بالكامل من الكود واعمل واحدة جديدة») شيت إعادة الترجمة الجديد — اتكتب من الصفر بدل القديم اللي كان بيختفي */


    /** يوقف المشغّل خالص، يسلّم الترجمة لخدمة الخلفية (إشعار بالتقدم والوقت المتبقي) ويطلع بره التطبيق من غير ما يقفله */
    fun translateInBackground(goHome: Boolean = true, src: String = "المشغّل (زرار 🌙)") {
        if (Cfg.allMainKeys().isEmpty() && conf.keys.isEmpty() && conf.backup.isEmpty()) { say("ضيف مفتاح API الأول"); return }
        if (incognito) { say("🕶 الترجمة بالخلفية مش متاحة في التخفي"); return }
        if (remote) { say("🌙 الترجمة بالخلفية مش متاحة وانت متحكم في التلفزيون — الترجمة شغّالة على التلفزيون نفسه"); return }   // (v568)(v1196) كان بيرجع بصمت
        if (handedOff) { say("🌙 الترجمة بالفعل شغّالة في الخلفية"); return }   // (v1196)
        handedOff = true
        closeSide(); resumePending = false
        say(if (src.contains("تلقائي")) "🌙 كمّلت الترجمة في الخلفية لأن ✔ «كمّل في الخلفية لما أخرج» مفعّل (من فوق في المشغّل) — تقفله من نفس الزرار" else "🌙 هكمّل الترجمة في الخلفية — التقدم في الإشعارات")
        try { player.pause() } catch (e: Exception) { LogStore.err("Main:1017", e) }
        saveRecentForce()
        val vidNow = vid; val uriS = uri?.toString(); val urlS = aurl ?: url; val hdrC = HashMap(hdr)
        val app = applicationContext
        val eng = engine
        Thread {
            try { eng.stop(); eng.awaitStopped(4000); eng.saveNow() } catch (e: Exception) { LogStore.err("Main:1023", e) }
            BgJobs.enqueue(app, BgJob(vidNow, Recents.titleOf(vidNow), uriS, urlS, hdrC), src)
        }.start()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            try { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 12) } catch (e: Exception) { LogStore.err("Main:1027", e) }
        }
        if (goHome) try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { LogStore.err("Main:1029", e) }
        try { pipOv?.hide(); pipOv = null } catch (_: Throwable) {}
        if (!goHome && !pipNow()) returnToOrigin()   // (v339)
        if (pipNow()) finishAndRemoveTask() else finish()   // (v149) من نافذة الـ PiP: يشيل النافذة خالص
    }

    /** (v149) وضع «صوت بس» (من زرار الـ PiP): يشيل نافذة الـ PiP ويسيب الفيديو شغّال كصوت في الخلفية، ويوقف الترجمة */
    private var audioOnlyMode = false
    fun audioOnly() {
        audioOnlyMode = true
        try { window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } catch (_: Throwable) {}   // (v468) وضع الصوت بس: الشاشة تنام عادي — الفلاج يرجع في onResume
        try { pipOv?.hide(); pipOv = null } catch (_: Throwable) {}
        try { if (!incognito) saveRecentForce() } catch (e: Exception) { LogStore.err("Player:audioOnly1", e) }
        val eng = engine
        try { retireEngine() } catch (e: Throwable) { LogStore.err("Player:audioOnly2", e) }   // وقف الترجمة (لو شغّالة)
        Thread { try { eng.awaitStopped(3000); eng.saveNow() } catch (e: Throwable) { LogStore.err("Player:audioOnly3", e) } }.start()
        try { if (!player.isPlaying) player.play() } catch (e: Exception) { LogStore.err("Player:audioOnly4", e) }
        try { moveTaskToBack(true) } catch (e: Exception) { LogStore.err("Player:audioOnly5", e) }
    }

    /** (v149) إيقاف نهائي (من زرار الـ PiP): يحفظ التقدم، يوقف الفيديو والمحرك وكل الترجمة في الخلفية والإشعارات، ويطلّع التطبيق من الرام */
    fun fullStop() {
        if (remote) { rmFrames = false; try { pipOv?.hide(); pipOv = null } catch (_: Throwable) {}; finishAndRemoveTask(); return }   // (v568)
        try { player.pause() } catch (e: Exception) { LogStore.err("Player:fullStop1", e) }
        try { if (!handedOff) saveRecentForce() } catch (e: Exception) { LogStore.err("Player:fullStop2", e) }
        try { pipOv?.hide(); pipOv = null } catch (_: Throwable) {}
        handedOff = true   // عشان onDestroy ما يحفظش تاني ولا يشغّل ترجمة خلفية
        val eng = engine; val app = applicationContext
        Thread {
            try { eng.stop(); eng.awaitStopped(3000); eng.saveNow() } catch (e: Throwable) { LogStore.err("Player:fullStop3", e) }
            try { BgJobs.jobs.filter { it.active }.forEach { BgJobs.stopAndWait(it.vid, 3000L) } } catch (e: Throwable) { LogStore.err("Player:fullStop4", e) }
            try { app.stopService(Intent(app, BgService::class.java)); app.stopService(Intent(app, KeepAliveService::class.java)) } catch (_: Throwable) {}
            try { Thread.sleep(300) } catch (_: InterruptedException) {}
            android.os.Process.killProcess(android.os.Process.myPid())
        }.start()
        finishAndRemoveTask()
    }

    // ===== حفظ SRT تلقائي جنب الفيديو لما الترجمة تخلص (أو لما تعدّل التزامن بعدها) =====
    var offFsB: TextView? = null
    private var lastSrtN = -1
    private var lastSrtOff = Long.MIN_VALUE
    private var srtToastShown = false   // (v104) إشعار «اتحفظ SRT» مرة واحدة بس في الجلسة
    private val srtRun = Runnable { srtCheck() }
    fun srtSoon() { h.removeCallbacks(srtRun); h.postDelayed(srtRun, 2500) }
    private fun srtCheck() {
        val u = uri?.toString() ?: return
        if (durMs <= 0 || engine.subs.isEmpty() /* (v229) حفظ SRT أوتوماتيك دايمًا */) return
        if (PlayerLogic.percent(engine.coveredSec(), durMs / 1000.0) < 97) return
        val n = engine.subs.size
        if (n == lastSrtN && offsetMs == lastSrtOff) return
        lastSrtN = n; lastSrtOff = offsetMs
        val subsNow = engine.subs; val off = offsetMs; val app = applicationContext
        Thread { SrtWriter.save(app, u, subsNow, off)?.let { p -> runOnUiThread { log("💾 اتحفظ SRT: $p"); if (!srtToastShown) { srtToastShown = true; say("💾 اتحفظ SRT جنب الفيديو") } } } }.start()
    }

    // ===== (v167) السلايدر الموحّد للصوت: 0..100% صوت عادي، 100..200% تضخيم (أحمر) — LoudnessEnhancer على جلسة صوت المشغّل (الجزء الزيادة 0..100 = لحد +15dB) =====
    /** (v270) 0..100 = صوت النظام (زراري الفوليوم)، 100..200 = تضخيم والنظام على الآخر */
    fun volTotal(): Int {
        val b = (Cfg.str("vol_boost", "0").toIntOrNull() ?: 0).coerceIn(0, 100)
        // (v604) على الأجهزة اللي صوتها ثابت، صوت النظام بيرجع دايمًا 100 — فالقيمة الحقيقية هي صوت المشغّل نفسه
        val fixed = !remote && try { (getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager).isVolumeFixed } catch (_: Throwable) { false }
        val s = if (fixed) Math.round(player.volume * 100f).coerceIn(0, 100) else SysVol.get(this)
        return if (b > 0 && s >= 100) 100 + b else s
    }
    private var volWatch: SysVol.Watch? = null
    fun setBoostPct(b: Int) { Cfg.put("vol_boost", b.coerceIn(0, 100).toString()); applyBoost() }
    fun boostDbText(b: Int) = "+" + "%.1f".format(b * 0.15) + " dB"
    private var loud: android.media.audiofx.LoudnessEnhancer? = null
    fun applyBoost() {
        val pct = (Cfg.str("vol_boost", "0").toIntOrNull() ?: 0).coerceIn(0, 100)
        try {
            if (!::player.isInitialized) return
            val sid = player.exo()?.audioSessionId ?: return
            if (sid == androidx.media3.common.C.AUDIO_SESSION_ID_UNSET || sid == 0) return
            if (loud == null) loud = android.media.audiofx.LoudnessEnhancer(sid)
            loud?.setTargetGain(pct * 15)
            loud?.enabled = pct > 0
        } catch (e: Throwable) { LogStore.err("boost", e) }
    }

    // ===== PiP =====
    private var inPip = false
    private var resumedNow = false
    private var pipOv: PipSubBar? = null
    private var stoppedNow = true   // (v1364) للتمييز بين ✕ الـPiP (onStop) والتوسيع (يفضل started)
    private val pipExitCheck = Runnable { if (!resumedNow && stoppedNow && !isFinishing && !audioOnlyMode) closeAfterPip() }   // (v1364 — ببلاغ علي: «دوسة الـPiP بتقفل التطبيق ساعات») السباق: لو onResume اتأخر عن 500ms كان closeAfterPip بيقفل التاسك كله — دلوقتي لازم الأكتيفيتي تكون متوقفة فعلًا
    fun pipNow() = inPip || (Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode)
    private fun closeAfterPip() {
        if (remote) { pipOv?.hide(); pipOv = null; finishAndRemoveTask(); return }   // (v568) مايوقفش التلفزيون
        try { player.pause() } catch (e: Exception) { LogStore.err("Main:1057", e) }
        pipOv?.hide(); pipOv = null
        finishAndRemoveTask()
    }
    // القايمة الجانبية (الأفقي)
    lateinit var sideMenuV: FrameLayout
    lateinit var sidePanel: LinearLayout
    var sideOpen = false
    fun closeSide() { sideOpen = false; if (::sideMenuV.isInitialized) sideMenuV.visibility = View.GONE }

    // ===== Host =====
    override fun log(s: String) {
        status = s
        if (BrainBus.active()) BrainBus.post("log", s)
        synchronized(logBuf) {
            logBuf.append(fmtMs(cur)).append("  ").append(s).append('\n')
            if (logBuf.length > 30000) logBuf.delete(0, 10000)
        }
        LogArchive.append(arcRun, fmtMs(cur) + "  " + s)
        LogStore.add(fmtMs(cur) + "  " + s)
    }
    private var lastBeat = 0L

    // ===== (v452) مؤقت النوم للفيديو: بعد 5-60 دقيقة أو لما الفيديو يخلص — الصوت بينزل تدريجيًا في آخر 4 ثواني وبعدها يقف =====
    private var sleepAtMs = 0L
    private var sleepEndOfVideo = false
    private val sleepTick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed || sleepAtMs <= 0L) return
            val left = sleepAtMs - System.currentTimeMillis()
            if (left <= 0L) { sleepFire(); return }
            if (left <= 10000L) { try { player.volume = (left / 10000f).coerceIn(0f, 1f) } catch (_: Throwable) {} }   // (v469) الخفوت التدريجي بقى في آخر 10 ثوانٍ (كان 4)
            h.postDelayed(this, if (left <= 10000L) 200L else 1000L)
        }
    }
    private fun sleepFire() {
        sleepAtMs = 0L; sleepEndOfVideo = false
        try { player.pause() } catch (_: Throwable) {}
        try { player.volume = 1f } catch (_: Throwable) {}
        say("😴 مؤقت النوم: الفيديو وقف")
    }
    /** min > 0 = بعد كذا دقيقة · -1 = لما الفيديو يخلص · 0 = إلغاء */
    private fun setSleepTimer(min: Int) {
        h.removeCallbacks(sleepTick)
        sleepAtMs = 0L; sleepEndOfVideo = false
        try { player.volume = 1f } catch (_: Throwable) {}
        if (min > 0) { sleepAtMs = System.currentTimeMillis() + min * 60_000L; h.postDelayed(sleepTick, 1000L) }
        else if (min < 0) sleepEndOfVideo = true
    }
    private fun sleepDialog() {
        var dlg: android.app.Dialog? = null
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) }
        fun add(label: String, on: Boolean, f: () -> Unit) {
            col.addView(ui.text(label, 15f, th.text, on).apply {
                gravity = Gravity.CENTER; setPadding(ui.dp(10), ui.dp(12), ui.dp(10), ui.dp(12))
                background = ui.box(if (on) Glass.alpha(th.primary, 0x44) else 0x14808080, if (on) th.primary else th.border, 12)
                setOnClickListener { f(); dlg?.dismiss() }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ui.dp(6) })
        }
        val leftMin = if (sleepAtMs > 0L) ((sleepAtMs - System.currentTimeMillis() + 59_999L) / 60_000L).toInt().coerceAtLeast(1) else 0
        if (sleepAtMs > 0L || sleepEndOfVideo) add("🚫 إلغاء المؤقت" + (if (leftMin > 0) " (فاضل $leftMin د)" else ""), false) { setSleepTimer(0); say("المؤقت اتلغى") }
        for (m in intArrayOf(5, 10, 15, 30, 45, 60)) add("⏱ بعد $m دقيقة", false) { setSleepTimer(m); say("😴 الفيديو هيقف بعد $m دقيقة (والصوت بينزل بهدوء)") }
        add("🎬 لما الفيديو ده يخلص", sleepEndOfVideo) { setSleepTimer(-1); say("😴 الفيديو هيقف في آخره (من غير ما يكمّل اللي بعده)") }
        dlg = ui.sheet(this, "😴 مؤقت النوم", listOf<View>(col)); dlg?.show()
    }
    // (v125) حفظ مكان الوقوف كل 3 ثواني (كان بيتحفظ عند الخروج بس → بعد PiP / تحديث النسخة بيرجع لمكان قديم)
    private var lastPosSave = 0L
    private var lastRecentSave = 0L
    private var lastLogLen = -1
    private var lastBatchTxt = ""
    private var lastCountersTxt = ""   // (v458) كاش نص العدّادات
    /** (v146) نص الباتشات (مفتاح · موديل · زمن الرد) والأسرع في كل دفعة أخضر */
    private fun batchStyled(): CharSequence {
        val sb = android.text.SpannableStringBuilder()
        val ftRows = try { fastTr?.takeIf { it.running && it.total > 0 }?.batchRows(engine.chunkOfSec(cur / 1000.0)) } catch (_: Throwable) { null }   // (v1141) المتوازن: صفوفه هو (⏳ اتبعت لجيميناي · مفتاح · وقت)
        for ((t, fast) in (ftRows ?: engine.batchRows())) {
            if (sb.isNotEmpty()) sb.append('\n')
            val a = sb.length; sb.append(t)
            if (fast) sb.setSpan(android.text.style.ForegroundColorSpan(0xFF2ECC71.toInt()), a, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }
    private var miniLog: View? = null
    private var miniLogTv: TextView? = null
    fun closeMiniLog() {
        miniLog?.let { p -> try { (p.parent as? ViewGroup)?.removeView(p) } catch (_: Exception) {} }
        miniLog = null; miniLogTv = null
    }
    /** (v125) اللوج الصغير: بيوضّح أنهي باتش بيترجم دلوقتي (دوس على عداد الجمل) — بيتحدّث لوحده ويتسكرول */
    fun toggleMiniLog() {
        if (miniLog != null) { closeMiniLog(); return }
        val tv = IconTextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; typeface = android.graphics.Typeface.MONOSPACE
            setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(8)); layoutDirection = View.LAYOUT_DIRECTION_RTL
            text = batchStyled().ifBlank { "مفيش باتشات لسه — دوس ▶ ترجمة" }
        }
        miniLogTv = tv
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; isClickable = true
            background = ui.box(0xEE101418.toInt(), 0x33FFFFFF, 12)
        }
        val head = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(10), ui.dp(6), ui.dp(4), ui.dp(2)) }
        head.addView(ui.text("📋 الباتشات — بيترجم دلوقتي", 12f, th.primary, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(IconTextView(this).apply { text = "✕"; textSize = 16f; setTextColor(Color.WHITE); setPadding(ui.dp(10), ui.dp(2), ui.dp(8), ui.dp(2)); setOnClickListener { closeMiniLog() } })
        col.addView(head)
        col.addView(MaxHeightScroll(this, (resources.displayMetrics.heightPixels * 0.42f).toInt()).apply { addView(tv, FrameLayout.LayoutParams(-1, -2)) }, LinearLayout.LayoutParams(-1, -2))
        val w = minOf(ui.dp(270), resources.displayMetrics.widthPixels - ui.dp(28))
        videoBoxRef.addView(col, FrameLayout.LayoutParams(w, -2, Gravity.TOP or Gravity.RIGHT).apply { setMargins(0, ui.dp(48), ui.dp(66), 0) })   // (v265) تحت الكبسولات يمين   // (v249) تحت الكبسولات شمال
        miniLog = col
    }
    private var logMode = 0
    override fun onTrimMemory(level: Int) { super.onTrimMemory(level); LogStore.add("⚠ onTrimMemory level=$level · ${LogStore.heapLine()}") }
    override fun onLowMemory() { super.onLowMemory(); LogStore.add("⚠ onLowMemory · ${LogStore.heapLine()}") }
    override fun status(s: String) { status = s; if (BrainBus.active()) BrainBus.post("status", s) }
    override fun changed() { dirty = true; srtSoon() }
    override fun notice(s: String) { if (BrainBus.active()) BrainBus.post("notice", s); runOnUiThread { try { Notice.show(this, s, 2600L) } catch (e: Throwable) { LogStore.err("Main:1089", e) } } }
    override fun position() = cur / 1000.0
    override fun playerDuration() = durMs / 1000.0

    // ===== نسخ كل الجمل بتوقيتات الظهور والاختفاء (وتحديد اللي مش بتظهر في المشغّل) =====
    private fun fmtT(ms: Long): String { val t = ms.coerceAtLeast(0L); return String.format("%d:%02d:%02d.%03d", t / 3600000, t / 60000 % 60, t / 1000 % 60, t % 1000) }
    /** الجمل اللي هتتحجب ومش هتظهر في المشغّل: السبب لكل جملة (بنفس منطق العرض: الأحدث بس لو الجمل متداخلة) */
    private fun hiddenReasons(): Map<Int, String> {
        val out = HashMap<Int, String>()
        for (i in list.indices) {
            val q = list[i]
            if (q.translated.isBlank()) { out[i] = "النص المترجم فاضي"; continue }
            if (ends[i] <= starts[i]) { out[i] = "مدتها صفر أو سالبة (الاختفاء قبل أو مع الظهور)"; continue }
            val snd = q.isSound
            val map = if (snd) sdMap else spMap; val st = if (snd) sdStarts else spStarts; val en = if (snd) sdEnds else spEnds
            val maxN = if (snd) 2 else 1
            var seen = false; var t = starts[i]
            while (t <= ends[i]) {
                if (PlayerLogic.activeIndices(st, en, t, 0L, 400L, maxN).any { map[it] == i }) { seen = true; break }
                if (t == ends[i]) break
                t = minOf(t + 100L, ends[i])
            }
            if (!seen) out[i] = "متغطّية بجملة تانية متداخلة معاها زمنيًا (المشغّل بيعرض الأحدث بس)"
        }
        return out
    }
    fun sentencesReport(): String {
        val hidden = hiddenReasons()
        val sb = StringBuilder()
        sb.append("📝 الجمل — العدد: ${list.size}\n")
        sb.append("الأوقات بساعة المشغّل (ساعة:دقيقة:ثانية.ملّي)")
        if (offsetMs != 0L) sb.append(" — شاملة تزامن ${String.format("%+.2f", offsetMs / 1000.0)}ث")
        sb.append("\n")
        val short = list.indices.filter { ends[it] > starts[it] && ends[it] - starts[it] < 500L && it !in hidden }
        sb.append("⚠ جمل مش بتظهر في المشغّل: ${hidden.size}")
        if (hidden.isNotEmpty()) sb.append(" ← أرقامها: " + hidden.keys.sorted().joinToString("، ") { (it + 1).toString() })
        sb.append("\n⏱ جمل بتظهر أقل من نص ثانية: ${short.size}")
        if (short.isNotEmpty()) sb.append(" ← أرقامها: " + short.joinToString("، ") { (it + 1).toString() })
        sb.append("\n\n")
        for (i in list.indices) {
            val q = list[i]
            val a = starts[i] + offsetMs; val b = ends[i] + offsetMs
            sb.append("#${i + 1}  ظهور ${fmtT(a)}  ←  اختفاء ${fmtT(b)}  (مدة ${String.format("%.2f", (b - a) / 1000.0)}ث)")
            if (q.isSound) sb.append("  🔊 صوت/خلفية (بتظهر فوق الفيديو)")
            sb.append("\n")
            sb.append("ترجمة: ").append(q.translated.replace("\n", " / ")).append("\n")
            if (q.original.isNotBlank() && q.original != q.translated) sb.append("أصل: ").append(q.original.replace("\n", " / ")).append("\n")
            hidden[i]?.let { sb.append("⚠ مش بتظهر في المشغّل: ").append(it).append("\n") }
            sb.append("\n")
        }
        return sb.toString().trimEnd() + "\n"
    }
    private var pendingSentTxt: String? = null
    fun copySentences() {
        if (list.isEmpty()) { Notice.show(this, ("مفيش جمل لسه").toString(), 2300L); return }
        val txt = try { sentencesReport() } catch (e: Throwable) { Notice.show(this, ("تعذّر تجهيز الجمل").toString(), 2300L); return }
        // الكليبورد بيتعدّى بالـ Binder (حد ~1MB): لو النص كبير جدًا بنحفظه كملف نصي بدل ما يفشل
        if (txt.length > 250_000) {
            pendingSentTxt = txt
            try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "sentences.txt") }, 31) } catch (_: Exception) { pendingSentTxt = null }
            Notice.show(this, ("الجمل كتير — اختار مكان حفظ ملف نصي").toString(), 3600L)
            return
        }
        try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("sentences", txt))
            Notice.show(this, ("📋 اتنسخت ${list.size} جملة بتوقيتاتها").toString(), 2300L)
        } catch (_: Throwable) {
            pendingSentTxt = txt
            try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "sentences.txt") }, 31) } catch (_: Exception) { pendingSentTxt = null }
        }
    }

    /** (v763) عرض احتياطي للترجمة: لو حلقة العرض الأساسية وقعت في استثناء قبل ما توصل لسطر الترجمة (كان بيسيب الجملة واقفة والجمل اللي بعدها ما بتظهرش)، الحلقة دي بتحسب الجملة الحالية وتعرضها لوحدها */
    // (v769) تشخيص «الترجمة مش بتظهر»: بيفرّق بين (الجمل مش واصلة للمشغّل) و(واصلة بس مش معروضة) و(حلقة العرض بتقع)
    private var diagCueN = 0; private var diagCueLast = ""; private var diagN = 0; private var diagAt = 0L
    /** (v770) سطر تشخيص: يروح اللوج + يوصل لموبايل الريموت (زرار 📜) من غير ما يغيّر نص الحالة */
    private fun diagLog(s: String) {
        try { if (BrainBus.active()) BrainBus.post("log", s) } catch (_: Throwable) {}
        synchronized(logBuf) { logBuf.append(fmtMs(cur)).append("  ").append(s).append('\n'); if (logBuf.length > 30000) logBuf.delete(0, 10000) }
        LogArchive.append(arcRun, fmtMs(cur) + "  " + s)
        LogStore.add(fmtMs(cur) + "  " + s)
    }
    private fun subDiag(bad: Boolean, errN: Int) {
        val now = System.currentTimeMillis()
        if (now - diagAt < 4000L || diagN >= 120 || !::sub.isInitialized || !::engine.isInitialized || !player.isPlaying) return
        diagAt = now; diagN++
        val txtOff = try { player.exo()?.trackSelectionParameters?.disabledTrackTypes?.contains(C.TRACK_TYPE_TEXT) == true } catch (_: Throwable) { false }
        // (v1116) FIX 1: النقط من المحرك الشغّال فعلًا — المتوازن (FastTr) ليه حوض مفاتيح خاص بيه، والمحرك القديم حوضه في Engine
        val dots = try { if (trIsTx() && Cfg.groqTx()) engine.keyDots() else fastTr?.keyDots() ?: engine.keyDots() } catch (_: Throwable) { "" }   // (v1376) نفس تفضيل نقطة جروك في التشخيص
        diagLog("🔬 عرض @" + fmtMs(cur) + " · حلقة_وقعت=" + bad + "(" + errN + ") · cc=" + ccOn + " · أصلية=" + nativeCue.length + "ح · مسارات_نص=" + sfNativeCountNow() + " · نص_مقفول=" + txtOff +
            " · hide=" + sfHideNative + " · ترجمة_شغالة=" + engineStarted + " · جمل_المحرك=" + engine.subs.size + " · نوع=" + (if (trIsTx()) "تفريغ" else "ترجمة") + "/علم=" + engine.transOnly + " · " + SongHint.state() + " · مفاتيح=" + dots + " · ظاهر=" + (sub.visibility == View.VISIBLE) + "/" + sub.height + " · curIdx=" + curIdx)
    }

    private fun subSafeTick() {
        if (!::sub.isInitialized || !::engine.isInitialized) return
        if (dirty) { try { refreshList() } catch (_: Throwable) {} }
        val c = try { player.currentPosition } catch (_: Throwable) { cur }
        val act = PlayerLogic.activeIndices(spStarts, spEnds, c, offsetMs, 400L, 1).map { spMap[it] }
        val gs = PlayerLogic.orderSpeakers(act.map { list[it] })
        // (v768) العرض الاحتياطي كان بيمسح ترجمة الملف الأصلية (السوفت صب) أثناء ترجمتها: مفيش جملة من المحرك ← null. دلوقتي لو مفيش جملة مترجمة بيعرض الأصلية
        val nat = ccOn && !sfHideNative && gs.isEmpty() && nativeCue.isNotEmpty()
        if (nat != natShown) { natShown = nat; try { sub.style = natStyle(SubStyle.load { k, d -> Cfg.str(k, d) }) } catch (_: Throwable) {} }
        val shown: Sub? = trMarkParens(if (!ccOn) null else if (gs.isNotEmpty()) PlayerLogic.combine(gs) else if (nat) natSub(nativeCue) else null, gs)   // (v1099) T4
        val idx = act.lastOrNull() ?: -1
        curIdx = idx; curKey = "safe:" + act.joinToString(",") + (if (nat) "|N:" + nativeCue else "")
        sub.show(shown, gs)
    }

    private fun refreshList() {
        val l = engine.subs.sortedBy { it.start }
        list = l; starts = LongArray(l.size) { (l[it].start * 1000).toLong() }; ends = LongArray(l.size) { (l[it].end * 1000).toLong() }
        // متحدثين مختلفين ورا بعض (فاصل ≤ 0.35ث): الأول بيفضل ظاهر لحد ما التاني يخلص، فيبانوا في سطرين (- ... / - ...) بدل ما واحد يختفي ويتبدّل
        for (j in 0 until l.size - 1) {
            val a = l[j]; val b = l[j + 1]
            val gap = starts[j + 1] - ends[j]
            val differ = (a.speakerTag.isNotBlank() && b.speakerTag.isNotBlank() && a.speakerTag != b.speakerTag) || a.gender != b.gender
            if (gap in 0..350 && differ && !b.isContinuation && !a.isSong && !b.isSong && !a.isSound && !b.isSound && !a.translated.startsWith("«") && !b.translated.startsWith("«") &&
                ends[j] - starts[j] <= 4000 && ends[j + 1] - starts[j + 1] in 600..5000) ends[j] = ends[j + 1]
        }
        val sp = l.indices.filter { !l[it].isSound }; val sd = l.indices.filter { l[it].isSound && (Extras.deaf || !l[it].translated.trim().let { t -> t.startsWith("[") && t.endsWith("]") }) }   // (v105) أوصاف الأصوات القديمة [موسيقى] متظهرش
        spMap = sp.toIntArray(); spStarts = LongArray(sp.size) { starts[sp[it]] }; spEnds = LongArray(sp.size) { ends[sp[it]] }
        sdMap = sd.toIntArray(); sdStarts = LongArray(sd.size) { starts[sd[it]] }; sdEnds = LongArray(sd.size) { ends[sd[it]] }
        if (::sentDlg.isInitialized && sentDlg.isShowing) { updVis(); adapter.notifyDataSetChanged() }   // القايمة مش ظاهرة = مفيش داعي نرسمها كل ثانية
    }

    /** (v121) أي فيديو جديد يفتح = أي مشغّل قديم لسه حي (PiP / خلفية / تحت في الستاك) يتوقف ويتقفل خالص: صوت + ترجمة */
    fun killForNewVideo() {
        if (remote) { rmFrames = false; if (!isFinishing) finish(); return }   // (v546) مايوقفش التلفزيون
        try { visual.stop() } catch (_: Throwable) {}
        try { player.pause() } catch (_: Throwable) {}
        try { saveRecent() } catch (_: Throwable) {}
        try { pipOv?.hide(); pipOv = null } catch (_: Throwable) {}
        val eng0 = engine
        retireEngine()
        Thread { try { eng0.saveNow() } catch (e: Throwable) { LogStore.err("Player:newVideoSave", e) } }.start()   // (v287)
        replacedByNew = true   // (v1147)
        if (!isFinishing) finish()
    }

    // ================= (v469) ميزات المشغّل (فريق B): سرعة كاملة · A-B · استوديو · فصول · التالي تلقائي · لقطة · شريط تزامن =================
    private var speedBRef: TextView? = null
    private var abA = -1L; private var abB = -1L
    private var sentFollow = true
    private var sentSearchFrom = 0
    private data class Chap(val ms: Long, val title: String)
    private var chapters: List<Chap> = emptyList()
    private var chapTicksRef: View? = null
    private var chapCur = -2
    private var nextUpCard: LinearLayout? = null
    private var nextUpTitleV: TextView? = null
    private var nextUpCountV: TextView? = null
    private var nextUpAt = 0L
    private var nextUpGo: (() -> Unit)? = null
    private var syncStripV: LinearLayout? = null
    private var syncValV: TextView? = null

    /** (v469) B3: تطبيق سرعة معيّنة وحفظها للفيديو الحالي (وترجع لوحدها لما يفتح تاني) + تحديث العام */
    fun setSpeedFull(f: Float) {
        speed = f.coerceIn(0.25f, 3f)
        try { player.setPlaybackSpeed(speed) } catch (_: Throwable) {}
        Cfg.p.edit().putString("speed", speed.toString()).putString("speed:$vid", speed.toString()).apply()
        speedBRef?.text = "⏩ " + PlayerLogic.speedLabel(speed)
        giShowFn("⏱ " + PlayerLogic.speedLabel(speed))
    }

    /** (v469) B3: لوحة السرعة الكاملة — منزلق 0.25×–3× + أزرار جاهزة */
    fun speedPanel() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(12)) }
        val lbl = ui.text("⏩ " + PlayerLogic.speedLabel(speed), 16f, th.primary, true).apply { gravity = Gravity.CENTER }
        col.addView(lbl, LinearLayout.LayoutParams(-1, -2))
        val sb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR;
            max = 275; progress = (speed * 100 - 25).toInt().coerceIn(0, 275)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) { setSpeedFull((p + 25) / 100f); lbl.text = "⏩ " + PlayerLogic.speedLabel(speed) } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        col.addView(sb, LinearLayout.LayoutParams(-1, -2))
        val row = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        for (p in listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) {
            row.addView(ui.fsBtn(PlayerLogic.speedLabel(p)) { _ -> setSpeedFull(p); sb.progress = (p * 100 - 25).toInt().coerceIn(0, 275); lbl.text = "⏩ " + PlayerLogic.speedLabel(speed) }.apply { minimumWidth = ui.dp(58) }, ViewGroup.MarginLayoutParams(-2, ui.dp(38)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        }
        col.addView(row, LinearLayout.LayoutParams(-1, -2))
        col.addView(ui.noHint(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(6) })
        ui.sheet(this, "⏩ سرعة التشغيل", listOf<View>(col))?.show()
    }

    /** (v469) B5: تعيين نقطتي حلقة A-B (لتعلّم اللغات: كرّر المقطع لحد ما تحفظه) */
    fun abSet(which: Int) {
        if (!::player.isInitialized) return
        val p = player.currentPosition
        if (which == 0) {
            abA = p; if (abB <= abA) abB = -1L
            say("🅰 نقطة أ: " + PlayerLogic.clock(abA) + (if (abB > abA) " · الحلقة شغالة لحد " + PlayerLogic.clock(abB) else " — عيّن نقطة ب من نفس القايمة"))
        } else {
            if (abA < 0 || p <= abA) { say("🅱 نقطة ب لازم تكون بعد أ — عيّن أ الأول وبعدين ب") ; return }
            abB = p; say("🔁 حلقة A-B شغالة: " + PlayerLogic.clock(abA) + " ← " + PlayerLogic.clock(abB) + " (الإلغاء من قايمة ⏱)")
        }
    }
    fun abClear() { if (abA >= 0 || abB >= 0) say("✖ حلقة A-B اتلغت"); abA = -1L; abB = -1L }
    private fun abTick() {
        if (abA >= 0 && abB > abA && ::player.isInitialized && player.isPlaying && cur >= abB) { try { player.seekTo(abA) } catch (_: Throwable) {} }
    }

    /** (v469) B9: استخراج الفصول من نص وصف — سطور تبدأ بطابع زمني (0:00 / 12:34 / 1:02:03) وبعدها عنوان */
    private fun parseChapters(desc: String): List<Chap> {
        val out = ArrayList<Chap>()
        val rx = Regex("^\\s*(?:(\\d{1,2}):)?([0-5]?\\d):([0-5]\\d)\\s+(.+)$")
        for (line in desc.lines()) {
            val m = rx.matchEntire(line.trim()) ?: continue
            val hh = m.groupValues[1].toLongOrNull() ?: 0L
            val mm = m.groupValues[2].toLongOrNull() ?: continue
            val ss = m.groupValues[3].toLongOrNull() ?: continue
            val t = m.groupValues[4].trim().trim('-', '–', '—', ' ').take(60)
            if (t.isNotEmpty()) out.add(Chap(((hh * 60 + mm) * 60 + ss) * 1000, t))
        }
        return out.distinctBy { it.ms }.sortedBy { it.ms }
    }

    /** (v469) B9: تحميل الفصول — وصف في الـ intent (لو أي مستدعٍ مرّره) أو ملف جانبي جنب الفيديو المحلي بنفس الاسم (.txt/.desc) */
    private fun loadChapters() {
        chapters = emptyList(); chapCur = -2
        intent.getStringExtra("desc")?.takeIf { it.isNotBlank() }?.let { chapters = parseChapters(it) }
        if (chapters.isNotEmpty()) { onChaptersReady(); return }
        val u = uri ?: return
        Thread {
            val found = try {
                val f = SrtWriter.pathOf(this, u.toString())
                val base = f?.nameWithoutExtension ?: ""
                val dir = f?.parentFile
                var txt: String? = null
                if (dir != null && base.isNotEmpty()) for (cand in listOf("$base.desc.txt", "$base.txt", "$base.desc")) { val cf = File(dir, cand); if (cf.isFile) { txt = cf.readText(); break } }
                txt
            } catch (_: Throwable) { null }
            if (!found.isNullOrBlank()) runOnUiThread { if (!isFinishing && !isDestroyed) { chapters = parseChapters(found); onChaptersReady() } }
        }.apply { isDaemon = true }.start()
    }
    private fun onChaptersReady() {
        chapTicksRef?.invalidate()
        if (chapters.isNotEmpty()) LogStore.add("📑 فصول: اتلقى ${chapters.size} فصل من الوصف")
    }
    fun chaptersSheet() {
        if (chapters.isEmpty()) { say("📑 مفيش فصول للفيديو ده — الفصول بتتقرا من وصف فيه سطور زي «12:34 عنوان الفصل» (للمحلي: ملف .txt بنفس اسم الفيديو جنبه)"); return }
        if (RcCapture.active) {   // (v1051) من ريموت الموبايل: الفصول بتتعرض على الموبايل
            rcPmList("📑 فصول الفيديو (${chapters.size})", chapters.map { c -> ("⏱ " + PlayerLogic.clock(c.ms) + "  ·  " + c.title) to { try { player.seekTo(c.ms); player.play() } catch (_: Throwable) {}; Unit } })
            return
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6)) }
        var dlg: android.app.Dialog? = null
        for (c in chapters) {
            col.addView(ui.fsBtn("⏱ " + PlayerLogic.clock(c.ms) + "  ·  " + c.title) { _ -> dlg?.dismiss(); try { player.seekTo(c.ms); player.play() } catch (_: Throwable) {} }.apply { minimumWidth = ui.dp(220) })
        }
        val svw = ScrollView(this).apply { addView(col) }
        dlg = ui.sheet(this, "📑 فصول الفيديو (${chapters.size})", listOf<View>(svw)); dlg?.show()
    }

    /** (v469) B9: علامات الفصول — شريط شفاف بيترسم فوق شريط التقدم بالظبط (نقاط صفرا عند مواضع الفصول) */
    private inner class ChapTicks : View(this) {
        private val pnt = android.graphics.Paint().apply { color = 0xFFFFD54F.toInt(); style = android.graphics.Paint.Style.FILL }
        override fun onDraw(c: android.graphics.Canvas) {
            super.onDraw(c)
            if (chapters.isEmpty() || durMs <= 0 || width == 0) return
            val r = 3.2f * resources.displayMetrics.density
            for (ch in chapters) { val x = (ch.ms.toFloat() / durMs * width).coerceIn(0f, width.toFloat()); c.drawCircle(x, height / 2f, r, pnt) }
        }
    }

    /** (v469) B6: رفع الترجمة الإضافي (dp) من استوديو الترجمة — بيتركّب على هامش الأساس جوه applyChromeFn */
    fun subPosExtra(): Int = ui.dp(Cfg.int("sub_posy", 0).coerceIn(-60, 240))   // (v759) سالب = ينزل تحت

    /** (v469) نداء واحد من حلقة العرض (كل 200ms): حلقة A-B + عدّاد بطاقة التالي + تمييز الفصل الحالي */
    fun v469Tick() {
        abTick(); nextUpTick()
        if (chapters.isNotEmpty() && durMs > 0) {
            val ci = chapters.indexOfLast { it.ms <= cur }
            if (ci != chapCur) { chapCur = ci; chapTicksRef?.invalidate() }
        }
    }

    // ================= (v469) التالي تلقائي + لقطة + شريط تزامن + استوديو + بحث النص =================
    /** (v469) B13: بطاقة «التالي بعد…» — أي لمسة عليها تلغي الانتقال، واستنى 6 ثواني بيشتغل لوحده */
    private fun showNextUp(title: String, delayMs: Long = 5000L, go: () -> Unit) {
        cancelNextUp()
        nextUpGo = go; nextUpAt = System.currentTimeMillis() + delayMs
        val card = nextUpCard ?: run {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(10)); background = ui.box(0xE61A1C22.toInt(), 0x33FFFFFF, 14); alpha = REST_A
                val t1 = ui.text("", 13f, Color.WHITE, true); nextUpTitleV = t1; addView(t1)
                val t2 = ui.text("", 11f, 0xFFE6D8C5.toInt()); nextUpCountV = t2; addView(t2)
                addView(ui.text(if (DeviceUi.isRemote(this@PlayerActivity)) "OK = شغّل دلوقتي  ·  رجوع = إلغاء" else "دوس على الكارت لإلغاء التشغيل التلقائي", 10f, 0xFF9AA0A6.toInt()))
                setOnClickListener { cancelNextUp(); say("✖ التشغيل التلقائي للتالي اتلغى") }
            }
            videoBoxRef.addView(c, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, ui.dp(14), ui.dp(120)) })
            nextUpCard = c; c
        }
        nextUpTitleV?.text = "⏭ التالي: " + title.take(46)
        card.visibility = View.VISIBLE
        fadeTo(card, 1f)
    }
    fun cancelNextUp() { nextUpAt = 0L; nextUpGo = null; nextUpCard?.visibility = View.GONE }
    private fun nextUpTick() {
        if (nextUpAt <= 0L) return
        val left = nextUpAt - System.currentTimeMillis()
        if (left <= 0L) { val g = nextUpGo; cancelNextUp(); try { g?.invoke() } catch (e: Throwable) { LogStore.err("Player:v469Next", e) }; return }
        nextUpCountV?.text = "هيبدأ بعد " + (left / 1000 + 1) + " ث…"
    }
    /** (v469) B13: قرار «التالي» عند انتهاء الفيديو — يوتيوب من الاقتراحات، والمحلي من نفس الفولدر. الإيقاف من إعداد «autoplay_next» */
    fun v469AutoNext() {
        val yid = intent.getStringExtra("ytid")
        if (yid != null) {
            val n = try { YtNext.nextAfter(yid) } catch (_: Throwable) { null }
            if (n != null) {
                if (Cfg.str("autoplay_next", "1") == "1") {
                    // (v531) يوتيوب: يستنى ~20 ثانية (yt_next_delay) وفي الأثناء لوحة الفيديوهات القريبة تتفتح، وبعدها يشغّل التالي لوحده
                    showNextUp(n.title, Cfg.int("yt_next_delay", 20).coerceIn(3, 120) * 1000L) { playNextYt(n) }
                    try { nextPanel?.reveal() } catch (_: Throwable) {}
                } else playNextYt(n)
            }
            return
        }
        if (!hasNextEpisode()) { endButtons(); return }
        if (Cfg.str("autoplay_next", "1") != "1") { stepEpisode(1); return }
        endButtons()   // (v1056) ⏮ السابق · 🔄 إعادة · ⏭ التالي (التالي بعد ٥ ثواني لوحده) بدل كارت «التالي بعد…»
    }

    // ===== (v1056) نهاية الفيديو + الاستكمال في Player.kt =====
    private var finishedMark = false
    private var endCheckDone = false
    private var resumeSeekDone = false
    private var askResumeMs = 0L
    private var noResPending = false

    /** الفيديو خلص: نمسح مكان الوقوف المحفوظ (lastpos) ونسجّل «آخر المشغّلة» من الصفر — فتحه الجاي يبدأ من الأول */
    private fun markFinished() {
        finishedMark = true
        if (incognito || remote) return
        try { clearSavedPos(); Thread { try { saveRecentForce() } catch (_: Throwable) {} }.apply { isDaemon = true }.start() } catch (_: Throwable) {}
    }
    private fun clearSavedPos() {
        try { if ((Cfg.p.getString("lastpos", "") ?: "").startsWith(vid + "\t")) Cfg.p.edit().remove("lastpos").apply() } catch (_: Throwable) {}
    }
    /** نسأل «كمّل ولا ابدأ من جديد؟» على التلفزيون لما مفيش موبايل متوصل، أو على الموبايل لو متوصل بالتلفزيون */
    private fun shouldAskResume(): Boolean = try {
        if (remote || incognito) false
        else if (DeviceUi.isTv(this)) TvLink.remoteList().none { it.alive() } else RemoteClient.state == RemoteClient.St.CONNECTED
    } catch (_: Throwable) { false }
    /** أول READY بعد الاستكمال: لو وقفنا على آخر الفيديو ← من الأول (أي مصدر)، ولو لازم نسأل ← الشاشة المنبثقة (٥ث ← من جديد) */
    private fun maybeEndCheck() {
        if (endCheckDone || !resumeSeekDone || isFinishing || isDestroyed) return
        if (player.playbackState != Player.STATE_READY) return
        val d = player.duration
        if (d <= 0L) return
        endCheckDone = true
        val pos = player.currentPosition
        if (pos >= d - 4000L) { askResumeMs = 0L; player.seekTo(0L); cur = 0L; clearSavedPos(); return }
        val ask = askResumeMs; askResumeMs = 0L
        if (ask > 5000L && ask < d - 4000L) {
            player.pause()
            ResumeAsk.show(this, ask) { resume ->
                if (isFinishing || isDestroyed) return@show
                try { if (resume) player.seekTo(ask) else { player.seekTo(0L); cur = 0L; clearSavedPos() }; player.play() } catch (_: Throwable) {}
            }
        }
    }
    /** أزرار نص الشاشة عند نهاية الفيديو المحلي: ⏮ السابق · 🔄 إعادة · ⏭ التالي (لف لأول/آخر فيديو لو اللف شغّال) */
    private fun endButtons() {
        if (isFinishing || isDestroyed || remote) return
        val p = libSibs()
        val wrap = wrapOn() && p != null && p.first.size > 1
        val hasN = p != null && (p.first.getOrNull(p.second + 1) != null || wrap)
        val hasP = p != null && (p.first.getOrNull(p.second - 1) != null || wrap)
        EndOverlay.show(this, hasP, hasN, 5,
            { stepEpisode(-1) },
            { try { player.seekTo(0L); player.play() } catch (_: Throwable) {} },
            { stepEpisode(1) })
    }

    /** (v469) B12: لقطة الإطار الحالي — بتتحفظ في صور الجهاز وبتتعرض للمشاركة على طول */
    fun snapFrame() {
        if (!::svRef.isInitialized || svRef.width <= 0 || svRef.height <= 0) { say("📸 مفيش إطار جاهز لسه"); return }
        val bmp = android.graphics.Bitmap.createBitmap(svRef.width, svRef.height, android.graphics.Bitmap.Config.ARGB_8888)
        try {
            android.view.PixelCopy.request(svRef, bmp, { res ->
                if (res != android.view.PixelCopy.SUCCESS) { say("📸 اللقطة فشلت — الإطار مش جاهز"); return@request }
                Thread {
                    var uriOut: android.net.Uri? = null
                    try {
                        val cv = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "subtitler_" + System.currentTimeMillis() + ".png")
                            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                            if (Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Subtitler")
                        }
                        uriOut = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                        uriOut?.let { u -> contentResolver.openOutputStream(u)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) } }
                    } catch (e: Throwable) { LogStore.err("Player:v469Snap", e) }
                    runOnUiThread {
                        val u = uriOut
                        if (u == null) { say("📸 ما اتحفظتش اللقطة"); return@runOnUiThread }
                        say("📸 اتحفظت اللقطة في «صور/Subtitler»")
                        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "image/png"; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "مشاركة اللقطة")) } catch (e: Throwable) { LogStore.err("Player:v469SnapShare", e) }
                    }
                }.apply { isDaemon = true }.start()
            }, h)
        } catch (e: Throwable) { LogStore.err("Player:v469SnapReq", e); say("📸 اللقطة فشلت") }
    }

    /** (v469) B14: خطوة تزامن من الشريط العائم — نفس منطق أزرار ⏱ بالظبط (±0.25ث، حد ±10ث، حفظ لكل فيديو) */
    private fun syncStep(d: Long) {
        offsetMs = (offsetMs + d).coerceIn(-10000L, 10000L)
        Cfg.p.edit().putString("sub_offset_ms:$vid", offsetMs.toString()).apply()
        offFsB?.text = String.format("%+.2fs", offsetMs / 1000.0)
        syncValV?.text = String.format("%+.2f", offsetMs / 1000.0)
        curIdx = -2; srtSoon()
    }
    /** (v469) B14: شريط التزامن السريع العائم — زرّين −/+ بضغط مطوّل متكرر + عرض القيمة الحالية، وبخفوت الأزرار العائمة المعتاد */
    fun toggleSyncStrip() {
        syncStripV?.let { val show = !it.isShown; it.visibility = if (show) View.VISIBLE else View.GONE; if (show) try { showChrome() } catch (_: Throwable) {}; if (show) syncValV?.text = String.format("%+.2f", offsetMs / 1000.0); return }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(ui.dp(5), ui.dp(6), ui.dp(5), ui.dp(6)); background = ui.box(0xCC14171C.toInt(), 0x33FFFFFF, 16); alpha = REST_A
        }
        fun repBtn(t: String, d: Long): TextView {
            val b = ui.fsCircle(t) { syncStep(d) }.apply { textSize = 16f }
            val rep = object : Runnable { override fun run() { syncStep(d); h.postDelayed(this, 110) } }
            b.setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { fadeTo(col, 1f); h.postDelayed(rep, 420) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { h.removeCallbacks(rep); fadeTo(col, REST_A) }
                }
                false
            }
            return b
        }
        col.addView(repBtn("+", 250L), LinearLayout.LayoutParams(ui.dp(38), ui.dp(38)))
        val valV = ui.text(String.format("%+.2f", offsetMs / 1000.0), 11f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, ui.dp(3), 0, ui.dp(3)) }
        syncValV = valV; col.addView(valV)
        col.addView(repBtn("−", -250L), LinearLayout.LayoutParams(ui.dp(38), ui.dp(38)))
        col.addView(ui.text("⏱", 10f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.CENTER })
        videoBoxRef.addView(col, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { setMargins(0, 0, ui.dp(6), 0) })
        syncStripV = col
        say("⏱ شريط التزامن السريع: ضغطة = ربع ثانية · ضغط مطوّل = تكرار سريع")
    }

    /** (v469) B6+B7: استوديو الترجمة — لوحة كاملة بمعاينة حية: حجم/لون/عتامة/هالة/موضع/خط/وضع مزدوج، وكلها بتتحفظ في Cfg */
    fun subStudio() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(12)) }
        fun lbl(t: String) = ui.text(t, 12f, th.muted).apply { setPadding(0, ui.dp(9), 0, ui.dp(2)) }
        fun apply() { restyleFn(); curIdx = -2 }
        val prev = ui.text("الترجمة بالعربي — معاينة حية", 15f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(ui.dp(10), ui.dp(10), ui.dp(10), ui.dp(10)); background = ui.box(0xFF000000.toInt(), 0x33FFFFFF, 10) }
        fun paintPrev() {
            val st = SubStyle.load { k, d -> Cfg.str(k, d) }
            prev.setTextColor(if (st.uniOn) runCatching { android.graphics.Color.parseColor(st.uniColor) }.getOrDefault(Color.WHITE) else Color.WHITE)
            prev.textSize = 15f * st.scale / 100f
            (prev.background as? GradientDrawable)?.setColor(android.graphics.Color.argb(if (st.noBg) 0 else st.bgOpa * 255 / 100, 0, 0, 0))
        }
        col.addView(prev, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("📏 حجم الخط"))
        val sizeSb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR; max = 140; progress = (Cfg.int("sub_scale", 100) - 60).coerceIn(0, 140)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { Cfg.put("sub_scale", (p + 60).toString()); apply(); paintPrev() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        col.addView(sizeSb, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("🎨 لون النص الموحّد (أو سيبه لألوان المتحدثين)"))
        val colorRow = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val palette = listOf("#FFFFFF" to "أبيض", "#FFE600" to "أصفر", "#FF9F1C" to "برتقالي", "#00CFFF" to "سماوي", "#AEE2FF" to "أزرق فاتح", "#FBC9E0" to "وردي", "#CE93D8" to "بنفسجي", "#FFAB91" to "مرجاني")
        for ((hex, name) in palette) {
            val chip = ui.text("   ", 14f, Color.WHITE).apply {
                background = ui.box(android.graphics.Color.parseColor(hex), 0x66FFFFFF, 10); setPadding(ui.dp(16), ui.dp(9), ui.dp(16), ui.dp(9))
                setOnClickListener { Cfg.put("sub_uni_on", "1"); Cfg.put("sub_uni_color", hex); apply(); paintPrev(); say("🎨 لون النص: " + name) }
            }
            colorRow.addView(chip, ViewGroup.MarginLayoutParams(-2, -2).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        }
        colorRow.addView(ui.fsBtn("🎭 ألوان المتحدثين") { _ -> Cfg.put("sub_uni_on", "0"); apply(); paintPrev() }, ViewGroup.MarginLayoutParams(-2, ui.dp(36)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        col.addView(colorRow, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("🌫 عتامة خلفية النص"))
        val bgSb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR; max = 100; progress = if (Cfg.str("sub_nobg", "0") == "1") 0 else Cfg.int("sub_bgopa", 45)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { Cfg.put("sub_bgopa", p.toString()); Cfg.put("sub_nobg", "0"); apply(); paintPrev() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        col.addView(bgSb, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("✨ هالة/حدود حول النص (بتوضّحه على أي خلفية)"))
        val blurSb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR; max = 20; progress = Cfg.int("sub_blur", 0)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { Cfg.put("sub_blur", p.toString()); apply() } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        col.addView(blurSb, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("↕ موضع الترجمة (رفعها عن أسفل الشاشة)"))
        val posSb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR; max = 240; progress = Cfg.int("sub_posy", 0).coerceIn(0, 240)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { Cfg.put("sub_posy", p.toString()); try { applyChromeFn() } catch (_: Throwable) {} } }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }) }
        col.addView(posSb, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("🔤 نوع الخط ونمطه"))
        val fontRow = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        for (f in SubStyle.fonts.take(10)) fontRow.addView(ui.fsBtn(f.label) { _ -> Cfg.put("sub_font", f.id); apply(); say("🔤 الخط: " + f.label) }, ViewGroup.MarginLayoutParams(-2, ui.dp(36)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        col.addView(fontRow, LinearLayout.LayoutParams(-1, -2))
        val styleRow = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        for ((sid, sname) in SubStyle.fontStyles) styleRow.addView(ui.fsBtn(sname) { _ -> Cfg.put("sub_fontstyle", sid); apply() }, ViewGroup.MarginLayoutParams(-2, ui.dp(36)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        col.addView(styleRow, LinearLayout.LayoutParams(-1, -2))
        col.addView(lbl("💬 الترجمة المزدوجة (الأصلي + الترجمة معًا)"))
        val dualRow = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        for ((did, dname) in listOf(0 to "فردي", 1 to "مزدوج: ترجمة فوق", 4 to "مزدوج: أصلي فوق", 3 to "الأصلي فقط")) dualRow.addView(ui.fsBtn((if (Cfg.int("sub_dual", 0) == did) "✓ " else "") + dname) { _ -> Cfg.put("sub_dual", did.toString()); apply(); say("💬 وضع الترجمة: " + dname) }, ViewGroup.MarginLayoutParams(-2, ui.dp(36)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
        col.addView(dualRow, LinearLayout.LayoutParams(-1, -2))
        paintPrev()
        val svw = ScrollView(this).apply { addView(col) }
        ui.sheet(this, "🎨 استوديو الترجمة", listOf<View>(svw))?.show()
    }

    /** (v469) B8: بحث داخل النص — يقفز لتالي جملة فيها الكلمة (ترجمة أو أصل) وينزّل القايمة لها */
    fun sentSearch(q: String) {
        val t = q.trim(); if (t.isEmpty() || list.isEmpty()) { say("🔎 اكتب كلمة للبحث في النص الأول"); return }
        val n = list.size
        for (k in 1..n) {
            val i = (sentSearchFrom + k) % n
            val s = list[i]
            if (s.translated.contains(t, true) || s.original.contains(t, true)) {
                sentSearchFrom = i
                try { player.seekTo(starts[i] + offsetMs) } catch (_: Throwable) {}
                try { listView.smoothScrollToPositionFromTop(i, ui.dp(30)) } catch (_: Throwable) {}
                say("🔎 جملة " + (i + 1) + " من " + n + ": " + (if (s.translated.isNotEmpty()) s.translated else s.original).take(50))
                return
            }
        }
        say("🔎 مفيش جملة فيها «" + t.take(20) + "»")
    }
    private var rotLaunch = false
    override fun onCreate(b: Bundle?) {
        NetLedger.start(this); NetLog.start(this); NetGate.apply(this)
        try { if (Build.VERSION.SDK_INT >= 27 && intent.getBooleanExtra("ytpage", false) && intent.getStringExtra("ytid")?.length == 11 && !DeviceUi.isTv(this)) setTheme(R.style.AppPlayerYt) } catch (_: Throwable) {}   // (v1161) نافذة شفافة: الصفحة الخلفية (الفيد) بتبان وقت سحب التصغير زي يوتيوب
        try { if (Build.VERSION.SDK_INT >= 27 && intent.getBooleanExtra("ytpage", false) && !DeviceUi.isTv(this)) { window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)); window.decorView.setBackgroundColor(android.graphics.Color.TRANSPARENT) } } catch (_: Throwable) {}   // (v1350) تأكيد الشفافية على مستوى النافذة والديكور: ممنوع أي أسود خلف الصفحة في أي مرحلة من السحب (بطلب علي)
        super.onCreate(b)
        smoothRotation()   // (v1123) كروس-فيد الدوران يتحدّد قبل أي شغل تقيل (قبل ما النافذة تتعرض)
        // (v1123) الدخول للشاشة الكاملة من يوتيوب كان بيفتح المشغّل بورتريه وبعد أول فريم (onVideoSizeChanged) يلف لاندسكيب — ده كان سبب النتشة الكبيرة والسواد.
        // دلوقتي الاتجاه الصح بيتطلب هنا في أول onCreate (قبل بناء الواجهة) من شكل الفيديو في المشغّل المتسلّم، فالنظام يفتح النافذة لاندسكيب من الأول بدورانه الناعم.
        try {
            val wantLand: Boolean? = when {
                intent.getBooleanExtra("pip", false) -> null
                intent.getBooleanExtra("handoff", false) -> YtHandoff.peek()?.videoSize?.let { vs -> if (vs.width > 0 && vs.height > 0) vs.width * vs.pixelWidthHeightRatio >= vs.height else null }
                intent.getBooleanExtra("landscape", false) -> true
                else -> null
            }
            if (wantLand != null) {
                autoRotDone = true   // الاتجاه معروف: مفيش لفّة تانية بعد أول فريم
                val isLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                if (wantLand != isLand) { rotLaunch = true; requestedOrientation = if (wantLand) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT }
            }
        } catch (_: Throwable) {}
        if (incognito) try { window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE) } catch (_: Throwable) {}   // (v1062) متخفي: المعاينة في الريسنت سودا
        smoothRotation()   // (v429)
        // (v1347) أنيميشن نافذة صفحة يوتيوب اتشال (بطلب علي): مفيش أي حركة نهائيًا
        try { if ((intent.getBooleanExtra("handoff", false) && !ytPage) || (rotLaunch && !ytPage)) overridePendingTransition(0, 0) else if (ytPage) overridePendingTransition(0, 0) else if (intent.getStringExtra("ytid")?.length == 11) overridePendingTransition(0, 0) else if (MtLook.playerAnim()) overridePendingTransition(R.anim.player_open_enter, R.anim.player_open_exit) } catch (_: Throwable) {}   // (v1347) يوتيوب: فتح فوري من غير ترانزيشن (بطلب علي)   // (v899) (v1340) أي فيديو يوتيوب بيفتح من تحت دايمًا — مفيش فتح جانبي/افتراضي للنظام: (v1143) صفحة يوتيوب: بتطلع من تحت (v1130) التسليم من المشغّل المصغّر: من غير حركة حركة فتح المشغّل من MeeTube
        synchronized(liveList) {
            liveList.removeAll { it.get() == null }
            liveList.toList().forEach { r -> r.get()?.let { o -> if (o !== this) try { o.runOnUiThread { o.killForNewVideo() } } catch (_: Throwable) {} } }
            liveList.removeAll { it.get() !== this }
            liveList.add(java.lang.ref.WeakReference(this))
        }
        UiWatchdog.start()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Cfg.init(this); CrashLog.install(this); try { TrProfile.restore() } catch (_: Throwable) {}; conf = Cfg.snapshot()   // (v1098) T3: الإعدادات المحفوظة بتتطبّق قبل لقطة الإعدادات
        th = Themes.current(); ui = Ui(this, th)
        applyBars(th)
        speed = Cfg.str("speed", "1").toFloatOrNull() ?: 1f; fit = Cfg.int("fit", 0).coerceIn(0, 3); fsFit = Cfg.int("fs_fit", 2).coerceIn(0, 3); offsetMs = 0L   // (v469) الحد بقى 3 عشان وضع 100% الجديد
        uri = intent.data; url = intent.getStringExtra("url")
        // (v736) الملف اللي بيتشغّل هو ملف تحميل لسه شغّال؟ (دوسة «تتفرج على اللي اتحمّل» في المهام)
        try {
            val pth = uri?.takeIf { it.scheme == "file" }?.path
            partTask = if (pth == null) null else TaskCenter.items.firstOrNull { (it.state == 1 || it.state == 6) && it.partPath == pth }
            partTask?.let { pt -> partLenAtPrep = java.io.File(pt.partPath).length(); partFracAtPrep = partFrac(pt); partLastPrep = System.currentTimeMillis() }
        } catch (_: Throwable) { partTask = null }
        remote = intent.getBooleanExtra("remote", false)
        if (remote) TvSync.install(this)   // (v568) مزامنة الإعدادات للتلفزيون بقت عامة (مش مرتبطة بشاشة التحكم بس)
        pendingYt = !remote && intent.getBooleanExtra("ytpend", false) && url == null && uri == null && intent.getStringExtra("ytid")?.length == 11   // (v351)
        try { if (!incognito && !hiddenSite) PubHistory.addVideoFrom(intent) } catch (_: Throwable) {}   // (v349) السجل العام
        try { if (!incognito) intent.getStringExtra("ytid")?.let { yid -> if (yid.length == 11) YtHistory.add(this, yid, intent.getStringExtra("title") ?: "") } } catch (_: Throwable) {}   // (v407) سجل يوتيوب المنفصل
        try {
            intent.getStringExtra("qlist")?.let { sj -> val qa = org.json.JSONArray(sj)
                qOpts = (0 until qa.length()).map { qi -> val o = qa.getJSONObject(qi); YtExtract.Opt(o.optString("l"), o.optString("u"), o.optString("a").ifEmpty { null }, o.optInt("h")) }; parseATracks(sj) }
        } catch (e: Exception) { LogStore.err("Player:qlist", e) }
        qCur = qOpts.indexOfFirst { it.url == url }
        aurl = intent.getStringExtra("aurl")?.takeIf { it.isNotEmpty() }   // (v118) صوت منفصل ليوتيوب (جودة عالية)
        noSub = intent.getBooleanExtra("nosub", false); askSaved = intent.getBooleanExtra("ask", false); autoTr = intent.getBooleanExtra("autotr", false)
        intent.getStringExtra("ua")?.takeIf { it.isNotEmpty() }?.let { hdr["User-Agent"] = it }
        intent.getStringExtra("ref")?.takeIf { it.isNotEmpty() }?.let { hdr["Referer"] = it }
        // (v976) المشغّلات الخارجية (hls.js) بتبعت Origin مع كل طلب — نفس أصل الـReferer، من غير يوتيوب
        hdr["Referer"]?.let { r0 -> if (!r0.contains("youtube.com", true) && !r0.contains("youtu.be", true)) Sniff.originOf(r0)?.let { o0 -> hdr["Origin"] = o0 } }
        intent.getStringExtra("cookie")?.takeIf { it.isNotEmpty() }?.let { hdr["Cookie"] = it }

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        ytPageRef = page   // (v1161)
        val videoBox = FrameLayout(this).apply { background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = ui.dp(14).toFloat() }; clipToOutline = true; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        videoBoxRef = videoBox
        hookRotAnim(videoBox)   // (v1125)
        val sv = SurfaceView(this); svRef = sv
        sv.holder.addCallback(object : android.view.SurfaceHolder.Callback {   // (v604) تدوير الموبايل في وضع المتحكم
            override fun surfaceCreated(h: android.view.SurfaceHolder) { if (remote) redrawLastRemoteFrame() else try { if (::player.isInitialized) player.exo()?.setVideoSurfaceView(sv) } catch (_: Throwable) {} }
            override fun surfaceChanged(h: android.view.SurfaceHolder, f: Int, w: Int, hh: Int) { if (remote) { redrawLastRemoteFrame(); rmFrameForce = true } }
            override fun surfaceDestroyed(h: android.view.SurfaceHolder) {}
        })
        videoBox.addView(sv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        sub = SubtitleView(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; style = SubStyle.load { k, d -> Cfg.str(k, d) } }
        val subLp = FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = ui.dp(12) }
        visOv = VisualOverlay(this); videoBox.addView(visOv, FrameLayout.LayoutParams(-1, -1))
        visOv.area = { if (sv.width > 0 && sv.height > 0) android.graphics.RectF(sv.left.toFloat(), sv.top.toFloat(), sv.right.toFloat(), sv.bottom.toFloat()) else android.graphics.RectF(0f, 0f, videoBox.width.toFloat(), videoBox.height.toFloat()) }
        videoBox.addView(sub, subLp)
        sub.backdrop = sv
        st = IconTextView(this).apply { setTextColor(th.primary); textSize = 11f; setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4)); setShadowLayer(4f, 0f, 0f, Color.BLACK) }
        videoBox.addView(st, FrameLayout.LayoutParams(-2, -2, Gravity.TOP))
        soundTv = IconTextView(this).apply {
            setTextColor(0xFFE8EAED.toInt()); textSize = 13f; typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.ITALIC)
            gravity = Gravity.CENTER; maxLines = 2; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(4)); background = ui.box(0x99000000.toInt(), 0x00000000, 14); visibility = View.GONE
        }
        // طبقة إيماءات شفافة فوق الفيديو والترجمة وتحت كل الأزرار (لازم تتضاف قبل درج اللوج وزرار 👁 وإلا بتبلع لمسهم)
        val gestureLayer = View(this)
        videoBox.addView(gestureLayer, FrameLayout.LayoutParams(-1, -1))
        // (v134) فوق طبقة الإيماءات عشان علامة ⓘ تستقبل اللمس
        videoBox.addView(soundTv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = ui.dp(28) })
        soundTv.setOnClickListener { showTermCard() }
        // أزرار عايمة فوق الفيديو: 📋 اللوج (يخفي/يظهر حالة الترجمة) و 👁 بصري
        batchTv = IconTextView(this).apply {
            setTextColor(Color.WHITE); textSize = 10f; setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4))
            background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = ui.dp(8).toFloat() }
            layoutDirection = View.LAYOUT_DIRECTION_RTL; typeface = android.graphics.Typeface.MONOSPACE
            setOnClickListener { toggleLog() }
        }
        // درج اللوج: اللوج + لسان صغير في نص حافته. الضغط على اللسان بيدخّل اللوج أقصى الشمال ويفرده تاني
        logHandle = IconTextView(this).apply {
            text = "◂"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); alpha = REST_A
            background = ui.box(0xCC14171C.toInt(), 0x33FFFFFF, 8); setOnClickListener { toggleLog() }
            visibility = View.GONE   // (v90) اللوج بقى بيتفتح من زرار 📋 جنب 📝 في الشريط السفلي
        }
        logHandle.text = if (logOn) "◂" else "▸"
        logDrawer = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL
            addView(batchTv, LinearLayout.LayoutParams(-2, -2)); addView(logHandle, LinearLayout.LayoutParams(ui.dp(22), ui.dp(46)).apply { marginStart = ui.dp(2) }) }
        batchTv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!logOn) logDrawer.translationX = -(batchTv.width + ui.dp(2)).toFloat() }
        // عمود الشمال: كبسولة الباتش الفاشل (لو في) فوق، واللوج تحتها
        leftCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; clipChildren = false; clipToPadding = false }
        // (v100) اللوج العايم اتلغى: حالة الباتشات بقت جوه صفحة اللوجز (logCol)
        videoBox.addView(leftCol, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(0, ui.dp(44), 0, 0) })   // (v182) نازل تحت الكبسولات (v249: الكبسولات بقت أصغر فالمسافة 44)
        // 👁 بصري: دايرة عايمة فوق دايرة ✦
        // (v185) ضغطة واحدة = لقطة (بتتصوّر وتتترجم وتتحفظ مع الفيديو)؛ مفيش ضغطة مطوّلة، والتلقائي مابيتقفلش من الزرار ده (القايمة من عدّاد 👁 أقصى الشمال)
        floatBar = ui.fsCircle("👁") { flashFloat(floatBar); visualSnap() }.apply {
            textSize = 24f; alpha = REST_A
            if (DeviceUi.isRemote(this@PlayerActivity)) visibility = View.GONE   // (v663) نفس سبب ⛶: مخفي من البداية على التلفزيون
        }
        videoBox.addView(floatBar, FrameLayout.LayoutParams(ui.dp(44), ui.dp(44), Gravity.END or Gravity.TOP).apply { setMargins(0, ui.dp(120), ui.dp(8), 0) })   // (v95) المكان بيتحسب في placeFloatFn
        // (v95) زرار الروتيشن: شاشة بسهمين دايريين زي MX Player — فوق 👁 على طول؛ بيقلب بين الرأسي والأفقي
        rotBtn = ui.fsCircle(Icons.ROT) { flashFloat(rotBtn); toggleFs() }.apply { textSize = 24f; alpha = REST_A }
        videoBox.addView(rotBtn, FrameLayout.LayoutParams(ui.dp(48), ui.dp(48), Gravity.END or Gravity.TOP).apply { setMargins(0, ui.dp(60), ui.dp(11), 0) })
        rotBtn.visibility = View.GONE   // (v97) زرار الروتيشن العايم اتلغى — الروتيشن في الشريط السفلي بس
        // (v343) 🎧 حوّل لصوت: بيكمّل نفس فيديو يوتيوب في مشغّل الموسيقى من نفس المكان (بيوفّر الداتا) — تحت 👁 على طول
        audBtn = ui.fsCircle("🎧") { switchToAudio() }.apply { textSize = 20f; alpha = REST_A; visibility = View.GONE }
        videoBox.addView(audBtn, FrameLayout.LayoutParams(ui.dp(44), ui.dp(44), Gravity.END or Gravity.TOP).apply { setMargins(0, ui.dp(174), ui.dp(8), 0) })
        // (v619) 📺 تحت 🎧: ابعت اللي شغّال على الموبايل للتلفزيون القريب (بنفس الثانية). مخفي إلا لو في تلفزيون قريب ومش متصل
        tvBtn = ui.fsCircle("📺") { sendToTv() }.apply { textSize = 20f; alpha = REST_A; visibility = View.GONE; contentDescription = "كمّل على التلفزيون" }
        videoBox.addView(tvBtn, FrameLayout.LayoutParams(ui.dp(44), ui.dp(44), Gravity.END or Gravity.TOP).apply { setMargins(0, ui.dp(278), ui.dp(8), 0) })
        TvModeFab.listeners.addIfAbsent(tvNearCb)
        // (v459) كبسولة الوضع العريضة: بتاخد مكان 👁 العايمة (مكانها بيتحسب في placeFloatFn) وبتظهر لفيديوهات يوتيوب بس
        modePill = ui.text("🎧 وضع الصوت", 13.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; includeFontPadding = false
            setPadding(ui.dp(14), ui.dp(9), ui.dp(14), ui.dp(9))
            background = ui.box(0xCC242832.toInt(), 0x33FFFFFF, 22)
            alpha = 0.92f; visibility = View.GONE
            setOnClickListener { flashFloat(modePill); toggleYtMode() }
        }
        videoBox.addView(modePill, FrameLayout.LayoutParams(-2, ui.dp(44), Gravity.END or Gravity.TOP).apply { setMargins(0, ui.dp(226), ui.dp(8), 0) })
        // 🔄 ترجم باتش معين: دايرة عايمة فوق 👁
        batchBtn = ui.fsCircle("🔄") { batchDialog() }.apply { textSize = 20f; alpha = REST_A; translationY = -ui.dp(60).toFloat(); if (DeviceUi.isRemote(this@PlayerActivity)) visibility = View.GONE }
        // (v90) الزرار العايم 🔄 اتشال من الشاشة — «إعادة ترجمة» لسه في 🧰 وفي ☰
        // (v90) كبسولة «▶ ترجمة» الحمرا على الشمال اتشالت — زرار ▶ ترجمة الوحيد في الشريط السفلي
        // كبسولة جانبية للباتشات الفاشلة (زي اللوج): مخفية خالص لحد ما باتش يفشل، وبعدها بيظهر لسان ⚠ على الحافة الشمال — دوس عليه يفرد الكبسولة ودوس تاني يلمّها
        probBar = IconTextView(this).apply {
            textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(ui.dp(10), ui.dp(5), ui.dp(10), ui.dp(5)); background = ui.box(0xE6B71C1C.toInt(), 0x33FFFFFF, 12)
            setOnClickListener { askRetryProblem() }
        }
        probHandle = IconTextView(this).apply {
            text = "⚠"; textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = ui.box(0xE6B71C1C.toInt(), 0x33FFFFFF, 8); alpha = PROB_A; setOnClickListener { toggleProb() }
        }
        probDrawer = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
            addView(probBar, LinearLayout.LayoutParams(-2, -2)); addView(probHandle, LinearLayout.LayoutParams(ui.dp(26), ui.dp(40)).apply { marginStart = ui.dp(2) }) }
        probBar.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!probOn) probDrawer.translationX = -(probBar.width + ui.dp(2)).toFloat() }
        leftCol.addView(probDrawer, 0, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = ui.dp(4) })
        // (v213) شريط حالة الوضع البصري: تحت شريط الباتش الفاشل (probDrawer) ومكان الكلام اللي كان بيظهر إشعارات. بيظهر بس والوضع البصري شغّال
        visBar = IconTextView(this).apply {
            setTextColor(0xFFE8EAED.toInt()); textSize = 10f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(ui.dp(8), ui.dp(3), ui.dp(8), ui.dp(3)); layoutDirection = View.LAYOUT_DIRECTION_RTL; alpha = 0.85f
            background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = ui.dp(8).toFloat() }
            maxWidth = ui.dp(230); visibility = View.GONE
        }
        // (v368) شريط حالة الوضع البصري («👁 تحليل N فريم» / «مسح @..ث») اتشال من الشاشة — الحالة في اللوج

        // زرار التشغيل الأوسط (بيظهر وقت الإيقاف) + شارة النسبة (شاشة كاملة) + فلاش السيك/الصوت/السطوع
        centerPlay = FadePop(this).apply {
            text = "▶"; textSize = 28f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); visibility = View.GONE
            background = if (Design.isNew()) GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Design.mint(0x4D)); setStroke(maxOf(1, (resources.displayMetrics.density * 1.5f).toInt()), Design.mint(0x99)) } else glassCircleBg(resources.displayMetrics.density)
            if (Design.isNew()) textSize = 34f
            setOnClickListener { togglePlay() }
            Glass.pressable(this)   // (v445)
            isFocusable = false; isFocusableInTouchMode = false; defaultFocusHighlightEnabled = false   // (v576) تلفزيون: ماياخدش حلقة التركيز (المربع الأزرق) — الريموت بيتحكم في المشغّل من غيره
        }
        videoBox.addView(centerPlay, FrameLayout.LayoutParams(ui.dp(if (Design.isNew()) 88 else 74), ui.dp(if (Design.isNew()) 88 else 74), Gravity.CENTER))
        // (v249) كبسولات العدّادات: صغيرة، التلاتة جنب بعض شمال فوق الفيديو (صوتي · بصري · نت) والشفافية من الإعدادات (badge_alpha)
        fsBadge = TransBadge(this, th, true).apply { visibility = View.GONE; setOnClickListener { badgeHot(); toggleMiniLog(); h.postDelayed({ applyBadgeAlpha() }, 4100) }; setOnLongClickListener { badgeHot(); closeMiniLog(); versionsPopup(this); h.postDelayed({ applyBadgeAlpha() }, 4100); true } }   // (v125) دوسة = اللوج الصغير (أنهي باتش بيترجم) · ضغطة طويلة = قايمة الترجمات المحفوظة
        visBadge = TransBadge(this, th, true).apply { visibility = View.GONE; setOnClickListener { badgeHot(); visualDialog(); h.postDelayed({ applyBadgeAlpha() }, 4100) } }
        netBadge = NetBadge(this).apply { visibility = View.GONE; setOnClickListener { badgeHot(); netDialog(); h.postDelayed({ applyBadgeAlpha() }, 4100) } }
        // (v217) مثلث ▲ أحمر شفاف 70% جنب عدّاد الجمل (فوق اليمين): بيظهر لما فيه إشعارات، ولمسة عليه = قايمة منسدلة من الأحدث للأقدم
        noticeBtn = ui.text("▲", 13f, 0xFFFF3B30.toInt(), true).apply {
            visibility = View.GONE; alpha = 0.7f; gravity = Gravity.CENTER
            setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4)); background = ui.box(0x33FF3B30, 0x99FF3B30.toInt(), 20)
            setOnClickListener { noticePopup(this) }
        }
        val badgeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        // (v322) عدّاد واحد: كبسولة فيها الصوتي والبصري بينهم فاصل (بدل كبسولتين ضيقين بيتقصّ نصهم)
        sentCap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL; background = glassBtnBg(resources.displayMetrics.density, 12) }
        sentDiv = View(this).apply { setBackgroundColor(0x33FFFFFF); visibility = View.GONE }
        sentCap.addView(fsBadge, LinearLayout.LayoutParams(-2, -2))
        sentCap.addView(sentDiv, LinearLayout.LayoutParams(ui.dp(1), ui.dp(24)).apply { setMargins(ui.dp(1), 0, ui.dp(1), 0) })
        sentCap.addView(visBadge, LinearLayout.LayoutParams(-2, -2))
        badgeRow.addView(sentCap, LinearLayout.LayoutParams(-2, -2))
        badgeRow.addView(netBadge, LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(4) })
        val badgeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        badgeCol.addView(badgeRow, LinearLayout.LayoutParams(-2, -2))
        badgeRowRef = badgeRow
        badgeRowV = badgeCol
        videoBox.addView(badgeCol, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply { setMargins(0, ui.dp(8), ui.dp(10), 0) })   // (v265) الكبسولات يمين فوق
        applyBadgeAlpha()
        NoticeLog.attach(this) { paintNotices() }; paintNotices()
        val gi = IconTextView(this).apply {
            textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(10)); background = ui.box(0x99000000.toInt(), Color.TRANSPARENT, 24); visibility = View.GONE
        }
        videoBox.addView(gi, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        // (v904) شريط الإطارات وقت سحب شريط التقدّم (من MeeTube) — موبايل/تابلت بس
        val seekFs: SeekFilmstrip? = if (MtGlass.on()) SeekFilmstrip(this).also { videoBox.addView(it, FrameLayout.LayoutParams(-1, -1)) } else null
        val volInd = VertInd(this, "🔊", 2f); val briInd = VertInd(this, "☀️")
        videoBox.addView(volInd, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { setMargins(0, 0, ui.dp(24), 0) })
        videoBox.addView(briInd, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL).apply { setMargins(ui.dp(24), 0, 0, 0) })
        val indHide = Runnable { volInd.visibility = View.GONE; briInd.visibility = View.GONE }
        fun indShow(v: VertInd, f: Float) { v.set(f); h.removeCallbacks(indHide); h.postDelayed(indHide, 900) }
        // (v200) فقاعة الأدوات ✦ (📝 🕳 📥 📂) اتشالت — نفس الأوامر موجودة في قايمة 🧰 الأدوات
        fsOnly = listOf<View>(fsBadge, visBadge, netBadge)
        val giHide = Runnable { gi.visibility = View.GONE }
        fun giShow(t: String, g: Int) {
            gi.text = t
            val lp = gi.layoutParams as FrameLayout.LayoutParams
            lp.gravity = g; val edge = (videoBox.width * 0.18f).toInt(); lp.setMargins(edge, 0, edge, 0); gi.layoutParams = lp
            gi.visibility = View.VISIBLE; h.removeCallbacks(giHide); h.postDelayed(giHide, 800)
        }

        // ---- نفس خطوات الأصل: تحكم الشاشة الكاملة (أزرار الترجمة فوق + كبسولة التقدم تحت) ----
        fun curStyle() = SubStyle.load { k, d -> Cfg.str(k, d) }
        fun restyle() { sub.style = natStyle(curStyle()); curIdx = -2 }
        restyleFn = { restyle() }
        fun fontLabel(): String { val f = curStyle().font; return SubStyle.fonts.firstOrNull { it.id == f }?.label ?: f }
        fun entLabel(): String { val a = curStyle().anim; return SubStyle.entrances.firstOrNull { it.id == a }?.label ?: "افتراضي" }
        giShowFn = { m -> giShow(m, Gravity.CENTER) }
        fun fb(t: String, f: (TextView) -> Unit): TextView = ui.fsBtn(t) { v -> f(v); showChrome() }
        /** زرار دايري صغير للصف الأدوات اللي تحت جنب أزرار الشاشة */
        fun mini(t: String, f: (TextView) -> Unit): TextView {
            val ref = arrayOfNulls<TextView>(1)
            val v = ui.fsCircle(t) { ref[0]?.let { f(it) }; showChrome() }
            ref[0] = v; v.textSize = 12f; return v
        }
        // زرار تبديل عرض الترجمة: ترجمة ← أصلي ← ترجمة+أصلي تحت ← أصلي فوق+ترجمة تحت
        val dualCycle = listOf(0, 3, 1, 4); val dualShort = mapOf(0 to "فردي", 3 to "أصلي", 1 to "مزدوج", 4 to "مزدوج (أصلي فوق)", 2 to "إنجليزي")
        fun dualLabel() = "💬 وضع الترجمة: " + (dualShort[curStyle().dual] ?: "فردي")
        fun dualCircleBg() = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (curStyle().dual == 0) 0xE00F0F12.toInt() else 0xFF8B6B50.toInt()); setStroke(ui.dp(1), if (MtGlass.on()) 0x40FFFFFF else 0x1FFFFFFF) }
        fun cycleDual(v: TextView) {
            val n = dualCycle[(dualCycle.indexOf(curStyle().dual) + 1) % dualCycle.size]
            Cfg.put("sub_dual", n.toString()); restyle(); v.text = "💬"; v.background = dualCircleBg()
            giShow(dualLabel(), Gravity.CENTER)
        }
        var fsSpeedB: TextView? = null
        var spdVisB: TextView? = null   // (v1025) زرار السرعة الظاهر في الشريط العلوي
        var ccFsB: TextView? = null
        fun cycleSpeed() {
            speed = PlayerLogic.nextSpeed(speed); player.setPlaybackSpeed(speed)
            Cfg.p.edit().putString("speed", speed.toString()).putString("speed:$vid", speed.toString()).apply()   // (v469) الدورة كمان بتحفظ لكل فيديو
            fsSpeedB?.text = "⏩ " + PlayerLogic.speedLabel(speed)
            spdVisB?.text = PlayerLogic.speedLabel(speed)
            giShow("⏱ " + PlayerLogic.speedLabel(speed), Gravity.CENTER)
        }
        fun toggleCc() {
            ccOn = !ccOn; val a = if (ccOn) 1f else 0.4f
            ccFsB?.alpha = a; ctl.cc.alpha = a
            if (!ccOn) sub.show(null) else curIdx = -2
        }
        fun offFmt() = String.format("%+.2fs", offsetMs / 1000.0)   // (v468) عرض الإزاحة بدقة ربع ثانية
        fun setOff(d: Long) {
            offsetMs = (offsetMs + d).coerceIn(-10000L, 10000L); Cfg.p.edit().putString("sub_offset_ms:$vid", offsetMs.toString()).apply(); srtSoon()   // (v468) حد الإزاحة ±10ث
            offFsB?.text = offFmt(); curIdx = -2
        }

        ctl = ui.controls()
        // صفّين ثابتين من اليمين (نفس البداية ونفس الارتفاع 32dp، والمسافة بينهم 6dp = هامش 3+3)
        var popup: android.widget.PopupWindow? = null; var popupOwner: View? = null
        fun dismissPop() { try { popup?.dismiss() } catch (e: Exception) { LogStore.err("Main:1353", e) }; popup = null; popupOwner = null }
        dismissPopFn = { dismissPop() }
        fun after(keep: Boolean) { if (!keep) dismissPop(); showChrome(); if (popup != null) h.removeCallbacks(hideChrome) }
        fun pk(t: String, f: (TextView) -> Unit): TextView = ui.fsBtn(t) { v -> f(v); after(true) }.apply { minimumWidth = ui.dp(150); if (DeviceUi.isRemote(this@PlayerActivity)) { isFocusable = true; tvRing(this) } }   // (v803) أزرار قايمة النص قابلة للتركيز بالريموت
        fun pd(t: String, f: (TextView) -> Unit): TextView = ui.fsBtn(t) { v -> f(v); after(false) }.apply { minimumWidth = ui.dp(150); isFocusable = true; tvRing(this) }
        fun gCol() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6)); background = glassPanelBg() }
        val gText = gCol(); val gAi = gCol(); val gTool = gCol()
        // الأزرار العلوية في صف واحد بس (في الرأسي الصف بيتسحب أفقيًا لو الأزرار أكتر من العرض بدل ما تنزل لسطر تاني)
        // الترتيب من اليمين: CC ← احتواء ← القائمة ← الجمل ← النص ← لهجة ← أدوات (كل زرار بيتضاف على يسار اللي قبله)
        val tbRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        fun tbAdd(v: View) { tbRow.addView(v, 0) }
        val tb = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(tbRow, FrameLayout.LayoutParams(-2, -2))
        }
        var tbScrolled = false
        tb.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> if (!tbScrolled && tbRow.width > 0) { tbScrolled = true; tb.post { tb.scrollTo(tbRow.width, 0) } } }
        var textAtBottom = false
        var qualCol: LinearLayout? = null   // (v808) مرجع متقدّم لقايمة الجودات — gQ بيتعرّف بعد togglePop
        fun togglePop(v: View, col: LinearLayout, above: Boolean) {
            val had = popupOwner === v && (popup?.isShowing == true); dismissPop()   // (v1042) لو القايمة اتقفلت من برّه (صاحبها فضل متسجّل) الدوسة الجاية لازم تفتح مش تقفل
            if (!had) {
                (col.parent as? android.view.ViewGroup)?.removeView(col)
                // (v125) القوايم الطويلة بتتسكرول وبتتحصر في المساحة المتاحة بدل ما تطلع بره الشاشة
                val dmP = resources.displayMetrics
                col.measure(View.MeasureSpec.makeMeasureSpec((dmP.widthPixels * 0.9f).toInt(), View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
                val loc = IntArray(2); v.getLocationOnScreen(loc)
                val goUp = above || (col === gText && textAtBottom)   // زرار في الشريط السفلي: القايمة تفتح فوقه
                val avail = (if (goUp) loc[1] - ui.dp(8) else dmP.heightPixels - loc[1] - v.height - ui.dp(8)).coerceAtLeast(ui.dp(120))
                val popH = minOf(col.measuredHeight, avail)
                val svP = android.widget.ScrollView(this).apply { overScrollMode = View.OVER_SCROLL_NEVER; isVerticalScrollBarEnabled = false; addView(col) }
                val pw = if (DeviceUi.isTv(this)) TvFocus.pop(this, svP, maxOf(col.measuredWidth, ui.dp(150)), popH, true)   // (v517) تلفزيون: القايمة بتاخد التركيز عشان الريموت يوصل لعناصرها
                    else android.widget.PopupWindow(svP, maxOf(col.measuredWidth, ui.dp(150)), popH, false)
                pw.isOutsideTouchable = true; pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0))
                if (DeviceUi.isTv(this)) pw.setOnDismissListener { if (popup === pw) { popup = null; popupOwner = null } }
                // (v1375 — بطلب علي) القايمة كانت بتتقص بحرف الشاشة (زرار ⏱ في الشريط العلوي): اقلبها تحت لو مفيش مساحة فوق، وظبط الإزاحة الأفقية عشان تفضل جوه الشاشة
                val popW = maxOf(col.measuredWidth, ui.dp(150))
                var xoff = 0
                if (loc[0] + popW > dmP.widthPixels - ui.dp(8)) xoff = (dmP.widthPixels - ui.dp(8)) - (loc[0] + popW)
                if (loc[0] + xoff < ui.dp(8)) xoff = ui.dp(8) - loc[0]
                if (goUp && loc[1] - popH - ui.dp(2) >= 0) pw.showAsDropDown(v, xoff, -(v.height + popH + ui.dp(2)))
                else pw.showAsDropDown(v, xoff, ui.dp(2))
                popup = pw; popupOwner = v
                if (col === qualCol && DeviceUi.isRemote(this)) col.post {   // (v803) قايمة الجودات: التركيز يبدأ على الجودة الشغّالة دلوقتي (✓) مش أول واحدة
                    try { for (i in 0 until col.childCount) { val c = col.getChildAt(i); if ((c as? TextView)?.text?.startsWith("✓") == true) { c.requestFocus(); break } } } catch (_: Throwable) {}
                }
            }
            showChrome(); if (popup != null) h.removeCallbacks(hideChrome)
        }
        fun grp(label: String, col: LinearLayout, above: Boolean = false): TextView = ui.fsBtn("$label ▾") { v -> togglePop(v, col, above) }
        gText.addView(pk("🔤 " + fontLabel()) { v ->
            val fs = SubStyle.fonts; val cf = curStyle().font
            val n = fs[(fs.indexOfFirst { it.id == cf } + 1) % fs.size]
            Cfg.put("sub_font", n.id); restyle(); v.text = "🔤 " + n.label
        })
        gText.addView(pk("🎨 استوديو الترجمة") { subStudio() })   // (v469) B6: لوحة ستايل كاملة بمعاينة حية
        gText.addView(pk("⏩ سرعة التشغيل…") { speedPanel() })   // (v469) B3: منزلق + جاهز + حفظ لكل فيديو
        gText.addView(pk("✨ " + entLabel()) { v ->
            val es = SubStyle.entrances; val ca = curStyle().anim
            val n = es[(es.indexOfFirst { it.id == ca } + 1) % es.size]
            Cfg.put("sub_anim", n.id); restyle(); v.text = "✨ " + n.label
        })
        val spB = pk("⏩ " + PlayerLogic.speedLabel(speed)) { cycleSpeed() }
        fsSpeedB = spB; speedBRef = spB; gText.addView(spB)   // (v469) مرجع كلاسي عشان استرجاع سرعة الفيديو يحدّث اللافتة
        run {
            val cs = curStyle()
            val bgTv = IconTextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; setPadding(0, ui.dp(6), 0, 0) }
            fun bgLabel(p: Int) = "🌫 غمقان الخلفية: " + (if (p == 0) "شفافة" else "$p%")
            val p0 = if (cs.noBg) 0 else cs.bgOpa
            bgTv.text = bgLabel(p0)
            val bgSb = SeekBar(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR;
                max = 100; progress = p0
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                        bgTv.text = bgLabel(p)
                        if (!u) return
                        Cfg.put("sub_bgopa", p.toString()); Cfg.put("sub_nobg", "0"); restyle()
                        showChrome(); h.removeCallbacks(hideChrome)
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) { h.removeCallbacks(hideChrome) }
                    override fun onStopTrackingTouch(sb: SeekBar?) { showChrome(); h.removeCallbacks(hideChrome) }
                })
            }
            gText.addView(bgTv, LinearLayout.LayoutParams(ui.dp(150), -2))
            gText.addView(bgSb, LinearLayout.LayoutParams(ui.dp(150), -2))
        }
        val ccB = mini("CC") { toggleCc() }.apply { textSize = 11f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        ccFsB = ccB
        fun loopBg() = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (Cfg.str("loop", "0") == "1") 0xFF8B6B50.toInt() else 0xE00F0F12.toInt()); setStroke(ui.dp(1), if (MtGlass.on()) 0x40FFFFFF else 0x1FFFFFFF) }
        val loopB = mini("🔂") { v -> Cfg.put("loop", if (Cfg.str("loop", "0") == "1") "0" else "1"); v.background = loopBg(); giShow(if (Cfg.str("loop", "0") == "1") "🔂 تكرار الفيديو: شغّال" else "🔂 تكرار الفيديو: مقفول", Gravity.CENTER) }.apply { background = loopBg() }
        val dualB = mini("💬") { v -> cycleDual(v) }.apply { background = dualCircleBg() }
        // (v208) زرار 🔑 بيبدّل وضع المفاتيح (1→2→3→4) ويوصل للمحرك الشغّال فورًا — زي زرار اللغة
        val voiceB = mini("🎙") { voiceMenu() }   // (v334) فصل صوت الكلام عن الموسيقى — يدوي بس
        voiceBtnRef = voiceB
   // وضع الترجمة (فردي / أصلي / مزدوج) — أيقونة بس من غير كلام
        ccToggleFn = { toggleCc() }
        if (noSub) { ccOn = false; ccB.alpha = 0.4f; ctl.cc.alpha = 0.4f }
        val fitB = fb("⬛ " + fitNameOf(curFit())) { v ->
            if (remote) { cycleFitNow(); return@fb }   // (v604) يسأل موبايل/تلفزيون
            if (isLandNow()) { fsFit = if (curFit() == 2) 0 else 2; Cfg.p.edit().putString("fs_fit", fsFit.toString()).apply() }   // (v1020) وضعين بس
            else { fit = if (curFit() == 2) 0 else 2; Cfg.p.edit().putString("fit", fit.toString()).apply() }
            v.text = "⬛ " + fitNameOf(curFit()); applyFit(sv, videoBox)
        }
        fitFsB = fitB
        val menuB = IconGlyphButton(this, "menu").apply { background = ui.box(0xE0141418.toInt(), 0x1FFFFFFF, 12); setOnClickListener { togglePop(this, gTool, false) } }
        val bgOnB = IconGlyphButton(this, if (Cfg.bool("ask_bg_exit", true)) "check_box" else "box").apply {
            background = ui.box(0xE0141418.toInt(), 0x1FFFFFFF, 12)
            setOnClickListener {
                val on = !Cfg.bool("ask_bg_exit", true)
                Cfg.put("ask_bg_exit", if (on) "1" else "0"); iconName = if (on) "check_box" else "box"
                giShowFn(if (on) "هسألك لما تخرج: كمّل في الخلفية ولا لا" else "لما تخرج: الترجمة بتتقفل من غير سؤال ومن غير خلفية")
                showChrome()
            }
            setOnLongClickListener { giShow("اسألني عند الخروج: أكمّل الترجمة في الخلفية؟", Gravity.CENTER); true }
        }
        // (v118) زرار الجودة: يوتيوب بقايمة جودات (بحجمها التقريبي) · روابط HLS/DASH بمساراتها — للفرجة بداتا أقل
        val gQ = gCol(); qualCol = gQ
        fun fillQ(): Boolean {
            gQ.removeAllViews()
            if (qOpts.size > 1) {
                for ((qi, o) in qOpts.withIndex()) gQ.addView(pd((if (qi == qCur) "✓ " else "") + o.label) { switchYt(qi) })
            } else {
                val tg = ArrayList<Triple<Int, androidx.media3.common.Tracks.Group, Int>>()
                for (g in (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>())) if (g.type == androidx.media3.common.C.TRACK_TYPE_VIDEO)
                    for (ti in 0 until g.length) if (g.isTrackSupported(ti)) tg.add(Triple(g.getTrackFormat(ti).height, g, ti))
                // (v120) أعلى bitrate لكل ارتفاع، والحجم الكلي تقريبي = bitrate × مدة الفيديو (HLS/DASH مفيهوش حجم جاهز)
                val hs = tg.filter { it.first > 0 }.sortedWith(compareByDescending<Triple<Int, androidx.media3.common.Tracks.Group, Int>> { it.first }.thenByDescending { it.second.getTrackFormat(it.third).bitrate }).distinctBy { it.first }
                fun szOf(q: Triple<Int, androidx.media3.common.Tracks.Group, Int>): String {
                    val br = q.second.getTrackFormat(q.third).bitrate.toLong()
                    return if (br > 0 && durMs > 0) " · ≈" + Sniff.fmtSize(br / 8 * (durMs / 1000)) else ""
                }
                if (hs.size > 1) {
                    gQ.addView(pd((if (hlsH == 0) "✓ " else "") + "تلقائي") { hlsAuto() })
                    for (q in hs) gQ.addView(pd((if (hlsH == q.first) "✓ " else "") + q.first + "p" + szOf(q)) { hlsPick(q.second, q.third, q.first) })
                }
            }
            // (v1320) تشيك بوكس «اجعله الافتراضي» تحت قايمة الجودات (بيظهر بس لما يكون فيه جودات للاختيار) — pk عشان القايمة متتقفلش عند التبديل
            val hadQ = gQ.childCount > 0
            if (hadQ) {
                val defOn = Cfg.bool("qual_pick_default", false)
                gQ.addView(pk((if (defOn) "☑ " else "⬜ ") + "اجعل الجودة المختارة الافتراضية لكل الفيديوهات") {
                    Cfg.put("qual_pick_default", if (defOn) "0" else "1")
                    fillQ()
                    Notice.show(this, if (defOn) "التثبيت اتقفل — اختيار الجودة بقى للفيديو ده بس" else "✅ أي جودة تختارها من هنا هتتثبّت افتراضية لكل الفيديوهات (فيديوهات موبايلك بتفضل بجودتها الأصلية)", 3000L)
                })
            }
            return hadQ
        }
        val qualB = mini("HD") { v -> if (fillQ()) togglePop(v, gQ, true) else Notice.show(this, "مفيش جودات تانية للفيديو ده", 2300L) }
        qualB.visibility = if (uri == null) View.VISIBLE else View.GONE
        qualBRef = qualB
        qualPopFn = { v -> if (fillQ()) togglePop(v, gQ, true) else Notice.show(this, "مفيش جودات تانية للفيديو ده", 2300L) }
        // (v388) قايمة لغات الصوت
        val gA = gCol()
        fun fillA(): Boolean {
            gA.removeAllViews()
            if (aTracks.size > 1) {
                for ((ai, t) in aTracks.withIndex()) gA.addView(pd((if (ai == aCur) "✓ " else "") + t.name) { switchAudio(ai) })
                return true
            }
            val la = localAud(); val curA = try { player.currentAudio() } catch (_: Throwable) { -1 }
            for (t in la) gA.addView(pd((if (t.idx == curA) "✓ " else "") + t.name) { switchLocalAudio(t) })
            return la.size > 1
        }
        audPopFn = { v -> if (fillA()) togglePop(v, gA, true) else Notice.show(this, "مفيش لغات صوت تانية للفيديو ده", 2300L) }
        setQualLabel(qOpts.getOrNull(qCur)?.h ?: 0)
        val sentB = mini("📝") { sentDlg.show() }   // الجمل
        val charsB = mini("🧑") { showChars() }   // (v151) الشخصيات وجنسها — نافذة فوق الفيديو من غير ما تضغط شاشته
        val logB = mini("📜") { toggleLog() }   // (v90) اللوج — مكان 🔄 جنب الجمل
        // (v357) زرار «📃 التالي» (يوتيوب بس): يفتح لوحة الفيديوهات اللي بعد الحالي من غير ما تخرج من المشغّل · وزرار الجودة (HD) بقى ظاهر في الشريط العلوي لفيديوهات يوتيوب
        val nextListB = mini("📃") { openNextSheet() }; nextListB.visibility = if (intent.getStringExtra("ytid") != null) View.VISIBLE else View.GONE
        // التوقيت: زرار واحد ⏱ (في الشريط السفلي) بيفتح قايمة صغيرة: تقديم −0.1 / القيمة (ضغطة = رجوع للصفر) / تأخير +0.1 — زي MX Player
        // لوحة ⏱: تزامن الترجمة (تقديم −0.1 / القيمة / تأخير +0.1) — حجم الخط بالقرص (pinch)
        val gSub = gCol()
        gSub.addView(pk("⏱ تقديم −0.25") { setOff(-250) })   // (v468) خطوة ربع ثانية
        val offB = pk(offFmt()) { setOff(-offsetMs) }
        offFsB = offB; gSub.addView(offB)
        gSub.addView(pk("⏱ تأخير +0.25") { setOff(250) })   // (v468) خطوة ربع ثانية
        // (v1375 — بطلب علي) لوحة ⏱ بقت تقديم/تأخير والعداد بس — أزرار حلقة A-B وشريط التزامن اتشالت من هنا
        // (v103) قايمة ☰ = قايمة منسدلة صغيرة فيها بس الأزرار اللي مش موجودة في المشغّل نفسه
        gTool.addView(pd("📤 تصدير SRT") { doExport() })
        if (Design.isNew()) gTool.addView(pd("🎧 ابعت الصوت كله (ملف واحد)") { shareFullAudio() })
        gTool.addView(pd("🎧 باتش الصوت للترجمة بره (على الموبايل)") { ghUpload() })   // (v1361) محلي بدل الريبو (بطلب علي)
        gTool.addView(pd("📋 نسخ برومبت باتش الصوت") { GhAudio.copyLast(this) })
        gTool.addView(pd("📥 استيراد ملف ترجمة (بيترجم فورًا)") { doImport() })
        gTool.addView(pd("📂 فتح فيديو") { doOpen() })
        // (v1025) اللي اتشال من الشريط العلوي لقلّة الاستعمال بقى هنا
        if (!Design.isNew()) gTool.addView(pd("📜 اللوج") { toggleLog() })
        if (!Design.isNew()) gTool.addView(pd("🧑 الشخصيات") { showChars() })
        if (!Design.isNew()) gTool.addView(pd("☑ اسألني عند الخروج (تبديل)") {
            val on = !Cfg.bool("ask_bg_exit", true)
            Cfg.put("ask_bg_exit", if (on) "1" else "0")
            giShowFn(if (on) "هسألك لما تخرج: كمّل في الخلفية ولا لا" else "لما تخرج: الترجمة بتتقفل من غير سؤال ومن غير خلفية")
        })
        // (v1020) ✨ تحسين الصورة اتنقل برّه القايمة: زرار لوحده جنب ☰ في الشريط العلوي
        if (!Design.isNew()) gTool.addView(pd("🕳 سد الفجوات") {   // (v1196) كان بيقول «بحاول» حتى لو مفيش حاجة تتسد أو الترجمة واقفة
                val fc = try { engine.failedCount() } catch (_: Throwable) { 0 }
                val wasPaused = try { engine.paused } catch (_: Throwable) { false }
                if (fc == 0 && !wasPaused) { say("🕳 مفيش مقاطع فاشلة دلوقتي — الفجوات اللي فيها صوت من غير ترجمة بتتسد تلقائي أثناء الترجمة") }
                else {
                    engine.retryFailed()
                    if (wasPaused) { try { engine.paused = false } catch (_: Throwable) {} }
                    say("🕳 هعيد " + (if (fc > 0) "$fc مقطع فاشل" else "الترجمة الواقفة") + (if (wasPaused) " وكمّلت الترجمة" else ""))
                }
            })
        // (v87) ترجمات الفيديو: قايمة صغيرة منسدلة بالنسخ المحفوظة (دوسة على نسخة ترجّعها)
        val gVer = gCol()
        fun fillVer() {
            gVer.removeAllViews()
            gVer.addView(pk("‹ رجوع") { dismissPop(); togglePop(menuB, gTool, false) })
            gVer.addView(pd("💾 احفظ النسخة الحالية") { engine.saveVersion("نسخة " + fmtMs(player.currentPosition).substring(3)); Notice.show(this, "اتحفظت نسخة", 1800L) })
            val vs = engine.versions.toList()
            if (vs.isEmpty()) gVer.addView(ui.text("مفيش نسخ محفوظة لسه", 12f, Color.WHITE).apply { setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(8)) })
            vs.forEachIndexed { i, v -> gVer.addView(pd("${v.name} — ${v.subs.size} جملة") { restoreVersion(i) }) }
        }
        if (!Design.isNew()) gTool.addView(pk("🗂 ترجمات الفيديو ›") { fillVer(); dismissPop(); togglePop(menuB, gVer, false) })
        // (v1326) «إعادة ترجمة» المكررة في التصميم القديم اتشالت — مكانها دايلوج «ترجم» وشيت النظام
        // (v1326) الدبلجة اتشالت من ⋮: زرار 🎙 مستقل جنب «ترجم» + الصوت في ⚙ إعدادات الترجمة
        gTool.addView(pd("👁 الوضع البصري") { visualDialog() })
        gTool.addView(pd("🌙 ترجمة بالخلفية") { translateInBackground() })
        if (!Design.isNew()) gTool.addView(pd("📶 استهلاك النت") { netDialog() })
        if (!Design.isNew()) gTool.addView(pd("📜 ذكّرني") { recapDialog() })
        if (!Design.isNew()) gTool.addView(pd("😴 مؤقت النوم") { sleepDialog() })   // (v452)
        if (!Design.isNew()) gTool.addView(pd("📸 لقطة إطار") { snapFrame() })   // (v469) B12
        if (!Design.isNew()) gTool.addView(pd("📑 فصول الفيديو") { chaptersSheet() })   // (v469) B9
        if (!Design.isNew()) gTool.addView(pd("⏭ التالي تلقائي: " + if (Cfg.str("autoplay_next", "1") == "1") "شغّال" else "مقفول") { v -> val on = Cfg.str("autoplay_next", "1") != "1"; Cfg.put("autoplay_next", if (on) "1" else "0"); v.text = "⏭ التالي تلقائي: " + (if (on) "شغّال" else "مقفول") })   // (v469) B13
        // (v356) اتشالت من القايمة: ترجمة جوجل بقت اختيار جوه خط الترجمة (الإعدادات ▸ 🚀). الدالة googleTranslateNow() لسه موجودة.
        // gTool.addView(pd("🌍 ترجمة جوجل (من غير API)") { googleTranslateNow() })
        // (v87) الإعدادات: قايمة صغيرة منسدلة بالأقسام — دوسة على قسم تفتحه دايركت (من غير شاشة القايمة الكبيرة)
        val gSet = gCol()
        gSet.addView(pk("‹ رجوع") { dismissPop(); togglePop(menuB, gTool, false) })
        // (v212) نفس أقسام الإعدادات اللي بره بالظبط (SettingsTabs): كانت القايمة هنا بأسماء أقسام مش موجودة بره فكانت بتفتح القايمة الكبيرة
        var lastG = ""
        for (sc in SettingsTabs.sections.filter { it.id != "music" }) {
            if (sc.group != lastG && SettingsTabs.sections.count { it.group == sc.group && it.id != "music" } > 1) gSet.addView(ui.text(sc.group, 11f, 0xFF9AA0A6.toInt(), true).apply { setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(2)) })
            lastG = sc.group
            gSet.addView(pd(sc.label) { openSettings(sc.id) })
        }
        gSet.addView(pd("📥 تحميل النص الأصلي (SRT)") { exportOriginalSrt() })
        // (v167) زرار «تضخيم الصوت» اتشال — التضخيم بقى جزء أحمر في سلايدر الصوت نفسه (بعد 100%)
        // (v1038) زرار ⋯ في الشريط العلوي: مركز التحميل + الليستة بس (أدوات القص/الصوت/GIF/الضغط/الترجمة الثابتة اتشالت)
        val gTools = gCol()
        gTools.addView(ui.text("⋯ المزيد", 12f, th.primary, true).apply { setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(4)) })
        gTools.addView(pd("➕ إضافة للليستة") { queueCurrent() })   // (v694)
        gTools.addView(pd("📋 الليستة") { PlayQueueUi.show(this) })
        // (v188) مركز التحميل (التقدم + الناتج) في نافذة فوق المشغّل
        fun openTasksDialog() {
            val tu = TasksUi(this, ui, th)
            val dlg = android.app.Dialog(this)
            dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setBackgroundColor(th.bg) }
            box.addView(ui.button("✕ إغلاق") { dlg.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(ui.dp(12), ui.dp(8), ui.dp(12), 0) })
            box.addView(tu.root, LinearLayout.LayoutParams(-1, 0, 1f))
            dlg.setContentView(box)
            val l: () -> Unit = { tu.refresh() }
            TaskCenter.extra.add(l)
            dlg.setOnDismissListener { TaskCenter.extra.remove(l) }
            TvFocus.attachDialog(this, dlg, th.primary)   // (v480 م7)
            dlg.show()
            dlg.window?.setLayout(-1, -1)
        }
        val tasksPageB = pd("⬇ مركز التحميل") { openTasksDialog() }
        gTools.addView(tasksPageB, 1)
        tasksPopFn = { v -> tasksPageB.text = "⬇ مركز التحميل (" + taskCount() + ")"; togglePop(v, gTools, true) }
        val toolsB = IconGlyphButton(this, "toolbox").apply { background = ui.box(0xE0141418.toInt(), 0x1FFFFFFF, 12); setOnClickListener { togglePop(this, gTools, false) } }
        tvMenuFn = { v -> togglePop(v, gTool, true) }; tvToolsFn = { v -> togglePop(v, gTools, true) }; tvMenuCol = gTool; tvToolsCol = gTools   // (v517) ⋯ المزيد على التلفزيون
        // (v151) خيارات متعددة الاختيار + زرار واحد «طبّق المحدد»: بيتنفّذوا ورا بعض (تنقيح ← لهجة+ ← عائلي/صريح ← ضمائر ← دمج مكرر)
        val aiBase = linkedMapOf("refine" to "✍ تنقيح بالسياق", "dial" to "🔥 لهجة +", "family" to "🧹 عائلي", "pron" to "🔧 ضمائر", "dedup" to "🧠 دمج مكرر")
        val aiBtns = HashMap<String, TextView>()
        val aiApplyB = pd("▶ طبّق المحدد (0)") { applyAiOptions() }
        fun paintAi() {
            for ((id, b) in aiBtns) { val on = id in aiSel; b.text = (if (on) "✓ " else "") + aiBase[id]; b.background = ui.box(if (on) 0xFF8B6B50.toInt() else 0xE0141418.toInt(), 0x1FFFFFFF, 12) }
            aiApplyB.text = "▶ طبّق المحدد (${aiSel.size})"; aiApplyB.alpha = if (aiSel.isEmpty()) 0.45f else 1f
        }
        for ((id, base) in aiBase) {
            val b = pk(base) { _ ->
                if (!aiSel.remove(id)) { aiSel.add(id); }
                paintAi()
            }
            aiBtns[id] = b; gAi.addView(b)
        }
        gAi.addView(aiApplyB); paintAi()
        // ===== الصف العلوي: الأساسي ظاهر دايمًا (☰ 📝 CC وضع-الترجمة Aa) والباقي بيتفرد بسهم ❮ وبيتلم بعد 5 ثواني =====
        fun tip(v: TextView, name: String): TextView { v.setOnLongClickListener { giShow(name, Gravity.CENTER); true }; return v }   // ضغطة طويلة = اسم الزرار
        // (v96) الزرار ❮ اتشال: كل أزرار الصف العلوي ظاهرة على طول (☰ القائمة + 🔤 النص)
        val tbExtra = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR }
        fun exAdd(v: View) { tbExtra.addView(v, 0) }
        tbCollapseFn = { }
        menuB.setOnLongClickListener { giShow("القائمة", Gravity.CENTER); true }
        toolsB.setOnLongClickListener { giShow("المزيد", Gravity.CENTER); true }
        tbRow.addView(menuB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) }); tbAdd(tbExtra)

        val textB = tip(grp("🔤", gText), "النص")
        exAdd(textB)

        fsPlayB = IconTextView(this).apply {
            text = "▶"; textSize = if (Design.isNew()) 36f else 30f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); includeFontPadding = false
            setOnClickListener { togglePlay(); showChrome() }
        }
        fsEl = ui.text("0:00", 12f, Color.WHITE); fsDu = ui.text("0:00", 12f, Color.WHITE)
        fsProgV = DualProgress(this, th)
        // زي MX: صف الوقت+التقدم فوق، وتحته: 🔓 قفل (شمال) | ⏮ ⏯ ⏭ (النص) | ⛶ احتواء/تمديد + ⧉ نافذة صغيرة (يمين)
        val fsBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_LTR
            if (Design.isNew()) setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(6)) else setPadding(ui.dp(14), ui.dp(34), ui.dp(14), 0)
            background = if (Design.isNew()) GradientDrawable().apply { setColor(0xB8141224.toInt()); cornerRadius = ui.dp(26).toFloat(); setStroke(ui.dp(1), 0x33FFFFFF) } else GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0x66000000, 0xCC000000.toInt()))   // (v445) تدرّج أنعم
        }
        val timeRow = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        timeRow.addView(fsEl, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = ui.dp(8) })
        // (v469) B9: غلاف حوالين شريط التقدم الكبير وجواه علامات الفصول فوق الشريط بالظبط
        val progWrap = FrameLayout(this)
        progWrap.addView(fsProgV, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL))
        val chapTicks = ChapTicks(); chapTicksRef = chapTicks
        progWrap.addView(chapTicks, FrameLayout.LayoutParams(-1, -1))
        timeRow.addView(progWrap, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(fsDu, LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(8) })
        // صف تحت (فوق شريط الوقت، فوق القفل): A− A+ | ⏱ توقيت | ترجمة (إيقاف/استئناف + اللغة). بيلفّ لسطر تاني لو الشاشة ضيقة
        // الصف ده بيبدأ من اليمين: شريحة الترجمة بس (حجم الترجمة والتوقيت اتنقلوا لزرار Aa فوق)
        val auxRow = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        auxRow.addView(makeTrRow(true))
        val lgIcon = trLgB   // (v224) هيتحطوا جنب 🗣 في الشريط السفلي
        if (!Design.isNew()) fsBar.addView(auxRow, LinearLayout.LayoutParams(-1, -2))
        fsBar.addView(timeRow, LinearLayout.LayoutParams(-1, ui.dp(30)))
        // صف الأدوات الصغيرة (فوق أزرار الشاشة) على اليمين: Aa (حجم/توقيت) · 📋 اللوج · 📝 الجمل · CC · 💬 وضع الترجمة
        val toolRow = FrameLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        val toolR = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        fun barPill(b: TextView): TextView = b.apply { layoutParams = LinearLayout.LayoutParams(-2, ui.dp(30)).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) }; minimumWidth = ui.dp(30); setPadding(ui.dp(8), 0, ui.dp(8), 0); textSize = 12f }
        val aiB = barPill(tip(grp("🗣", gAi, true), "لهجة (عائلي/صريح)"))
        trAiB = aiB; applyModeCaps()
        val audRouteB = mini("🎧") { AudioBridge.showMenu(this) }   // (v811) مصدر الصوت (تلفزيون/موبايل) — الشريط السفلي جنب أيقونات اللهجة
        val syncB = barPill(tip(grp("⏱", gSub, true), "تزامن الترجمة (تقديم / تأخير)"))   // (v91) مكان Aa — حجم الخط بقى بالقرص (pinch) على الشاشة
        toolR.addView(syncB)
        val audPill = barPill(tip(mini("🔊") { v -> audPopFn?.invoke(v) }, "لغة الصوت"))   // (v661) بيظهر بس لو الفيديو فيه أكتر من لغة صوت
        audPill.visibility = View.GONE; audPills.add(audPill); toolR.addView(audPill)
        rcViews["dual"] = dualB; rcViews["bgon"] = bgOnB; rcViews["ai"] = aiB   // (v531) ريموت الموبايل
        // (v1025) إعادة توزيع أزرار الشريط العلوي (الأماكن ثابتة): الأكتر استعمالًا بقت ظاهرة، والأقل اتنقل لقايمة ☰
        //   ⚡ السرعة ← مكان 📋 اللوج · 🔄 إعادة ترجمة ← مكان 🧑 الشخصيات · 🌙 ترجمة بالخلفية ← مكان ☑ سؤال الخروج
        val spdB = tip(ui.fsCircle(PlayerLogic.speedLabel(speed)) { cycleSpeed(); showChrome() }.apply { textSize = 11f }, "السرعة"); spdVisB = spdB
        val rtB = tip(mini("🔄") { batchDialog() }, "إعادة ترجمة")
        val bgTrB = tip(mini("🌙") { translateInBackground() }, "ترجمة بالخلفية")
        val toolBtns = listOf<TextView>(syncB, tip(logB, "اللوج"), tip(sentB, "الجمل"), tip(mini("📝") { sfTranslationsDialog(window.decorView) }, "ترجمات الفيديو"), tip(loopB, "تكرار الفيديو"), tip(dualB, "وضع الترجمة"), tip(charsB, "الشخصيات"), tip(voiceB, "فصل صوت الكلام عن الموسيقى"), qualB, nextListB, tip(mini("🔄") { toggleFsLocal() }, "تدوير الشاشة (طولي/عرضي)"), tip(mini("لهجة") { dialectBtn(false) }.apply { textSize = 10f }, "ترجمة بلهجة اللغة المختارة"), tip(mini("فصحى") { dialectBtn(true) }.apply { textSize = 10f }, "ترجمة بالصيغة الفصحى/الرسمية"))
        toolBtns.drop(1).filter { it !== voiceB && it !== qualB && it !== nextListB && it !== toolBtns[11] && it !== toolBtns[12] }.forEach { b ->   // (v226) 🔑 اتشال من الشريط العلوي
            toolR.addView(b, LinearLayout.LayoutParams(if (b.text.startsWith("🔑")) ui.dp(42) else ui.dp(30), ui.dp(30)).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) })
        }
        // (v1047) تكبير/تصغير الترجمة السريع: A+ / A− في آخر الشريط العلوي (الأماكن الثابتة اللي قبلهم ما اتحرّكتش)
        for ((lbl, dlt, tp) in listOf(Triple("A−", -10, "تصغير الترجمة"), Triple("A+", 10, "تكبير الترجمة"))) {
            val b = tip(mini(lbl) { tvSubScale(dlt) }, tp).apply { textSize = 11f }
            toolR.addView(b, LinearLayout.LayoutParams(ui.dp(30), ui.dp(30)).apply { setMargins(ui.dp(3), 0, ui.dp(3), 0) })
        }
        toolRow.addView(toolR, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        fsBar.addView(toolRow, LinearLayout.LayoutParams(-1, ui.dp(36)))
        // (v90) شمال: 🔓 ✨ 🧰 جنب بعض · النص: ⏮ ⏯ ⏭ كبار وموزّعين على عرض الشريط · يمين: 🔄(لاندسكيب/بورتريت) ⧉ ⛶ (⛶ على الحافة)
        val btnRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER_VERTICAL }
        // (v96) ثلاث أعمدة: شمال (وزن 1) | نص (⏮ ▶ ⏭ متسنطرين فعلًا على عرض الشاشة) | يمين (وزن 1) — فالنص دايمًا في نص الشريط بالظبط
        val leftB = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        val lockB = ui.fsCircle("🔓") { setLock(true) }
        val lockLp = { LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginEnd = ui.dp(4) } }
        fun smallIcon(v: TextView?) {
            if (v == null) return
            (v.parent as? ViewGroup)?.removeView(v); v.textSize = 15f; v.setPadding(0, 0, 0, 0)
            leftB.addView(v, LinearLayout.LayoutParams(ui.dp(34), ui.dp(34)).apply { marginStart = ui.dp(3) })
        }
        leftB.addView(lockB, lockLp()); leftB.addView(aiB); smallIcon(lgIcon); smallIcon(audRouteB)
        btnRow.addView(leftB, LinearLayout.LayoutParams(0, -2, 1f))
        val pillBg = { if (Design.isNew()) ui.box(0x00000000, 0x00000000, 24) else ui.box(0xE00F0F12.toInt(), 0x29FFFFFF, 24) }
        val prevB = ui.fsCircle("⏮") { stepOrSeek(-1); showChrome() }.apply { textSize = 20f; background = pillBg() }
        val nextB = ui.fsCircle("⏭") { stepOrSeek(1); showChrome() }.apply { textSize = 20f; background = pillBg() }
        fsPlayB.textSize = 30f
        fsPlayB.background = if (Design.isNew()) GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x40FFFFFF); setStroke(ui.dp(1), 0x66FFFFFF) } else GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE00F0F12.toInt()); setStroke(ui.dp(1), if (MtGlass.on()) 0x40FFFFFF else 0x29FFFFFF) }
        val mid = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.CENTER; setPadding(ui.dp(6), 0, ui.dp(6), 0) }
        mid.addView(prevB, LinearLayout.LayoutParams(ui.dp(60), ui.dp(44)).apply { marginEnd = ui.dp(8) })
        mid.addView(fsPlayB, LinearLayout.LayoutParams(ui.dp(fsPlayDp()), ui.dp(fsPlayDp())))
        mid.addView(nextB, LinearLayout.LayoutParams(ui.dp(60), ui.dp(44)).apply { marginStart = ui.dp(8) })
        btnRow.addView(mid, LinearLayout.LayoutParams(-2, -2))
        val rightB = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR; gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        fsBarFs = ui.fsCircle("⤢") { cycleFitNow(); showChrome() }.apply { textSize = 18f }   // (v1019) ⤢ التمديد — نفس أيقونة ووظيفة زرار MeeTube (احتواء ← ملء ← تمديد ← 100%)
        val rotBarB = ui.fsCircle("⛶") { toggleFs(); showChrome() }.apply { textSize = 18f }   // (v1019) ⛶ الشاشة الكاملة/التدوير — نفس أيقونة زرار MeeTube بالظبط
        val pipBarB = ui.fsCircle("⧉") { enterPip() }
        (noticeBtn.parent as? ViewGroup)?.removeView(noticeBtn)
        if (!Design.isNew()) rightB.addView(noticeBtn, LinearLayout.LayoutParams(-2, ui.dp(34)).apply { marginEnd = ui.dp(8) })
        rightB.addView(pipBarB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)))
        rightB.addView(fsBarFs, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginStart = ui.dp(4) })   // (v1019) نفس ترتيب MeeTube: ⤢ ثم ⛶
        rightB.addView(rotBarB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginStart = ui.dp(4) })
        btnRow.addView(rightB, LinearLayout.LayoutParams(0, -2, 1f))
        fsBar.addView(btnRow, LinearLayout.LayoutParams(-1, ui.dp(72)))
        // (v91) في العرض الواسع (لاندسكيب): ⏱ 📋 📝 CC 💬 بتتنقل للصف السفلي جنب 🔄؛ في الضيق (بورتريت) بتفضل في صفها
        var toolsWide = false
        fun placeTools(wide: Boolean) {
            if (toolsWide == wide) return; toolsWide = wide
            // (v101) كل الأزرار قليلة الاستعمال (☰ 🔤 ⏱ 💬 CC 📋 📝 🔁) في الشريط العلوي جنب عداد الجمل، مفرودة بطوله — والشريط السفلي فيه 🔓 ✨ + ⏮ ▶ ⏭ + أزرار الشاشة بس.
            // 🧰 اتشال: كل اللي فيه موجود في ☰ القائمة / عداد الجمل ▾ / شريحة الترجمة 🔁
            toolBtns.forEach { (it.parent as? ViewGroup)?.removeView(it) }
            (menuB.parent as? ViewGroup)?.removeView(menuB); (textB.parent as? ViewGroup)?.removeView(textB)
            leftB.removeAllViews(); rightB.removeAllViews(); tbRow.removeAllViews()
            // toolBtns = [⏱ توقيت, 📋 لوج, 📝 جمل, CC, 🔁 تكرار, 💬 وضع الترجمة, 🧑 شخصيات]
            fun lp(i: Int) = LinearLayout.LayoutParams(if (i == 0) -2 else ui.dp(38), ui.dp(38)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) }
            leftB.addView(lockB, lockLp()); leftB.addView(aiB); smallIcon(lgIcon); smallIcon(audRouteB)
            (noticeBtn.parent as? ViewGroup)?.removeView(noticeBtn)
            if (!Design.isNew()) rightB.addView(noticeBtn, LinearLayout.LayoutParams(-2, ui.dp(34)).apply { marginEnd = ui.dp(8) })
            rightB.addView(pipBarB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)))
            rightB.addView(fsBarFs, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginStart = ui.dp(4) })   // (v1019) نفس ترتيب MeeTube: ⤢ ثم ⛶
            rightB.addView(rotBarB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { marginStart = ui.dp(4) })
            // من الشمال لليمين (LTR): 🔁 📋 📝 🔤 ⏱ 💬 CC ☰  ← يعني ☰ على اليمين جنب عداد الجمل
            tbRow.addView(toolBtns[4], lp(4)); tbRow.addView(toolBtns[10], lp(4)); tbRow.addView(spdB, lp(1)); tbRow.addView(toolBtns[2], lp(2)); if (Design.isNew()) { tbRow.addView(toolBtns[1], lp(1)) } else tbRow.addView(rtB, lp(6))   // (v1025)
            tbRow.addView(textB, LinearLayout.LayoutParams(-2, ui.dp(38)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
            tbRow.addView(toolBtns[0], lp(0)); tbRow.addView(toolBtns[5], lp(5)); // (v1141) 📝 ترجمات الفيديو اتشال من الشريط (الشكل القديم) — القايمة لسه من ☰ → 🗂 ترجمات الفيديو
            // (v378) 🎙 فصل الصوت و HD و 📃 اتشالوا من الشريط العلوي (الجودة رجعت جنب زرار الترجمة، والتالي بقى لوحة تحت الأزرار)
            // (v221) زرار 🔑 وضع المفاتيح (toolBtns[7]) كان بيتشال هنا ومابيترجّعش — فمكانش بيظهر خالص في الشريط العلوي
            (bgTrB.parent as? ViewGroup)?.removeView(bgTrB); (spdB.parent as? ViewGroup)?.removeView(spdB); (rtB.parent as? ViewGroup)?.removeView(rtB)
            tbRow.addView(bgTrB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })   // (v1025) 🌙 مكان ☑
            (toolsB.parent as? ViewGroup)?.removeView(toolsB)
            tbRow.addView(toolsB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
            tbRow.addView(menuB, LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)).apply { setMargins(ui.dp(3), ui.dp(3), ui.dp(3), ui.dp(3)) })
            textB.minimumWidth = ui.dp(38); textB.setPadding(ui.dp(8), 0, ui.dp(8), 0)
            textAtBottom = false
            tb.visibility = View.VISIBLE
            toolRow.visibility = View.GONE
        }
        // (v101) الزراير اللي على جنبين ⏮ ⏭ كتير: لو مكانها ضيّق بنصغّرها (حجم + مسافات + خط) بدل ما آخر زرار يتاكل
        placeTools(true)
        val sideOrig = HashMap<View, FloatArray>()
        var fitW = -1
        fun scaleSide(g: LinearLayout, avail: Int) {
            val kids = (0 until g.childCount).map { g.getChildAt(it) }
            if (kids.isEmpty()) return
            var need = 0f
            for (c in kids) {
                val lp = c.layoutParams as LinearLayout.LayoutParams
                if (!sideOrig.containsKey(c)) {
                    val ts = (c as? TextView)?.textSize ?: 0f
                    val nat = if (lp.width > 0) lp.width.toFloat() else { c.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)); c.measuredWidth.toFloat() }
                    sideOrig[c] = floatArrayOf(lp.width.toFloat(), lp.height.toFloat(), lp.leftMargin.toFloat(), lp.rightMargin.toFloat(), ts, c.paddingLeft.toFloat(), c.paddingRight.toFloat(), nat, c.minimumWidth.toFloat())
                }
                val o = sideOrig[c]!!; need += o[7] + o[2] + o[3]
            }
            val f = if (need <= 0f) 1f else (avail / need).coerceIn(0.58f, 1f)
            for (c in kids) {
                val o = sideOrig[c] ?: continue; val lp = c.layoutParams as LinearLayout.LayoutParams
                lp.width = if (o[0] > 0) (o[0] * f).toInt() else o[0].toInt()
                lp.height = if (o[1] > 0) (o[1] * f).toInt() else o[1].toInt()
                lp.setMargins((o[2] * f).toInt(), lp.topMargin, (o[3] * f).toInt(), lp.bottomMargin)
                (c as? TextView)?.let { tv -> if (o[4] > 0) tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, o[4] * (0.5f + 0.5f * f)) }
                c.minimumWidth = (o[8] * f).toInt()
                c.setPadding((o[5] * f).toInt(), c.paddingTop, (o[6] * f).toInt(), c.paddingBottom)
                c.layoutParams = lp
            }
        }
        fun fitSides(w: Int) {
            if (w == fitW) return; fitW = w
            val mf = if (w >= ui.dp(720)) 1f else if (w >= ui.dp(480)) 0.86f else 0.76f
            (prevB.layoutParams as LinearLayout.LayoutParams).apply { width = (ui.dp(60) * mf).toInt(); height = (ui.dp(44) * mf).toInt(); marginEnd = (ui.dp(8) * mf).toInt() }.also { prevB.layoutParams = it }
            (nextB.layoutParams as LinearLayout.LayoutParams).apply { width = (ui.dp(60) * mf).toInt(); height = (ui.dp(44) * mf).toInt(); marginStart = (ui.dp(8) * mf).toInt() }.also { nextB.layoutParams = it }
            (fsPlayB.layoutParams as LinearLayout.LayoutParams).apply { width = (ui.dp(fsPlayDp()) * mf).toInt(); height = (ui.dp(fsPlayDp()) * mf).toInt() }.also { fsPlayB.layoutParams = it }
            val midW = (ui.dp(60) * 2 + ui.dp(8) * 2 + ui.dp(56)) * mf + ui.dp(12)
            val avail = ((w - ui.dp(28) - midW) / 2f - ui.dp(2)).toInt().coerceAtLeast(ui.dp(60))
            scaleSide(leftB, avail); scaleSide(rightB, avail)
        }
        fsBar.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ -> val w = r - l; if (w > 0) fsBar.post { placeTools(true); fitSides(w) } }
        fsBar.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob -> if (b - t != ob - ot && chromeShown) applyChromeFn() }   // ارتفاع الشريط اتغيّر: ارفع الترجمة فوقه
        val chromeFrame = FrameLayout(this).apply { visibility = View.GONE; tag = "chromeFrame" }
        // في الرأسي الصفوف بتلفّ لسطر جديد (FlowRow) — من غير HorizontalScrollView لأنه بيدّي عرض لا نهائي فالصف عمره ما بيلفّ
        // (v330) الصف الفوق: اسم الفيديو (شمال) + كبسولات العدّ (يمين)؛ أزرار المشغّل نزلت درجة تحتهم عشان ما تغطّيش الكبسولات
        topTitle = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
            typeface = android.graphics.Typeface.DEFAULT_BOLD; setShadowLayer(5f, 0f, 1f, Color.BLACK)
            setPadding(ui.dp(8), ui.dp(4), ui.dp(8), ui.dp(4)); background = if (Design.isNew()) GradientDrawable().apply { setColor(0x80141224.toInt()); cornerRadius = ui.dp(16).toFloat(); setStroke(ui.dp(1), 0x33FFFFFF) } else ui.box(0x73000000, 0x1FFFFFFF, 12); if (Design.isNew()) setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6)); visibility = View.GONE
        }
        chromeFrame.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x99000000.toInt(), 0x00000000)); isClickable = false; isFocusable = false },
            FrameLayout.LayoutParams(-1, ui.dp(120), Gravity.TOP))   // (v445) ظل علوي ناعم يطلّع الأزرار والعنوان
        chromeFrame.addView(topTitle, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply { setMargins(ui.dp(12), ui.dp(10), ui.dp(190), 0) })
        chromeFrame.addView(tb, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply { setMargins(ui.dp(8), ui.dp(50), ui.dp(8), 0) }); tbView = tb
        fixTopRowFn = fn@{
            val bw = if (::badgeRowV.isInitialized && badgeRowV.visibility == View.VISIBLE) badgeRowV.width else 0
            val bh = if (::badgeRowV.isInitialized && badgeRowV.visibility == View.VISIBLE) badgeRowV.height else 0
            val tl = topTitle.layoutParams as FrameLayout.LayoutParams
            val rm = bw + ui.dp(24)
            if (tl.rightMargin != rm) { tl.rightMargin = rm; topTitle.layoutParams = tl }
            val tp = (ui.dp(8) + bh + ui.dp(6)).coerceAtLeast(ui.dp(46))
            val tbl = tb.layoutParams as FrameLayout.LayoutParams
            if (tbl.topMargin != tp) { tbl.topMargin = tp; tb.layoutParams = tbl; placeFloatFn() }
        }
        if (::badgeRowV.isInitialized) badgeRowV.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob -> if (r - l != orr - ol || b - t != ob - ot) fixTopRowFn() }   // (v265) في ملء الشاشة الهامش بيكبر عشان الشريط مايغطّيش الكبسولات   // (v90) يمين، جنب عداد الجمل
        if (Design.isNew()) {
            chromeFrame.addView(auxRow, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(ui.dp(12), 0, ui.dp(12), ui.dp(170)) })
            fsBar.addOnLayoutChangeListener { _, _, t, _, b, _, _, _, _ ->
                val alp = auxRow.layoutParams as FrameLayout.LayoutParams
                val nb = (fsBar.layoutParams as FrameLayout.LayoutParams).bottomMargin + (b - t) + ui.dp(8)
                if (alp.bottomMargin != nb) { alp.bottomMargin = nb; auxRow.layoutParams = alp }
            }
        }
        chromeFrame.addView(fsBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { if (Design.isNew()) setMargins(ui.dp(12), 0, ui.dp(12), ui.dp(6)) else setMargins(0, 0, 0, ui.dp(6)) })
        // زرار القفل الصغير: بيظهر لما تلمس الشاشة وهي مقفولة
        lockOv = ui.fsCircle("🔒") { setLock(false) }.apply { visibility = View.GONE }
        videoBox.addView(lockOv, FrameLayout.LayoutParams(ui.dp(44), ui.dp(44), Gravity.BOTTOM or Gravity.START).apply { setMargins(ui.dp(22), 0, 0, ui.dp(22)) })
        videoBox.addView(chromeFrame, FrameLayout.LayoutParams(-1, -1))
        // (v362) لودينج كبير في نص الفيديو (لودينج ويندوز + عدّاد ثواني) وقت جلب رابط يوتيوب وأول تحميل — كان بس على زرار التشغيل الصغير ومخفي لما الشريط ظاهر
        ytBusyV = FrameLayout(this).apply {
            visibility = View.GONE; isClickable = false; isFocusable = false
            val colB = LinearLayout(this@PlayerActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            colB.addView(View(this@PlayerActivity).apply { foreground = ytBusyDr }, LinearLayout.LayoutParams(ui.dp(72), ui.dp(72)))
            ytBusyTv = TextView(this@PlayerActivity).apply { textSize = 13f; setTextColor(Color.WHITE); setShadowLayer(5f, 0f, 1f, Color.BLACK); gravity = Gravity.CENTER; setPadding(0, ui.dp(6), 0, 0) }
            colB.addView(ytBusyTv, LinearLayout.LayoutParams(-2, -2))
            addView(colB, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        videoBox.addView(ytBusyV, FrameLayout.LayoutParams(-1, -1))
        intent.getStringExtra("ytid")?.let { yid ->   // (v378)
            val fsLp = fsBar.layoutParams as FrameLayout.LayoutParams
            nextPanel = NextPanel(this, ui, th, videoBox, yid, { n -> playNextYt(n) },
                { px -> fsLp.bottomMargin = ui.dp(6) + px; fsBar.layoutParams = fsLp },
                { on -> if (on) { h.removeCallbacks(hideChrome); chromeShown = true; applyChromeFn() } else showChrome() },
                { val a = IntArray(2); val b = IntArray(2); fsProgV.getLocationOnScreen(a); videoBox.getLocationOnScreen(b); (a[1] - b[1]) + fsProgV.height })
        }
        // (v104) شرايط التقدم الـ3 بحجم رفيع جدًا دايمًا تحت الفيديو؛ لمسة على الشاشة بتظهر الشريط الكبير ولمسة تانية ترجّعها صغيرة
        miniBar = DualProgress(this, th).apply { thin = true; isClickable = false; isFocusable = false; alpha = 0.33f }
        videoBox.addView(miniBar, FrameLayout.LayoutParams(-1, 3, Gravity.BOTTOM))
        videoBox.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) { val hh = ((b - t) * 0.025f).toInt().coerceAtLeast(3); val lp = miniBar.layoutParams; if (lp.height != hh) { lp.height = hh; miniBar.layoutParams = lp } }
        }
        // زرار ⛶ (.fullscreen-btn): أسفل يسار الفيديو 10dp في الرأسي، 18dp في الشاشة الكاملة
        fsBtnV = ui.fsCircle("⛶") { toggleFs(); showChrome() }.apply { if (DeviceUi.isRemote(this@PlayerActivity)) visibility = View.GONE }   // (v663) تلفزيون/تابلت: مخفي من أول لحظة (كان بيظهر لحد أول OK على الريموت لأن applyChromeFn ماكانتش بتتنادى قبلها)
        fsBtnLp = FrameLayout.LayoutParams(ui.dp(34), ui.dp(34), Gravity.BOTTOM or (if (ytPage) Gravity.RIGHT else Gravity.LEFT))   // (v1143) صفحة يوتيوب: ⛶ يمين
        videoBox.addView(fsBtnV, fsBtnLp)
        // (v95) مكان 👁 والروتيشن: في النص بين الشريط العلوي والشريط السفلي (مش فوق شريحة الترجمة أبدًا)
        var modePillMoving = false
        placeFloatFn = fn@{
            val bh = videoBox.height; if (bh <= 0) return@fn
            val chromeOn = fullMode && chromeShown && !pipNow()
            val eyeH = ui.dp(44); val rotH = ui.dp(48); val gap = ui.dp(10)
            val zTop = ui.dp(84) + (if (chromeOn) ui.dp(48) else 0)   // (v97) تحت عداد الجمل خالص (v330) + الأزرار نزلت درجة
            val zBot = bh - (if (chromeOn) fsBar.height + ui.dp(16) else ui.dp(60))
            val room = zBot - zTop
            val both = rotH + gap + eyeH
            val showRot = false   // (v97) مفيش روتيشن عايم
            val stackH = if (showRot) both else eyeH
            val top = (if (chromeOn) zTop + (room - stackH) / 2 else zTop).coerceAtMost(zBot - stackH).coerceAtLeast(ui.dp(2))
            val rotLp = rotBtn.layoutParams as FrameLayout.LayoutParams
            val eyeLp = floatBar.layoutParams as FrameLayout.LayoutParams
            val eyeTop = if (showRot) top + rotH + gap else top
            if (rotLp.topMargin != top) { rotLp.topMargin = top; rotBtn.layoutParams = rotLp }
            if (eyeLp.topMargin != eyeTop) { eyeLp.topMargin = eyeTop; floatBar.layoutParams = eyeLp }
            if (::audBtn.isInitialized) { val al = audBtn.layoutParams as FrameLayout.LayoutParams; val at = eyeTop + ui.dp(52); if (al.topMargin != at) { al.topMargin = at; audBtn.layoutParams = al } }
            if (::tvBtn.isInitialized) { val tl = tvBtn.layoutParams as FrameLayout.LayoutParams; val tt = eyeTop + ui.dp(52) + (if (::audBtn.isInitialized && audBtn.visibility == View.VISIBLE) ui.dp(52) else 0); if (tl.topMargin != tt) { tl.topMargin = tt; tvBtn.layoutParams = tl } }
            if (::modePill.isInitialized) {   // (v467) الكبسولة انتقلت لصف الكبسولات جنب 👁 (طلب صاحب التطبيق: جنب زرار الوضع البصري مش تحته) — فلا حساب مواضع ولا تغطية من زرار الترجمة بعد كده
                val br = badgeRowRef
                // (v471) كان بيتنقّل هنا مباشرة وده بيتنادى من مستمعات onLayoutChange → تعديل شجرة الواجهة جوه مرحلة الـ layout = NullPointerException في FrameLayout.layoutChildren (فورس كلوز بعد ثواني من التشغيل). دلوقتي بيتأجّل بـ post بعد ما الـ layout يخلص
                if (br != null && modePill.parent !== br && !modePillMoving) {
                    modePillMoving = true
                    modePill.post {
                        modePillMoving = false
                        try { val b2 = badgeRowRef; if (b2 != null && modePill.parent !== b2) { (modePill.parent as? ViewGroup)?.removeView(modePill); b2.addView(modePill, LinearLayout.LayoutParams(-2, ui.dp(34)).apply { marginStart = ui.dp(6) }) } } catch (e: Throwable) { LogStore.err("Player:modePill", e) }
                    }
                }
            }
            val rv = if (showRot) View.VISIBLE else View.GONE
            if (rotBtn.visibility != rv) rotBtn.visibility = rv
        }
        videoBox.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob -> if (b - t != ob - ot) placeFloatFn() }
        fsBar.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob -> if (b - t != ob - ot) placeFloatFn() }
        applyChromeFn = {
            val on = fullMode && chromeShown && !pipNow() && !DeviceUi.isRemote(this)   // (v524) تلفزيون: طبقة التحكم القديمة (اللمس) مشالة، شريط التلفزيون بس
            try { nextPanel?.onChrome(on) } catch (_: Throwable) {}
            val wasOn = chromeFrame.visibility == View.VISIBLE
            if (on) { chromeFrame.visibility = View.VISIBLE; if (wasOn && chromeFrame.alpha < 1f) { chromeFrame.animate().cancel(); chromeFrame.alpha = 1f; chromeFrame.translationY = 0f } }
            else {
                dismissPop(); tbCollapseFn()
                if (wasOn) {   // (v445) اختفاء ناعم — (v1347) في قسم يوتيوب: اختفاء فوري (بطلب علي)
                    chromeFrame.animate().cancel()
                    if (ytPage) { chromeFrame.visibility = View.GONE; chromeFrame.alpha = 1f; chromeFrame.translationY = 0f }
                    else chromeFrame.animate().setStartDelay(0L).alpha(0f).translationY(ui.dp(10).toFloat()).setDuration(Skins.dur(160L))
                        .withEndAction { if (!(fullMode && chromeShown && !pipNow())) chromeFrame.visibility = View.GONE; chromeFrame.alpha = 1f; chromeFrame.translationY = 0f }.start()
                } else chromeFrame.visibility = View.GONE
            }
            if (on) { try { val tt = titleWithSummary(); if (topTitle.text.toString() != tt.toString()) topTitle.text = tt; topTitle.visibility = if (tt.isBlank()) View.GONE else View.VISIBLE; fixTopRowFn() } catch (_: Throwable) {} }   // (v330) (v360) + ملخص الإعداد
            if (on && !wasOn) { chromeFrame.animate().cancel(); if (ytPage) { chromeFrame.alpha = 1f; chromeFrame.translationY = 0f } else { chromeFrame.alpha = 0f; chromeFrame.translationY = ui.dp(22).toFloat(); chromeFrame.animate().setStartDelay(0L).alpha(1f).translationY(0f).setDuration(Skins.dur(280L)).setInterpolator(android.view.animation.DecelerateInterpolator(1.8f)).start() } }   // (v1347) يوتيوب: ظهور الشريط فوري (بطلب علي)
            else if (!on && !wasOn) { chromeFrame.animate().cancel(); chromeFrame.alpha = 1f; chromeFrame.translationY = 0f }
            centerPlay.visibility = if ((on && !Design.isNew()) || pipNow() || uiLocked || busyShown()) View.GONE else if (on) View.VISIBLE else if (buffering) View.VISIBLE else if (::player.isInitialized && player.isPlaying) View.GONE else View.VISIBLE   // الشريط ظاهر = فيه زرار تشغيل تحت، فمنشيلش الأوسط فوق الترجمة
            val cv = (!fullMode || chromeShown) && !pipNow()
            val tvHide = DeviceUi.isTv(this) || (DeviceUi.isRemote(this) && tvGateClosed())   // (v662) تلفزيون: 👁 و🔄 و⛶ العايمين مش بيظهروا خالص (الوظايف على شريط التحكم و«⋯») — (v636) تلفزيون: 👁 و⛶ مخفيين لحد ما شريط التحكم يظهر
            floatBar.visibility = if (cv && !tvHide && caps().visual) View.VISIBLE else View.GONE   // (v444) البصري في وضع صوت←جيميناي بس · (v427) 👁 مابقاش ظاهر طول الوقت: بيظهر مع الشريط (أو في الوضع العادي)
            batchBtn.visibility = if (cv && !tvHide) View.VISIBLE else View.GONE
            if (::audBtn.isInitialized) audBtn.visibility = if (cv && intent.getStringExtra("ytid")?.length == 11) View.VISIBLE else View.GONE
            if (::tvBtn.isInitialized) tvBtn.visibility = if (cv && !remote && !DeviceUi.isTv(this) && TvModeFab.nearby()) View.VISIBLE else View.GONE   // (v619)
            if (::modePill.isInitialized) modePill.visibility = if (cv && intent.getStringExtra("ytid")?.length == 11 && ytAudioUrl() != null) View.VISIBLE else View.GONE   // (v459)
            // (v430) في الشاشة الكاملة 👁 (وجنبه 🔄/🎧) مخفي 100% وبيظهر بس مع باقي أدوات المشغّل (لمسة) بوضوح كامل مش باهت
            if (fullMode) {
                floatBar.animate().cancel(); batchBtn.animate().cancel(); floatFades.remove(floatBar)?.let { h.removeCallbacks(it) }
                val ta = if (on) 1f else 0f
                floatBar.alpha = ta; batchBtn.alpha = ta
                if (::audBtn.isInitialized) { audBtn.animate().cancel(); audBtn.alpha = ta }
                if (::tvBtn.isInitialized) { tvBtn.animate().cancel(); tvBtn.alpha = ta }
                if (::modePill.isInitialized) { modePill.animate().cancel(); modePill.alpha = 1f }   // (v467) الكبسولة جوّه صف الكبسولات: شفافيتها من الصف نفسه
            }
            if (!fullMode && ::modePill.isInitialized && modePill.visibility == View.VISIBLE && modePill.alpha < 0.9f) modePill.alpha = 1f   // (v467) ألفا الكبسولة من صفّها
            miniBar.visibility = if (!on && !pipNow()) View.VISIBLE else View.GONE
            updateTrChip(); applyBadgeAlpha()   // (v323) العدّادات بتظهر مع أزرار المشغّل بس
            fsBtnV.visibility = if (!fullMode && !tvHide) View.VISIBLE else View.GONE   // في الشاشة الكاملة ⛶ جوه الشريط السفلي
            if (DeviceUi.isTv(this)) { fsBtnV.visibility = View.GONE; floatBar.visibility = View.GONE; batchBtn.visibility = View.GONE; rotBtn.visibility = View.GONE }   // (v664) تلفزيون: الزراري العايمة دي ممنوعة نهائيًا مهما حصل
            val subOldBm = subLp.bottomMargin
            subLp.bottomMargin = ((if (on) maxOf(ui.dp(128), fsBar.height + ui.dp(12)) else ui.dp(12)) + subPosExtra()).coerceAtLeast(0)
            if (subOldBm != subLp.bottomMargin && sub.height > 0) {   // (v1169) انزلاق الترجمة — (v1347) في يوتيوب: فوري (بطلب علي)
                sub.animate().cancel(); if (ytPage) sub.translationY = 0f else { sub.translationY = sub.translationY + (subLp.bottomMargin - subOldBm); sub.animate().translationY(0f).setStartDelay(0L).setDuration(Skins.dur(210L)).setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start() }
            }
            sub.requestLayout()   // (v469) + رفع الاستوديو
            placeFloatFn()
            applyPageChrome()
        }

        // ---- لمس الفيديو: لمسة = إظهار/إخفاء الشريط (أو تشغيل/إيقاف في الوضع الرأسي)، لمستين = ±10ث، سحب رأسي = صوت (يمين) / سطوع (شمال) ----
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        var volF = (Cfg.str("vol_boost", "0").toIntOrNull() ?: 0).coerceIn(0, 100).let { b -> if (b > 0) 1f + b / 100f else am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }   // (v167) 0..1 صوت النظام، 1..2 تضخيم
        var briF = window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
        var scrollLogged = false
        var hScrub = false; var scrubBase = 0L; var scrubTarget = 0L; var fast2x = false
        // ---- تحريك الفيديو لحظيًا مع الصباع (سحب أفقي على الفيديو أو سحب شريط التقدم) ----
        var lastScrub = 0L
        fun fastSeek(on: Boolean) { try { player.exo()?.setSeekParameters(if (on) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT) } catch (e: Exception) { LogStore.err("Main:1623", e) } }
        fun scrubTo(posMs: Long) { val now = System.currentTimeMillis(); if (now - lastScrub >= 90) { lastScrub = now; player.seekTo(posMs) } }
        fun deltaTxt(ms: Long) = (if (ms >= 0) "+" else "−") + PlayerLogic.clock(Math.abs(ms))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean { scrollLogged = false; hScrub = false; scrubBase = player.currentPosition; dismissPop(); dismissStrip(); return true }
            override fun onLongPress(e: MotionEvent) {
                if (hScrub || fast2x) return
                fast2x = true; try { player.setPlaybackSpeed(2f) } catch (e: Exception) { LogStore.err("Main:1630", e) }
                log("👆 ضغطة مطولة: 2×")
                giShow("2× ⏩", Gravity.CENTER)
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (ytPage && !fullMode && !pipNow()) { pageCpShow = true; centerPlay.visibility = if (busyShown()) View.GONE else View.VISIBLE; h.removeCallbacks(pageCpHide); h.postDelayed(pageCpHide, 2500L); return true }   // (v1143)
                // اللمس على الشاشة ما بيشغّلش ولا بيوقّف الفيديو — التشغيل/الإيقاف من زرار التشغيل بس
                if (fullMode) {
                    if (chromeShown) { log("👆 ضغطة: إخفاء الشريط"); h.removeCallbacks(hideChrome); chromeShown = false; applyChromeFn() }
                    else { log("👆 ضغطة: إظهار الشريط"); showChrome() }
                }
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val right = e.x > videoBox.width / 2f
                log(if (right) "👆👆 ضغطتين يمين: +${MtLook.doubleTapMs() / 1000L}ث" else "👆👆 ضغطتين شمال: -${MtLook.doubleTapMs() / 1000L}ث")
                val dtMs = MtLook.doubleTapMs(); val dtSec = (dtMs / 1000L).toInt()
                player.seekTo((player.currentPosition + (if (right) dtMs else -dtMs)).coerceAtLeast(0))
                giShow(if (right) "$dtSec ⏩" else "⏪ $dtSec", (if (right) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL)
                // (v469) نبضة أنيميشن على مؤشر التقديم/الترجيع (تكبير لحظي ورجوع) عشان الإيماءة تبقى محسوسة بصريًا
                if (!ytPage) try { gi.animate().cancel(); gi.scaleX = 0.7f; gi.scaleY = 0.7f; gi.animate().scaleX(1.15f).scaleY(1.15f).setDuration(130).withEndAction { try { gi.animate().scaleX(1f).scaleY(1f).setDuration(160).start() } catch (_: Throwable) {} }.start() } catch (_: Throwable) {}   // (v1347) يوتيوب: من غير نبضة (بطلب علي)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (fast2x) return true
                if (e1 == null) return false
                // سحب أفقي على الفيديو: الفيديو بيتحرك معاك وانت ماسك (عرض الشاشة كله ≈ 3 دقايق)، ويثبت لما ترفع صباعك
                if (MtLook.seekSwipe() && (hScrub || !scrollLogged && Math.abs(e2.x - e1.x) > ui.dp(16) && Math.abs(e2.x - e1.x) > Math.abs(e2.y - e1.y) * 1.2f && durMs > 0)) {
                    if (!hScrub) { hScrub = true; scrubBase = player.currentPosition; fastSeek(true); h.removeCallbacks(hideChrome); log("↔ سحب أفقي: تقديم/ترجيع") }
                    val span = minOf(durMs, 180_000L)
                    scrubTarget = (scrubBase + (e2.x - e1.x) / videoBox.width.coerceAtLeast(1) * span).toLong().coerceIn(0L, maxOf(0L, durMs))
                    scrubTo(scrubTarget)
                    giShow(PlayerLogic.clock(scrubTarget) + "  (" + deltaTxt(scrubTarget - scrubBase) + ")", Gravity.CENTER)
                    return true
                }
                if (Math.abs(dy) < Math.abs(dx)) return false
                // (v340) سحب لفوق من حرف الفيديو التحتاني = لوحة «التالي» (فيديوهات القايمة / المقترحة) زي يوتيوب
                if (!scrollLogged && !incognito && intent.getStringExtra("ytid") != null && e1.y > videoBox.height * 0.78f && e1.y - e2.y > ui.dp(56)) {
                    scrollLogged = true; log("↕ سحب لفوق: التالي"); openNextSheet(); return true
                }
                if (ytPage && !fullMode) {   // (v1143) صفحة يوتيوب المصغّرة: سحب لتحت = تصغير (صورة مصغّرة)، ومفيش صوت/سطوع
                    return true   // (v1161) السحب لتحت بقى تفاعلي (ytDragTouch) مش ضغطة واحدة
                }
                if (!MtLook.levelSwipes()) return true
                val d = dy / videoBox.height.coerceAtLeast(1) * 1.3f
                if (!scrollLogged) { scrollLogged = true; log(if (e1.x > videoBox.width / 2f) "↕ سحب: الصوت" else "↕ سحب: السطوع") }
                if (e1.x > videoBox.width / 2f && remote) {   // (v568) سحب الصوت في وضع المتحكم = صوت التلفزيون
                    volF = (volF + d).coerceIn(0f, 2f)
                    rmSendVolume(Math.round(volF * 100)); ctl.vol.progress = Math.round(volF * 100); indShow(volInd, volF)
                } else if (e1.x > videoBox.width / 2f) {
                    volF = (volF + d).coerceIn(0f, 2f)
                    val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(minOf(volF, 1f) * mx), 0)
                    val bNow = Math.round((volF - 1f).coerceAtLeast(0f) * 100)
                    if (bNow != (Cfg.str("vol_boost", "0").toIntOrNull() ?: 0)) setBoostPct(bNow)
                    if (bNow > 0) player.volume = 1f
                    ctl.vol.progress = Math.round(volF * 100)
                    indShow(volInd, volF)
                } else {
                    briF = (briF + d).coerceIn(0.02f, 1f)
                    val wl = window.attributes; wl.screenBrightness = briF; window.attributes = wl
                    indShow(briInd, briF)
                }
                return true
            }
        })
        // ===== قرص (pinch out/in) على الشاشة = تكبير/تصغير الترجمة (60%–200%) =====
        var pinching = false; var pinchLock = false; var pinchBase = 100; var pinchAcc = 1f
        var pinchVideo = false; var pinchZoomBase = 1f   // (v469) في وضع العرض 100%: القرص بيكبّر سطح الفيديو نفسه بدل حجم الترجمة
        val sgd = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: android.view.ScaleGestureDetector): Boolean {
                if (pipNow() || uiLocked) return false
                pinching = true; pinchLock = true; pinchBase = Cfg.int("sub_scale", 100); pinchAcc = 1f
                pinchVideo = curFit() == 3; pinchZoomBase = vidZoomF
                val t = android.os.SystemClock.uptimeMillis()
                val c = MotionEvent.obtain(t, t, MotionEvent.ACTION_CANCEL, 0f, 0f, 0); gd.onTouchEvent(c); c.recycle()   // ألغي أي إيماءة شغالة (ضغطة مطولة 2× / سحب)
                h.removeCallbacks(hideChrome); log("🤏 قرص: حجم الترجمة")
                return true
            }
            override fun onScale(d: android.view.ScaleGestureDetector): Boolean {
                pinchAcc *= d.scaleFactor
                if (pinchVideo) {   // (v469) زوم الفيديو 50%–300% حوالين المركز
                    val z = (pinchZoomBase * pinchAcc).coerceIn(0.5f, 3f)
                    if (z != vidZoomF) { vidZoomF = z; applyFit(sv, videoBox) }
                    giShow("🔍 " + Math.round(z * 100) + "%", Gravity.CENTER)
                    return true
                }
                val n = Math.round(pinchBase * pinchAcc).coerceIn(60, 200)
                if (n != Cfg.int("sub_scale", 100)) { Cfg.put("sub_scale", n.toString()); restyle() }
                giShow("📏 $n%", Gravity.CENTER)
                return true
            }
            override fun onScaleEnd(d: android.view.ScaleGestureDetector) { pinching = false }
        })
        // ===== سحب التزامن: دوس على الترجمة واسحب يمين = تتأخر، شمال = تتقدّم (كل ~18dp = 0.1 ث) — بيتحفظ لكل فيديو =====
        var syncCand = false; var syncing = false; var sx = 0f; var syncStart = 0L
        fun hitSub(x: Float, y: Float): Boolean {
            if (pipNow() || !ccOn || sub.visibility != View.VISIBLE || sub.height <= 0) return false
            val slop = ui.dp(28)
            val cx = (sub.left + sub.right) / 2f; val half = maxOf(sub.boxWidthPx() / 2f, ui.dp(60).toFloat()) + slop
            return Math.abs(x - cx) <= half && y >= sub.top - slop && y <= sub.bottom + slop
        }
        gestureLayer.setOnTouchListener { _, ev ->
            if (uiLocked) {
                if (ev.actionMasked == MotionEvent.ACTION_UP && ev.eventTime - ev.downTime < 300) { lockOv.visibility = View.VISIBLE; h.removeCallbacks(hideLockOv); h.postDelayed(hideLockOv, 2500) }
                return@setOnTouchListener true
            }
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (fast2x) { fast2x = false; try { player.setPlaybackSpeed(speed) } catch (e: Exception) { LogStore.err("Main:1711", e) }; gi.visibility = View.GONE }
                if (hScrub) { hScrub = false; fastSeek(false); player.seekTo(scrubTarget); if (ev.actionMasked == MotionEvent.ACTION_UP && !syncing) showChrome() }
            }
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) { pinchLock = false; pinching = false }
            sgd.onTouchEvent(ev)
            if (pinchLock || ev.pointerCount > 1) {   // القرص شغال (أو لسه صباع واحد باقي بعده): ما نبعتش اللمس لباقي الإيماءات
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) { pinching = false; pinchLock = false }
                return@setOnTouchListener true
            }
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { syncing = false; syncCand = hitSub(ev.x, ev.y); sx = ev.x; syncStart = offsetMs }
                MotionEvent.ACTION_MOVE -> if (syncCand && (syncing || Math.abs(ev.x - sx) > ui.dp(14))) {
                    if (!syncing) {
                        syncing = true; log("↔ سحب على الترجمة: تزامن")
                        val c = MotionEvent.obtain(ev); c.action = MotionEvent.ACTION_CANCEL; gd.onTouchEvent(c); c.recycle()
                        h.removeCallbacks(hideChrome)
                    }
                    val steps = Math.round((ev.x - sx) / ui.dp(18).toFloat())
                    val target = (syncStart + steps * 250L).coerceIn(-10000L, 10000L)   // (v468) نفس خطوة وحد أزرار التزامن
                    if (target != offsetMs) setOff(target - offsetMs)
                    giShow(String.format("⏱ %+.2fs", offsetMs / 1000.0) + (if (offsetMs > syncStart) "  تأخير" else if (offsetMs < syncStart) "  تقديم" else ""), Gravity.CENTER)
                    return@setOnTouchListener true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (syncing) { syncing = false; syncCand = false; if (fullMode) showChrome(); return@setOnTouchListener true }
            }
            if (ytPage && !fullMode && !pipNow() && !hScrub && !fast2x) {   // (v1161) سحب التصغير التفاعلي
                if (ytAnim?.isRunning == true) return@setOnTouchListener true
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> ytDragDown(ev)
                    MotionEvent.ACTION_MOVE -> {
                        if (!ytDragOn && ytDragStart(ev)) { val c = MotionEvent.obtain(ev); c.action = MotionEvent.ACTION_CANCEL; gd.onTouchEvent(c); c.recycle(); h.removeCallbacks(pageCpHide) }
                        if (ytDragOn) { ytDragMove(ev); return@setOnTouchListener true }
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (ytDragOn) { ytDragEnd(ev); return@setOnTouchListener true }
                }
            }
            gd.onTouchEvent(ev); true
        }

        // ---- الكبسولة تحت الفيديو (الوضع الرأسي) ----
        ctl.play.setOnClickListener { togglePlay() }
        ctl.speed.setOnClickListener { cycleSpeed() }
        ctl.cc.setOnClickListener { toggleCc() }
        ctl.cc.visibility = View.GONE   // (v1138) CC اتنقل لصف أزرار الترجمة
        ctl.exp.setOnClickListener { doExport() }
        ctl.rot.setOnClickListener { toggleFs() }
        ctl.prev.setOnClickListener { val t = player.currentPosition - offsetMs; val i = starts.indexOfLast { it < t - 1500 }; player.seekTo(if (i >= 0) starts[i] + offsetMs else 0L) }
        ctl.next.setOnClickListener { val t = player.currentPosition - offsetMs; val i = starts.indexOfFirst { it > t + 200 }; if (i >= 0) player.seekTo(starts[i] + offsetMs) }
        ctl.vol.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (!u) return
                if (remote) { rmSendVolume(p); return }   // (v568) السلايدر في وضع المتحكم = صوت التلفزيون
                player.volume = 1f   // (v270) الصوت العادي = صوت النظام
                if (p <= 100) { SysVol.set(this@PlayerActivity, p); if ((Cfg.str("vol_boost", "0").toIntOrNull() ?: 0) != 0) setBoostPct(0) }
                else { SysVol.set(this@PlayerActivity, 100); setBoostPct(p - 100) }
                giShow(if (p <= 100) "🔊 $p%" else "🔊 $p%  تضخيم ${boostDbText(p - 100)}", Gravity.CENTER)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        ctl.vol.max = 200; ctl.vol.progress = volTotal()
        // (v270) زراري الفوليوم أب/داون بيحرّكوا السلايدر (وبيصفّروا التضخيم لو الصوت نزل عن الآخر)
        volWatch?.stop()
        volWatch = if (remote) null else SysVol.watch(this) {
            if (SysVol.get(this) < 100 && (Cfg.str("vol_boost", "0").toIntOrNull() ?: 0) != 0) setBoostPct(0)
            val t = volTotal(); volF = t / 100f
            if (ctl.vol.progress != t) ctl.vol.progress = t
        }
        fun seekFrac(f: Float) { if (durMs > 0) player.seekTo((f * durMs).toLong()) }
        // سحب شريط التقدم: الفيديو بيتحرك معاك لحظيًا + بيكتب الوقت والفرق، ويثبت لما ترفع صباعك
        var barStart = 0L
        val barDrag: (Boolean) -> Unit = { on ->
            if (on) { barStart = player.currentPosition; fastSeek(true); h.removeCallbacks(hideChrome); seekFs?.begin(uri, url, hdr, durMs) }
            else { fastSeek(false); seekFs?.end() }
        }
        val barScrub: (Float) -> Unit = { f ->
            if (durMs > 0) {
                val t = (f * durMs).toLong(); scrubTo(t)
                if (seekFs != null && seekFs.active) seekFs.update(t, PlayerLogic.clock(t), "(" + deltaTxt(t - barStart) + ")")   // (v904) الوقت الكبير + الإطارات بدل الفقاعة
                else giShow(PlayerLogic.clock(t) + "  (" + deltaTxt(t - barStart) + ")", Gravity.CENTER)
            }
        }
        ctl.prog.onDrag = barDrag; ctl.prog.onScrub = barScrub
        fsProgV.onDrag = barDrag; fsProgV.onScrub = barScrub
        ctl.prog.onSeek = { f -> seekFrac(f) }
        fsProgV.onSeek = { f -> seekFrac(f); showChrome() }

        // ---- الجمل واللوجز (نوافذ سفلية بدل اللوحة اللي تحت الفيديو) ----
        logTv = ui.text("", 11f, th.text).apply { setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6)) }
        logSv = ScrollView(this).apply { addView(logTv); layoutParams = LinearLayout.LayoutParams(-1, -1) }
        adapter = object : BaseAdapter() {
            override fun getCount() = list.size + visList.size
            override fun getItem(i: Int): Any = if (i < list.size) list[i] else visList[i - list.size]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
                if (i >= list.size) {   // (v226) جمل الوضع البصري: شريط أزرق
                    val ve = visList[i - list.size]
                    val vrow = LinearLayout(this@PlayerActivity).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
                    val vbar = View(this@PlayerActivity).apply { setBackgroundColor(0xFF3B82F6.toInt()) }
                    val vcol = LinearLayout(this@PlayerActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6)) }
                    vcol.addView(ui.text("👁 " + PlayerLogic.clock((ve.start * 1000).toLong()), 10f, th.muted))
                    vcol.addView(ui.text(if (ve.translated.isEmpty()) ve.original else ve.translated, 14f, th.text))
                    if (ve.original.isNotBlank() && ve.original != ve.translated) vcol.addView(ui.text(ve.original, 11f, th.muted))
                    vrow.addView(vbar, LinearLayout.LayoutParams(ui.dp(4), -1)); vrow.addView(vcol, LinearLayout.LayoutParams(0, -2, 1f))
                    return vrow
                }
                val q = list[i]
                val row = LinearLayout(this@PlayerActivity).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
                val bar = View(this@PlayerActivity).apply { setBackgroundColor(0x55FFFFFF) }   // (v1199) من غير لون الجنس
                val col = LinearLayout(this@PlayerActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6)) }
                col.addView(ui.text(PlayerLogic.clock((q.start * 1000).toLong()), 10f, th.muted))
                col.addView(ui.text(dispTr(q), 14f, th.text))   // (v1099) T4
                if (q.original.isNotBlank() && q.original != q.translated) col.addView(ui.text(q.original, 11f, th.muted))
                row.addView(bar, LinearLayout.LayoutParams(ui.dp(4), -1)); row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.setBackgroundColor(if (i == curIdx) (th.primary and 0x00FFFFFF) or 0x33000000 else Color.TRANSPARENT)
                return row
            }
        }
        listView = ListView(this).apply {
            this.adapter = this@PlayerActivity.adapter; divider = android.graphics.drawable.ColorDrawable(th.border); dividerHeight = 1
            layoutParams = LinearLayout.LayoutParams(-1, -1)
            setOnItemClickListener { _, _, i, _ -> if (i < list.size) player.seekTo(starts[i] + offsetMs) else visList.getOrNull(i - list.size)?.let { player.seekTo((it.start * 1000).toLong()) } }
        }
        counters = ui.text("", 10f, th.muted).apply { setPadding(ui.dp(16), ui.dp(6), ui.dp(16), ui.dp(2)) }
        val copyChip = IconTextView(this).apply {
            text = "📋 نسخ كل الجمل بالتوقيتات"; textSize = 12f; setTextColor(th.text); gravity = Gravity.CENTER
            setPadding(ui.dp(12), ui.dp(7), ui.dp(12), ui.dp(7)); background = ui.box(th.surface, th.border, 8)
            setOnClickListener { copySentences() }
        }
        val sentCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; layoutParams = LinearLayout.LayoutParams(-1, -1) }
        sentCol.addView(copyChip, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = ui.dp(6) })
        // (v469) B8: صف بحث داخل النص (يقفز ويسييك لتالي جملة مطابقة) + مفتاح المتابعة التلقائية للجملة الحالية
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val searchEt = android.widget.EditText(this).apply { hint = "🔎 ابحث في النص…"; setSingleLine(true); textSize = 13f; setTextColor(th.text); setHintTextColor(th.muted); setPadding(ui.dp(10), 0, ui.dp(10), 0); background = ui.box(th.surface, th.border, 8) }
        searchRow.addView(searchEt, LinearLayout.LayoutParams(0, ui.dp(40), 1f))
        searchRow.addView(ui.button("🔎 التالي") { sentSearch(searchEt.text.toString()) }, LinearLayout.LayoutParams(-2, ui.dp(40)).apply { marginStart = ui.dp(6) })
        val followCb = android.widget.CheckBox(this).apply { text = "متابعة تلقائية"; isChecked = true; textSize = 12f; setTextColor(th.text); setOnCheckedChangeListener { _, on -> sentFollow = on } }
        searchRow.addView(followCb, LinearLayout.LayoutParams(-2, ui.dp(40)).apply { marginStart = ui.dp(6) })
        sentCol.addView(searchRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ui.dp(6) })
        sentCol.addView(listView, LinearLayout.LayoutParams(-1, 0, 1f))
        sentDlg = ui.sheet(this, "📝 الجمل", listOf<View>(sentCol), true, frac = 0.5f)
        sentDlg.setOnShowListener { updVis(); adapter.notifyDataSetChanged() }
        val logCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; layoutParams = LinearLayout.LayoutParams(-1, -1) }
        fun logChip(t: String, f: () -> Unit) = IconTextView(this).apply {
            text = t; textSize = 12f; setTextColor(th.text); gravity = Gravity.CENTER; minHeight = ui.dp(44); setPadding(ui.dp(10), ui.dp(7), ui.dp(10), ui.dp(7)); background = ui.box(th.surface, th.border, 8)
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = ui.dp(6); topMargin = ui.dp(4) }; setOnClickListener { f() }
        }
        fun logShow(m: Int) {
            logMode = m; lastLogLen = -1
            logTv.text = when (m) {
                1 -> LogStore.prevText(80000).ifBlank { "مفيش لوج لجلسة سابقة" }
                2 -> LogStore.crashText().ifBlank { "مفيش كراش متسجّل" }
                else -> synchronized(logBuf) { logBuf.toString() }
            }
            logSv.post { if (m == 0) logSv.fullScroll(View.FOCUS_DOWN) else logSv.scrollTo(0, 0) }
        }
        fun logCopy() {
            val body = when (logMode) { 1 -> LogStore.prevText(150000); 2 -> LogStore.crashText(); else -> LogStore.currentText(150000) }
            (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("log", LogStore.header(this) + "\n\n" + body))
            Notice.show(this, ("📋 اللوج اتنسخ").toString(), 2300L)
        }
        val logRow = LinearLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(8), 0, ui.dp(8), ui.dp(4)) }
        logRow.addView(logChip("📋 نسخ") { logCopy() }); logRow.addView(logChip("الحالي") { logShow(0) })
        logRow.addView(logChip("🕘 الجلسة اللي فاتت") { logShow(1) }); logRow.addView(logChip("💥 آخر كراش") { logShow(2) })
        logRow.addView(logChip("📦 ZIP لوج+ترجمة") { exportLogZip() })   // (v1195)
        logCol.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(logRow) }, LinearLayout.LayoutParams(-1, -2))
        (batchTv.parent as? android.view.ViewGroup)?.removeView(batchTv)
        batchTv.setOnClickListener(null); batchTv.isClickable = false; batchTv.setTextIsSelectable(true)
        logCol.addView(MaxHeightScroll(this, (resources.displayMetrics.heightPixels * 0.14f).toInt()).apply { addView(batchTv, FrameLayout.LayoutParams(-1, -2)) }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(ui.dp(8), 0, ui.dp(8), ui.dp(6)) })
        logSv.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f); logCol.addView(logSv)
        logDlg = ui.sheet(this, "📜 اللوجز", listOf<View>(logCol), true, frac = 0.45f)
        logDlg.setOnShowListener { logShow(0) }
        mem = ui.memRow()

        // (v103) القايمة الجانبية اتشالت: ☰ بقت قايمة منسدلة (gTool)
        val extrasCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, ui.dp(2), 0, ui.dp(20)) }
        extrasCol.addView(ctl.root)
        extrasCol.addView(makeTrRow(false), LinearLayout.LayoutParams(-1, -2).apply { setMargins(ui.dp(16), ui.dp(8), ui.dp(16), 0) })
        val pRow = LinearLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            addView(ui.button("🔄 إعادة ترجمة") { batchDialog() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = ui.dp(4) })
            addView(ui.button("🌙 ترجمة بالخلفية") { translateInBackground() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(4) })
        }
        extrasCol.addView(pRow, LinearLayout.LayoutParams(-1, -2).apply { setMargins(ui.dp(16), ui.dp(8), ui.dp(16), 0) })
        extrasCol.addView(counters); extrasCol.addView(mem.root, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(6) })
        val scroll = ScrollView(this).apply { addView(extrasCol) }
        val extraView: View = if (ytPage) buildYtPage() else scroll
        extras = extraView
        page.addView(videoBox, LinearLayout.LayoutParams(-1, ui.dp(220)))
        page.addView(extraView, LinearLayout.LayoutParams(-1, 0, 1f))
        val rootFrame = FrameLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_LTR }
        rootFrame.addView(page, FrameLayout.LayoutParams(-1, -1))
        setContentView(rootFrame)
        if (DeviceUi.isRemote(this)) { TvFocus.attach(this, th.primary); tvInitBar(rootFrame); tvSnapChrome(); tvChromeGate() }   // (v477 م4)
        // شاشة كاملة دايمًا (أفقي ورأسي) إلا في صفحة يوتيوب: الصفحة تحت الفيديو والتكبير بزرار ⛶
        applyFull(wantFull())
        // (v1347) أنيميشن التمدد من القايمة اتلغى بالكامل (بطلب علي): الفتح فوري
        // فيديو اتفتح من فولدرات الجهاز: يشتغل لاندسكيب مباشرة زي MX Player
        // الاتجاه الأولي من شكل الفيديو (من المكتبة) — وبعدها بيتصحح لوحده أول ما الأبعاد الحقيقية تظهر (onVideoSizeChanged)
        if (intent.getBooleanExtra("landscape", false) && resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        videoBox.addOnLayoutChangeListener { _, l, t, r, bt, ol, ot, orr, ob -> if (r - l != orr - ol || bt - t != ob - ot) applyFit(sv, videoBox) }

        buildPlayer()

        // المحرك + استرجاع التقدم المحفوظ
        freshOnce = intent.getBooleanExtra("fresh", false)
        initEngine()
        if (!remote && !pendingYt && !handedOff) try { setBuffering(true) } catch (_: Throwable) {}
        if (pendingYt) startYtPend()   // (v351)
        if (Build.VERSION.SDK_INT >= 33) { try { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7) } catch (e: Exception) { LogStore.err("Main:1892", e) } }
        PlayerRemote.act = java.lang.ref.WeakReference(this)
        KeepAliveService.start(this)

        var tickErrN = 0
        var tickBad = false   // (v763) لو حلقة العرض وقعت في استثناء، العرض الاحتياطي يكمّل الترجمة
        h.post(object : Runnable {
            override fun run() {
                tickBad = false
                try {
                cur = player.currentPosition
                val d = player.duration
                if (d > 0) durMs = d
                if (partTask != null) partTick(d)
                if (!remote) v469Tick() else remoteWatch()   // (v469) حلقة A-B + عدّاد «التالي» + تمييز الفصل الحالي (v546: في وضع المتحكم التلفزيون هو اللي بيعملها)
                brainTick()   // (v542) نشر الحالة والترجمة للريموت (لو فيه ريموت بيسأل)
                run {
                    val nowP = System.currentTimeMillis()
                    if (nowP - lastPosSave >= 3000 && engineReady && !incognito && !remote && durMs > 0) {
                        lastPosSave = nowP
                        try {
                            if (cur > 1000 && cur < durMs - 4000) Cfg.p.edit().putString("lastpos", vid + "\t" + cur).apply()
                            else if (cur >= durMs - 4000 && (Cfg.p.getString("lastpos", "") ?: "").startsWith(vid + "\t")) Cfg.p.edit().remove("lastpos").apply()
                            saveYtProg()   // (v586)
                        } catch (_: Throwable) {}
                    }
                    if (nowP - lastRecentSave >= 20000 && !remote && player.isPlaying) { lastRecentSave = nowP; Thread { try { saveRecent() } catch (_: Throwable) {} }.apply { isDaemon = true }.start() }
                }
                val frac = if (durMs > 0) (cur.toFloat() / durMs).coerceIn(0f, 1f) else 0f
                val cov = if (durMs > 0) (engine.coveredSec() * 1000.0 / durMs).toFloat().coerceIn(0f, 1f) else 0f
                val pr = if (fullMode) fsProgV else ctl.prog
                if (!pr.dragging) pr.played = frac
                pr.translated = cov
                if (durMs > 0) {
                    val sr = engine.subs; val pn = engine.pendingCount()
                    if (sr !== segSubsRef || pn != segPendN) { segSubsRef = sr; segPendN = pn; segCov = engine.coverageSegs(); segPend = engine.pendingSegs() }
                }
                try { val vc = if (::visual.isInitialized) visual.count else 0; if (vc != segVisN) { segVisN = vc; segVis = if (vc == 0) emptyList() else visual.spans() } } catch (_: Throwable) {}
                val onlineSrc = url != null || uri?.scheme?.startsWith("http") == true
                if (onlineSrc && durMs > 0) { try { addBuf(cur / 1000.0, player.bufferedPosition / 1000.0) } catch (_: Throwable) {} }
                val refSegs = engine.refiningSegs
                val sentSegs = allSentSegs()   // (دمج v1081) أزرق = اتبعت ولسه ما رجعش — في كل الأوضاع (سريع · ٧٥/٢٥ · الأدق · متوازن)
                pr.sent = sentSegs
                pr.durSec = durMs / 1000.0; pr.cov = segCov; pr.pend = segPend; pr.refine = refSegs; pr.vis = segVis; pr.buf = if (onlineSrc) ArrayList(bufSegs) else partBuf
                pr.invalidate()
                if (miniBar.visibility == View.VISIBLE) { miniBar.played = frac; miniBar.durSec = durMs / 1000.0; miniBar.cov = segCov; miniBar.sent = sentSegs; miniBar.pend = segPend; miniBar.refine = refSegs; miniBar.vis = segVis; miniBar.buf = pr.buf; miniBar.invalidate() }
                val tEl = PlayerLogic.clock(cur); val tDu = PlayerLogic.clock(durMs)
                if (fullMode) { fsEl.text = tEl; fsDu.text = tDu } else { ctl.tEl.text = tEl; ctl.tDur.text = tDu }
                val now = System.currentTimeMillis()
                if (now - lastNotifAt >= 1000) { lastNotifAt = now; pushNotif() }
                if (dirty && now - lastRefresh > 1000) { dirty = false; lastRefresh = now; refreshList(); curIdx = -2 }
                visNow = (cur - offsetMs) / 1000.0
                visOv.showBoxes(visual.boxesAt(visNow, cur / 1000.0))
                val act = PlayerLogic.activeIndices(spStarts, spEnds, cur, offsetMs, 400L, 1).map { spMap[it] }   // (v158) كل متحدث بيظهر لوحده (الأحدث بس)
                val sact = PlayerLogic.activeIndices(sdStarts, sdEnds, cur, offsetMs, 400L, 2).map { sdMap[it] }
                // مراقبة العرض: لو جملة عدّى وقتها وأنا شغّال عادي ومظهرتش في act → اتسجلت في اللوج بتوقيتها ونصها
                run {
                    val tNow = cur - offsetMs
                    for (ix in act) seenKeys.add(sentKey(list[ix]))
                    val pv = lastChkT
                    if (player.isPlaying && pv >= 0 && tNow - pv in 1L..1500L) {
                        for (q in list.indices) {
                            if (list[q].isSound || ends[q] <= pv || ends[q] > tNow || ends[q] - starts[q] < 600L) continue
                            val k = sentKey(list[q])
                            if (k !in seenKeys && warnedKeys.add(k)) LogStore.add("⚠ جملة #${q + 1} عدّى وقتها ومظهرتش في المشغّل (${fmtMs(starts[q] + offsetMs)} → ${fmtMs(ends[q] + offsetMs)}): ${list[q].translated.take(60)} | ظاهر وقتها: ${act.map { it + 1 }}")
                        }
                    }
                    lastChkT = tNow
                    if (seenKeys.size > 6000) seenKeys.clear()
                    if (warnedKeys.size > 2000) warnedKeys.clear()
                }
                val idx = act.lastOrNull() ?: -1
                val gs = PlayerLogic.orderSpeakers(act.map { list[it] })
                // جملة طويلة واحدة: بتتقسم لأجزاء بتظهر بالتتابع على مدة الجملة (التوقيت الأصلي ثابت)
                var parts: List<String> = emptyList(); var part = 0
                val ssn = sub.style
                // (v1045) عرض بالتتابع: جملة واحدة بتتقسم عند علامة الفصل وكل جزء بيظهر لوقته ويختفي وبعده اللي بعده
                if (ccOn && !preferNative && gs.size == 1 && idx >= 0 && ssn.splitOn) {
                    try {
                        val g0 = gs[0]; val src = if (ssn.dual >= 3) g0.original.ifBlank { g0.translated } else g0.translated
                        val pp = PlayerLogic.seqParts(src, ends[idx] - starts[idx], maxOf(ssn.splitThresh * 2, 12))
                        if (pp.size > 1) { parts = pp; part = PlayerLogic.partIndex(starts[idx], ends[idx], cur - offsetMs, pp, true) }
                    } catch (e: Throwable) { LogStore.err("Player:seqParts", e) }
                }
                // (v633) مفيش وميض: لو فيه ترجمة للبرنامج (محرك شغّال/جمل مترجمة) ما نعرضش الترجمة الأصلية في الفجوة القصيرة بين جملتين (أو قبل ما جملة المحرك تبدأ بأجزاء من الثانية)
                //        إلا لو الفجوة فعلًا استمرت. من غير ترجمة برنامج بتظهر الأصلية فورًا زي الأول.
                val natGap = ccOn && gs.isEmpty() && nativeCue.isNotEmpty()
                if (!natGap) natGapSince = 0L else if (natGapSince == 0L) natGapSince = now
                val natHold = !preferNative && natGap && (engineStarted || sfBusy.isNotEmpty() || engine.subs.isNotEmpty()) && now - natGapSince < 900L
                val nat = ccOn && !sfHideNative && (gs.isEmpty() || preferNative) && nativeCue.isNotEmpty() && !natHold   // (v515) (v521) preferNative = المستخدم اختار مسار الفيديو الأصلي ترجمة الفيديو الأصلية لما مفيش ترجمة من المحرك
                if (nat != natShown) { natShown = nat; try { sub.style = natStyle(SubStyle.load { k, d -> Cfg.str(k, d) }) } catch (e: Throwable) { LogStore.err("Player:natStyle", e) } }
                val ul = (sfShown && !preferNative && gs.isNotEmpty()) || (nat && sfLive.isNotEmpty())
                if (ul != sub.style.underline) { sub.style = sub.style.copy(underline = ul); curIdx = -2 }
                if (nativeCue != natWaitCue) { natWaitCue = nativeCue; natWaitSince = now }
                val liveWait = nat && sfLive.isNotEmpty() && sfLiveCache[nativeCue] == null && now - natWaitSince < 2500L   // (v703) لسه الترجمة ماجتش: ما نعرضش الأصل
                val key = act.joinToString(",") + ":" + part + (if (liveWait) "|W" else "") + (if (nat) "|N:" + nativeCue + (if (sfLive.isNotEmpty()) "|L" + sfLiveGen else "") else "")
                if (idx != curIdx || key != curKey) {
                    curIdx = idx; curKey = key
                    val shown0: Sub? = when {
                        !ccOn -> null
                        gs.isEmpty() || preferNative -> if (nat && !liveWait) natSub(nativeCue) else null
                        parts.size > 1 -> (if (ssn.dual >= 3) gs[0].copy(original = parts[part], isContinuation = gs[0].isContinuation && part == parts.size - 1) else gs[0].copy(translated = parts[part], isContinuation = gs[0].isContinuation && part == parts.size - 1))
                        else -> PlayerLogic.combine(gs)
                    }
                    val shown = trMarkParens(shown0, gs)   // (v1099) T4: أقواس على الجمل المتغيّرة بأثر رجعي
                    sub.show(shown, gs)
                    if (pipNow()) pipOv?.set(if (shown == null) "" else sub.style.mainText(shown))
                    if (sentDlg.isShowing) { updVis(); adapter.notifyDataSetChanged() }
                    if (idx >= 0 && sentDlg.isShowing && !listView.isPressed && sentFollow) listView.smoothScrollToPositionFromTop(idx, ui.dp(30))   // (v469) المتابعة بقت اختيارية
                }
                // حارس العرض: جملة المفروض ظاهرة (curIdx >= 0) بس الـview مخفي أو ارتفاعه صفر → نرجّعه ونسجّل في اللوج
                if (ccOn && curIdx >= 0 && !sub.suppressed && !pipNow() && (sub.visibility != View.VISIBLE || sub.height <= 0)) {
                    if (++hideTicks >= 2) { hideTicks = 0; LogStore.add("⚠ الترجمة #${curIdx + 1} المفروض ظاهرة بس الـview مخفي/ارتفاعه صفر — اتصلّحت"); sub.visibility = View.VISIBLE; sub.requestLayout(); curIdx = -2 }
                } else hideTicks = 0
                // (v134) شرح المصطلحات: علامة ⓘ + اسم المصطلح بس بخط صغير (الشرح بيظهر لما تدوس عليها)؛ أوصاف الأصوات بتفضل زي ما هي
                val termIx = if (!ccOn) -1 else sact.firstOrNull { list[it].translated.trimStart().startsWith("«") } ?: -1
                val sTxt = if (!ccOn || sact.isEmpty()) "" else sact.joinToString("   ") { ix -> val t = list[ix].translated; if (t.trimStart().startsWith("«")) "ⓘ " + termName(t) else t }
                if (sTxt != soundKey) {
                    soundKey = sTxt; termFull = if (termIx >= 0) list[termIx].translated else ""
                    soundTv.textSize = if (termIx >= 0) 10.5f else 13f
                    soundTv.setTextColor(if (Extras.deaf && termIx < 0) 0xFFB8C0CC.toInt() else 0xFFE8EAED.toInt())
                    soundTv.text = sTxt; soundTv.visibility = if (sTxt.isEmpty()) View.GONE else View.VISIBLE
                }
                LoadUi.set(st, status)   // (v1122) «⏳ …» ← لودينج متحرك
                run {   // (v213) شريط الوضع البصري
                    val vs = ""   // (v224) شريط حالة الوضع البصري مخفي (visbar=1 يرجّعه)
                    if (::visBar.isInitialized && vs != visBarTxt) { visBarTxt = vs; visBar.text = vs; visBar.visibility = if (vs.isBlank()) View.GONE else View.VISIBLE }
                }
                if (now - lastBatch > 700) {
                    lastBatch = now
                    val bs = batchStyled(); val od = try { engine.offlineDetail() } catch (_: Throwable) { null }; val bl = (od ?: "") + bs.toString()
                    if (bl != lastBatchTxt) { lastBatchTxt = bl; batchTv.text = bs; miniLogTv?.text = if (bl.isBlank()) "مفيش باتشات لسه" else if (od != null) android.text.TextUtils.concat(od + "\n", bs) else bs }
                    updateProblems()
                }
                if (now - lastBeat > 20000) { lastBeat = now; LogStore.add("💓 ${LogStore.heapLine()} · ${if (player.isPlaying) "بيشتغل" else "واقف"} @${fmtMs(cur)} · مترجم ${(engine.coveredSec() / 60).toInt()}د · ${engine.subs.size} جملة") }
                run { val pc = covPct(); val wp = Offline.livePct() * 1000 + Offline.runIdx; if (pc != trPct || wp != lastWp) { trPct = pc; lastWp = wp; updateTr() }; val dn = dotsNow(); if (dn != lastDotsShown) { lastDotsShown = dn; updateTr() }; netStallWatch() }
                if (fullMode) { fsBadge.set("🔊 " + covPct().toString() + "% · " + list.size.toString() + " جملة" + dotsNow() + " ▾", ((try { engine.offlineBrief() } catch (_: Throwable) { null }) ?: "")); fsBadge.setOn(engineStarted && !engine.userPaused, ((Strict.freeText() || Strict.freeGem()) && FreeLlm.waiting)); netBadge.set(NetUse.fmt(NetUse.localTotal()), NetUse.fmt(NetUse.onlineTotal())); applyBadgeAlpha() }   // (v236) نقطة خضراء = الوضع الصوتي شغّال
                if (fullMode && ::visual.isInitialized) {   // (v431) الجزء البصري (👁 + الفاصل) بيظهر بس لما الوضع البصري شغّال؛ غير كده الكبسولة صوتي بس
                    val vOn = visual.running; val vv = if (vOn) View.VISIBLE else View.GONE
                    if (visBadge.visibility != vv) visBadge.visibility = vv
                    if (sentDiv.visibility != vv) sentDiv.visibility = vv
                    if (vOn) visBadge.set("👁 " + visual.count, "")
                }   // (v358) كبسولة واحدة للصوتي والبصري: من غير نقطة ولا كلمة شغّال/واقف ولا فاصل — الحالة من الدايرة الحمراء
                if (now - lastMem > 4000) { lastMem = now; if (!fullMode) mem.update(this@PlayerActivity) }
                run { val ct = "جمل ${list.size} · 👁 ${visList.size} · تغطية ${covPct()}% · فجوات ${engine.failedCount()} · كوتة ${Quota.used(conf.model)}/${Models.quotaOf(conf.model)} · ${NetUse.sessionLine()}"; if (ct != lastCountersTxt) { lastCountersTxt = ct; counters.text = ct } }   // (v458) كانت بتتكتب وتتقاس 5 مرات/ثانية حتى لو ما اتغيّرتش
                if (logDlg.isShowing && logMode == 0) {
                    val nl = synchronized(logBuf) { logBuf.length }
                    if (nl != lastLogLen) {
                        lastLogLen = nl
                        val atBottom = !logSv.canScrollVertically(1)
                        logTv.text = synchronized(logBuf) { logBuf.toString() }
                        if (atBottom) logSv.post { logSv.fullScroll(View.FOCUS_DOWN) }
                    }
                }
                } catch (e: Throwable) { tickBad = true; if (tickErrN++ < 5) { try { LogStore.err("Player:tick", e) } catch (_: Throwable) {} } } finally { if (tickBad) { try { subSafeTick() } catch (_: Throwable) {} }; try { subDiag(tickBad, tickErrN) } catch (_: Throwable) {}; h.postDelayed(this, 200) }   // (v471) أي استثناء في حلقة العرض كان بيقفل التطبيق — دلوقتي بيتسجّل في اللوج والحلقة تكمل
            }
        })
        engineStarted = false; updateTr()
        // «🌐 ترجمة وفرجة» من المتصفح: الترجمة تبدأ لوحدها من غير ما تدوس ▶ ترجمة
        if (autoTr && !noSub && !askSaved && (Cfg.str("hard_mode", "0") != "1" || SourceMode.get() == SourceMode.HYBRID) && SourceMode.get() != SourceMode.VISUAL) videoBoxRef.post { if (!engineStarted && !isFinishing && !isDestroyed && !pendingYt) beginTranslate(auto = true) }
    }

    /** (v118) تبديل جودة يوتيوب في نفس المكان من غير ما التشغيل يتقطع كتير. الجودة بتتحفظ للفيديوهات الجاية (داتا أقل) */
    private fun switchYt(i: Int, force: Boolean = false) {
        val o = qOpts.getOrNull(i) ?: return
        if (i == qCur && !force) return
        try {
            val pos = player.currentPosition; val play = player.playWhenReady
            val f = cachedDsf(httpDsf ?: DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl))
            val au = if (o.audio != null) (aOverride ?: o.audio) else null   // (v388) لغة الصوت اللي اخترتها بتفضل مع تبديل الجودة
            // (v120) أي موقع: من غير صوت منفصل بنسيب ExoPlayer يختار النوع (MP4/HLS…) من اللينك؛ يوتيوب بصوت منفصل بيتدمج
            val src = if (au != null) { val pf = androidx.media3.exoplayer.source.ProgressiveMediaSource.Factory(f)
                androidx.media3.exoplayer.source.MergingMediaSource(pf.createMediaSource(MediaItem.fromUri(Uri.parse(o.url))), pf.createMediaSource(MediaItem.fromUri(Uri.parse(au)))) }
            else DefaultMediaSourceFactory(f).createMediaSource(MediaItem.fromUri(Uri.parse(o.url)))
            ytVideoTrackOn(); ytMerged = au != null   // (v1150)
            player.exo()?.let { xp -> xp.setMediaSource(src, pos); xp.prepare() }; player.playWhenReady = play
            qCur = i; sizeTxt = ""; setQualLabel(o.h); refreshSize()
            if (ytAudioOnly) { ytAudioOnly = false; paintModePill() }   // (v459) تغيير الجودة بيرجّع الفيديو
            // (v985) اختيار جودة من قايمة الفيديو دي مايتحفظش في yt_maxh العام: كان كل اختيار
            // (حتى 240p مرة واحدة) بيفضل سقف لكل الفيديوهات والستريمنج بعد كده للأبد
            // (MtYt.video/pick + سقف Auto بتاع MeeTube بيقروا yt_maxh). الاختيار بيفضل
            // ساري للفيديو ده بس (qCur + المصدر اتبدّل فوق)؛ السقف العام بيتغيّر من
            // الإعدادات بس (شيب «الجودة الافتراضية» في Main.kt).
            if (!force) { Notice.show(this, "🎞 الجودة: " + o.label, 2000L) }
            if (!force && o.h > 0) pinPickedQ(o.h)
        } catch (e: Exception) { LogStore.err("Player:switchYt", e); Notice.show(this, "ما قدرتش أغيّر الجودة", 2300L) }
    }
    /** (v459) رابط الصوت المنفصل الحالي (لغة الصوت المختارة أولًا، بعده الصوت الافتراضي، بعده أي جودة بصوت) */
    private fun ytAudioUrl(): String? = aOverride ?: aurl ?: qOpts.getOrNull(qCur)?.audio ?: qOpts.firstOrNull { it.audio != null }?.audio

    private var ytResolving = false   // (v467) جلب مسار الصوت عند الطلب شغّال
    /** (v1150) بيرجّع مسار الفيديو (لو كان مقفول بوضع الصوت) وبيصفّر علامة وضع الصوت */
    private fun ytVideoTrackOn() {
        try { player.exo()?.let { xp -> if (xp.trackSelectionParameters.disabledTrackTypes.contains(androidx.media3.common.C.TRACK_TYPE_VIDEO)) xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, false).build() } } catch (_: Throwable) {}
        if (ytAudioOnly) { ytAudioOnly = false; paintModePill() }
    }
    private fun paintModePill() { if (::modePill.isInitialized) modePill.text = if (ytAudioOnly) "🎬 وضع الفيديو" else "🎧 وضع الصوت" }

    /** (v459) تبديل وضع الصوت/الفيديو لفيديو يوتيوب جوه المشغّل نفسه ومن نفس المكان: الصوت بس بيوفّر الداتا،
     *  والرجوع للفيديو بيعيد تشغيل الجودة الحالية بالدمج العادي (switchYt). */
    private fun toggleYtMode() {
        try {
            val play = player.playWhenReady
            // (v1150) تبديل فوري من غير إعادة تحميل: المصدر (فيديو + صوت منفصلين) بيفضل زي ما هو وبنقفل/نفتح مسار الفيديو بس —
            // الصوت مابيقطعش ومكانك مابيتغيّرش، ومسار الفيديو المقفول مابيحمّلش داتا. المصدر المدمج في ملف واحد بيكمّل بالطريقة القديمة تحت.
            val xpFast = player.exo()
            if (xpFast != null && (ytMerged ?: (aurl != null))) {
                val vt = androidx.media3.common.C.TRACK_TYPE_VIDEO
                ytAudioOnly = !ytAudioOnly
                xpFast.trackSelectionParameters = xpFast.trackSelectionParameters.buildUpon().setTrackTypeDisabled(vt, ytAudioOnly).build()
                Notice.show(this, if (ytAudioOnly) "🎧 وضع الصوت: صوت بس — بيوفّر الداتا والبطارية" else "🎬 وضع الفيديو", 1500L)
                paintModePill()
                return
            }
            if (!ytAudioOnly) {
                val au = ytAudioUrl() ?: run {
                    // (v467) مفيش مسار صوت جاهز (دخول handoff مثلًا): بنجيبه عند الطلب بدل ما نقول «ملوش» على طول
                    val yid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 }
                    if (yid != null && !ytResolving) { ytResolving = true; Notice.show(this, "⏳ بجيب مسار الصوت…", 1500L)
                        Thread { val got = try { MtYt.video(yid, Cfg.int("yt_maxh", 0), true) } catch (_: Throwable) { null }
                            runOnUiThread { ytResolving = false
                                if (got != null && !isFinishing && !isDestroyed) { aurl = got.audio?.takeIf { it.isNotEmpty() } ?: aurl
                                    try { got.qlist.takeIf { it.isNotEmpty() }?.let { sj -> val qa = org.json.JSONArray(sj); qOpts = (0 until qa.length()).map { qi -> val o = qa.getJSONObject(qi); YtExtract.Opt(o.optString("l"), o.optString("u"), o.optString("a").ifEmpty { null }, o.optInt("h")) }; parseATracks(sj) } } catch (_: Exception) {}
                                    if (ytAudioUrl() != null) toggleYtMode() else Notice.show(this, "الفيديو ده ملوش مسار صوت منفصل", 2000L)
                                } else if (!isFinishing && !isDestroyed) Notice.show(this, "ما قدرتش أجيب مسار الصوت — جرّب تاني", 2200L) }
                        }.apply { isDaemon = true }.start()
                    } else Notice.show(this, "الفيديو ده ملوش مسار صوت منفصل", 2000L)
                    return }
                val pos = player.currentPosition
                val f = cachedDsf(httpDsf ?: DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl))
                val src = DefaultMediaSourceFactory(f).createMediaSource(MediaItem.fromUri(Uri.parse(au)))
                player.exo()?.let { xp -> xp.setMediaSource(src, pos); xp.prepare() }; player.playWhenReady = play
                ytAudioOnly = true
                Notice.show(this, "🎧 وضع الصوت: صوت بس — بيوفّر الداتا والبطارية", 2000L)
            } else {
                ytAudioOnly = false
                switchYt(if (qCur >= 0) qCur else 0, force = true)   // بيرجع يدمج الفيديو + الصوت من نفس المكان
                Notice.show(this, "🎬 وضع الفيديو", 1500L)
            }
            paintModePill()
        } catch (e: Exception) { LogStore.err("Player:ytMode", e); Notice.show(this, "ما قدرتش أبدّل الوضع", 2200L) }
    }

    /** (v1320) تشيك بوكس «اجعله الافتراضي» في قايمة الجودة: لما يكون شغّال، الجودة اللي بتتختار من قايمة المشغّل بتتحفظ في yt_maxh — السقف العام لكل مصادر الإنترنت (يوتيوب/متصفح/HLS)، وفيديوهات اللوكال أصلًا ما بتقراهوش فبتفضل بجودتها الأصلية */
    private fun pinPickedQ(h: Int) {
        if (!Cfg.bool("qual_pick_default", false)) return
        if (h < 0) return
        if (Cfg.int("yt_maxh", 0) == h) return
        Cfg.put("yt_maxh", h.toString())
        Notice.show(this, ("📌 الجودة الافتراضية لكل الفيديوهات: " + (if (h == 0) "أعلى جودة" else h.toString() + "p")).toString(), 2400L)
    }

    /** (v1320) فحص سريع لحالة المسار البديل: موديل الوشبر متنزّل؟ وجوجل ترانسليت بيرد؟ */
    private var whDlView: LinearLayout? = null
    /** (v1341) اختيار موديل الويشبر قبل التحميل (بطلب علي 11/26): قايمة بكل الموديلات الخمسة وحجمها وحالة التنزيل، والاختيار بيتحفظ في off_model */
    private fun whisperModelPick(onReady: () -> Unit) {
        val ms = Offline.models
        fun dl(m: Offline.Model): Boolean = try { Offline.downloaded(m) } catch (_: Throwable) { false }
        val labels = ms.map { m -> m.label + "  ·  ~" + m.approxMb + " ميجا  ·  " + (if (dl(m)) "✅ متنزّل" else "❌ مش متنزّل") }.toTypedArray()
        GAlert(this).setTitle("🎙 اختار موديل الويشبر")
            .setItems(labels) { _, i ->
                val m = ms.getOrNull(i) ?: return@setItems
                Cfg.put("off_model", m.id)
                if (dl(m)) { say("✅ «" + m.label + "» متنزّل أصلًا — اتحدد كموديل التفريغ"); h.post { onReady() } }
                else whisperModelAsk(m, onReady)
            }
            .setNegativeButton("إلغاء", null).show()
    }
    /** (v1332) موديل الويشبر مش متنزّل: تحميل بصفحة بروجرس أو في الخلفية (دايرة صغيرة فوق الشمال)، وأول ما يتنصّب التفريغ يبدأ فورًا */
    private fun whisperModelAsk(m: Offline.Model, onReady: () -> Unit) {
        GAlert(this).setTitle("🎙 موديل الويشبر")
            .setMessage("الموديل («" + m.label + "» ~" + m.approxMb + " ميجا) مش متنزّل على الجهاز. تحب تنزّله دلوقتي؟")
            .setPositiveButton("⬇ تحميل") { _, _ -> whisperDownloadDialog(m, onReady) }
            .setNeutralButton("📥 في الخلفية") { _, _ -> whisperDownloadBg(m, onReady) }
            .setNegativeButton("إلغاء", null).show()
    }
    private fun whisperDownloadDialog(m: Offline.Model, onReady: () -> Unit) {
        val tv = ui.text("⏳ بيبدأ التنزيل…", 14f, Color.WHITE)
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val c2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(16), ui.dp(8), ui.dp(16), ui.dp(8)); addView(tv); addView(pb, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(10) }) }
        val d = GAlert(this).setTitle("⬇ تحميل موديل الويشبر").setView(c2).setNegativeButton("إلغاء التحميل") { _, _ -> try { Offline.cancelDownload() } catch (_: Throwable) {} }.create()
        d.setCancelable(false); d.show()
        Offline.download(m, { a, t -> runOnUiThread { if (t > 0) { pb.progress = (a * 100 / t).toInt(); tv.text = "⬇ " + (a / 1048576) + " / " + (t / 1048576) + " ميجا" } } },
            { err -> runOnUiThread { try { d.dismiss() } catch (_: Throwable) {}; if (err == null) { say("✅ موديل الويشبر اتنزّل"); h.post { onReady() } } else say("❌ " + err) } })
    }
    private fun whisperDownloadBg(m: Offline.Model, onReady: () -> Unit) {
        if (whDlView != null) return
        val pb = ProgressBar(this).apply { isIndeterminate = false; max = 100 }
        val tv = ui.text("", 11f, Color.WHITE)
        val pill = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(8), ui.dp(4), ui.dp(10), ui.dp(4)); background = GradientDrawable().apply { setColor(0xCC1A1A1A.toInt()); cornerRadius = ui.dp(16).toFloat() }; addView(pb, LinearLayout.LayoutParams(ui.dp(22), ui.dp(22))); addView(tv, LinearLayout.LayoutParams(-2, -2).apply { marginStart = ui.dp(6) }) }
        whDlView = pill
        try { videoBoxRef.addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { marginStart = ui.dp(10); topMargin = ui.dp(64) }) } catch (_: Throwable) {}
        say("📥 الموديل بينزّل في الخلفية…")
        Offline.download(m, { a, t -> runOnUiThread { if (t > 0) { pb.progress = (a * 100 / t).toInt(); tv.text = (a * 100 / t).toInt().toString() + "٪" } } },
            { err -> runOnUiThread { try { videoBoxRef.removeView(pill) } catch (_: Throwable) {}; whDlView = null; if (err == null) { say("✅ موديل الويشبر اتنزّل — التفريغ بيبدأ"); h.post { onReady() } } else say("❌ " + err) } })
    }

    private fun altPathCheck() {
        Notice.show(this, "⏳ بفحص المسار البديل…", 1800L)
        Thread {
            val wOk = try { Offline.engine().ready() || Offload.wanted() } catch (_: Throwable) { false }
            val g = try { TrWizard.probeGoogle() } catch (t: Throwable) { Pair(false, (t.message ?: t.javaClass.simpleName).take(80)) }
            runOnUiThread {
                try {
                    GAlert(this).setTitle("🩺 حالة المسار البديل")
                        .setMessage("🎙 وشبر (التفريغ على الجهاز): " + (if (wOk) "✅ جاهز" else "❌ موديل الوشبر مش متنزّل — نزّله من إعدادات الترجمة") + "\n🌐 جوجل ترانسليت: " + (if (g.first) "✅ شغال (" + g.second + ")" else "❌ مش بيرد: " + g.second) + "\n\nالمحرك الحالي: " + (if (TrWizard.method() == "google") "🎙 المسار البديل مفعّل" else "☁ جيميناي"))
                        .setPositiveButton("تمام", null)
                        .show()
                } catch (t: Throwable) { LogStore.err("Player:altChk", t) }
            }
        }.apply { isDaemon = true }.start()
    }

    /** (v1320) جلب موديلات المفتاح من جوجل واختيار واحد بيتطبّق على كل المفاتيح — نفس زرار الإعدادات (تغيير يدوي بس، مفيش fallback) */
    private fun modelsPick() {
        val k = try { Cfg.allMainKeys().filter { it != LocalKey.ID && it.isNotBlank() }.firstOrNull() } catch (_: Throwable) { null }
        if (k == null) { Notice.show(this, "ضيف مفتاح API الأول", 2300L); return }
        Notice.show(this, "⏳ بجيب الموديلات…", 2300L)
        Thread {
            try {
                val rows = Api.listModels(k).filter { Models.KEEP.containsMatchIn(it.id) && !Models.JUNK.containsMatchIn(it.id) && !Models.JUNK.containsMatchIn(it.display) }   // (v1354) قايمة الترجمة: فلاش/فلاش-لايت/أومني/برو بس (بطلب علي) — من غير صور/TTS/live/embed
                val fresh = ModelWatch.candidates(rows.map { it.id }).toSet()
                val sorted = rows.sortedWith(compareBy({ it.id !in fresh }, { !it.id.startsWith("gemini") }, { it.id }))
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (sorted.isEmpty()) { Notice.show(this, "مفيش موديلات رجعت", 3000L); return@runOnUiThread }
                    val cur = Cfg.str("model", Models.DEFAULT)
                    val labels = sorted.map { (if (it.id == cur) "✓ " else if (it.id in fresh) "🆕 " else "") + it.id + (if (it.display.isNotEmpty() && it.display != it.id) "\n" + it.display else "") }.toTypedArray()
                    GAlert(this).setTitle("اختار الموديل (${sorted.size}) — بيتطبّق على كل المفاتيح")
                        .setItems(labels) { _, which ->
                            val id = sorted[which].id
                            Cfg.put("model", id)
                            try { ModelWatch.refreshPending() } catch (_: Throwable) {}
                            Notice.show(this, "🤖 الموديل: " + id + " — اتطبّق على كل المفاتيح", 2600L)
                        }
                        .setNegativeButton("إلغاء", null).show()
                }
            } catch (e: Exception) {
                runOnUiThread { Notice.show(this, "⚠ فشل جلب الموديلات: " + (e.message ?: "").take(120), 3200L) }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun hlsAuto() {
        hlsH = 0
        pinPickedQ(0)
        try { player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().clearOverridesOfType(androidx.media3.common.C.TRACK_TYPE_VIDEO).build() } } catch (e: Exception) { LogStore.err("Player:hlsAuto", e) }
        setQualLabel(0); Notice.show(this, "🎞 الجودة: تلقائي", 1800L)
    }
    private fun hlsPick(g: androidx.media3.common.Tracks.Group, i: Int, h: Int) {
        hlsH = h
        try { player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setOverrideForType(androidx.media3.common.TrackSelectionOverride(g.mediaTrackGroup, i)).build() } } catch (e: Exception) { LogStore.err("Player:hlsPick", e) }
        setQualLabel(h); Notice.show(this, "🎞 الجودة: " + h + "p", 1800L)
        pinPickedQ(h)
    }

    private fun buildPlayer() {
        if (remote) { buildRemotePlayer(); return }
        val sv = svRef; val videoBox = videoBoxRef
        // (v406) تكبير من المشغّل المصغّر في يوتيوب: بناخد نفس المشغّل (شغّال ومحمّل) بدل ما نبني واحد جديد ونحمّل من الأول
        // (v1113) التسليم رجع بعد ما اتشال في v888 — بدونه التكبير كان بيبني مشغّل جديد ويحمّل الفيديو من الأول
        val ho = if (intent.getBooleanExtra("handoff", false) && uri == null) YtHandoff.take() else null
        handedOff = ho != null
        if (ho != null) {
            httpDsf = DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl)
            player = LocalPlayback(ho)
        } else {
        val castSrc = uri == null && CastCache.isCast(url)   // (v564) فيديو جاي من الموبايل: كاش مؤقت بيتمسح لما تخرج
        // (v1113) فيديو إنترنت عادي (http): كاش دائم + باك-بفر — الرجوع في المتحمّل من القرص مش من النت
        val netSrc = uri == null && !castSrc && (url?.startsWith("http") == true)
        val factory = if (uri != null) DefaultMediaSourceFactory(this)
        else {
            val f = DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl).apply { if (castSrc) { setConnectTimeoutMs(15_000); setReadTimeoutMs(30_000) } }
            httpDsf = f
            val dsf = when {
                castSrc -> CastCache.factory(this, f)
                netSrc -> NetCache.factory(this, f)
                else -> f
            }
            DefaultMediaSourceFactory(dsf).apply { if (castSrc) setLoadErrorHandlingPolicy(androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy(60)) }   // (v767) فيديو الموبايل: مهلة قراءة 30ث + 60 محاولة (بدل 8ث و3) — الموبايل ممكن يتأخر لما شاشته تتقفل
        }
        // MKV وغيره: لو الديكودر الأول فشل (HEVC / 10-bit) جرّب اللي بعده بدل شاشة سودا
        val rf = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val eb = ExoPlayer.Builder(this, rf).setMediaSourceFactory(factory)
        if (castSrc) eb.setLoadControl(CastCache.loadControl())
        else if (netSrc) eb.setLoadControl(NetCache.loadControl())
        player = LocalPlayback(eb.build())
        }
        // (v467) دخول الـ handoff (تكبير من مشغّل يوتيوب المصغّر): qOpts/aurl بيبقوا فاضيين فزرار الصوت/فيديو والجودات كانوا ميتين — بنجيب بيانات الستريم في الخلفية من غير ما نلمس التشغيل الشغّال
        if (ho != null && qOpts.isEmpty()) intent.getStringExtra("ytid")?.takeIf { it.length == 11 }?.let { yid ->
            Thread { val got = try { MtYt.video(yid, Cfg.int("yt_maxh", 0)) } catch (_: Throwable) { null }
                if (got != null) runOnUiThread { if (!isFinishing && !isDestroyed && qOpts.isEmpty() && intent.getStringExtra("ytid") == yid) {
                    aurl = got.audio?.takeIf { it.isNotEmpty() } ?: aurl
                    try { aurl?.let { a -> spec?.let { sp -> if (sp.uri == null) sp.url = a } } } catch (_: Throwable) {}   // (v1172) محرك الترجمة يقرا الصوت مش لينك الفيديو
                    try { got.qlist.takeIf { it.isNotEmpty() }?.let { sj -> val qa = org.json.JSONArray(sj); qOpts = (0 until qa.length()).map { qi -> val o = qa.getJSONObject(qi); YtExtract.Opt(o.optString("l"), o.optString("u"), o.optString("a").ifEmpty { null }, o.optInt("h")) }; parseATracks(sj) } } catch (e: Exception) { LogStore.err("Player:hoQlist", e) }
                    if (qCur < 0) qCur = qOpts.indexOfFirst { it.url == url }
                    paintModePill(); try { applyChromeFn() } catch (_: Throwable) {}
                } }
            }.apply { isDaemon = true }.start()
        }
        // (v149) المشغّل بيمسك الـ audio focus: أي تطبيق تاني شغّال صوت بيتوقف، ولو حد تاني خد الصوت المشغّل بيقف بدل ما الصوتين يتخلطوا
        try { player.exo()?.let { xp -> xp.setAudioAttributes(androidx.media3.common.AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true); xp.setHandleAudioBecomingNoisy(true) } } catch (e: Throwable) { LogStore.err("Player:focus", e) }
        WebMute.pauseAll()
        player.exo()?.setVideoSurfaceView(sv)
        applyBoost()
        // (v1124) تسليم من يوتيوب: لقطة آخر فريم فوق السطح الجديد لحد أول فريم حقيقي عليه (مفيش لحظة سواد) — بتتشال بأول onRenderedFirstFrame أو بعد 1.5ث
        if (ho != null) YtHandoff.takeSnap()?.let { bm ->
            try {
                val iv = android.widget.ImageView(this).apply { setImageBitmap(bm); scaleType = android.widget.ImageView.ScaleType.FIT_CENTER }
                videoBox.addView(iv, minOf(1, videoBox.childCount), FrameLayout.LayoutParams(-1, -1))
                var gone = false
                val rm = Runnable {
                    if (!gone) { gone = true
                        try { videoBox.removeView(iv); bm.recycle() } catch (_: Throwable) {} }   // (v1347) إزالة اللقطة فورًا من غير فيد (بطلب علي)
                }
                player.exo()?.addListener(object : Player.Listener {
                    override fun onRenderedFirstFrame() { h.post(rm); try { player.exo()?.removeListener(this) } catch (_: Throwable) {} }
                })
                h.postDelayed(rm, 1500L)
            } catch (e: Throwable) { LogStore.err("Player:snap", e) }
        }
        // (v714) الجودة اللي مختارها في الإعدادات (yt_maxh) هي الحد الأقصى لفيديوهات المتصفح/HLS: أعلى جودة لحد الحد ده، ولو مفيش ينزل تحتها — وما يطلعش فوقه إلا لما تختار بإيدك من زرار الجودة
        try { val mh = if (DeviceUi.realTvCached) TvQ.HARD else Cfg.int("yt_maxh", 0); if (mh > 0 && uri == null) player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setMaxVideoSize(Int.MAX_VALUE, mh).build() } } catch (e: Throwable) { LogStore.err("Player:maxh", e) }
        player.setPlaybackSpeed(speed)
        var firstFrame = false
        ffShown = false
        if (!remote) { val wdP = player.exo(); h.postDelayed({ try { if (!ffShown && !gone && !isFinishing && wdP != null && wdP === player.exo() && ::svRef.isInitialized) { wdP.clearVideoSurfaceView(svRef); wdP.setVideoSurfaceView(svRef) } } catch (_: Throwable) {} }, 2000L) }
        val plst = object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { try { loud?.release() } catch (_: Throwable) {}; loud = null; applyBoost() }
            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.width > 0 && v.height > 0) {
                    vidW = v.width; vidH = v.height; videoBox.post { applyFit(sv, videoBox) }
                    if (hlsH == 0 && qOpts.getOrNull(qCur) == null) setQualLabel(0)
                    // الفيديو يفتح على شكله الحقيقي: طولي → رأسي، عريض → أفقي (مرة واحدة، ومالهاش دعوة لو إنت بدّلت بإيدك)
                    if (!userRot && !autoRotDone && !pipNow() && !ytPage) {
                        autoRotDone = true
                        val wantLand = v.width >= v.height
                        val isLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
                        if (wantLand != isLand) requestedOrientation = if (wantLand) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                    }
                }
            }
            override fun onIsPlayingChanged(p: Boolean) {
                val t = if (p) "⏸" else "▶"; if (!buffering) { ctl.play.text = t; morphText(fsPlayB, t); if (::centerPlay.isInitialized) morphText(centerPlay, t) }; centerPlay.visibility = if (pipNow() || busyShown() || (fullMode && chromeShown && !Design.isNew())) View.GONE else if (buffering || (Design.isNew() && fullMode && chromeShown)) View.VISIBLE else if (p) (if (ytPage && !fullMode && pageCpShow) View.VISIBLE else View.GONE) else View.VISIBLE
                // تشخيص الشاشة السودا: صوت شغّال ومفيش ولا فريم فيديو اتعرض بعد ٥ ثواني
                if (p && !firstFrame) h.postDelayed({ if (!firstFrame && !isFinishing) log("⚠️ مفيش فريم فيديو اتعرض بعد ٥ ثواني — غالبًا كودك/بروفايل الفيديو مش مدعوم على الجهاز (مثلًا HEVC 10-bit)") }, 5000)
            }
            override fun onPlaybackStateChanged(st: Int) {
                setBuffering(st == Player.STATE_BUFFERING)
                if (st != Player.STATE_ENDED) { finishedMark = false; try { EndOverlay.hide() } catch (_: Throwable) {} }   // (v1056)
                if (st == Player.STATE_READY) h.post { try { maybeEndCheck() } catch (e: Throwable) { LogStore.err("Player:endCheck", e) } }   // (v1056)
                if (st == Player.STATE_READY) { ytBusy(false); castRecover = 0 }   // (v362) · (v767)
                else if (st == Player.STATE_BUFFERING && !firstFrame && intent.getStringExtra("ytid") != null) ytBusy(true, "⏳ بيحمّل الفيديو…")
                if (st == Player.STATE_READY) h.postDelayed({ checkIdentityDuration() }, 1500)
                // (v97) الفيديو خلص: لو اللوب شغّال يعيد من الأول، وإلا يروح للحلقة اللي بعدها (لو في)
                if (st == Player.STATE_ENDED && !isFinishing) {
                    markFinished()   // (v1056) الفيديو المخلّص يتفتح من الأول
                    if (sleepEndOfVideo) { sleepEndOfVideo = false; say("😴 مؤقت النوم: الفيديو خلص") }
                    else if (Cfg.str("loop", "0") == "1") { player.seekTo(0); player.play() }
                    else if (!remote && PlayQueue.hasNext(this@PlayerActivity)) h.post { if (PlayQueue.playNext(this@PlayerActivity)) h.postDelayed({ if (!isFinishing) finish() }, 700L) }   // (v694) طابور التشغيل: التالي لوحده (له الأولوية على الحلقة اللي بعدها)
                    else if (hasNextEpisode() || intent.getStringExtra("ytid") != null) h.post { v469AutoNext() }   // (v469) يوتيوب: بطاقة «التالي بعد…» · (v1056) المحلي: أزرار ⏮ 🔄 ⏭
                    else if (uri != null && !remote && libSibs() != null) h.post { endButtons() }   // (v1056) آخر فيديو ومفيش لف: سابق + إعادة بس
                    else if (uri != null && VideoScan.cache == null && VideoScan.hasPermission(this@PlayerActivity)) {   // (v531) المكتبة لسه ما اتفحصتش: افحص وكمّل للتالي
                        Thread {
                            try { VideoScan.scan(this@PlayerActivity) } catch (_: Throwable) {}
                            runOnUiThread { if (!isFinishing && !isDestroyed) { if (hasNextEpisode()) v469AutoNext() else endButtons() } }
                        }.also { it.isDaemon = true }.start()
                    }
                }
            }
            override fun onRenderedFirstFrame() { firstFrame = true; ffShown = true; webFirstFrame = true; ytBusy(false) }
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                val rawCue = cueGroup.cues.mapNotNull { it.text?.toString()?.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
                nativeCue = if (sfHideNative) "" else rawCue   // (v762) الأصلية مقفولة بعد ترجمة الملف
                if (diagCueN < 120 && rawCue != diagCueLast) { diagCueLast = rawCue; diagCueN++; diagLog("🔬 cue وصل من المشغّل @" + fmtMs(cur) + (if (sfHideNative) " (مخفي)" else "") + ": " + (if (rawCue.isEmpty()) "(فاضي)" else rawCue.take(25))) }   // (v769) تشخيص
            }
            override fun onTracksChanged(t: Tracks) {
                try { runOnUiThread { paintAud(); paintQual() } } catch (_: Throwable) {}   // (v714) جودات HLS بتظهر هنا — زرار الجودة يظهر أول ما تتعرف
                try {
                    if (sfHideNative) { textPicked = true; sfKillNative() }   // (v762) مفيش تفعيل تلقائي لمسار الترجمة الأصلي بعد ترجمة الملف
                    else if (!textPicked) {
                        val tg = t.groups.filter { it.type == C.TRACK_TYPE_TEXT && it.length > 0 && it.isSupported }
                        if (tg.isNotEmpty()) {
                            textPicked = true
                            if (tg.none { it.isSelected }) {
                                val pick = tg.firstOrNull { g -> (g.getTrackFormat(0).language ?: "").lowercase().startsWith("ar") } ?: tg.first()
                                player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(androidx.media3.common.TrackSelectionOverride(pick.mediaTrackGroup, 0)).build() }
                            }
                            log("💬 ترجمة أصلية في الفيديو: ${tg.size} مسار")
                        }
                    }
                    // (v670) الأوتوماتيك كان فحص قبل ما المشغّل يحمّل مساراته وقال «مفيش»: دلوقتي المسار ظهر ← نجرّب مرة واحدة
                    if (t.groups.any { it.type == C.TRACK_TYPE_TEXT && it.length > 0 && it.isSupported }) {
                        val lk = softLateKey; val cu = uri?.toString() ?: ""
                        if (lk.isNotEmpty() && lk == cu) {
                            softLateKey = ""
                            runOnUiThread {
                                try {
                                    if (!isFinishing && !isDestroyed && ::engine.isInitialized && !engineStarted && engine.subs.isEmpty() && sfBusy.isEmpty() && sfLive.isEmpty() && Cfg.str("auto_sub", "1") != "0" && !noSub && !remote && logArcPlay == null) {
                                        LogStore.add("💬 سوفت صب: المسار ظهر متأخر — بجرّب الترجمة الأوتوماتيك تاني")
                                        uri?.let { vu2 -> softAuto(vu2, 0L) { } }
                                    }
                                } catch (e: Throwable) { LogStore.err("Player:softLate", e) }
                            }
                        }
                    }
                } catch (e: Throwable) { LogStore.err("Player:textTrack", e) }
                paintQual()
                if (sizeTxt.isEmpty()) refreshSize()
                for (g in t.groups) {
                    if (g.type != C.TRACK_TYPE_VIDEO || g.length == 0) continue
                    val f = g.getTrackFormat(0)
                    val desc = "${f.sampleMimeType ?: "?"} ${f.width}x${f.height}"
                    if (g.isSelected) log("🎞 فيديو: $desc")
                    else if (!g.isSupported) { log("⚠️ كودك الفيديو ($desc) مش مدعوم على الجهاز ده — هيشتغل صوت من غير صورة"); say("كودك الفيديو ($desc) مش مدعوم على جهازك") }
                }
            }
            override fun onPlayerError(e: PlaybackException) {
                if (pendingYt) return   // (v351)
                log("❌ خطأ في التشغيل: ${e.errorCodeName} — ${e.cause?.message ?: e.message}")
                if (castRecoverOnce()) return   // (v767) فيديو من الموبايل: يعيد الاتصال ويكمّل من نفس المكان
                if (refRetryOnce(e)) return   // (v847)
                if (ytSilentRetryOnce()) return   // (v468) يوتيوب: محاولة صامتة واحدة بستريم فريش قبل أي ديالوج يدوي
                say("خطأ في تشغيل الفيديو — التفاصيل في 📜 اللوجز")
                offerLinkRefresh()
            }
        }
        plstRef = plst   // (v1162)
        player.exo()?.addListener(plst)
        if (handedOff) {   // (v406) المشغّل جاهز وشغّال: بنزامن الواجهة (حجم الفيديو/زرار التشغيل/اللودينج) لأن الأحداث دي عدّت قبل ما نسمع
            h.post {
                try {
                    player.exo()?.let { plst.onVideoSizeChanged(it.videoSize) }
                    plst.onIsPlayingChanged(player.isPlaying)
                    plst.onPlaybackStateChanged(player.playbackState)
                    if (player.playbackState == Player.STATE_READY) plst.onRenderedFirstFrame()
                } catch (_: Throwable) {}
            }
            return
        }
        if (pendingYt) return   // (v351) لسه بنجيب الرابط: المشغّل فاضي ولودينج ويندوز بيلف
        val au = aurl
        val xp0: ExoPlayer = player.exo() ?: return
        ytVideoTrackOn(); ytMerged = (uri == null && au != null)   // (v1150)
        if (uri == null && au != null) {
            val pf = androidx.media3.exoplayer.source.ProgressiveMediaSource.Factory(cachedDsf(httpDsf ?: DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl)))
            xp0.setMediaSource(androidx.media3.exoplayer.source.MergingMediaSource(pf.createMediaSource(MediaItem.fromUri(Uri.parse(url!!))), pf.createMediaSource(MediaItem.fromUri(Uri.parse(au)))))
        } else xp0.setMediaItem(uri?.let { mediaItemFor(it) } ?: MediaItem.fromUri(Uri.parse(url!!)))
        xp0.prepare(); xp0.playWhenReady = true
    }

    // ===== (v139) عزل كل فيديو عن اللي قبله =====
    /** مصدر الصوت متربط بالفيديو اللي المحرك اتعمل له (مش بيقرا حقول المشغّل الحيّة): المحرك القديم ما يقدرش يفتح فيديو جديد بالغلط */
    private class SrcSpec(val uri: Uri?, @Volatile var url: String?, val hdr: HashMap<String, String>)
    private var spec: SrcSpec? = null
    /** وسيط بين المحرك والمشغّل: لما المحرك يتقفل (خروج / تغيير فيديو) كل ندائاته للمشغّل بتتجاهل */
    private class GuardedHost(val inner: Host) : Host {
        @Volatile var dead = false
        @Volatile var lastPos = 0.0
        @Volatile var lastDur = 0.0
        override fun log(s: String) { if (!dead) inner.log(s) }
        override fun status(s: String) { if (!dead) inner.status(s) }
        override fun changed() { if (!dead) inner.changed() }
        override fun notice(s: String) { if (!dead) inner.notice(s) }
        override fun position(): Double = if (dead) lastPos else inner.position().also { lastPos = it }
        override fun playerDuration(): Double = if (dead) lastDur else inner.playerDuration().also { lastDur = it }
        fun kill() { if (!dead) { try { lastPos = inner.position(); lastDur = inner.playerDuration() } catch (_: Throwable) {}; dead = true } }
    }
    private var guard: GuardedHost? = null
    /** أي مكان بيقفل المحرك الحالي لازم يعدّي من هنا: يقطع ندائاته للمشغّل الأول، وبعدين يقفله ويختمه */
    private fun retireEngine() {
        if (remote) return   // (v546) وضع المتحكم: المحرك بتاع التلفزيون ومايتقفلش من الموبايل
        try { fastTr?.stop(); fastTr = null } catch (_: Throwable) {}   // (دمج v1090)
        try { guard?.kill() } catch (_: Throwable) {}
        try { if (::engine.isInitialized) engine.stop() } catch (e: Throwable) { LogStore.err("Player:retire", e) }
    }

    // (v362) لودينج يوتيوب الكبير
    private var ytBusyV: FrameLayout? = null
    private var ytBusyTv: TextView? = null
    private val ytBusyDr = WinSpinnerDrawable()
    private var ytBusyT0 = 0L
    private var ytBusyMsg = ""
    private val ytBusyTick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed || ytBusyV?.visibility != View.VISIBLE) return
            val sec = (System.currentTimeMillis() - ytBusyT0) / 1000L
            ytBusyTv?.text = ytBusyMsg + (if (sec >= 2L) " · " + sec + " ث" else "")
            h.postDelayed(this, 500L)
        }
    }
    /** (v377) طبقة «بيحمّل الفيديو» ظاهرة (ليها سبينر خاص بيها) — زرار التشغيل الأوسط ماينفعش يعرض سبينر تاني فوقها */
    private fun busyShown(): Boolean = ytBusyV?.visibility == View.VISIBLE
    private fun ytBusy(on: Boolean, msg0: String = "") {
        val msg = LoadUi.strip(msg0)   // (v1122) اللودينج المتحرك فوق النص بالفعل — من غير إيموجي ⏳
        val v = ytBusyV ?: return
        if (on) {
            if (::centerPlay.isInitialized) { spinners.remove(centerPlay)?.stop(); centerPlay.foreground = null; centerPlay.visibility = View.GONE }
            ytBusyMsg = msg
            if (v.visibility != View.VISIBLE) { ytBusyT0 = System.currentTimeMillis(); v.visibility = View.VISIBLE; ytBusyDr.start(); h.removeCallbacks(ytBusyTick); ytBusyTick.run() }
            else ytBusyTv?.text = msg
        } else { h.removeCallbacks(ytBusyTick); v.visibility = View.GONE; ytBusyDr.stop()
            if (::centerPlay.isInitialized && buffering && !pipNow() && !uiLocked) { val sp = spinners.getOrPut(centerPlay) { WinSpinnerDrawable() }; centerPlay.text = ""; centerPlay.foreground = sp; sp.start(); centerPlay.visibility = View.VISIBLE } }
    }

    private var freshOnce = false
    /** (v351) المشغّل بيفتح فورًا بشكله الكامل واللودينج جواه؛ رابط الفيديو بيتجاب في الخلفية وبعدين التشغيل يبدأ في نفس الشاشة */
    @Volatile private var pendingYt = false
    private var pendTok = 0
    private fun startYtPend(fresh: Boolean = false) {
        val id = intent.getStringExtra("ytid") ?: return
        val tok = ++pendTok
        h.post { try { setBuffering(true); ytBusy(true, "⏳ بجيب الفيديو…") } catch (_: Throwable) {} }
        Thread {
            val got = try { MtYt.video(id, Cfg.int("yt_maxh", 0), fresh) } catch (_: Throwable) { null }   // (v362) YtExtract + NewPipe بالتوازي
            runOnUiThread {
                if (tok != pendTok || isFinishing || isDestroyed || !pendingYt) return@runOnUiThread
                val u = got?.url
                if (u == null || got == null) {
                    if (!fresh) { startYtPend(true); return@runOnUiThread }   // (v467) محاولة تانية صامتة بـ fresh (تخطي الكاش + إعادة فحص العملاء) قبل إزعاج المستخدم برسالة الفشل
                    try { setBuffering(false); ytBusy(false) } catch (_: Throwable) {}
                    val why = YtExtract.lastWhy.ifBlank { "السبب مش معروف (راجع اللوج)" }
                    GAlert(this).setTitle("⚠ ما قدرتش أجيب الفيديو")
                        .setMessage("يوتيوب ما رضيش يدّي لينك للفيديو ده من التطبيق.\n\n" + why)
                        .setPositiveButton("🔁 جرّب تاني") { _, _ -> startYtPend(true) }
                        .setNeutralButton("🌐 افتحه في المتصفح") { _, _ ->
                            try { startActivity(Intent(this, BrowserActivity::class.java).putExtra("start", YtHistory.watchUrl(id)).putExtra("noauto", true)) } catch (_: Throwable) {}
                            closeNoBg() }
                        .setNegativeButton("إغلاق") { _, _ -> closeNoBg() }.show()
                    return@runOnUiThread
                }
                pendingYt = false
                url = u; aurl = got.audio?.takeIf { it.isNotEmpty() }
                try { ytBusy(true, "⏳ بيبدأ التشغيل…") } catch (_: Throwable) {}
                try {
                    got.qlist.takeIf { it.isNotEmpty() }?.let { sj -> val qa = org.json.JSONArray(sj)
                        qOpts = (0 until qa.length()).map { qi -> val o = qa.getJSONObject(qi); YtExtract.Opt(o.optString("l"), o.optString("u"), o.optString("a").ifEmpty { null }, o.optInt("h")) }; parseATracks(sj) }
                } catch (e: Exception) { LogStore.err("Player:pendQlist", e) }
                qCur = qOpts.indexOfFirst { it.url == url }
                hdr["User-Agent"] = got.ua; hdr["Referer"] = "https://www.youtube.com/"
                if (intent.getStringExtra("title").isNullOrBlank()) got.title.takeIf { it.isNotBlank() }?.let { intent.putExtra("title", it) }
                // نفس خطوات swapVideo: نقفل المحرك والمشغّل الفاضيين ونبنيهم على الرابط الحقيقي
                try { retireEngine() } catch (_: Throwable) {}
                try { loud?.release(); loud = null } catch (_: Throwable) {}
                try { player.release() } catch (_: Throwable) {}
                buildPlayer(); initEngine()
                try { refreshList(); updateTr() } catch (_: Throwable) {}
                val autoOk = autoTr && !noSub && !askSaved && (Cfg.str("hard_mode", "0") != "1" || SourceMode.get() == SourceMode.HYBRID) && SourceMode.get() != SourceMode.VISUAL
                if (autoOk) videoBoxRef.post { if (!engineStarted && !isFinishing && !isDestroyed) beginTranslate(auto = true) }
            }
        }.apply { isDaemon = true }.start()
    }
    /** يشغّل المحرك. لو الدخول كان «ابدأ من الأول وجديد»: المسح والحفظ على خيط الخلفية قبل ما الحلقة تبدأ (مش على الـ UI) */
    private fun startEngine() {
        if (remote) return
        if (logArcPlay != null) return   // (v1167) عرض لوج محفوظ
        val fresh = freshOnce; freshOnce = false
        if (fresh) { try { player.seekTo(0) } catch (e: Exception) { LogStore.err("Main:2041", e) }; cur = 0L }
        val eng = realEngine   // (v139) المحرك اللي اتطلب له التشغيل بالذات — مش اللي يبقى في الحقل وقت ما الخيط يشتغل
        Thread {
            if (fresh) try { eng.redoAll() } catch (e: Throwable) { val m = "⚠ " + (e.message ?: e.toString()).take(120); log(m); runOnUiThread { say(m) } }
            eng.run()
        }.apply { isDaemon = true }.start()
    }

    /** (v117) الدخول الفوري: تحميل الترجمة المحفوظة بيتم في خيط خلفي — الشاشة بتفتح على طول واللودنج بيلف لحد ما تتحمّل البيانات */
    @Volatile private var engineReady = false
    private var pendingBegin = false
    private fun initEngine() {
        if (remote) { initRemoteEngine(); return }
        try { if (TrProfile.restore()) conf = Cfg.snapshot() } catch (_: Throwable) {}   // (v1098) T3: فيديو جديد ← الإعدادات المحفوظة (نوع/لهجة/شدة/وضع)
        endCheckDone = false; resumeSeekDone = false; askResumeMs = 0L; finishedMark = false   // (v1056)
        if (StartFresh.consume()) noResPending = true   // (v1056) «ابدأ من جديد» جاية من الموبايل
        vid = videoId()
        try { SongHint.begin(vid, notifTitle()) } catch (_: Throwable) {}   // (v1171) 🎵
        NetLedger.setVideo("player", try { notifTitle() } catch (_: Throwable) { null }, try { uri?.toString() ?: intent.getStringExtra("page")?.takeIf { it.isNotBlank() } ?: url } catch (_: Throwable) { null }); NetUse.init(); NetUse.videoReset(); NetUse.sessionReset(); NetUse.online = (uri == null)   // عدّاد النت: فيديو الإنترنت بيتحسب لوحده
        if (uri == null && url != null && !incognito) webRegister()
        offsetMs = (Cfg.str("sub_offset_ms:$vid", "0").toLongOrNull() ?: 0L).coerceIn(-10000L, 10000L)   // (v468) قص القيم المحفوظة القديمة لحد ±10ث
        runCatching { offFsB?.text = String.format("%+.2fs", offsetMs / 1000.0) }
        // (v469) B3: سرعة الفيديو ده بالذات لو متسجّلة بتتطبّق فورًا · B9: تحميل فصول الوصف
        (Cfg.str("speed:$vid", "").toFloatOrNull())?.let { sp -> speed = sp.coerceIn(0.25f, 3f); try { player.setPlaybackSpeed(speed) } catch (_: Throwable) {}; speedBRef?.text = "⏩ " + PlayerLogic.speedLabel(speed) }
        loadChapters()
        lastSrtN = -1
        val wasBg = BgJobs.isActive(vid)
        val store = Store(File(filesDir, "progress"), Store.keyFor(vid))
        val pb = PromptBuilder { p -> assets.open(p).bufferedReader(Charsets.UTF_8).use { it.readText() } }
        engineReady = false; pendingBegin = false
        // (v139) أي محرك قديم لسه شغال يتقفل الأول ونقطع ندائاته، وبعدين الجديد بيتربط بمصدر صوت فيديوه هو بس
        retireEngine()
        val sp = SrcSpec(uri, aurl ?: url, HashMap(hdr)); spec = sp
        val gh = GuardedHost(this); guard = gh
        val eng = Engine(conf, { makeSource(sp) }, store, gh, pb)
        eng.persistBlocked = true
        // (v1167) سجل اللوجات: تشغيلة جديدة لكل فتحة فيديو (إلا المتخفي · الريموت · عرض لوج محفوظ)
        val lap0 = intent.getStringExtra("logarc")?.takeIf { it.isNotBlank() } ?: LogArchive.takePending(vid)
        if (lap0 != null) { logArcPlay = lap0; logArcPlayVid = vid } else if (logArcPlayVid != vid) logArcPlay = null   // إعادة initEngine لنفس الفيديو (رابط متأخر) بتفضل في وضع العرض
        if (logArcPlay != null || incognito || remote || !Cfg.bool("logarc_on", true)) arcRun = null
        else if (arcRun?.vid != vid) arcRun = LogArchive.start(applicationContext, vid, intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: "", uri?.toString() ?: "", intent.getStringExtra("page")?.takeIf { it.isNotBlank() } ?: (url ?: ""))
        eng.onFreshRun = { archiveRotate() }
        if (logArcPlay != null) log("🗂 بتشغّل الفيديو بترجمات لوج محفوظ — عرض بس (مفيش ترجمة ولا حفظ على ترجمة الفيديو الأصلية)")
        realEngine = eng
        engine = LocalEngine(eng)
        brainSubsRef = null
        BrainBus.reset()   // (v542) فيديو/محرك جديد: ترجمة الفيديو القديم ما تتبعتش للريموت
        engine.convDialect = Cfg.str("conv_dialect", "")
        engine.toneStyle = Cfg.str("tone_style", ""); engine.toneStrength = Cfg.str("tone_strength", "متوسطة")
        try { TrLib.stamp(applicationContext, vid, intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid), engine.convDialect.ifBlank { conf.lang }, engine.toneStyle, engine.toneStrength, conf.model, TrLib.engineLabel(conf)) } catch (_: Throwable) {}   // (v990) مكتبة الترجمات
        engine.titleHint = run {
            val t = (intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)).substringBeforeLast('.', Recents.titleOf(vid))
            val folder = try { uri?.toString()?.let { SrtWriter.pathOf(applicationContext, it)?.parentFile?.name } } catch (_: Exception) { null } ?: ""
            // (v134) تنضيف الاسم قبل البحث على النت: شيل [الجروب] و(السنة) والجودة وصيغ الريبّ (1080p / x265 / WEB-DL …) عشان جوجل يلاقي العمل أسهل
            fun clean(x: String): String {
                val c = x.replace(Regex("\\[[^\\]]*\\]|\\([^)]*\\)"), " ")
                    .replace(Regex("(?i)\\b(2160p|1080p|720p|480p|360p|x264|x265|h\\.?264|h\\.?265|hevc|web-?dl|web-?rip|blu-?ray|brrip|hdrip|hdtv|aac|ac3|mkv|mp4)\\b"), " ")
                    .replace(Regex("[._]+"), " ").replace(Regex("\\s+"), " ").trim()
                return if (c.length >= 3) c else x
            }
            listOf(clean(t), clean(folder)).filter { it.isNotBlank() }.distinct().joinToString(" | ")
        }
        Live.engine = realEngine
        visual = VisualMode({ visConfNow() }, { cur / 1000.0 }, { makeRetriever() }, { m ->   // (v182) cur = نسخة volatile من مكان التشغيل — ExoPlayer بيرمي استثناء لو اتنادى من خيط تاني
            visLog(m)   // (v182) كل رسائل الوضع البصري بتتسجّل في اللوج
            // (v213) الوضع البصري بيشتغل في صمت: حالته بتظهر في شريطه (visBar) تحت شريط الباتش الفاشل، ومفيش إشعارات على الشاشة غير الأخطاء اللي لازم تتصلّح (مفتاح ناقص / مصدر مش مدعوم)
            val important = (m.startsWith("ضيف مفتاح") || m.contains("مش مدعوم") || m.startsWith("المفاتيح") || m.startsWith("⚠")) && !(visAutoRun && !m.startsWith("المفاتيح"))
            if (important) runOnUiThread { Notice.show(this, m, 2300L) }
        }, { }, { grabSurface() }, log = { m -> visLog(m) })
        // (v185) النتايج بتتحفظ مع الفيديو وبترجع لما تفتحه تاني (المتخفي: من غير حفظ)
        if (!incognito) try { visual.bind(File(File(filesDir, "visual"), Store.keyFor(vid) + ".json")) } catch (e: Throwable) { LogStore.err("Player:visualBind", e) }   // (v287) لو فشل نتايج البصري مش هتتحفظ
        // (v181) الوضع البصري تلقائي: بيشتغل لوحده مع فتح الفيديو لو فيه مفتاح للوضع البصري (ضغطة 👁 بتقفله/تشغّله، ومن الإعدادات تقدر تقفل التلقائي)
        if (VisualMode.auto() && conf.visKeys.any { it.length > 10 } && !incognito) {
            visAutoRun = true
            h.postDelayed({ if (!isFinishing && !isDestroyed && !visual.running) { visLog("👁 تشغيل تلقائي مع فتح الفيديو"); visual.mode = "scene"; visualStart() } }, 1200)
        }
        status = "⏳ بحمّل بيانات الفيديو…"
        val vidNow = vid
        Thread {
            // (كانت بتتعمل على الـ UI وبتجمّد الشاشة): إيقاف ترجمة الخلفية + قراءة وتحليل ملف الترجمة المحفوظة
            if (wasBg) try { BgJobs.stopAndWait(vidNow, 2500) } catch (e: Throwable) { LogStore.err("Player:stopBg", e) }
            val savedPos0 = try { eng.load() } catch (e: Throwable) { LogStore.err("Player:load", e); 0.0 }
            val viewLog = logArcPlay
            if (viewLog != null) try { LogArchive.readSubs(applicationContext, viewLog)?.let { eng.loadSnapshot(it); log("🗂 اتحمّلت ${it.size} جملة من اللوج المحفوظ (${LogArchive.translatedCount(it)} مترجمة)") } } catch (e: Throwable) { LogStore.err("Player:logarcLoad", e) }
            // (v125) آخر مكان وقوف فعلي (بيتحفظ كل 3 ث، حتى وإنت في PiP) أحدث من اللي في ملف الترجمة
            val lastPosSec = try { val s = Cfg.p.getString("lastpos", "") ?: ""; val i = s.indexOf('\t'); if (i > 0 && s.substring(0, i) == vidNow) (s.substring(i + 1).toLongOrNull() ?: 0L) / 1000.0 else 0.0 } catch (_: Throwable) { 0.0 }
            // (v892) مخزن YtProg اتمسح مع طبقة يوتيوب القديمة (v889) — الاستكمال بقى من lastpos/recent.json بس
            val ytMs = 0L
            val savedPos = if (ytMs > 5000L) ytMs / 1000.0 else if (lastPosSec > 5.0) lastPosSec else savedPos0
            val rp = if (savedPos <= 5.0 && uri == null) {
                try { Recents.parse(File(filesDir, "recent.json").readText()).firstOrNull { it.id == vidNow }?.posSec ?: 0.0 } catch (_: Exception) { 0.0 }
            } else 0.0
            eng.persistBlocked = (viewLog != null)   // (v1167) عرض لوج محفوظ: ممنوع الحفظ على ترجمة الفيديو
            runOnUiThread {
                if (isFinishing || isDestroyed || realEngine !== eng) return@runOnUiThread
                engineReady = true
                if (pendingYt) return@runOnUiThread   // (v351) لسه مفيش رابط: الاستكمال/السؤال بيحصلوا بعد ما initEngine تتعاد على الرابط الحقيقي
                val startMs = intent.getLongExtra("startms", 0L)   // (v343) جاي من تحويل صوت→فيديو: كمّل من نفس مكان الصوت
                if (startMs > 0L) intent.removeExtra("startms")   // (v351) بيتستهلك مرة واحدة
                val noRes = noResPending; noResPending = false   // (v1056)
                if (startMs > 0L) { player.seekTo(startMs); cur = startMs; log("⏩ كملت من ${fmtMs(cur)}") }
                else if (noRes) { clearSavedPos(); player.seekTo(0L); cur = 0L; log("⏮ بدأت من جديد") }   // (v1056) الموبايل اختار «ابدأ من جديد»
                else if (savedPos > 5.0 && !freshOnce) { player.seekTo((savedPos * 1000).toLong()); cur = (savedPos * 1000).toLong(); log("⏩ كملت من ${fmtMs(cur)}"); if (shouldAskResume()) askResumeMs = cur }
                else if (uri == null && !freshOnce && rp > 5.0) {
                    // رابط من الإنترنت: لو مفيش مكان وقوف في الترجمة، كمّل من آخر مكان اتفرجت عليه (من السجل)
                    player.seekTo((rp * 1000).toLong()); cur = (rp * 1000).toLong(); log("⏩ كملت من ${fmtMs(cur)}"); if (shouldAskResume()) askResumeMs = cur
                }
                resumeSeekDone = true; maybeEndCheck()   // (v1056)
                refreshList()
                LogStore.add("🎬 فتح فيديو $vidNow · ${LogStore.heapLine()}")
                maybePrompt(wasBg)
                if (studioAskOpen && studioAskedVid == vidNow) {
                    if (pendingBegin) studioAskOpen = false else studioAsk(vidNow)
                } else if (studioApplied) {
                    say("🎙 ترجمة الاستوديو شغّالة (" + studioAppliedN + " جملة)")
                }
                if (!sfShown && ::engine.isInitialized && engine.subs.isNotEmpty()) {
                    try { if (sfSidecar() != null) sfShown = true } catch (_: Throwable) {}
                }
                if (pendingBegin) { pendingBegin = false; beginTranslate() } else { autoSub(); castSubAuto() }
            }
        }.apply { isDaemon = true }.start()
    }

    // ===== فشل لينك التحميل: تحديثه في الخلفية من صفحة الفيديو المحفوظة =====
    private var refTried = 0   // (v847) محاولات تبديل الـReferer لما السيرفر يرفض (مواقع زي ماي سيما)
    private var ytErrRetried = false   // (v468) محاولة يوتيوب الصامتة مرة واحدة لكل فتح

    // (v767) فيديو جاي من الموبايل (CastServer): لو الاتصال بالموبايل وقع (شاشته اتقفلت / الواي فاي نام) المشغّل كان بيدخل في خطأ ويقف نهائي.
    // دلوقتي بيعيد التحضير من نفس المكان لحد 12 مرة بفاصل متزايد، ولو وقف فدوسة تشغيل بتعيد المحاولة.
    private var castRecover = 0
    private fun isCastSrc(): Boolean = uri == null && CastCache.isCast(url)
    /** (v847) فيديو من موقع: لو التشغيل فشل بخطأ شبكة/HTTP (غالبًا 403 من فحص الـReferer) نجرّب Referer/Origin تاني (صفحة المتصفح ← أصل الإطار ← أصل اللينك) ونكمّل من نفس المكان. true = لسه بنحاول */
    private fun refRetryOnce(e: PlaybackException): Boolean {
        if (refTried >= 3 || isFinishing || isDestroyed || remote || uri != null || isCastSrc()) return false
        if (e.errorCode !in 2000..2999) return false
        val u = url ?: return false
        val dsf = httpDsf ?: return false
        val xp = player.exo() ?: return false
        fun org(x: String?): String? = try { if (x == null) null else Uri.parse(x).let { if (it.scheme != null && it.host != null) it.scheme + "://" + it.host + "/" else null } } catch (_: Throwable) { null }
        val cands = listOfNotNull(intent.getStringExtra("page")?.takeIf { it.startsWith("http", true) }, org(hdr["Referer"]), org(u))
        val curRef = hdr["Referer"] ?: ""
        val pick = cands.filter { it != curRef }.distinct().getOrNull(refTried) ?: return false
        refTried++
        hdr["Referer"] = pick; org(pick)?.let { hdr["Origin"] = it.trimEnd('/') }
        val pos = try { xp.currentPosition } catch (_: Throwable) { 0L }
        log("🔁 (v847) السيرفر رفض — محاولة $refTried بـReferer تاني: $pick")
        try { dsf.setDefaultRequestProperties(hdr) } catch (_: Throwable) {}
        h.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            try { xp.prepare(); xp.playWhenReady = true; if (pos > 0L) xp.seekTo(pos) } catch (ex: Throwable) { LogStore.err("Player:refRetry", ex) }
        }, 400L)
        return true
    }
    private fun castRecoverOnce(): Boolean {
        if (!isCastSrc() || isFinishing || isDestroyed || castRecover >= 12) return false
        val xp = player.exo() ?: return false
        castRecover++
        val n = castRecover
        val pos = try { xp.currentPosition } catch (_: Throwable) { 0L }
        log("🔁 (v767) الاتصال بالموبايل وقع — محاولة $n/12 من ${fmtMs(pos)}…")
        if (n == 1) say("🔄 الاتصال بالموبايل وقع — برجّعه…")
        h.postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            try { xp.prepare(); if (pos > 0L) xp.seekTo(pos) } catch (ex: Throwable) { LogStore.err("Player:castRecover", ex) }
        }, minOf(n * 1500L, 8000L))
        return true
    }
    /** (v468) خطأ تشغيل يوتيوب أثناء المشاهدة: بنجيب ستريم فريش بصمت (fresh=true) وبنكمّل من نفس المكان؛ true = اتعاملنا ولسه بنحاول، false = مش يوتيوب/اتجربت خلاص فيقع للمسار اليدوي */
    private fun ytSilentRetryOnce(): Boolean {
        val yid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 } ?: return false
        if (ytErrRetried || isFinishing || isDestroyed) return false
        ytErrRetried = true
        val pos = try { player.currentPosition } catch (_: Throwable) { cur }
        log("🔁 (v468) خطأ يوتيوب — محاولة صامتة واحدة بستريم فريش من ${fmtMs(pos)}…")
        Thread {
            val got = try { MtYt.video(yid, Cfg.int("yt_maxh", 0), true) } catch (_: Throwable) { null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (got == null) { say("خطأ في تشغيل الفيديو — التفاصيل في 📜 اللوجز"); offerLinkRefresh(); return@runOnUiThread }
                url = got.url; aurl = got.audio?.takeIf { it.isNotEmpty() }
                hdr["User-Agent"] = got.ua; hdr["Referer"] = "https://www.youtube.com/"
                try { httpDsf?.setDefaultRequestProperties(hdr) } catch (_: Throwable) {}
                try {
                    val au = aurl
                    ytMerged = au != null   // (v1150)
                    if (au != null) {
                        val pf = androidx.media3.exoplayer.source.ProgressiveMediaSource.Factory(cachedDsf(httpDsf ?: DefaultHttpDataSource.Factory().setDefaultRequestProperties(hdr).setAllowCrossProtocolRedirects(true).setTransferListener(netStreamTl)))
                        player.exo()?.setMediaSource(androidx.media3.exoplayer.source.MergingMediaSource(pf.createMediaSource(MediaItem.fromUri(Uri.parse(got.url))), pf.createMediaSource(MediaItem.fromUri(Uri.parse(au)))))
                    } else player.exo()?.setMediaItem(MediaItem.fromUri(Uri.parse(got.url)))
                    player.exo()?.prepare(); if (pos > 0L) player.seekTo(pos); player.playWhenReady = true
                    log("✓ (v468) الستريم الفريش اشتغل — كمّلنا من نفس المكان")
                } catch (ex: Exception) { LogStore.err("Player:ytSilentRetry", ex); offerLinkRefresh() }
            }
        }.apply { isDaemon = true }.start()
        return true
    }
    private var refreshAsked = false
    private var refreshTries = 0
    private var phoneTried = false
    @Volatile private var phoneAck = false
    /** (v820) بيبعت للموبايل طلب تحديث اللينك. لو ماردش في 8 ثواني (أو قال مش قادر) بنكمّل على التلفزيون زي ما كان */
    private fun askPhoneRefresh(page: String) {
        phoneAck = false
        val j = org.json.JSONObject().put("vid", vid).put("page", page).put("old", url ?: "").put("ua", hdr["User-Agent"] ?: "").put("title", intent.getStringExtra("title") ?: "")
        BrainBus.post("linkreq", j.toString())
        h.postDelayed({ if (!phoneAck && !isFinishing && !isDestroyed) { phoneAck = true; refreshAsked = false; startLinkRefresh(page) } }, 8000L)
    }
    private fun offerLinkRefresh() {
        if (uri != null || url == null || refreshAsked || isFinishing || isDestroyed) return
        refreshAsked = true
        val appCtx = applicationContext; val id = vid
        Thread {
            val w = WebVideos.find(appCtx, id)
            // (v750) من غير مربع لصق: الصفحة المحفوظة ← صفحة التاب وقت الاصطياد ← الـReferer المحدد ← أي Referer
            val ex = intent.getStringExtra("page") ?: ""
            val cands = listOf(w?.page ?: "", ex, hdr["Referer"] ?: "", w?.ref ?: "")
            val page = cands.firstOrNull { WebIdent.specific(it) } ?: cands.firstOrNull { it.startsWith("http") } ?: ""
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (!page.startsWith("http")) { say("⚠ مفيش صفحة محفوظة للفيديو ده — افتحه تاني من المتصفح مرة واحدة وهتتحفظ"); refreshAsked = false; return@runOnUiThread }
                if (++refreshTries > 2) { refreshAsked = false; return@runOnUiThread }   // (v142) محاولتين بس في الجلسة عشان مايدخلش في لف
                if (BrainBus.active() && !phoneTried) { phoneTried = true; askPhoneRefresh(page); return@runOnUiThread }   // (v820) موبايل متوصّل وبيتابع: التحديث يظهر عليه مش على التلفزيون
                startLinkRefresh(page)   // (v142) بيجيب اللينك لوحده من غير ما يسألك
            }
        }.apply { isDaemon = true }.start()
    }
    /** (v203) بيفتح صفحة الفيديو قدامك في المتصفح: تدوس تشغيل، والتطبيق بيلقط اللينك الجديد ويرجّعك للمشغّل بنفس الفيديو (ترجمته وتقدمه وإعداداته) */
    private fun repairInBrowser(page: String) {
        val id = vid; val old = url ?: ""; val t = intent.getStringExtra("title") ?: ""
        try { player.pause() } catch (_: Throwable) {}
        startActivity(Intent(this, BrowserActivity::class.java).putExtra("start", page).putExtra("noauto", true)
            .putExtra("repair_id", id).putExtra("repair_url", old).putExtra("repair_title", t))
        finish()
    }
    private fun startLinkRefresh(page: String) {
        val old = url ?: return
        Notice.show(this, "⏳ بجيب لينك الفيديو من الصفحة…", 4000L)
        LinkRefresh.run(this, page, old, hdr["User-Agent"] ?: "") { r ->
            if (isFinishing || isDestroyed) return@run
            refreshAsked = false
            if (r != null && r.same) {
                applyNewLink(r)
                Notice.show(this, "✓ اتحدّث لينك الفيديو", 2500L)
                return@run
            }
            // (v142) مالقيناش نفس الفيديو بالظبط: بنعرضلك اللينكات اللي اتلقت في قايمة تختار منها هنا، من غير ما تروح تدوّر بإيدك
            val opts = r?.all?.distinct().orEmpty()
            if (r != null && opts.isNotEmpty()) {
                val labels = opts.mapIndexed { i, u -> val hh = Sniff.heightOf(u); (if (hh > 0) "${hh}p" else "لينك ${i + 1}") + " · " + Sniff.nameOf(u).take(40) }.toTypedArray()
                GAlert(this).setTitle("اختار لينك الفيديو (" + opts.size + ")")
                    .setItems(labels) { _, w -> applyNewLink(LinkRefresh.Res(opts[w], true, r.cookie, r.ua)); Notice.show(this, "✓ اتحدّث لينك الفيديو", 2500L) }
                    .setNegativeButton("إلغاء", null).show()
            } else {
                GAlert(this).setTitle("⚠ مالقيتش لينك الفيديو").setMessage("الصفحة ماطلّعتش أي لينك فيديو (غالبًا محمية أو محتاجة ضغطة على زرار التحميل).\nتفتح الصفحة تصطاد بنفسك؟")
                    .setPositiveButton("نعم") { _, _ -> repairInBrowser(page) }
                    .setNegativeButton("لا", null).show()
            }
        }
    }
    private fun applyNewLink(r: LinkRefresh.Res) {
        url = r.url
        if (r.cookie.isNotEmpty()) hdr["Cookie"] = r.cookie
        spec?.let { sp -> if (aurl == null) sp.url = r.url; if (r.cookie.isNotEmpty()) sp.hdr["Cookie"] = r.cookie }
        httpDsf?.setDefaultRequestProperties(hdr)
        val appCtx = applicationContext; val id = vid; val nu = r.url; val ck = r.cookie
        val refB = intent.getStringExtra("ref") ?: ""; val titleB = intent.getStringExtra("title") ?: ""
        Thread { WebVideos.update(appCtx, id) { it.copy(url = nu, cookie = if (ck.isNotEmpty()) ck else it.cookie, ts = System.currentTimeMillis()) }; if (!incognito) WebIdent.bindLink(id, nu, refB, titleB) }.apply { isDaemon = true }.start()
        try { val pos = player.currentPosition; player.exo()?.setMediaItem(MediaItem.fromUri(Uri.parse(r.url)), pos); player.exo()?.prepare(); player.playWhenReady = true } catch (e: Exception) { LogStore.err("Main:2115", e) }
    }

    // ===== الفيديوهات المصطادة: تسجيل في السجل + لقطة مصغّرة (الاسم من صفحة الموقع) =====
    @Volatile private var webFirstFrame = false
    private var webSnapTries = 0
    private fun webRegister() {
        val u = url ?: return
        val appCtx = applicationContext; val id = vid
        val ref = hdr["Referer"] ?: ""; val ua = hdr["User-Agent"] ?: ""; val ck = hdr["Cookie"] ?: ""
        val siteTitle = intent.getStringExtra("title")?.takeIf { it.isNotBlank() }
        val t0 = siteTitle ?: Sniff.nameOf(u)
        val kind = if (u.contains("videoplayback")) "YT" else Sniff.kindOf(u)
        val pageX = intent.getStringExtra("page") ?: ""
        val page = if (WebIdent.specific(pageX)) pageX else if (WebIdent.specific(ref)) ref else ""   // (v750) صفحة التاب الأصلية أولًا · (v142) صفحة الفيديو بتتحفظ لوحدها (من الصفحة اللي اتصاد منها) عشان تحديث اللينك يشتغل من غير ما تدخلها بإيدك
        Thread { WebVideos.register(appCtx, id, u, ref, ua, ck, t0, kind, siteTitle != null, page, hiddenSite) }.apply { isDaemon = true }.start()
        h.postDelayed({ webSnap() }, 9000)
    }
    private fun webSnap() {
        if (isFinishing || isDestroyed || !::svRef.isInitialized) return
        val ready = webFirstFrame && svRef.width > 0 && svRef.height > 0
        if (!ready) { if (++webSnapTries < 4) h.postDelayed({ webSnap() }, 8000); return }
        val appCtx = applicationContext; val id = vid
        val bmp = android.graphics.Bitmap.createBitmap(svRef.width, svRef.height, android.graphics.Bitmap.Config.ARGB_8888)
        try {
            android.view.PixelCopy.request(svRef, bmp, { res ->
                if (res != android.view.PixelCopy.SUCCESS) return@request
                Thread { try { WebVideos.saveThumb(appCtx, id, bmp) } catch (e: Throwable) { LogStore.err("Main:2140", e) } }.apply { isDaemon = true }.start()
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) { LogStore.err("Main:2142", e) }
    }

    /** زرار 📋 في المشغّل = نفس صفحة اللوجز بتاعة القايمة (اللوج العايم اتلغى) */
    fun toggleLog() { if (logDlg.isShowing) logDlg.dismiss() else logDlg.show() }

    /**
     * (v151) 🧑 الشخصيات وجنسها: نافذة سفلية فوق الفيديو (الفيديو مابيتضغطش ولا بيتوقف).
     * لو مفيش شخصيات متحللة لسه (فيديو اتترجم قبل كده، أو التحليل التلقائي ماجاش) بتحلّلها من الترجمة الحالية أول ما تفتح.
     */
    private var charsDlg: android.app.Dialog? = null
    private fun showChars() {
        if (charsDlg?.isShowing == true) { charsDlg?.dismiss(); return }
        if (!::engine.isInitialized) { Notice.show(this, "المحرك لسه بيحمّل — جرّب كمان لحظة", 2300L); return }
        val eng = engine
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val d = ui.sheet(this, "🧑 الشخصيات", listOf<View>(col), false, onClose = { charsDlg = null })
        charsDlg = d
        var busy = false
        var analyzeRef: () -> Unit = {}
        fun render(list: List<Chr>, msg: String) {
            col.removeAllViews()
            if (msg.isNotEmpty()) col.addView(ui.text(msg, 12f, th.muted).apply { setPadding(0, 0, 0, ui.dp(6)) })
            for (c in list) {
                val f = c.gender == "female"
                val row = LinearLayout(this).apply {
                    layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(ui.dp(12), ui.dp(9), ui.dp(12), ui.dp(9)); background = ui.box(th.surface, th.border, 10)
                }
                row.addView(ui.text(c.name, 15f, th.text, true), LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(ui.text(if (f) "👩 أنثى" else "👨 ذكر", 13f, if (f) 0xFFE0559A.toInt() else 0xFF4F8FE8.toInt(), true))
                col.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(5) })
                if (c.role.isNotBlank()) col.addView(ui.text(c.role, 11f, th.muted).apply { setPadding(ui.dp(12), ui.dp(2), ui.dp(12), 0) })
            }
            col.addView(ui.button(if (busy) "⏳ بحلّل…" else "🔄 حلّل الشخصيات من الترجمة دلوقتي") { if (!busy) analyzeRef() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(10) })
        }
        fun analyze() {
            busy = true
            render(eng.charactersNow(), "⏳ بحلّل الشخصيات من الترجمة… (ممكن ياخد شوية — تقدر تقفل النافذة)")
            eng.analyzeCharsNow(
                { m -> runOnUiThread { if (d.isShowing) Notice.show(this, m, 2600L) } },
                { list -> runOnUiThread { busy = false; if (d.isShowing) render(list, if (list.isEmpty()) "ملقيتش شخصيات واضحة في الجمل الحالية — كمّل الترجمة وجرّب تاني" else "") } }
            )
        }
        analyzeRef = { analyze() }
        val now = eng.charactersNow()
        d.show()
        if (now.isEmpty()) analyze() else render(now, "")
    }

    /** (v125) ⏮ ⏭: لو الفيديو من فولدر في المكتبة → الحلقة اللي قبلها/بعدها، وإلا (فيديو إنترنت/ملف لوحده) → الجملة اللي قبلها/بعدها (قبل كده كانت بتطلّع رسالة بس) */
    /** (v531) إخوات الفيديو الحالي في نفس الفولدر + مكانه. على التلفزيون الترتيب هو ترتيب صفحة «الفيديوهات» (tv_vid_sort، الأحدث افتراضيًا)، وعلى الموبايل بالاسم */
    private fun libSibs(): Pair<List<VideoItem>, Int>? {
        val curU = uri?.toString() ?: return null
        val all = VideoScan.cache ?: return null
        val me = all.firstOrNull { it.uri == curU } ?: return null
        val mode = if (DeviceUi.isTv(this)) Cfg.str("tv_vid_sort", VideoLib.SORT_NEW) else VideoLib.SORT_NAME
        val sib = VideoLib.sortVideos(all.filter { it.folderKey == me.folderKey }, mode)
        return Pair(sib, sib.indexOfFirst { it.uri == curU })
    }
    /** (v531) آخر فيديو في القايمة ← يرجع لأول فيديو (تلفزيون افتراضيًا؛ على الموبايل لو autoplay_wrap=1) */
    /** (v781) وضع التكرار: 0 عادي (التالي لو فيه وبعدها يقف) · 1 يعيد نفس الفيديو · 2 يكمّل الفولدر ولما يخلص يرجع لأول فيديو */
    private fun loopMode(): Int = if (Cfg.str("loop", "0") == "1") 1 else if (wrapOn()) 2 else 0
    private fun loopCycle() {
        val n = (loopMode() + 1) % 3
        Cfg.put("loop", if (n == 1) "1" else "0"); Cfg.put("autoplay_wrap", if (n == 2) "1" else "0")
        say(when (n) { 1 -> "🔂 تكرار نفس الفيديو"; 2 -> "🔁 تكرار كل فيديوهات الفولدر"; else -> "➡ تشغيل عادي" })
    }
    /** (v787) ضبط وضع التكرار مباشرة: 1 نفس الفيديو · 2 كل الفولدر؛ لو هو الوضع الحالي أصلًا يرجع عادي */
    private fun loopSet(n0: Int) {
        val n = if (n0 == loopMode()) 0 else n0.coerceIn(0, 2)
        Cfg.put("loop", if (n == 1) "1" else "0"); Cfg.put("autoplay_wrap", if (n == 2) "1" else "0")
        say(when (n) { 1 -> "🔂 تكرار نفس الفيديو"; 2 -> "🔁 تكرار كل فيديوهات الفولدر"; else -> "➡ تشغيل عادي" })
    }
    private fun wrapOn(): Boolean = Cfg.str("autoplay_wrap", if (DeviceUi.isTv(this)) "1" else "0") == "1"

    fun stepOrSeek(d: Int) {
        if (remote && TvQueue.active) { TvQueue.step(this, d); showChrome(); return }   // (v658) قايمة «تشغيل على التلفزيون»: ⏮ ⏭ بينقلوا بين فيديوهاتها
        run {
            val p = libSibs()
            if (p != null && (p.first.getOrNull(p.second + d) != null || (wrapOn() && p.first.size > 1))) { stepEpisode(d); return }
        }
        val t = player.currentPosition - offsetMs
        if (starts.isNotEmpty()) {
            val i = if (d > 0) starts.indexOfFirst { it > t + 200 } else starts.indexOfLast { it < t - 1500 }
            if (i >= 0) { player.seekTo(starts[i] + offsetMs); return }
        }
        player.seekTo((player.currentPosition + d * 10000L).coerceIn(0L, if (durMs > 0) durMs else Long.MAX_VALUE))
    }
    /** الحلقة اللي بعدها (+1) أو اللي قبلها (-1) من نفس الفولدر: بيوقف ترجمة الحالية ويبدأ ترجمة الجديدة */
    fun stepEpisode(d: Int) {
        val p = libSibs() ?: run { say("الفيديو ده مش من مكتبة الجهاز"); return }
        val sib = p.first
        var t = sib.getOrNull(p.second + d)
        if (t == null && wrapOn() && sib.size > 1) { t = if (d > 0) sib.first() else sib.last(); say("🔁 رجعنا " + (if (d > 0) "لأول" else "لآخر") + " فيديو في القايمة") }   // (v531)
        if (t == null) { say(if (d > 0) "دي آخر حلقة في الفولدر" else "دي أول حلقة في الفولدر"); return }
        Cfg.put("lib_last", t.uri); Cfg.put("lib_last_f:" + t.folderKey, t.uri)
        say("▶ " + t.title)
        swapVideo(Uri.parse(t.uri))
    }

    /** بدّل الفيديو في نفس الشاشة من غير ما تفتح Activity جديدة */
    fun swapVideo(newUri: Uri) {
        try { EndOverlay.hide(); ResumeAsk.dismiss() } catch (_: Throwable) {}   // (v1056)
        stopVoice()   // (v334) الصوت النضيف بتاع الفيديو القديم
        saveRecent()
        try { visual.stop() } catch (e: Exception) { LogStore.err("Main:2164", e) }
        retireEngine()
        try { engine.saveNow() } catch (e: Exception) { LogStore.err("Main:2166", e) }
        try { loud?.release(); loud = null } catch (_: Throwable) {}
        try { player.release() } catch (e: Exception) { LogStore.err("Main:2167", e) }
        uri = newUri; url = null; aurl = null; hdr.clear()
        cur = 0L; durMs = 0L; vidW = 0; vidH = 0; curIdx = -2; curKey = ""; dirty = true
        nativeCue = ""; sfHideNative = false; textPicked = false; natShown = false; natLast = ""; diagCueN = 0; diagCueLast = ""; diagN = 0; preferNative = false; sfLive = ""; sfLiveCache.clear(); sfLiveAsk.clear()
        sfShown = false; sfOffKey = ""
        synchronized(logBuf) { logBuf.setLength(0) }
        status = ""; conf = Cfg.snapshot()
        try { sub.show(null) } catch (e: Exception) { LogStore.err("Main:2172", e) }
        visOv.showBoxes(emptyList())
        resumePending = false; applyCard()
        engineStarted = false; autoRotDone = false; userRot = false
        buildPlayer(); initEngine()
        notifTitleOv = Recents.titleOf(vid)
        updateTr()
    }

    /** أفقي = ملء الشاشة (شريط الأزرار العلوي + كبسولة التقدم تظهر بلمسة)، رأسي = فيديو فوق والكبسولة وشبكة الأزرار تحت */
    private fun applyFull(f: Boolean) {
        if (pipNow()) return   // في PiP الشاشة بتتغير مقاسها (config) وماينفعش نرجّع الأزرار
        fullMode = f
        if (!f) closeSide()
        fitFsB?.text = "⬛ " + fitNameOf(curFit()); if (::svRef.isInitialized) applyFit(svRef, videoBoxRef)
        extras.visibility = if (f) View.GONE else View.VISIBLE
        val lp = videoBoxRef.layoutParams as LinearLayout.LayoutParams
        val dm = resources.displayMetrics
        lp.height = if (f) -1 else (minOf(dm.widthPixels, dm.heightPixels) - ui.dp(32)) * 9 / 16
        if (f) lp.setMargins(0, 0, 0, 0) else lp.setMargins(ui.dp(16), ui.dp(32), ui.dp(16), if (ytPage && Design.isNew()) ui.dp(16) else 0)
        videoBoxRef.layoutParams = lp
        videoBoxRef.background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = if (f) 0f else ui.dp(14).toFloat() }
        if (ytPage) { fsBtnLp.gravity = Gravity.BOTTOM or Gravity.RIGHT; fsBtnLp.setMargins(0, 0, ui.dp(10), ui.dp(10)) } else fsBtnLp.setMargins(ui.dp(10), 0, 0, ui.dp(10)); fsBtnV.layoutParams = fsBtnLp   // (v1143)
        fsOnly.forEach { it.visibility = if (f && (it !== visBadge || (::visual.isInitialized && visual.running))) View.VISIBLE else View.GONE }   // (v431) 👁 البصري بس لو شغّال
        try { tbView?.let { v -> (v.layoutParams as? FrameLayout.LayoutParams)?.let { lp -> lp.rightMargin = ui.dp(8); v.layoutParams = lp } } } catch (_: Throwable) {}   // (v265)
        st.visibility = if (f) View.GONE else View.VISIBLE
        if (::logDrawer.isInitialized) { (leftCol.layoutParams as FrameLayout.LayoutParams).topMargin = ui.dp(44); logDrawer.visibility = View.VISIBLE; leftCol.requestLayout() }
        // (v1113) ملء الشاشة من الحافة للحافة: المحتوى يمتد تحت شريط الحالة والتنقل
        // (v1113) فمافيش شريط رمادي فوق ولا تحت ياكل من الفيديو — والشرايط نفسها شفافة فتظهر سودا فوق الفيديو
        if (f) {
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
        } else {
            applyBars(th)
        }
        @Suppress("DEPRECATION") window.decorView.systemUiVisibility = if (f) (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION) else (if (Build.VERSION.SDK_INT >= 23 && th.isLight) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0)
        placeCard()
        if (f) showChrome() else { h.removeCallbacks(hideChrome); chromeShown = false; applyChromeFn() }
        if (::svRef.isInitialized) videoBoxRef.post { applyFit(svRef, videoBoxRef) }   // (v429) بعد ما الـ layout يخلص بالمقاس الجديد (كان بيتحسب على المقاس القديم لفريم)
        applyPageChrome()
    }
    fun showChrome() { if (pipNow() || uiLocked || DeviceUi.isRemote(this)) return; chromeShown = true; applyChromeFn(); h.removeCallbacks(hideChrome); h.postDelayed(hideChrome, 3500) }
    fun togglePlay() { if (player.isPlaying) player.pause() else { if (player.playbackState == Player.STATE_ENDED) player.seekTo(0); if (player.playbackState == Player.STATE_IDLE && isCastSrc()) { castRecover = 0; try { player.exo()?.prepare() } catch (_: Throwable) {} }; player.play() } }   // (v767) واقف بعد خطأ في فيديو الموبايل: ▶ بيعيد المحاولة
    /** (v97) في حلقة بعد الحالية في نفس الفولدر؟ (من غير رسالة) */
    private fun hasNextEpisode(): Boolean {
        if (remote) return false
        val p = libSibs() ?: return false
        return p.first.getOrNull(p.second + 1) != null || (wrapOn() && p.first.size > 1)   // (v531) + اللفّ لأول فيديو
    }
    private var userRot = false
    private var autoRotDone = false
    private val ytPage: Boolean by lazy {
        intent.getBooleanExtra("ytpage", false) && !DeviceUi.isTv(this) && !remote && intent.getStringExtra("ytid")?.length == 11
    }
    private var pageFullP = false
    private var pageCpShow = false   // (v1143) لمسة على الفيديو في وضع الصفحة = يظهر ⏸/▶ ٢.٥ث
    private val pageCpHide = Runnable { pageCpShow = false; try { if (ytPage && !fullMode && !buffering && player.isPlaying) centerPlay.visibility = View.GONE } catch (_: Throwable) {} }
    private var ytWatch: YtWatchPage? = null

    // ===== (v1161) سحب التصغير زي يوتيوب: الفيديو بيصغّر ويتحرك لتحت مع الصباع · الصفحة تنزل وتبهت · الفيد اللي ورا يبان · بعد الإفلات يكمّل أو يرجع بحركة ناعمة =====
    private var ytPageRef: LinearLayout? = null
    private var ytDragOn = false
    private var ytDragP = 0f
    private var ytDownX = 0f
    private var ytDownY = 0f
    private var ytVt: android.view.VelocityTracker? = null
    private var ytAnim: android.animation.ValueAnimator? = null
    private fun ytPageH(): Float { val pg = ytPageRef; return (if (pg != null && pg.height > 0) pg.height else resources.displayMetrics.heightPixels).toFloat() }
    private fun ytMiniScale(): Float { val w = videoBoxRef.width.toFloat().coerceAtLeast(1f); return minOf(ui.dp(104).toFloat(), w * 0.42f) / w }   // (v1162) نفس عرض فيديو الدوك السفلي
    private fun ytMiniTy(): Float { val vb = videoBoxRef; return (ytPageH() - vb.height * ytMiniScale() - ui.dp(72)) - vb.top }
    private fun ytApplyDrag(p0: Float) {
        val vb = videoBoxRef; val pg = ytPageRef ?: return
        val p = p0.coerceIn(0f, 1f); ytDragP = p
        val s = ytMiniScale(); val sc = 1f - p * (1f - s)
        vb.pivotX = 0f; vb.pivotY = 0f
        vb.scaleX = sc; vb.scaleY = sc; vb.translationY = p * ytMiniTy(); vb.translationX = p * (pg.width - vb.width * s)   // (v1162) يلزق يمين زي الدوك
        extras.translationY = p * (ytPageH() - vb.height)
        extras.alpha = (1f - p * 1.7f).coerceIn(0f, 1f)
        try { pg.background.mutate().alpha = (255f * (1f - (p * 1.4f).coerceAtMost(1f))).toInt() } catch (_: Throwable) {}   // (v1343) السحب للتصغير: الصفحة بتشف تدريجي وتكشف قايمة يوتيوب اللي وراها (رجوع لسلوك v1161) — اللي وراها دايمًا الفيد بعد v1343 (بطلب علي)
    }
    private fun ytAnimTo(target: Float, then: (() -> Unit)? = null) {   // (v1347) إنهاء السحب فوري من غير أنيميشن (بطلب علي)
        ytAnim?.cancel()
        ytApplyDrag(target)
        then?.invoke()
    }
    private fun ytDragReset() {
        try { ytAnim?.cancel() } catch (_: Throwable) {}
        ytDragOn = false
        try {
            ytApplyDrag(0f)
            videoBoxRef.scaleX = 1f; videoBoxRef.scaleY = 1f; videoBoxRef.translationX = 0f; videoBoxRef.translationY = 0f
            extras.translationY = 0f; extras.alpha = 1f
            ytPageRef?.background?.mutate()?.alpha = 255
        } catch (_: Throwable) {}
    }
    private fun ytDragDown(ev: MotionEvent) {
        ytDownX = ev.rawX; ytDownY = ev.rawY; ytDragOn = false
        try { ytVt?.recycle() } catch (_: Throwable) {}
        ytVt = android.view.VelocityTracker.obtain().also { it.addMovement(ev) }
    }
    private fun ytDragStart(ev: MotionEvent): Boolean {
        try { ytVt?.addMovement(ev) } catch (_: Throwable) {}
        val dy = ev.rawY - ytDownY; val dx = ev.rawX - ytDownX
        if (dy > ui.dp(14) && dy > Math.abs(dx) * 1.3f) { ytDragOn = true; log("↕ سحب لتحت: تصغير (تفاعلي)"); return true }
        return false
    }
    private fun ytDragMove(ev: MotionEvent) {
        try { ytVt?.addMovement(ev) } catch (_: Throwable) {}
        val span = maxOf(ui.dp(220).toFloat(), ytMiniTy())
        ytApplyDrag((ev.rawY - ytDownY - ui.dp(14)) / span)
    }
    private fun ytDragEnd(ev: MotionEvent) {
        var vy = 0f
        try { ytVt?.addMovement(ev); ytVt?.computeCurrentVelocity(1000); vy = ytVt?.yVelocity ?: 0f; ytVt?.recycle() } catch (_: Throwable) {}
        ytVt = null; ytDragOn = false
        val commit = ev.actionMasked == MotionEvent.ACTION_UP && (ytDragP > 0.35f || (vy > ui.dp(700) && ytDragP > 0.06f))
        if (commit) ytAnimTo(1f) { ytCommitMini() } else ytAnimTo(0f)
    }
    // ===== (v1162) تسليم المشغّل للدوك السفلي في Main + سحب التصغير من الصفحة نفسها =====
    @Volatile private var dockedAway = false
    private var plstRef: Player.Listener? = null
    private fun ytTryDock(pending: Boolean = false): Boolean {
        if (remote || !ytPage || !YtDockCfg.on() || audioOnlyMode) return false
        try {
            val ex = player.exo() ?: return false
            val u = url?.takeIf { it.isNotBlank() } ?: return false
            val st = ex.playbackState
            if (st == Player.STATE_IDLE || st == Player.STATE_ENDED) return false
            val item = ytItemFromIntent()
            if (item.id.length != 11) return false
            val pos = ex.currentPosition
            val was = ex.playWhenReady
            plstRef?.let { try { ex.removeListener(it) } catch (_: Throwable) {} }
            try { loud?.release(); loud = null } catch (_: Throwable) {}
            try { ex.setPlaybackSpeed(1f); ex.volume = 1f } catch (_: Throwable) {}
            val pick = YtPick(u, aurl, hdr["User-Agent"] ?: "", item.title, vidH)
            YtDockHold.put(item, YtKept(ex, pick, pos), was, pending)
            dockedAway = true
            try { visual.stop() } catch (_: Throwable) {}
            try { saveRecent() } catch (_: Throwable) {}
            val eng0 = engine
            retireEngine()
            Thread { try { eng0.saveNow() } catch (e: Throwable) { LogStore.err("Player:dockSave", e) } }.start()
            log("⤵ تصغير للدوك السفلي")
            if (!isFinishing) finish()
            return true
        } catch (e: Throwable) { LogStore.err("Player:ytTryDock", e); dockedAway = false; return false }
    }
    private var ytPgActive = false   // السحب بدأ من صفحة المشاهدة (تحت الفيديو) مش من الفيديو
    private fun ytCanScrollUp(v: View): Boolean {
        if (v.visibility != View.VISIBLE) return false
        if (v.canScrollVertically(-1)) return true
        if (v is ViewGroup) for (i in 0 until v.childCount) if (ytCanScrollUp(v.getChildAt(i))) return true
        return false
    }
    /** سحب التصغير من صفحة المشاهدة: لو القايمة فوق خالص وسحبت لتحت = نفس تصغير الفيديو */
    private fun ytPageTouch(ev: MotionEvent): Boolean {
        if (ytAnim?.isRunning == true) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ytPgActive = false
                if (!::extras.isInitialized) return false
                val loc = IntArray(2); videoBoxRef.getLocationOnScreen(loc)
                if (ev.rawY <= loc[1] + videoBoxRef.height) return false   // اللمسة على الفيديو: بتتعامل من gestureLayer
                ytPgActive = true; ytDragDown(ev); return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!ytPgActive) return false
                if (!ytDragOn) {
                    try { ytVt?.addMovement(ev) } catch (_: Throwable) {}
                    val dy = ev.rawY - ytDownY; val dx = ev.rawX - ytDownX
                    if (dy > ui.dp(18) && dy > Math.abs(dx) * 1.4f && !ytCanScrollUp(extras)) {
                        ytDragOn = true; ytDownY = ev.rawY - ui.dp(14)
                        log("↕ سحب لتحت من الصفحة: تصغير")
                        val c = MotionEvent.obtain(ev); c.action = MotionEvent.ACTION_CANCEL; super.dispatchTouchEvent(c); c.recycle()
                        return true
                    }
                    return false
                }
                ytDragMove(ev); return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!ytPgActive) return false
                ytPgActive = false
                if (ytDragOn) { ytDragEnd(ev); return true }
                try { ytVt?.recycle() } catch (_: Throwable) {}; ytVt = null
                return false
            }
        }
        return ytPgActive && ytDragOn
    }
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        try { if (ytPage && !gone && !fullMode && !pipNow() && (ytPgActive || !ytDragOn || ytAnim?.isRunning == true) && ytPageTouch(ev)) return true } catch (_: Throwable) {}
        return super.dispatchTouchEvent(ev)
    }
    /** نهاية التصغير: دوك التطبيق السفلي من غير إذن PiP. لو الدوك مش متاح (صوت بس/الإعداد مقفول/خطأ) PiP النظام احتياطي، ولو ما دخلش الفيديو يرجع مكانه بحركة ناعمة */
    private fun ytCommitMini() {
        // (v1326) النزول بالسحب = دوك التطبيق السفلي (مفيش إذن صورة-في-صورة) — زرار ⧉ في ملء الشاشة لسه بيدخل PiP عادي
        if (ytTryDock()) return
        try { ytAnimTo(0f) } catch (e: Throwable) { LogStore.err("Player:ytCommitMini", e) }
    }

    private fun wantFull(): Boolean {
        if (!ytPage) return true
        if (pageFullP) return true
        return resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    }

    private fun enterPageFull() {
        if (fullMode) return
        userRot = true
        val wide = vidW <= 0 || vidH <= 0 || vidW >= vidH
        val isLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (wide && !isLand) {
            pageFullP = false
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            pageFullP = true
            applyFull(true)
        }
    }

    private fun exitPageFull() {
        if (!fullMode) return
        pageFullP = false
        userRot = true
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        } else {
            applyFull(false)
        }
    }

    private fun applyPageChrome() {
        if (!ytPage || fullMode) return
        floatBar.visibility = View.GONE
        batchBtn.visibility = View.GONE
        rotBtn.visibility = View.GONE
        miniBar.visibility = View.GONE
        centerPlay.visibility = if (busyShown()) View.GONE else if (buffering || pageCpShow || (::player.isInitialized && !player.isPlaying)) View.VISIBLE else View.GONE   // (v1143) زرار ⏸/▶ في النص · (v1159) لودينج «بيحمّل الفيديو» ظاهر = مفيش زرار أوسط فوقه (كان بيطلع لودينجين فوق بعض)
        st.visibility = View.GONE
        trChipV?.visibility = View.GONE
        if (::audBtn.isInitialized) audBtn.visibility = View.GONE
        if (::tvBtn.isInitialized) tvBtn.visibility = View.GONE
        if (::modePill.isInitialized) modePill.visibility = View.GONE
        fsBtnV.visibility = View.VISIBLE
    }

    private fun ytItemFromIntent(): NpItem {
        val id = intent.getStringExtra("ytid") ?: ""
        val th0 = intent.getStringExtra("ytthumb") ?: ""
        val thumb = if (th0.isNotBlank()) th0 else "https://i.ytimg.com/vi/" + id + "/hqdefault.jpg"
        return NpItem(id, intent.getStringExtra("title") ?: "", intent.getStringExtra("ytchan") ?: "", intent.getStringExtra("ytchanurl") ?: "", thumb,
            intent.getLongExtra("ytdur", 0L), intent.getLongExtra("ytcount", 0L), intent.getStringExtra("ytage") ?: "", 0, YtNp.watchUrl(id), 0L, intent.getStringExtra("ytav") ?: "", intent.getStringExtra("ytcid") ?: "")
    }

    private fun buildYtPage(): View {
        val wp = YtWatchPage(this, ui, ytHost(), true)
        wp.link = object : YtPageLink {
            override fun posMs(): Long = try { player.currentPosition } catch (_: Throwable) { 0L }
            override fun durMs(): Long = if (durMs > 0L) durMs else 0L
            override fun seekToMs(ms: Long) {
                try { player.seekTo(ms) } catch (_: Throwable) {}
            }
            override fun playing(): Boolean = try { player.isPlaying } catch (_: Throwable) { false }
            override fun pause() {
                try { player.pause() } catch (_: Throwable) {}
            }
        }
        ytWatch = wp
        val it0 = ytItemFromIntent()
        wp.post { wp.open(it0, null) }
        // (v1347) أنيميشن تبديل الفيديو جوه الصفحة اتلغى (بطلب علي): المحتوى بيتبدل فورًا
        return wp
    }

    private fun ytHost(): YtWatchHost = object : YtWatchHost {
        override fun expand(id: String, title: String, posMs: Long, translate: Boolean, pick: YtPick?) {
            runOnUiThread {
                if (translate) {
                    enterPageFull()
                    beginTranslate()
                }
            }
        }
        override fun openChannel(url: String, name: String) {
            runOnUiThread { openYtChannelInMain(url) }
        }
        override fun openVideo(v: NpItem) {
            runOnUiThread { openYtPageVideo(v) }
        }
        override fun audio(v: NpItem) { runOnUiThread { try { audioOnly() } catch (e: Throwable) { LogStore.err("Player:ytAudio", e) } } }   // (v1144) صوت بس في نفس المشغّل
        override fun download(anchor: View, v: NpItem) { runOnUiThread { try { if (url == null) Notice.show(this@PlayerActivity, "⏳ استنى لحد ما الفيديو يحمّل", 1800L) else downloadPopup(anchor) } catch (e: Throwable) { LogStore.err("Player:ytDl", e) } } }   // (v1144)
        override fun state(open: Boolean) {}
        override fun bgTranslate() { runOnUiThread { try { translateInBackground(false, "صفحة يوتيوب (🌙 تفريغ وترجمة)") } catch (e: Throwable) { LogStore.err("Player:ytBg", e) } } }   // (v1145)
    }

    private fun openYtChannelInMain(url: String) {
        if (url.isBlank()) return
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT).putExtra(Links.EX_URL, url))
        closeNoBg()
    }

    private fun openYtPageVideo(v: NpItem) {
        // تبديل الفيديو في نفس الشاشة: صندوق الفيديو ثابت والمحتوى تحته بس هو اللي بيتغيّر (من غير Activity جديدة ولا حركة أفقية)
        try { EndOverlay.hide(); ResumeAsk.dismiss() } catch (_: Throwable) {}
        try { stopVoice() } catch (_: Throwable) {}
        try { saveRecent(); saveYtProg() } catch (_: Throwable) {}
        try { visual.stop() } catch (_: Throwable) {}
        try { retireEngine() } catch (_: Throwable) {}
        try { engine.saveNow() } catch (_: Throwable) {}
        try { loud?.release(); loud = null } catch (_: Throwable) {}
        try { player.release() } catch (_: Throwable) {}
        intent.putExtra("ytid", v.id); intent.putExtra("title", v.title); intent.putExtra("ytchan", v.channel); intent.putExtra("ytchanurl", v.channelUrl)
        intent.putExtra("ytthumb", v.thumb); intent.putExtra("ytav", v.avatar); intent.putExtra("ytcid", v.channelId); intent.putExtra("ytcount", v.count)
        intent.putExtra("ytage", v.age); intent.putExtra("ytdur", v.dur); intent.putExtra("ytpend", true); intent.putExtra("handoff", false)
        try { YtHistory.add(this, v.id, v.title) } catch (_: Throwable) {}
        uri = null; url = null; aurl = null; hdr.clear(); qOpts = emptyList(); qCur = -1
        cur = 0L; durMs = 0L; vidW = 0; vidH = 0; curIdx = -2; curKey = ""; dirty = true
        nativeCue = ""; sfHideNative = false; textPicked = false; natShown = false; natLast = ""; diagCueN = 0; diagCueLast = ""; diagN = 0; preferNative = false; sfLive = ""; sfLiveCache.clear(); sfLiveAsk.clear()
        sfShown = false; sfOffKey = ""
        synchronized(logBuf) { logBuf.setLength(0) }
        status = ""; conf = Cfg.snapshot()
        try { sub.show(null) } catch (_: Throwable) {}
        try { visOv.showBoxes(emptyList()) } catch (_: Throwable) {}
        resumePending = false; engineStarted = false; autoRotDone = false; userRot = false
        try { ytWatch?.open(v, null) } catch (_: Throwable) {}
        pendingYt = true
        startYtPend()
    }
    /** (v604) تدوير صورة الفيديو نفسها (0/90/180/270) — على التلفزيون بس (شاشته مابتلفّش) */
    private var rotDeg = 0
    private var rmFitSkip = false
    /** (v604) في وضع المتحكم: السؤال «على الموبايل ولا على التلفزيون؟» لأي زرار ليه أثر على الاتنين */
    private fun rmChoose(title: String, phoneLbl: String, tvLbl: String, onPhone: () -> Unit, onTv: () -> Unit) {
        try {
            var dlg: android.app.Dialog? = null
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(4), ui.dp(2), ui.dp(4), ui.dp(2)) }
            col.addView(ui.button(phoneLbl) { dlg?.dismiss(); onPhone() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = ui.dp(8) })
            col.addView(ui.button(tvLbl, true) { dlg?.dismiss(); onTv() }, LinearLayout.LayoutParams(-1, -2))
            dlg = ui.sheet(this, title, listOf<View>(col)); dlg.show()
        } catch (e: Throwable) { LogStore.err("Player:rmChoose", e); onPhone() }
    }
    /** (v604) على التلفزيون: لفّ صورة الفيديو 90° (للفيديوهات المصوّرة على الجنب) */
    private fun rotateVideoNow(deg: Int = (rotDeg + 90) % 360) {
        rotDeg = ((deg % 360) + 360) % 360
        try { if (::svRef.isInitialized && ::videoBoxRef.isInitialized) { applyFit(svRef, videoBoxRef); videoBoxRef.post { applyFit(svRef, videoBoxRef) } } } catch (_: Throwable) {}
        try { say("🔄 " + rotDeg + "°") } catch (_: Throwable) {}
    }
    /** (v429) الدوران بين البورتريه والشاشة الكاملة كان بيبان «نتشة»: الشاشة بتلف بأنيميشن النظام والسطح بيتمدّد لحظة بمقاس قديم. كروس-فيد بيخفي ده */
    private fun smoothRotation() {
        try { val ra = if (ytRotAnimOn()) 2 else 1; val a = window.attributes; if (a.rotationAnimation != ra) { a.rotationAnimation = ra; window.attributes = a } } catch (_: Throwable) {}   // 1 = CROSSFADE · (v1125) 2 = JUMPCUT لما حركة تدوير الفيديو بتاعتنا شغّالة (يوتيوب)
    }
    /** (v1125) حركة «تدوير عنصر الفيديو» زي يوتيوب: بتتطبّق على جلسات يوتيوب بس، ومقفولة لو player_rot_anim=0 */
    private fun ytRotAnimOn(): Boolean = try { intent.getStringExtra("ytid") != null && Cfg.str("player_rot_anim", "1") != "0" } catch (_: Throwable) { false }
    private var lastDispRot = -1
    private fun dispRot(): Int = try { if (Build.VERSION.SDK_INT >= 30) (display?.rotation ?: 0) else @Suppress("DEPRECATION") windowManager.defaultDisplay.rotation } catch (_: Throwable) { 0 }
    /** (v1125) لما الشاشة تلف 90°: صندوق الفيديو يبدأ من شكله القديم (مدوّر ومصغّر/مكبّر ومن مكانه) ويلف لمكانه الجديد في 280ms بدل قفزة/كروس-فيد */
    private fun hookRotAnim(box: View) {
        box.addOnLayoutChangeListener { v, l, t, r, b, ol, ot, or2, ob ->
            try {
                val rot = dispRot()
                if (lastDispRot < 0) { lastDispRot = rot; return@addOnLayoutChangeListener }
                if (rot == lastDispRot) return@addOnLayoutChangeListener
                val prev = lastDispRot; lastDispRot = rot
                val nw = r - l; val nh = b - t; val ow = or2 - ol; val oh = ob - ot
                if (ow <= 0 || oh <= 0 || nw <= 0 || nh <= 0 || !ytRotAnimOn() || remote || gone || pipNow()) return@addOnLayoutChangeListener
                val d = -((((rot - prev) * 90) % 360 + 540) % 360 - 180)   // الصورة اللي كانت لازقة في الجهاز بتبان مدوّرة عكس لفّة الجهاز
                if (kotlin.math.abs(d) != 90) return@addOnLayoutChangeListener
                val dv = window.decorView
                val sw = dv.width.toFloat(); val sh = dv.height.toFloat()   // الشاشة الجديدة
                val wo = sh; val ho = sw                                    // الشاشة القديمة (مقلوبة)
                val cxo = (ol + or2) / 2f; val cyo = (ot + ob) / 2f
                val cx = if (d < 0) cyo else ho - cyo
                val cy = if (d < 0) wo - cxo else cxo
                val s = (ow.toFloat() / nw).coerceIn(0.3f, 3f)
                v.pivotX = nw / 2f; v.pivotY = nh / 2f
                v.rotation = d.toFloat(); v.scaleX = s; v.scaleY = s
                v.translationX = cx - (l + r) / 2f; v.translationY = cy - (t + b) / 2f
                if (ytPage) { v.animate().cancel(); v.rotation = 0f; v.scaleX = 1f; v.scaleY = 1f; v.translationX = 0f; v.translationY = 0f }   // (v1347) يوتيوب: لف فوري (بطلب علي)
                else v.animate().rotation(0f).scaleX(1f).scaleY(1f).translationX(0f).translationY(0f).setDuration(280L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
            } catch (e: Throwable) { LogStore.err("Player:rotAnim", e) }
        }
    }
    /** (v1125) الخروج من الشاشة الكاملة: لو لاندسكيب في جلسة يوتيوب، الشاشة بتلف بورتريه والفيديو بيلف (المشغّل لسه فوق) وبعدها بس نرجع للصفحة — الصفحة بتبان بورتريه من غير نتشة */
    private var exitRotating = false
    private fun exitRotateThen(block: () -> Unit) {
        if (exitRotating) return   // Back مرتين أثناء اللفّة: تتجاهل التانية
        if (!ytRotAnimOn() || remote || gone || isFinishing || isDestroyed || pipNow() || resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE) { block(); return }
        try {
            exitRotating = true; smoothRotation(); userRot = true
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            h.postDelayed({ if (!isDestroyed) block() }, 340L)
        } catch (_: Throwable) { block() }
    }
    fun toggleFs() {
        if (remote) {   // (v604) متوصّل بتلفزيون: لفّ إيه بالظبط؟
            rmChoose("🔄 تدوير", "📱 لفّ شاشة الموبايل", "📺 لفّ الفيديو على التلفزيون (90°)", { toggleFsLocal() }, {
                LinkSession.send("act", org.json.JSONObject().put("a", "rotate"))
                try { say("📺 🔄 90°") } catch (_: Throwable) {}   // مابنغيّرش rotDeg هنا: التدوير بيتطبّق على التلفزيون بس (معاينة الموبايل مابتتلفّش عشان ماتتلفّش مرتين)
            })
            return
        }
        toggleFsLocal()
    }
    private fun toggleFsLocal() {
        if (ytPage) {
            if (fullMode) exitPageFull() else enterPageFull()
            return
        }
        smoothRotation()
        userRot = true
        requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }
    /** مكان وحجم نافذة الـ PiP على الشاشة [x, y, w, h] (من الـ decor بتاع الأكتيفيتي) */
    fun pipRect(): IntArray? = try {
        val v = window.decorView; val loc = IntArray(2); v.getLocationOnScreen(loc)
        if (v.width > 0 && v.height > 0) intArrayOf(loc[0], loc[1], v.width, v.height) else null
    } catch (_: Exception) { null }
    fun canOverlay() = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
    fun enterPip(fromUser: Boolean = true) {
        // (v1344) الدخول في PiP مش محتاج إذن «العرض فوق التطبيقات» (أندرويد مش بيطلبه) — الإذن ده لشريط الترجمة الطافي بس، وبيظهر لو الإذن ممنوح
        if ((vidW <= 0 || vidH <= 0) && ::player.isInitialized) { try { val vs = player.videoSize(); if (vs.first > 0 && vs.second > 0) { vidW = vs.first; vidH = vs.second } } catch (_: Throwable) {} }   // (v606) تسليم من يوتيوب: المقاس لسه ماوصلش للـlistener
        if (Build.VERSION.SDK_INT >= 26) try {
            val pb = PictureInPictureParams.Builder()
            if (vidW > 0 && vidH > 0) pb.setAspectRatio(Rational((vidW.toFloat() / vidH).coerceIn(0.45f, 2.3f).times(1000).toInt(), 1000))
            // (v1191) لو الفيديو مصغّر بالسحب: نقول للنظام مكانه الحالي عشان حركة الـPiP تنزل من نفسه من غير نطّة
            if (ytPage && ytDragP > 0.5f) try {
                val r = android.graphics.Rect()
                if (videoBoxRef.getGlobalVisibleRect(r) && r.width() > 0 && r.height() > 0) pb.setSourceRectHint(r)
            } catch (_: Throwable) {}
            if (Build.VERSION.SDK_INT >= 31) try { pb.setSeamlessResizeEnabled(true) } catch (e: Throwable) { LogStore.err("Main:2234", e) }
            enterPictureInPictureMode(pb.build())
        } catch (_: Exception) { if (fromUser) Notice.show(this, ("PiP مش مدعوم على الجهاز ده").toString(), 2300L) }
    }
    private var internalNav = false
    override fun startActivity(i: Intent?) { internalNav = true; super.startActivity(i) }
    @Suppress("DEPRECATION")
    override fun startActivityForResult(i: Intent?, rc: Int) { internalNav = true; super.startActivityForResult(i, rc) }
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (gone) return
        if (!internalNav && !isFinishing && Build.VERSION.SDK_INT >= 26 && !isInPictureInPictureMode && try { player.isPlaying } catch (_: Exception) { false }) {
            if (!DeviceUi.isTv(this) && !remote && ytPage && !audioOnlyMode && (!packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE) || Cfg.str("yt_auto_pip", "1") == "0")) {   // (v1344) الدوك الداخلي بقى بس لو الجهاز مابيدعمش PiP أو المستخدم قافل «يكمّل في نافذة صغيرة»
                if (!ytTryDock(true)) try { player.pause() } catch (_: Throwable) {}
                return
            }
            enterPip(false)
        }
    }
    fun doExport() { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/x-subrip"; putExtra(Intent.EXTRA_TITLE, "subtitles.srt") }, 7) }
    fun doImport() { startActivityForResult(filePicker("*/*", "اختار ملف SRT", false), 9) }
    fun doOpen() { startActivityForResult(filePicker("video/*", "اختار فيديو", true), 8) }
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); if (gone) return; if (!pipNow()) applyFull(wantFull()); if (remote) { rmFrameForce = true; try { h.postDelayed({ redrawLastRemoteFrame() }, 250L) } catch (_: Throwable) {} } }
    override fun onPictureInPictureModeChanged(inPipNow: Boolean, c: Configuration) {
        super.onPictureInPictureModeChanged(inPipNow, c)
        if (gone) return
        inPip = inPipNow
        if (inPipNow) try { ytDragReset() } catch (_: Throwable) {}   // (v1161)
        if (inPipNow) { try {
            closeSide(); dismissPopFn()
            h.removeCallbacks(hideChrome); chromeShown = false
            extras.visibility = View.GONE; st.visibility = View.GONE; floatBar.visibility = View.GONE; rotBtn.visibility = View.GONE; batchBtn.visibility = View.GONE; trChipV?.visibility = View.GONE; closeBatchPanel(); closeMiniLog(); probDrawer.visibility = View.GONE; logDrawer.visibility = View.GONE; logHandle.visibility = View.GONE
            fsOnly.forEach { it.visibility = View.GONE }; centerPlay.visibility = View.GONE
            visOv.showBoxes(emptyList())
            val lp = videoBoxRef.layoutParams as LinearLayout.LayoutParams; lp.height = -1; lp.setMargins(0, 0, 0, 0); videoBoxRef.layoutParams = lp; fsBtnV.visibility = View.GONE
            videoBoxRef.findViewWithTag<View>("chromeFrame")?.visibility = View.GONE
            sub.suppressed = true; applyCard()
            applyFit(svRef, videoBoxRef)
            // الترجمة في شريط صغير فوق الشاشة (تحت الستاتس بار) بدل جوه الفيديو
            if (canOverlay()) { pipOv = PipSubBar(this, { pipRect() }, listOf<Pair<String, () -> Unit>>("🌙 ترجم في الخلفية" to { translateInBackground(false, "شريط الـ PiP (زرار 🌙)") }, "🔊 صوت بس" to { audioOnly() }, "⏹ إيقاف نهائي" to { fullStop() })).also { it.show() } }
            curIdx = -2
        } catch (e: Exception) { LogStore.err("Main:2266", e) } }
        else {
            pipOv?.hide(); pipOv = null
            sub.suppressed = false; curIdx = -2; applyCard()
            applyFull(wantFull())
            // لو الخروج من PiP كان بالـ ✕ (الأكتيفيتي مش ظاهرة) نقفل الفيديو ونخرج؛ لو كان توسيع، onResume بيلغي الفحص
            h.removeCallbacks(pipExitCheck); h.postDelayed(pipExitCheck, 1000)   // (v1364) مهلة أوسع + شرط stoppedNow
        }
    }

    private var lastFitTag = ""
    private fun applyFit(sv: SurfaceView, box: View) {
        if ((vidW == 0 || vidH == 0) && ::player.isInitialized) { val vs = player.videoSize(); if (vs.first > 0 && vs.second > 0) { vidW = vs.first; vidH = vs.second } }
        if (vidW == 0 || box.width == 0) return
        val mode = if (pipNow()) 0 else curFit()
        // (v469) وضع 100%: مقاس الفيديو الطبيعي 1:1 × عامل الزوم (القرص) — ممكن يعدّي الحاوية وبيتوسّط (FrameLayout بيقصّ الزيادة)
        val r90 = rotDeg % 180 != 0   // (v604) لفّ 90/270: المقاس المرئي بعد اللف هو اللي بيتظبط على الصندوق
        val (w, hh) = if (mode == 3) Pair((vidW * vidZoomF).toInt().coerceAtLeast(1), (vidH * vidZoomF).toInt().coerceAtLeast(1))
                      else { val (fa, fb2) = PlayerLogic.fitSize(box.width, box.height, if (r90) vidH else vidW, if (r90) vidW else vidH, mode); if (r90) Pair(fb2, fa) else Pair(fa, fb2) }
        try { sv.rotation = rotDeg.toFloat() } catch (_: Throwable) {}
        val lp = FrameLayout.LayoutParams(w, hh, Gravity.CENTER)
        sv.layoutParams = lp; sv.requestLayout(); box.requestLayout()
        val tag = "$mode:${box.width}x${box.height}:${vidW}x$vidH:$vidZoomF:$rotDeg"
        if (tag != lastFitTag) { lastFitTag = tag; LogStore.add("⬛ احتواء/تمديد: وضع=${fitNameOf(mode)} الحاوية=${box.width}x${box.height} الفيديو=${vidW}x$vidH ← السطح=${w}x$hh") }
    }

    private fun videoId(): String {
        val u = uri
        if (u != null) {
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                    if (c.moveToFirst()) return "f:" + c.getString(0) + ":" + c.getLong(1)
                }
            } catch (e: Exception) { LogStore.err("Main:2289", e) }
            // (v310) ملف مفتوح من الفايل مانجر (file://): نفس صيغة الهوية بتاعة المكتبة (الاسم:الحجم) فالتقدم والترجمة يتشاركوا
            if (u.scheme == "file") { try { val ff = java.io.File(u.path ?: ""); if (ff.isFile) return "f:" + ff.name + ":" + ff.length() } catch (e: Exception) { LogStore.err("Player:fileId", e) } }
            return "f:$u"
        }
        intent.getStringExtra("ytid")?.takeIf { it.length == 11 }?.let { return "yt:$it" }   // (v117) يوتيوب: التقدم والترجمة على معرّف الفيديو مش على لينك الستريم المتغيّر
        val ref0 = intent.getStringExtra("ref") ?: ""; val title0 = intent.getStringExtra("title") ?: ""
        // (v203) رجعنا من «إصلاح اللينك» في المتصفح: نفس هوية الفيديو القديم (الترجمة والتقدم والإعدادات) على اللينك الجديد
        intent.getStringExtra("forceid")?.takeIf { it.isNotEmpty() }?.let { fid -> if (!incognito) WebIdent.bindLink(fid, url ?: "", ref0, title0); return fid }
        val legacy = webId(url ?: "", ref0, title0)
        if (incognito) return legacy
        // (v142) نفس الفيديو بجودة تانية أو اتصاد تاني بلينك جديد = نفس الهوية القديمة (الترجمة والتقدم بيفضلوا)
        val hit = WebIdent.resolve(legacy, url ?: "", ref0, title0)
        idVia = if (hit.id != legacy) hit.via else null
        return hit.id
    }
    private var idVia: String? = null
    private var durChecked = false
    /** حماية من دمج غلط: لو الهوية جت من تطابق صفحة/عنوان والمدة مختلفة كتير عن اللي اتسجّل، اسأل المستخدم */
    private fun checkIdentityDuration() {
        val via = idVia ?: return
        if (durChecked || durMs <= 0) return
        durChecked = true
        val id = vid; val d = durMs / 1000.0
        Thread {
            val old = try { Recents.parse(File(filesDir, "recent.json").readText()).firstOrNull { it.id == id }?.durSec ?: 0.0 } catch (_: Exception) { 0.0 }
            if (old > 30 && Math.abs(old - d) > 5.0) runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                Notice.ask(this, "⚠ مدة الفيديو (" + PlayerLogic.clock((d * 1000).toLong()) + ") مختلفة عن الفيديو المحفوظ بنفس الاسم (" + PlayerLogic.clock((old * 1000).toLong()) + ") — ممكن يكون فيديو تاني؟", "افصله", "هو نفسه", 12000L,
                    { WebIdent.blockKey(via); startActivity(Intent(this, javaClass).pipTask(this).apply { putExtras(intent) }); finish() }, { })
            }
        }.apply { isDaemon = true }.start()
    }
    /** (v138) هوية فيديو النت: الاسم في اللينك لوحده ما بيكفيش — لينكات زي /videoplayback أو master.m3u8 أو video.mp4 بتتكرر لفيديوهات مختلفة،
     *  فكانت ترجمة فيديو بتتحمّل على فيديو تاني. اللينك العادي (اسم ملف مميّز) بيفضل بنفس الهوية القديمة عشان التقدم المحفوظ ما يضيعش. */
    private fun webId(u: String, ref: String, title: String): String {
        val noFrag = u.substringBefore('#')
        val base = noFrag.substringBefore('?')
        val q = noFrag.substringAfter('?', "")
        fun qp(k: String): String? = q.split('&').firstNotNullOfOrNull { kv -> if (kv.substringBefore('=').equals(k, true)) kv.substringAfter('=', "").takeIf { it.isNotBlank() } else null }
        val file = base.substringAfterLast('/').lowercase()
        val generic = u.contains("videoplayback") || file.isBlank() ||
            Regex("(master|index|playlist|chunklist|manifest|stream|video|play|media|file|main|source|hls|dash)(\\.(m3u8|mpd|mp4|webm|ts|php|m4v))?").matches(file)
        val stable = listOf("id", "docid", "vid", "video", "video_id", "videoid", "v", "fid", "file", "name", "mid").firstNotNullOfOrNull { k -> qp(k)?.let { "$k=$it" } }
        if (!generic) return "u:$base"
        if (stable != null) return "u:" + (if (u.contains("videoplayback")) "gv" else base) + "?" + stable
        val page = ref.substringBefore('#').substringBefore('?').trim()
        val extra = listOf(title.trim(), if (page.length > 12 && page.substringAfter("://").contains('/')) page else "").filter { it.isNotBlank() }.joinToString("|")
        return if (extra.isNotBlank()) "u:$base|$extra" else "u:$base?" + Integer.toHexString(q.hashCode())
    }

    private fun makeSource(sp: SrcSpec): AudioSource {
        val lg: (String) -> Unit = { if (spec === sp) log(it) }
        val src = AudioSources.make(applicationContext, sp.uri, sp.url, sp.hdr, conf.audioTrack, lg)   // يوتيوب بصوت منفصل: sp.url فيه رابط الصوت
        lg("🎙 مصدر الصوت: " + (if (sp.uri != null) "ملف محلي" else if (src is HlsSource) "رابط HLS" else "رابط مباشر"))
        return src
    }

    fun fmtMs(ms: Long) = String.format("%02d:%02d:%02d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60)

    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 8 && c == RESULT_OK) d?.data?.let { u ->
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { LogStore.err("Main:2308", e) }
            swapVideo(u)
        }
        if (r == 9 && c == RESULT_OK) d?.data?.let { u ->
            sfRun("soft", autoEng(), u, -1, true)   // (v667) أول ما تستورد ملف ترجمة (SRT/ASS/VTT) بيترجمه فورًا ويشغّله مكان الأصلي
        }
        if (r == 41 && c == RESULT_OK) d?.data?.let { u -> sfRun("soft", sfPickEng, u, -1, true) }   // (v529) ملف ترجمة اخترته من الجهاز
        if (r == 32) {
            val t = pendingOrigSrt; pendingOrigSrt = null
            if (c == RESULT_OK && t != null) d?.data?.let { u ->
                try { contentResolver.openOutputStream(u)?.use { it.write(t.toByteArray(Charsets.UTF_8)) }; Notice.show(this, ("تم حفظ SRT بالنص الأصلي").toString(), 2300L) }
                catch (_: Exception) { Notice.show(this, ("تعذّر حفظ الملف").toString(), 2300L) }
            }
        }
        if (r == 31) {
            val t = pendingSentTxt; pendingSentTxt = null
            if (c == RESULT_OK && t != null) d?.data?.let { u ->
                try { contentResolver.openOutputStream(u)?.use { it.write(t.toByteArray(Charsets.UTF_8)) }; Notice.show(this, ("تم حفظ الجمل").toString(), 2300L) }
                catch (_: Exception) { Notice.show(this, ("تعذّر حفظ الملف").toString(), 2300L) }
            }
        }
        if (r == 7 && c == RESULT_OK) d?.data?.let { u ->
            contentResolver.openOutputStream(u)?.use { it.write(PlayerLogic.toSrt(engine.subs, offsetMs).toByteArray()) }
            Notice.show(this, ("تم حفظ SRT").toString(), 2300L)
        }
    }

    private fun saveRecent() { if (!handedOff && !remote && !panicShut) saveRecentForce() }
    /** (v586) يوتيوب: نفس مخزن تقدم المشغّل المصغّر (YtProg) — عشان الخروج من تكبير الشاشة وفتح الفيديو تاني يكمّل من نفس المكان */
    private fun saveYtProg() {
        try {
            if (incognito || remote || hiddenSite) return
            val yid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 } ?: return
            if (durMs <= 0 || cur < 1000L) return
            // (v892) YtProg اتمسح (v889) — مفيش مخزن تقدم يوتيوب منفصل؛ lastpos/recent.json بيغطّوا الاستكمال
        } catch (_: Throwable) {}
    }
    private fun saveRecentForce() {
        if (incognito) return
        if (logArcPlay != null) return   // (v1167) عرض لوج محفوظ: ما نغيّرش آخر مكان وقوف ولا تقدّم الفيديو
        archiveNow()   // (v1167) سجل اللوجات: بيتحفظ مع كل حفظ لآخر المشغّلة (كل 20ث وقت التشغيل + الإيقاف + الخروج)
        saveYtProg()
        try { if (!hiddenSite && durMs > 0 && cur > 1000 && cur < durMs - 4000 && vid.isNotEmpty()) Cfg.p.edit().putString("lastpos", vid + "\t" + cur).apply() } catch (_: Throwable) {}
        try {
            if (!incognito && !hiddenSite && vid.isNotEmpty()) {
            val f = File(filesDir, "recent.json")
            // (v664) كان بيرجع هنا لو المحرك لسه مش جاهز (خروج سريع/فيديو من غير ترجمة) فالفيديو الجديد ما بيتسجّلش ويفضل الأول في «آخر المشغّلة». دلوقتي بيتسجّل دايمًا، وعدد الجمل/التغطية من المحرك لو جاهز وإلا من السجل القديم
            synchronized(Recents.ioLock) {
            val old = Recents.parse(try { f.readText() } catch (_: Exception) { "" })
            val prev = old.firstOrNull { it.id == vid }
            val ready = ::engine.isInitialized && engineReady
            val r = Recent(vid, (if (uri == null) intent.getStringExtra("title")?.takeIf { it.isNotBlank() } else null) ?: Recents.titleOf(vid), url ?: "", uri?.toString() ?: "", (if (finishedMark) 0.0 else cur / 1000.0), durMs / 1000.0, if (ready) engine.subs.size else (prev?.subs ?: 0), if (ready) engine.coveredSec() else (prev?.coverSec ?: 0.0), System.currentTimeMillis())
            f.writeText(Recents.toJson(Recents.upsert(old, r, 300)))
            }
            // (v570) لينك مش يوتيوب (جاي من المتصفح): نحفظ مصغّرة من الفيديو الشغّال مرة واحدة عشان تظهر في «آخر المشغّلة» (بس من خيط خلفي — PixelCopy)
            if ((uri != null || (!url.isNullOrEmpty() && intent.getStringExtra("ytid") == null)) && cur > 3000L && android.os.Looper.myLooper() != android.os.Looper.getMainLooper())   // (v690) الملفات المحلية كمان (ts / mkv اللي المكتبة مش بتطلّع لها صورة)
                LinkThumb.saveIfMissing(applicationContext, vid) {
                    val b = grabSurface(640)
                    if (b == null) null else {
                        var sum = 0L; var n = 0
                        val sx = maxOf(1, b.width / 16); val sy = maxOf(1, b.height / 16)
                        var yy = 0
                        while (yy < b.height) { var xx = 0; while (xx < b.width) { val c = b.getPixel(xx, yy); sum += (((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255)) / 3; n++; xx += sx }; yy += sy }
                        if (n > 0 && sum / n < 12) { b.recycle(); null } else b   // لقطة سودا: نجرّب في الحفظ الجاي
                    }
                }
            }
        } catch (e: Exception) { LogStore.err("Main:2341", e) }
    }
    /** أفقي: يرجع للرأسي من غير ما يقفل. رأسي: يحفظ التقدم ويوقف الفيديو ويقفل. */
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (gone) { super.onBackPressed(); return }
        if (ytPage && fullMode && !pipNow()) { exitPageFull(); return }
        if (remote) { leaveController(); return }   // (v568) شاشة التحكم: الخروج منها ما بيوقّفش الفيديو على التلفزيون
        if (DeviceUi.isRemote(this) && miniLog != null) { closeMiniLog(); return }   // (v509) ✕ الصغيرة في لوج الجمل: Back يقفلها
        if (tvBar?.visible == true) { tvBar?.hide(); return }   // (v477 م4) تلفزيون: Back بيقفل شريط التحكم الأول
        if (nextPanel?.consumeBack() == true) return   // (v378)
        if (sideOpen) { closeSide(); return }
        // (v110) علامة ✔ فوق: لو الترجمة لسه ما خلصتش، كمّلها في الخلفية أول ما أخرج
        // (v232) مفيش ترجمة في الخلفية من غير موافقتك: لو الترجمة لسه ما خلصتش بنسألك، و«لا» = بتتقفل خالص ومفيش أي استهلاك نت
        val unfinished = !incognito && !handedOff && engineStarted && durMs > 0 && PlayerLogic.percent(engine.coveredSec(), durMs / 1000.0) < 99
        val hasKey = Cfg.allMainKeys().isNotEmpty() || conf.keys.isNotEmpty() || conf.backup.isNotEmpty()
        if (unfinished && hasKey && Cfg.bool("ask_bg_exit", true)) { askBgOnExit(); return }
        if (ytPage && ytTryDock()) return   // (v1356) Back من صفحة المشاهدة = تصغير للدوك العايم زي يوتيوب مش قفل الفيديو (بطلب علي) — لو الدوك مش متاح يكمّل للقفل العادي
        closeNoBg()
    }
    private fun netDialog() {
        shConfirm("📶 استهلاك النت", NetUse.sessionReport(), listOf(ShBtn("تمام", SH_BLUE) { }))
    }
    private var exitAsk: android.app.Dialog? = null
    private fun askBgOnExit() {
        if (exitAsk?.isShowing == true) return
        exitAsk = shConfirm("🌙 الترجمة لسه ما خلصتش", "أكمّل الترجمة في الخلفية؟ (هيستهلك نت)\nلو اخترت «لا» الترجمة بتتقفل خالص ومفيش نت بيتصرف.",
            listOf(ShBtn("🌙 أيوه، كمّل في الخلفية", SH_BLUE) { translateInBackground(false, "خروج (اخترت: كمّل في الخلفية)") },
                ShBtn("⛔ لا، قفّل خالص", SH_RED) { closeNoBg() },
                ShBtn("رجوع للفيديو", SH_GRAY) { }))
    }
    /** خروج من غير ترجمة خلفية: بيحفظ التقدم، يوقف المحرك وأي مهمة خلفية لنفس الفيديو، ويقفل */
    /** (v340) لوحة «التالي»: دوسة على فيديو = يفتح في مشغّل جديد (القديم بيتقفل ويحفظ تقدمه) وبيكمّل نفس وضع الترجمة */
    fun openNextSheet() {
        val cid = intent.getStringExtra("ytid") ?: return
        YtNext.show(this, ui, th, cid) { n -> playNextYt(n) }
    }
    private fun playNextYt(n: NpItem) {
        if (remote) { Notice.show(this, "📺 الفيديو اللي بعده بيتحدد من التلفزيون", 2200L); return }
        cancelNextUp()   // (v531) اخترت فيديو من اللوحة أثناء العدّاد
        say("⏳ بجيب «" + n.title.take(40) + "»…")
        val ret = intent.getStringExtra("ret") ?: ""; val nosub = intent.getBooleanExtra("nosub", false); val auto = intent.getBooleanExtra("autotr", false)
        Thread {
            val got = try { MtYt.video(n.id, Cfg.int("yt_maxh", 0)) } catch (_: Throwable) { null }   // (v362)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                val url = got?.url
                if (url == null || got == null) { say("ما قدرتش أجيب الفيديو ده — جرّب غيره"); return@runOnUiThread }
                startActivity(Intent(this, javaClass).pipTask(this).apply {
                    putExtra("url", url); putExtra("aurl", got.audio ?: ""); putExtra("ref", "https://www.youtube.com/"); putExtra("ua", got.ua)
                    got.qlist.takeIf { it.isNotEmpty() }?.let { putExtra("qlist", it) }
                    putExtra("title", n.title.ifBlank { got.title }); putExtra("ytid", n.id)
                    putExtra("nosub", nosub); putExtra("autotr", auto); putExtra("ret", ret)
                })
            }
        }.apply { isDaemon = true }.start()
    }
    @Suppress("DEPRECATION")
    /** (v343) 🎧 حوّل لصوت: بنقفل الفيديو (بيحفظ مكانه) ونفتح نفس الفيديو في مشغّل الموسيقى من نفس المكان */
    fun switchToAudio() {
        val id = intent.getStringExtra("ytid") ?: return
        audioHandoff = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("ytaudio", id).putExtra("ytaudtitle", intent.getStringExtra("title") ?: "").putExtra("ytaudpos", cur)
        // (v351) رابط الصوت اللي بيشتغل دلوقتي (لو صوت منفصل) بيتبعت جاهز: التحويل فوري من غير ما نجيب الفيديو من الصفر
        try {
            val au = (qOpts.getOrNull(qCur)?.audio ?: aurl)?.takeIf { it.startsWith("http") }
            if (au != null) audioHandoff?.putExtra("ytaudurl", au)?.putExtra("ytaudua", hdr["User-Agent"] ?: "")?.putExtra("ytauddur", durMs)
        } catch (e: Throwable) { LogStore.err("Player:audHandoff", e) }
        closeNoBg()
    }
    /** (v568) خروج من شاشة التحكم من غير أي أمر للتلفزيون: الفيديو يكمّل شغّال، وتقدر ترجع له من كبسولة «▶ اسم ✕» */
    private fun leaveController() {
        rmFrames = false
        try { returnToOrigin() } catch (_: Throwable) {}
        super.onBackPressed()
    }
    private fun closeNoBg() {
        if (remote) { leaveController(); return }
        try { player.pause() } catch (e: Exception) { LogStore.err("Main:2347", e) }
        saveRecent()
        val eng = engine; val v = vid
        try { retireEngine() } catch (e: Throwable) { LogStore.err("Player:closeNoBg1", e) }
        Thread {
            try { eng.awaitStopped(3000); eng.saveNow() } catch (e: Throwable) { LogStore.err("Player:closeNoBg0", e) }   // (v287)
            try { if (BgJobs.isActive(v)) BgJobs.stop(v) } catch (e: Throwable) { LogStore.err("Player:closeNoBg2", e) }
        }.start()
        exitRotateThen { returnToOrigin(); super.onBackPressed() }   // (v1125)
    }
    /** (v339) الرجوع من الفيديو يرجّعك للصفحة اللي فتحته منها (يوتيوب / المتصفح) بنفس مكانك — حتى لو النظام كان قفل الصفحة دي وإحنا في المشغّل */
    private fun returnToOrigin() {
        audioHandoff?.let { h -> audioHandoff = null; try { startActivity(h) } catch (e: Throwable) { LogStore.err("Player:audioHandoff", e) }; return }   // (v343)
        try {
            when (intent.getStringExtra("ret")) {
                "yt" -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("tab", "youtube"))
                "browser" -> startActivity(Intent(this, BrowserActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                // (v570) فيديو اتفتح على التلفزيون من الموبايل/صف يوتيوب: الخروج يرجّعك للصفحة اللي كنت فيها (اللي تحت المشغّل)؛ ولو مفيش حاجة تحته (التطبيق ماكانش شغّال) للرئيسية
                TvDirect.RET -> if (isTaskRoot) startActivity(Intent(this, TvActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
            }
        } catch (e: Throwable) { LogStore.err("Player:ret", e) }
    }
    // ===== أدوات الـ HTML اللي كانت ناقصة في النسخة النيتف =====
    // ===== لودينج ويندوز: بدل زرار ⏸/▶ اللي في النص أثناء التحميل (فيديو أونلاين / تنقّل / سيك) =====
    @Volatile private var buffering = false
    private val spinners = HashMap<View, WinSpinnerDrawable>()
    /** (v576) المصدر شبكة (يوتيوب/لينك/فيديو من الموبايل متبعوت للتلفزيون) ولا ملف محلي على الجهاز */
    private fun tvSrcIsNet(): Boolean {
        if (intent.getStringExtra("ytid") != null) return true
        val sc = try { player.exo()?.currentMediaItem?.localConfiguration?.uri?.scheme } catch (_: Throwable) { null }
        if (sc != null) return sc.startsWith("http")
        return url != null || uri?.scheme?.startsWith("http") == true
    }
    fun setBuffering(b0: Boolean) {
        val b = b0 && !(DeviceUi.isTv(this) && !tvSrcIsNet())   // (v576) تلفزيون + فيديو محلي: مفيش سبينر ولا مربع (القفز سريع)
        if (b == buffering && (b || spinners.isEmpty())) return
        buffering = b
        // (v925) اللودينج في نص الشاشة بس (centerPlay) — أزرار التشغيل اللي في الشريط فضلت بشكلها العادي
        for (v in listOfNotNull<TextView>(if (::fsPlayB.isInitialized) fsPlayB else null, if (::ctl.isInitialized) ctl.play else null)) {
            spinners.remove(v)?.stop(); v.foreground = null
            v.text = if (player.isPlaying) "⏸" else "▶"
        }
        if (::centerPlay.isInitialized) {
            val v = centerPlay
            if (b && !busyShown()) {
                val sp = spinners.getOrPut(v) { WinSpinnerDrawable() }
                v.text = ""; v.foreground = sp; sp.start()
            } else if (!b) {
                spinners.remove(v)?.stop(); v.foreground = null
                v.text = if (player.isPlaying) "⏸" else "▶"
            }
        }
        applyChromeFn()
    }
    private fun paintNotices() {
        if (!::noticeBtn.isInitialized) return
        val n = NoticeLog.list().size
        noticeBtn.visibility = View.VISIBLE   // (v221) ظاهر دايمًا عشان تلاقيه — خافت لو مفيش إشعارات
        noticeBtn.alpha = if (n == 0) 0.35f else 0.7f
        noticeBtn.text = if (n == 0) "▲" else "▲ $n"
    }

    private var noticePop: android.widget.PopupWindow? = null
    /** (v236) قايمة إشعارات صغيرة شفافة بتفتح لفوق (زي قوايم المشغّل): الإشعارات بس من الأحدث للأقدم، ضغطة طويلة = مسح الكل */
    private fun noticePopup(anchor: View) {
        if (RcCapture.active) {   // (v1051) 🔔 على الموبايل
            val l = NoticeLog.list().map { it.msg to { } }
            rcPmList("🔔 الإشعارات", if (l.isEmpty()) listOf("مفيش إشعارات" to { }) else l)
            return
        }
        noticePop?.let { if (it.isShowing) { it.dismiss(); noticePop = null; return } }
        val dm = resources.displayMetrics
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(2)); background = ui.box(0x99141418.toInt(), 0x22FFFFFF, 12)
        }
        val items = NoticeLog.list()
        for (it in items) col.addView(ui.text(it.msg, 11.5f, 0xFFF1F3F4.toInt()).apply { setPadding(0, 0, 0, ui.dp(6)) }, LinearLayout.LayoutParams(-1, -2))
        if (items.isEmpty()) col.addView(ui.text("مفيش إشعارات", 11.5f, 0xFFC9CED6.toInt()).apply { setPadding(0, 0, 0, ui.dp(6)) })
        val popW = minOf(dm.widthPixels - ui.dp(24), ui.dp(240))
        col.measure(View.MeasureSpec.makeMeasureSpec(popW, View.MeasureSpec.EXACTLY), View.MeasureSpec.UNSPECIFIED)
        val loc = IntArray(2); anchor.getLocationOnScreen(loc)
        val avail = (loc[1] - ui.dp(12)).coerceAtLeast(ui.dp(80))
        val popH = minOf(col.measuredHeight, avail, (dm.heightPixels * 0.4f).toInt())
        val scroll = android.widget.ScrollView(this).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(col) }
        val pw = TvFocus.pop(this@PlayerActivity, scroll, popW, popH, true)
        Motion.popIn(scroll, false)   // (v445)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(0)); pw.isOutsideTouchable = true
        col.setOnLongClickListener { NoticeLog.clear(); pw.dismiss(); true }
        pw.setOnDismissListener { if (noticePop === pw) noticePop = null }
        try { pw.showAsDropDown(anchor, 0, -(anchor.height + popH + ui.dp(2)), Gravity.END) } catch (e: Throwable) { LogStore.err("Player:noticePopup", e) }
        noticePop = pw
    }

    /** (v1013) نقل MtSmooth (مطابقة معدل الشاشة مع فريمات الفيديو + تنبيه الديكودر) و MtEnhance (✨ تحسين الصورة) لمشغّل Joyboy القديم.
     *  نفس الـExoPlayer الشغّال (من غير محرك تاني)؛ لو المشغّل ريموت/كاست (exo()==null) بيتخطّى. الافتراضي المحفوظ (إيقاف) مابيغيّرش حاجة. لم يتم compile. */
    private var mtParityExo: androidx.media3.exoplayer.ExoPlayer? = null
    private fun mtParityAttach() {
        try {
            if (remote || !::player.isInitialized) return
            val ex = player.exo() ?: return
            if (mtParityExo === ex) return
            mtParityExo = ex
            try { MtSmooth.attach(this, ex, null) } catch (_: Throwable) {}
        } catch (_: Throwable) {}
    }
    private fun mtParityDetach() {
        try { MtSmooth.detach(this) } catch (_: Throwable) {}
        try { MtEnhance.detach(this) } catch (_: Throwable) {}
        mtParityExo = null
    }

    private fun say(m: String) = runOnUiThread { Notice.show(this, (m).toString(), 2300L) }

    // (v1358) الدبلجة اتشالت بالكامل من التطبيق (بطلب علي) — المحرك Dub.kt متساب من غير أي استدعاء

    private fun morphText(v: TextView, t: String) {
        if (v.text.toString() == t) return
        if (!Design.isNew() || !v.isShown) { v.text = t; return }
        if (ytPage) { v.animate().cancel(); v.text = t; return }   // (v1347) يوتيوب: تغيير النص فوري (بطلب علي)
        v.animate().cancel()
        v.animate().scaleX(0.55f).scaleY(0.55f).rotation(-25f).setDuration(90L).withEndAction {
            v.text = t; v.rotation = 25f
            v.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(190L).setInterpolator(android.view.animation.OvershootInterpolator(1.6f)).start()
        }.start()
    }
    private fun fsPlayDp(): Int = if (Design.isNew()) 64 else 56
    private fun auroraPill(rDp: Int): GradientDrawable {
        if (ui.th.isLight && !Design.isMaterial()) return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCCEF5350.toInt(), 0xCCC62828.toInt())).apply { cornerRadius = ui.dp(rDp).toFloat(); setStroke(maxOf(1, ui.dp(1)), 0x66FFFFFF) }   // (v1247) الفاتح: زجاجي بالأحمر القديم بدل النعناعي
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Design.mint(0xFF), Design.violet(0xFF))).apply { cornerRadius = ui.dp(rDp).toFloat() }
    }
    private fun trComplete(): Boolean = try { trPct >= 100 || (::realEngine.isInitialized && realEngine.fullyDone()) } catch (_: Throwable) { false }

    private fun touchSubs() = runOnUiThread { curIdx = -2; dirty = true }

    fun runTool(label: String, instruction: String, all: Boolean) {
        if (Cfg.allMainKeys().isEmpty() && conf.keys.isEmpty()) { say("ضيف مفتاح API الأول"); return }
        say("بدأ: $label…")
        engine.rewriteAll(label, instruction, if (all) 0.0 else player.currentPosition / 1000.0, { _ -> }) { n ->
            say(if (n > 0) "✅ $label: اتغيّرت $n جملة (تقدر ترجع من 🗂 ترجمات الفيديو)" else "$label: مفيش جمل اتغيّرت"); touchSubs()
        }
    }
    var giShowFn: (String) -> Unit = {}

    private var pendingOrigSrt: String? = null
    /** (v153) تحميل SRT بالنص الأصلي المستخرج (من الإعدادات) — بيفتح اختيار مكان الحفظ */
    /** (v1165) ينزّل الصوت مقسّم لنفس الباتشات ومترقّم (Download/Joyboy_Batches/<الفيديو>) عشان يتبعت للمراجعة */
    fun exportBatches() {
        if (!::engine.isInitialized) { say("المحرك لسه ما اشتغلش — شغّل الترجمة أو افتح الفيديو الأول"); return }
        val t = try { Recents.titleOf(vid).substringBeforeLast('.', Recents.titleOf(vid)) } catch (_: Throwable) { "video" }
        val le = (engine as? LocalEngine)?.e
        if (le == null) { say("تنزيل الباتشات متاح لما الترجمة تشتغل على الجهاز ده نفسه"); return }
        BatchExport.run(this, le, t)
    }

    /** (v1361 — بطلب علي) باتش الصوت محلي: فصل صوت الفيديو الحالي + برومبت ترجمة على الموبايل (بدل رفع الريبو v1202)، ويتابع من مركز التحميل */
    fun ghUpload() {
        val u = uri; val su = aurl ?: url
        if (u == null && su == null) { say("افتح الفيديو الأول"); return }
        val t = try { Recents.titleOf(vid).substringBeforeLast('.', Recents.titleOf(vid)) } catch (_: Throwable) { "video" }
        GhAudio.start(this, u, su, HashMap(hdr), t, durMs)
    }

    /** (v1195) ZIP «اللوج + الترجمة»: اللوج كامل + الأصل لوحده + الترجمة الناتجة لوحدها (Download/Joyboy_Logs) */
    fun exportLogZip() {
        if (!::engine.isInitialized) { say("المحرك لسه ما اشتغلش — افتح الفيديو الأول"); return }
        val t = try { Recents.titleOf(vid).substringBeforeLast('.', Recents.titleOf(vid)) } catch (_: Throwable) { "video" }
        val snap: List<Sub> = try { ArrayList(engine.subs) } catch (_: Throwable) { ArrayList() }
        val runLog = try { arcRun?.let { r -> synchronized(r.log) { r.log.toString() } } ?: "" } catch (_: Throwable) { "" }
        LogZip.run(this, t, snap, offsetMs, (engine as? LocalEngine)?.e, runLog)
    }

    /** (v1238) صوت الفيديو كله ملف واحد ← نافذة المشاركة */
    private var fullAudioBusy = false
    fun shareFullAudio() {
        if (fullAudioBusy) { say("⏳ لسه بطلّع الصوت…"); return }
        val u = uri; val su = aurl ?: url
        if (u == null && su == null) { say("افتح الفيديو الأول"); return }
        val t = try { Recents.titleOf(vid).substringBeforeLast('.', Recents.titleOf(vid)) } catch (_: Throwable) { "video" }
        val hd = HashMap(hdr)
        fullAudioBusy = true; say("🎧 بطلّع صوت الفيديو كله في ملف واحد…")
        Thread {
            try {
                var lastP = -10
                val f = FullAudio.extract(applicationContext, u, su, hd, t) { p -> if (p >= lastP + 20) { lastP = p; runOnUiThread { say("🎧 تجهيز الصوت " + p + "%") } } }
                LogStore.add("🎧 صوت كامل: " + f.name + " · " + (f.length() / 1024) + "KB")
                runOnUiThread { fullAudioBusy = false; if (!isDestroyed) { say("✅ الصوت جاهز (" + (f.length() / 1048576L) + "MB) — اختار واتساب"); try { FullAudio.share(this, f) } catch (e: Throwable) { say("تعذّر فتح المشاركة") } } }
            } catch (e: Throwable) {
                LogStore.add("🎧 صوت كامل فشل: " + (e.message ?: e.javaClass.simpleName))
                runOnUiThread { fullAudioBusy = false; say("❌ " + (e.message ?: "فشل استخراج الصوت").take(120)) }
            }
        }.apply { isDaemon = true }.start()
    }

    fun exportOriginalSrt() {
        val txt = PlayerLogic.toSrtOriginal(engine.subs, offsetMs)
        if (txt.isBlank()) { say("مفيش نص أصلي لسه"); return }
        val base = try { Recents.titleOf(vid).substringBeforeLast('.', Recents.titleOf(vid)) } catch (_: Throwable) { "video" }
        val safe = base.replace(Regex("[\\\\/:*?\"<>|]+"), " ").trim().ifEmpty { "video" }
        pendingOrigSrt = txt
        try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "application/x-subrip"; putExtra(Intent.EXTRA_TITLE, "$safe.orig.srt") }, 32) }
        catch (_: Exception) { pendingOrigSrt = null; say("تعذّر فتح اختيار مكان الحفظ") }
    }


    private val aiSel = linkedSetOf<String>()
    /** (v1140) «لهجة +»: لو الترجمة فصحى بترفع قوة الفصحى نفسها (من غير أي لهجة)، ولو لهجة معيّنة بترفع شدة اللهجة دي بس */
    private val DIAL_INSTR: String get() {
        val eff = Cfg.str("conv_dialect", "").ifBlank { Cfg.str("lang", "فصحى") }.ifBlank { "فصحى" }.trim()
        return if (eff == "فصحى")
            "ارفع قوة وجودة الفصحى في كل جملة درجة واحدة: فصحى معاصرة سليمة وبليغة وطبيعية بدل الركاكة أو الحرفية، ومن غير أي ألفاظ عامية أو لهجة دارجة (لا مصرية ولا غيرها) — ممنوع تدخّل أي لهجة. من غير ما تغيّر المعنى أو الجنس."
        else
            "زوّد شدة اللهجة الشعبية ($eff) في كل جملة درجة واحدة: ألفاظ وتعبيرات الشارع والعامية المحلية ($eff) بدل الفصحى والكلام الرسمي، ومن غير ما تدخّل أي لهجة تانية. من غير ما تغيّر المعنى أو الجنس."
    }
    private val FAMILY_INSTR = "نضّف الجملة من الألفاظ الخارجة والإيحاءات الجنسية وخليها عائلية ومناسبة لكل الأعمار مع الحفاظ على المعنى العام."

    /** (v151) بينفّذ كل الخيارات المحددة في قايمة ✨ بالترتيب بدوسة واحدة، وكل خطوة بتستنى اللي قبلها */
    fun applyAiOptions(sel: Collection<String> = aiSel) {
        if (sel.isEmpty()) { say("اختار خيار واحد على الأقل من القايمة"); return }
        // (v360) من غير مفتاح جيميناي، المهام الجانبية بتكمّل بمحرك LLM المختار (conv_via) — نفس شرط Engine.bgCall
        val llmOk = ExtLlm.byId(Cfg.str("conv_via", "").trim())?.let { ExtLlm.configured(it) && ExtLlm.enabled(it) && ExtLlm.blockedWhy(it) == null } == true
        if (Cfg.allMainKeys().isEmpty() && conf.keys.isEmpty() && !llmOk) { say("ضيف مفتاح API (أو اختار محرك LLM للمهام الجانبية) الأول"); return }
        val order = listOf("refine", "dial", "family", "pron", "dedup").filter { it in sel }
        val results = ArrayList<String>()
        var stopped = false
        fun rep(m: String) { if (m.startsWith("في عملية شغالة")) { stopped = true; say(m) } else say(m) }
        fun step(k: Int) {
            if (stopped) return
            if (k >= order.size) { say("✅ خلصت: " + results.joinToString(" · ") + " (تقدر ترجع من 🗂 ترجمات الفيديو)"); touchSubs(); return }
            fun fin(label: String, n: Int) { results.add("$label $n"); touchSubs(); step(k + 1) }
            when (order[k]) {
                "refine" -> { say("✍ (${k + 1}/${order.size}) تنقيح بالسياق…"); engine.refineWholeNow({ m -> rep(m) }) { n -> fin("تنقيح", n) } }
                "dial" -> { say("🔥 (${k + 1}/${order.size}) لهجة +…"); engine.rewriteAll("زيادة شدة اللهجة", DIAL_INSTR, 0.0, { m -> rep(m) }) { n -> fin("لهجة", n) } }
                "family" -> { say("🧹 (${k + 1}/${order.size}) عائلي…"); engine.rewriteAll("عائلي", FAMILY_INSTR, 0.0, { m -> rep(m) }) { n -> fin("عائلي", n) } }
                "pron" -> { say("🔧 (${k + 1}/${order.size}) ضمائر…"); engine.correctPronounsNow({ m -> rep(m) }) { n -> fin("ضمائر", n) } }
                else -> { val n = engine.removeDuplicates(); fin("دمج مكرر", n) }
            }
        }
        step(0)
    }



    private var langPop: android.widget.PopupWindow? = null
    /** 🌐 لغة الترجمة: قايمة صغيرة تحت الزرار بنفس شكل قوايم الشريط. فصحى = ترجمة حرفية بس، غير كده = حرفية + تحويل تلقائي كل ~3 باتشات */
    // ===== (v218) وضع المفاتيح: الأوضاع التلاتة + قايمة الاختيار جنب زرار الترجمة =====
    private val kmLabels = ArrayList<Pair<TextView, (Int) -> String>>()
    private var kmPop: android.widget.PopupWindow? = null

    fun applyKeyMode(n0: Int) {
        val n = KeyMode.SPLIT_A   // (v425) ثابت
        Cfg.put("kmode", n.toString())
        try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:kmode", e) }
        for ((v, f) in kmLabels) v.text = f(n)
        LogStore.add("🔑 وضع المفاتيح اتغيّر لـ " + KeyMode.name(n))
    }


    /**
     * (v408) 📴 ترجمة أوفلاين — زرار واحد: لو مفيش موديل Whisper نازل بينزّل small (~185 ميجا)، وموديل ML Kit بيتنزّل لوحده، وبعدين يبدأ
     * تفريغ Whisper على الجهاز + ترجمة ML Kit (فصحى؛ اللهجة بتتحوّل زي إعدادك). اللغة: إعداد التفريغ أو الإنجليزي لو تلقائي. الخطة بتتحفظ (وإلا الاستئناف كان هيرجّع القديمة).
     */
    private var offBusy = false
    fun offlineQuick(only: Boolean = false, free: Boolean = false) {
        if (offBusy) return
        if (!free) { Cfg.put("tr_kind", if (only) "transcribe" else "translate"); Cfg.put("tr_engine", "off") }   // (v1098) T3
        if (!WhisperLib.loaded) { say("📴 الأوفلاين مش مدعوم على جهازك"); return }
        if (Offline.downloading()) { say("⬇ فيه تنزيل موديل شغّال — استنى يخلص وادوس تاني"); return }
        if (!Offload.wanted() && Offline.models.none { try { Offline.downloaded(it) } catch (_: Throwable) { false } }) { whisperModelPick { h.post { beginTranslate() } }; return }   // (v1375 — بطلب علي) وشبر مختار ومفيش موديل متنزّل: نزّله الأول بدل التحويل الصامت لجيميناي
        offBusy = true
        val lang = Offline.lang()   // (v411) "" = تلقائي: Whisper بيكتشف اللغة، وموديل ML Kit بيتنزّل أول ما اللغة تتأكد (مع إشعار تقدم)
        val order = listOf(Offline.model()) + Offline.models.asReversed()   // (v1325) الاحتياطي من الأحدث للأقدم (كان base/small/medium بس — turbo مكانش في القايمة خالص)
        val m = order.firstOrNull { Offline.downloaded(it) } ?: Offline.models.first { it.id == "base" }
        fun startIt() {
            if (!only && !LocalMt.ready()) { offBusy = false; askMtModel(only, free, m); return }   // (v743) موديل الترجمة الأوفلاين لازم يكون نازل
            val pl = TrWizard.Plan("offline", "", lang, m.id, "google", "whisper", if (only) "" else "فصحى", false, free = "", only = only)   // (v743) وشبر + Hy-MT2 أوفلاين · (v427) only = تفريغ بس بوشبر
            Cfg.put("tr_mode_id", if (only) "w_only" else Strict.MT); SourceMode.set(SourceMode.AUDIO)
            try { TrWizard.save(pl) } catch (e: Throwable) { LogStore.err("Player:offQuickSave", e) }
            offBusy = false
            runPlan(pl)
        }
        fun stepMl() { startIt() }   // (v425) ML Kit اتشال
        fun go() {
            if (Offline.downloaded(m)) { stepMl(); return }
            say("⬇ بنحمّل موديل التفريغ " + m.label + " (~" + m.approxMb + " ميجا، مرة واحدة)…")
            Offline.download(m, { a, t -> runOnUiThread { Notice.show(this, "⬇ موديل التفريغ: " + (a / 1048576) + " / " + (t / 1048576) + " ميجا", 900L) } }) { e ->
                runOnUiThread { if (e != null) { offBusy = false; say("⚠ تنزيل موديل التفريغ فشل: $e") } else stepMl() }
            }
        }
        // (v413) لو في موديل مش نازل: شاشة صغيرة تسأل قبل التنزيل (بدل ما ينزّل لوحده)
        fun runIt() { Thread {
            val needMl = false   // (v425)
            runOnUiThread {
                val needW = !Offline.downloaded(m)
                if (!needW && !needMl) { go(); return@runOnUiThread }
                val what = ArrayList<String>()
                if (needW) what.add("• موديل التفريغ Whisper " + m.label + " (~" + m.approxMb + " ميجا)")
                if (needMl) what.add("• موديل ترجمة اللغة (ML Kit ~30 ميجا)")
                shConfirm("⬇ محتاج تنزيل مرة واحدة", what.joinToString("\n") + "\n\nمحتاج نت للتنزيل بس، وبعدها الأوفلاين بيشتغل من غير نت.",
                    listOf(ShBtn("⬇ نزّل وابدأ", SH_BLUE) { go() }, ShBtn("إلغاء", SH_GRAY) { offBusy = false }), { offBusy = false })
            }
        }.also { it.isDaemon = true }.start() }
        // (v739) موديل وشبر ضعيف للغة (tiny/base مع ياباني/كوري/صيني/عربي/تلقائي): اسأل قبل ما يبدأ — بدل ما يترجم كلام غلط ويسكت
        val adv = try { whisperAdvice(lang, m)?.takeIf { Cfg.str("wadv_ok") != lang + "|" + m.id } } catch (_: Throwable) { null }
        if (adv == null) runIt()
        else askWhisperAdvice(lang, m, adv,
            { Cfg.put("wadv_ok", lang + "|" + m.id); runIt() },
            { r ->
                offBusy = false
                if (Offline.downloaded(r)) { Cfg.put("off_model", r.id); try { TrWizard.syncSaved("off_model", r.id) } catch (_: Throwable) {}; offlineQuick(only, free) }
                else pickWhisperModel(r)   // مش نازل: بيسأل ينزّله ويطبّقه، وبعدها دوس «ترجم» تاني
            },
            { offBusy = false })
    }

    /** (v743) موديل ترجمة Hy-MT2 مش نازل / مش مدعوم: نزّله من هنا أو فرّغ بس */
    private fun askMtModel(only: Boolean, free: Boolean, m: Offline.Model) {
        if (!LocalMt.supported()) { shConfirm("📴 الترجمة الأوفلاين مش مدعومة", "جهازك مش بيدعم موديل الترجمة (محتاج معالج 64-bit). تقدر تفرّغ بوشبر بس، أو تترجم بجيميناي.", listOf(ShBtn("✍ فرّغ بس", SH_BLUE) { offlineQuick(true) }, ShBtn("إلغاء", SH_GRAY) { })); return }
        val mm = LocalMt.model()
        shConfirm("⬇ موديل الترجمة الأوفلاين", "HY-MT1.5 " + mm.label + " (~" + mm.approxMb + " ميجا، مرة واحدة، محتاج نت للتنزيل بس) — بعدها الترجمة بتشتغل من غير نت.",
            listOf(ShBtn("⬇ نزّل وكمّل", SH_BLUE) { mtDownload { offlineQuick(only, free) } },
                ShBtn("✍ فرّغ بس دلوقتي", SH_GRAY) { offlineQuick(true) }, ShBtn("إلغاء", SH_GRAY) { }))
    }
    private fun mtDownload(after: () -> Unit) {
        val mm = LocalMt.model()
        say("⬇ بنحمّل موديل الترجمة…")
        try {
            Offline.fetchModel("mt/" + mm.file, LocalMt.url(mm), mm.approxMb,
                { a, t -> runOnUiThread { Notice.show(this, "⬇ موديل الترجمة: " + (a / 1048576) + " / " + (if (t > a) (t / 1048576).toString() else "~" + mm.approxMb) + " ميجا", 900L) } },
                { err -> runOnUiThread { if (err != null) say("⚠ تنزيل موديل الترجمة فشل: $err") else { say("✅ موديل الترجمة نزل"); after() } } })
        } catch (e: Throwable) { LogStore.err("Player:mtFetch", e); say("⚠ تعذّر بدء التنزيل") }
    }

    /** (v254) ▶ ترجمة قبل البداية: لو فيه إعداد محفوظ بيشتغل بيه على طول، وإلا بيسأل (أونلاين / أوفلاين ← لغة ← تفريغ ← ترجمة ← حفظ؟) */

    /** (v334) 🎙 فصل صوت الكلام عن الموسيقى — يدوي بس (VoiceClean: DPDFNet على قطع متوازية) */
    private fun voiceMenu() {
        try {
            val u = uri
            if (u == null || (u.scheme != "file" && u.scheme != "content")) { say("🎙 الفصل شغّال على الفيديو المحلي بس — نزّل الفيديو الأول"); return }
            val dur = player.duration.let { if (it > 0) it else 0L }
            val items = ArrayList<Pair<String, () -> Unit>>()
            val pb = voice
            val ready = VoiceClean.ready(this, u, dur)
            when {
                VoiceClean.busy -> items.add("⏹ وقّف الفصل اللي شغّال" to { VoiceClean.cancel() })
                VoiceClean.downloading() -> items.add("⏹ وقّف تنزيل الموديل" to { VoiceClean.cancelDownload() })
                pb != null && pb.active -> items.add("🔊 رجّع الصوت الأصلي" to { stopVoice() })
                ready != null -> items.add("🎙 شغّل صوت الكلام النضيف" to { startVoice(ready) })
                else -> items.add("🎙 ابدأ فصل صوت الكلام (" + VoiceClean.model().label + ")" to { startVoiceJob(u, dur) })
            }
            if (!VoiceClean.busy && !VoiceClean.downloading()) {
                for (m in VoiceClean.models) if (m.file != VoiceClean.model().file) items.add("⚙ المحرك: " + m.label + " — " + m.note to { VoiceClean.setModel(m.file); say("⚙ المحرك: " + m.label) })
                if (ready != null) items.add("🗑 امسح كل الصوت المفصول" to { stopVoice(); VoiceClean.deleteAll(this); say("🗑 اتمسح") })
            }
            if (RcCapture.active) { rcPmList("🎙 فصل صوت الكلام", items); return }   // (v1051) على الموبايل
            shDialog(340) { col, close ->
                col.addView(shHead("🎙 فصل صوت الكلام"))
                for ((t, f) in items) col.addView(shRow(t) { close(); f() })
            }
        } catch (e: Throwable) { LogStore.err("Player:voiceMenu", e); say("تعذّر فتح قايمة فصل الصوت") }
    }

    private fun startVoiceJob(u: Uri, dur: Long) {
        val m = VoiceClean.model()
        if (!VoiceClean.has(this, m)) {
            say("🎙 بنزّل موديل الفصل…")
            VoiceClean.download(this, m, { have, total -> runOnUiThread { voiceBtnRef?.text = if (total > 0) "⬇" + (have * 100 / total) + "%" else "⬇" + (have / 1_000_000) + "MB" } }) { err ->
                runOnUiThread {
                    voiceBtnRef?.text = "🎙"
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    if (err == null) startVoiceJob(u, dur) else say("🎙 التنزيل فشل: " + err)
                }
            }
            return
        }
        say("🎙 بدأ فصل صوت الكلام — الفيديو شغّال عادي لحد ما يخلص")
        VoiceClean.run(this, u, dur, { p -> runOnUiThread { voiceBtnRef?.text = "🎙" + p + "%" } }) { f, err ->
            runOnUiThread {
                voiceBtnRef?.text = "🎙"
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (f == null) { say("🎙 " + (if (err == "اتلغى") "اتلغى" else "فشل: " + err)); return@runOnUiThread }
                if (uri != u) { say("🎙 الفيديو اتغيّر — الصوت النضيف اتحفظ وهتلاقيه لما ترجع للفيديو"); return@runOnUiThread }
                say("✅ الصوت النضيف جاهز — بيشتغل دلوقتي"); startVoice(f)
            }
        }
    }

    private fun startVoice(f: File) {
        stopVoice()
        try { voice = VoiceClean.Playback(this, player.exo() ?: throw IllegalStateException("remote"), f).also { it.start() }; voiceBtnRef?.text = "🎙✓"; say("🎙 صوت الكلام النضيف شغّال") }
        catch (e: Throwable) { LogStore.err("Player:startVoice", e); stopVoice(); say("تعذّر تشغيل الصوت النضيف") }
    }

    private fun stopVoice() {
        try { voice?.stop() } catch (_: Throwable) {}
        voice = null; voiceBtnRef?.text = "🎙"
    }

    /** edit = true: جاي من زرار ⚙ (تغيير/مسح الإعداد من غير بدء ترجمة) */
    fun trWizard(edit: Boolean) {
        try {
            val oldLang = Offline.lang()   // (v413)
            TrWizard.keyModeHook = { n -> applyKeyMode(n) }   // (v275)
            TrWizard.sourceHook = { ed -> if (ed) say("💾 اتحفظ: " + SourceMode.line()) else runVisualOnly(); try { applyChromeFn() } catch (_: Throwable) {} }   // (v291)
            TrWizard.show(this, edit) { pl, save, start ->
                if (save) TrWizard.save(pl)
                if (start) runPlan(pl)
                else if (save) {
                    // (v399) تعديل الوضع (⚙) في نص الفيديو كان بيتحفظ بس ومابيوصلش للمحرك الشغّال (فالاستئناف يكمّل بالوضع القديم): دلوقتي بيتطبّق فورًا على المحرك من غير ما يبدأ الترجمة
                    val live = try { ::engine.isInitialized && (engineStarted || engine.subs.isNotEmpty()) } catch (_: Throwable) { false }
                    if (live) { runPlan(pl, false); say("💾 اتحفظ واتطبّق على الترجمة: " + TrWizard.describe(pl).replace("\n", " · ") + (if (engineStarted) "\n▶ دوس «إلغاء الإيقاف» تكمّل" else "")) }
                    else say("💾 اتحفظ: " + TrWizard.describe(pl).replace("\n", " · "))
                }
                if ((save || start) && pl.offline && pl.lang != oldLang) {   // (v413) غيّرت اللغة: كمّل من مكاني وصلّح الباتشات اللي باظت
                    try {
                        if (::engine.isInitialized && (engineStarted || engine.subs.isNotEmpty())) {
                            engine.langChanged(pl.lang, player.currentPosition.coerceAtLeast(0) / 1000.0)
                            say("🌐 اللغة بقت " + TrWizard.langLabel(pl.lang) + " — بكمّل من مكانك وبعيد الباتشات اللي اتفرّغت بلغة غلط")
                        }
                    } catch (e: Throwable) { LogStore.err("Player:langChanged", e) }
                }
                try { applyChromeFn() } catch (_: Throwable) {}   // (v360) ملخص الإعداد تحت اسم الفيديو
            }
        } catch (e: Throwable) { LogStore.err("Player:trWizard", e); say("تعذّر فتح شاشة طريقة الترجمة") }
    }

    /** بيطبّق الخطة على الإعدادات اللي المحرك بيقراها وبيبدأ الترجمة */
    /** (v291) بيشغّل الخطة وبعدها بيظبط البصري حسب المصدر (صوتي: يقفله · هجين: يشغّله بنوعه) */
    private fun runPlan(pl: TrWizard.Plan, startNow: Boolean = true) {
        runPlanCore(pl, startNow)
        if (!startNow) return   // (v399) تطبيق على المحرك بس: ماتلمسش الوضع البصري ولا تبدأ حاجة
        if (pl.onlineId == TrPresets.HARD_ID) return
        when (SourceMode.get()) {
            SourceMode.AUDIO -> try {
                Cfg.put("hard_mode", "0")
                if (::visual.isInitialized && visual.running) { visual.stop(); visOv.showBoxes(emptyList()); visAutoRun = false; visLog("🎙 صوتي بس — الوضع البصري اتقفل") }
            } catch (e: Throwable) { LogStore.err("Player:srcAudio", e) }
            SourceMode.HYBRID -> if (!Strict.noGemKeys()) {   // (v410) البصري جيميناي = أونلاين بس
                Cfg.put("hard_mode", if (SourceMode.kind() == "hard") "1" else "0")
                startVisualNow("🎙+👁 هجين · " + SourceMode.kindLabel())
            }
        }
    }

    /** (v291) 👁 بصري بس: الصوت واقف، والبصري بنوعه (نصوص الشاشة / هارد سب) */
    fun runVisualOnly() {
        try { if (::engine.isInitialized) { engine.transOnly = false; if (engineStarted) pauseTranslate() } } catch (_: Throwable) {}
        Cfg.put("hard_mode", if (SourceMode.kind() == "hard") "1" else "0")
        try { conf = Cfg.snapshot() } catch (e: Throwable) { LogStore.err("Player:visOnlySnapshot", e) }
        if (startVisualNow("👁 بصري بس · " + SourceMode.kindLabel())) say("👁 بصري بس · " + SourceMode.kindLabel() + " — الترجمة الصوتية واقفة")
    }

    private fun startVisualNow(tag: String): Boolean {
        try {
            if (!::visual.isInitialized) return false
            if (Strict.noGemKeys()) { say(Strict.NO_VISUAL_MSG); return false }   // (v410)
            if (!conf.visKeys.any { it.length > 10 }) { say("👁 ضيف مفتاح للوضع البصري الأول (الإعدادات ← 🔑 المفاتيح ← مفتاح الوضع البصري)"); return false }
            visAutoRun = false; visual.mode = "scene"
            if (!visual.running) visualStart()
            visLog(tag + " اتشغّل")
            return true
        } catch (e: Throwable) { LogStore.err("Player:startVisualNow", e); return false }
    }

    private fun runPlanCore(pl: TrWizard.Plan, startNow: Boolean = true) {
        TrWizard.apply(pl)
        appliedSig = planSig(pl)   // (v399)
        // (v297) اللهجة الفعلية بتتحط على المحرك في كل المسارات (كانت في الأوفلاين والسحابي بس) وبتظهر في إشعار واللوج
        try { if (::engine.isInitialized) engine.convDialect = Cfg.str("conv_dialect", "") } catch (_: Throwable) {}
        try {
            val eff = if (Strict.hideTrOpts()) "فصحى" else Cfg.str("conv_dialect", "").ifBlank { Cfg.str("lang", "فصحى") }.ifBlank { "فصحى" }   // (v696) أي لهجة محفوظة = فصحى في الأوفلاين الكامل (من غير مسح إعداداتك)
            LogStore.add("🗣 لهجة الترجمة الفعلية: " + eff + " (conv_dialect='" + Cfg.str("conv_dialect", "") + "' · lang='" + Cfg.str("lang", "") + "')")
            if (!pl.only && !Strict.hideTrOpts()) h.postDelayed({ try { Notice.show(this, "🗣 لهجة الترجمة: " + eff, 2600L) } catch (_: Throwable) {} }, 500L)
        } catch (_: Throwable) {}
        try { if (::engine.isInitialized) engine.transOnly = pl.only } catch (e: Throwable) { LogStore.err("Player:transOnly", e) }   // (v280) تفريغ بس
        if (pl.offline) {
            // الأوفلاين = وضع «نسخ ثم ترجمة سياقية» (Cfg.snapshot بيجبره لما Offline.on()): نفس إعدادات بريست الترانسكريبشن (مقاطع 60ث، من غير تنقيح ولا بصري)
            TrPresets.byId("transcript")?.let { TrPresets.apply(it) }
            if (pl.live) { Cfg.put("chunk", if (pl.engine == "sherpa") "20" else "30"); Cfg.put("trstart", "0") }   // (v266) لحظي: باتشات قصيرة تبدأ من مكان التشغيل
            try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:runPlan", e) }
            for ((v, f) in kmLabels) v.text = f(KeyMode.clamp(Cfg.int("kmode", 3)))
            if (::engine.isInitialized) engine.convDialect = Cfg.str("conv_dialect", "")   // (v257) اللهجة اللي اخترتها في الشاشة
            LogStore.add("🎛 طريقة الترجمة: أوفلاين — لغة=" + pl.lang.ifEmpty { "تلقائي" } + " · محرك=" + pl.engine + " · موديل=" + (if (pl.engine == "sherpa") "SenseVoice" else pl.model) + " · ترجمة=" + pl.method + " · لهجة=" + pl.dialect.ifBlank { "فصحى" })
            if (startNow) say(if (pl.only) "✍ أوفلاين · " + TrWizard.langLabel(pl.lang) + " · تفريغ بس (من غير ترجمة)" else "📴 أوفلاين · " + TrWizard.langLabel(pl.lang) + " · " + (if (pl.method == "google") "ترجمة جوجل" else "ترجمة جيميناي") + "\n" + ExtTranslate.setupLine())
            if (startNow) beginTranslate() else engineKick()
            if (startNow) TrWizard.startNotices(pl).forEachIndexed { i, m -> h.postDelayed({ try { Notice.show(this, m, 4500L) } catch (e: Throwable) { LogStore.err("Player:startNotices", e) } }, 600L + i * 3200L) }   // (v255)
        } else if (pl.cloud) {
            // (v274) أونلاين بمحرك خارجي: نفس مسار «نسخ ثم ترجمة سياقية» (التفريغ سحابي) والترجمة بالسلسلة: المحرك المختار ← الباقي ← جوجل ← جيميناي بمفاتيحك
            TrPresets.byId("transcript")?.let { TrPresets.apply(it) }
            try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:runPlan", e) }
            for ((v, f) in kmLabels) v.text = f(KeyMode.clamp(Cfg.int("kmode", 3)))
            if (::engine.isInitialized) engine.convDialect = Cfg.str("conv_dialect", "")
            LogStore.add("🎛 طريقة الترجمة: أونلاين بمحرك خارجي — ترجمة=" + pl.ext + " · تفريغ=" + (TrWizard.sttCandidate(pl.ext)?.id ?: "؟") + " · السلسلة: " + ExtTranslate.chainLabel())
            if (startNow) say(if (pl.only) "✍ تفريغ سحابي بس (من غير ترجمة)" else "☁ " + (ExtLlm.byId(pl.ext)?.label ?: pl.ext) + " · تفريغ سحابي\n" + ExtTranslate.setupLine())
            if (startNow) beginTranslate() else engineKick()
            if (startNow) TrWizard.startNotices(pl).forEachIndexed { i, m -> h.postDelayed({ try { Notice.show(this, m, 4500L) } catch (e: Throwable) { LogStore.err("Player:startNotices", e) } }, 600L + i * 3200L) }
        } else {
            val pr = TrPresets.byId(pl.onlineId)
            if (pr != null) applyPreset(pr, pl.only, false, startNow)
            else {
                try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:runPlan", e) }
                if (startNow) beginTranslate() else engineKick()
            }
        }
    }

    private var presetPop: android.widget.PopupWindow? = null

    /** (v297) اختيار بريست والترجمة شغّالة/موجودة: يتطبّق على الباتشات الجاية بس (اللي اتترجم يفضل) ولا يعيد من الأول خالص (القديمة بتتحفظ في 🗂) */

    private fun applyPreset(pr: TrPresets.P, keepOnly: Boolean = false, fresh: Boolean = false, startNow: Boolean = true) {
        if (Strict.noGemini()) { Cfg.put("tr_mode_id", ""); Cfg.put("stt_offline", "0") }   // (v410) بريست أونلاين = جيميناي: اخرج من نص-أونلاين/أوفلاين
        if (!keepOnly) try { if (::engine.isInitialized) engine.transOnly = false } catch (_: Throwable) {}   // (v280)
        val kv = TrPresets.apply(pr)
        if (pr.id == TrPresets.HARD_ID) {
            // (v240) وضع ترجمة الهارد سب: بصري بس — الترجمة الصوتية واقفة، والوضع البصري بيترجم الهارد سب
            try { if (::engine.isInitialized && engineStarted) pauseTranslate() } catch (_: Throwable) {}
            try { conf = Cfg.snapshot() } catch (e: Throwable) { LogStore.err("Player:hardSnapshot", e) }   // (v287)
            try {
                if (::visual.isInitialized) {
                    if (!conf.visKeys.any { it.length > 10 }) { say("🔤 ضيف مفتاح للوضع البصري الأول (الإعدادات ← 🔑 المفاتيح ← مفتاح الوضع البصري)"); return }
                    visAutoRun = false; visual.mode = "scene"
                    if (visual.running) visual.stop()
                    visualStart(); visLog("🔤 وضع ترجمة الهارد سب اتشغّل")
                }
            } catch (e: Throwable) { LogStore.err("Player:hardMode", e) }
            say("🔤 وضع ترجمة الهارد سب شغّال — الترجمة الصوتية واقفة")
            return
        }
        try { val nc = Cfg.snapshot(); conf = nc; if (::engine.isInitialized) engine.applyConf(nc) } catch (e: Throwable) { LogStore.err("Player:preset", e) }
        for ((v, f) in kmLabels) v.text = f(KeyMode.clamp(Cfg.int("kmode", 3)))
        // الوضع البصري: يتظبط حسب البريست (يتقفل لو البريست قافله، ويشتغل لو فاتحه وفيه مفتاح بصري)
        try {
            if (::visual.isInitialized) {
                if (Cfg.str("vis_auto", "1") == "1") {
                    if (!visual.running && conf.visKeys.any { it.length > 10 } && !incognito) { visAutoRun = true; visual.mode = "scene"; visualStart(); visLog("👁 اتشغّل مع بريست " + pr.name) }
                } else if (visual.running) { visual.stop(); visOv.showBoxes(emptyList()); visAutoRun = false; visLog("👁 اتقفل مع بريست " + pr.name) }
            }
        } catch (e: Throwable) { LogStore.err("Player:presetVis", e) }
        LogStore.add("🎛 بريست الترجمة: " + pr.name + " — " + kv.entries.joinToString(" · ") { it.key + "=" + it.value })
        say(pr.icon + " " + pr.name + " — اتظبطت كل الإعدادات")
        if (fresh) { try { player.seekTo(0) } catch (_: Throwable) {}; redoGo("🔄 بترجم من الأول بالبريست: " + pr.name) { engine.redoAll(true) } } else if (startNow) beginTranslate() else engineKick()
    }

    fun langPopup(anchor: View) {
        langPop?.let { if (it.isShowing) { it.dismiss(); langPop = null; return } }
        if (!::engine.isInitialized) { say("استنى لحظة — الفيديو لسه بيتحمّل"); return }   // (v262) engine lateinit: الضغط قبل التحميل كان بيكرّش
        if (!caps().dialect) { say("🗣 اللهجة والأسلوب مش شغّالين في «" + modeName() + "» — اختار وضع من اللي فيها لهجات (FreeLLM / وشبر + مترجم LLM)"); return }   // (v444)
        val langs = listOf("فصحى", "مصري")
        val curL = Cfg.str("conv_dialect", "").ifBlank { "فصحى" }
        if (RcCapture.active) {   // (v1051) اختيار اللهجة على الموبايل (الأسلوب والشدة سلايدرات: لسه على التلفزيون)
            rcPmList("🌐 اللهجة (الحالية: $curL)", langs.map { l -> (if (l == curL) "✓ " else "") + (if (l == "فصحى") "فصحى (حرفية)" else l) to { dialectPick(l) } })
            return
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(ui.dp(6), ui.dp(6), ui.dp(6), ui.dp(6)); background = glassPanelBg()
        }
        // (v134) الشكل بقى صفوف أفقية: اللهجات جنب بعض · تحتها الأسلوب والشدة · تحتها أزرار التطبيق (كانت عمود طويل)
        fun flow() = FlowRow(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun cLp() = ViewGroup.MarginLayoutParams(-2, ui.dp(34)).apply { setMargins(ui.dp(3), ui.dp(2), ui.dp(3), ui.dp(2)) }
        fun lbl(t: String) = ui.text(t, 11f, 0xFF9AA0A6.toInt()).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(ui.dp(8), 0, ui.dp(4), 0) }
        col.addView(shHead("🌐 اللهجة والأسلوب", "اللهجة بتتطبّق على الباتشات الجاية"))
        val rowL = shFlow()
        for (l in langs) rowL.addView(shChip(if (l == "فصحى") "فصحى (حرفية)" else l, l == curL) { langPop?.dismiss(); dialectPick(l) }, shChipLp())
        col.addView(rowL, LinearLayout.LayoutParams(-1, -2))
        // (v1199) أسلوب الترجمة: زرارين بس — حرفي · مناسب للمشاهدة العائلية (الشدة والأساليب القديمة اتشالت)
        val toneStyles = listOf("حرفي", "عائلي"); val toneLabels = listOf("حرفي", "مناسب للمشاهدة العائلية")
        var stI = toneStyles.indexOf(Cfg.str("tone_style", "")).coerceAtLeast(0)
        fun curStyle() = toneLabels[stI]
        col.addView(shHead("🗣 أسلوب الترجمة", "بيتطبّق على الباتشات الجاية"), LinearLayout.LayoutParams(-1, -2))
        val rowS = shFlow()
        fun paintTone() {
            rowS.removeAllViews()
            for ((si, sl) in toneLabels.withIndex())
                rowS.addView(shChip(sl, si == stI) {
                    stI = si; Cfg.put("tone_style", toneStyles[si]); engine.toneStyle = toneStyles[si]; paintTone()
                    say("الأسلوب: " + sl + " — الباتشات الجاية هتتترجم بيه. لو عايزه على اللي اتترجم دوس «طبّق»")
                }, shChipLp())
        }
        col.addView(rowS, LinearLayout.LayoutParams(-1, -2))
        paintTone()
        fun toneInstr(): String = toneInstrOf(toneStyles[stI], "")
        // (v999 ملاحظة 5) صف «طبّق» كان آخر عناصر السكرول فبيتقص في الأفقي — بقى فوتر ثابت برّه السكرول
        val applyRow = shDuo(
            shBtn("🔁 طبّق من هنا للآخر", SH_BLUE) { langPop?.dismiss(); runTool("أسلوب " + curStyle(), toneInstr(), false) },
            shBtn("🔁 طبّق على الفيديو كله", SH_GRAY) { langPop?.dismiss(); runTool("أسلوب " + curStyle(), toneInstr(), true) })
        langPop = showSheet(anchor, col, 430, "langPopup", footer = applyRow) { pw -> if (langPop === pw) langPop = null }
    }

    /** كبسولة جانبية: باتش ما اترجمش / رجع ناقص + إعادة على المفاتيح الاحتياطية. مخفية لحد ما يحصل فشل */
    lateinit var probBar: TextView
    lateinit var probHandle: TextView
    lateinit var probDrawer: LinearLayout
    private var probOn = false
    private var probIdx = -1
    fun toggleProb() {
        probOn = !probOn
        if (ytPage) { probDrawer.animate().cancel(); probDrawer.translationX = if (probOn) 0f else -(probBar.width + ui.dp(2)).toFloat() } else probDrawer.animate().translationX(if (probOn) 0f else -(probBar.width + ui.dp(2)).toFloat()).setDuration(220).start()   // (v1347) يوتيوب: فوري (بطلب علي)
        probHandle.text = if (probOn) "◂" else "⚠"
        fadeTo(probHandle, if (probOn) 1f else PROB_A)
        h.removeCallbacks(probAuto); if (probOn) h.postDelayed(probAuto, 8000)
    }
    fun updateProblems() {
        val p = try { engine.problems() } catch (_: Exception) { emptyList() }
        if (p.isEmpty() || pipNow()) {
            probIdx = -1
            if (probDrawer.visibility != View.GONE) { probDrawer.visibility = View.GONE; probOn = false; probHandle.text = "⚠" }
            return
        }
        val b = p[0]; probIdx = b.idx
        val what = if (b.mark == "❌") "ما اترجمش" else "رجع ناقص"
        probBar.text = "باتش ${b.idx + 1} $what" + (if (p.size > 1) " (+${p.size - 1})" else "") + " · 🔁 إعادة؟"
        if (probDrawer.visibility != View.VISIBLE) {
            probDrawer.visibility = View.VISIBLE; probOn = false; probHandle.text = "⚠"
            probDrawer.post { probDrawer.translationX = -(probBar.width + ui.dp(2)).toFloat() }
        }
    }
    /** زرار الباتش الفاشل: من غير سؤال — بيعيد على طول وإشعار صغير (والإعادة التلقائية شغالة لوحدها كمان) */
    fun askRetryProblem() {
        val i = probIdx; if (i < 0) return
        val n = try { engine.retryProblems() } catch (_: Exception) { 0 }
        if (probOn) toggleProb()
        if (n > 0) Notice.show(this, if (n == 1) "🔁 بعيد ترجمة باتش ${i + 1}" else "🔁 بعيد ترجمة $n باتش", 2200L)
    }


    /** يرجّع نسخة محفوظة ويظبط لهجة الترجمة الجاية على لهجتها */
    fun restoreVersion(i: Int) {
        val v = engine.versions.getOrNull(i) ?: return
        sfShown = false
        val n = engine.applyVersion(i)
        val d = if (v.dialect == "فصحى") "" else v.dialect
        Cfg.p.edit().putString("conv_dialect", d).apply()
        TrWizard.syncSaved("conv_dialect", d)
        engine.adoptDialect(d)
        say("اتطبّقت نسخة «${v.name}» (اتغيّرت $n جملة)"); touchSubs()
    }
    private var verPop: android.widget.PopupWindow? = null
    /** قايمة صغيرة جنب عداد الجمل: الترجمات المحفوظة ولهجة كل واحدة — دوس على واحدة تبدّل ليها */
    fun versionsPopup(anchor: View) {
        verPop?.let { if (it.isShowing) { it.dismiss(); verPop = null; return } }
        val col = LinearLayout(this)   // (v741) نفس شكل الشيت الموحّد
        fun close() { verPop?.dismiss() }
        val curD = Cfg.str("conv_dialect", "").ifBlank { "فصحى" }
        val srcNote = if (studioLabel.isNotBlank()) " · " + studioLabel else ""
        col.addView(shHead("🗂 الترجمات", "الحالية: $curD$srcNote · دوس على نسخة تبدّل ليها"))
        val vs = engine.versions.toList()
        if (vs.isEmpty()) col.addView(shNote("مفيش نسخ لسه — أول ما تغيّر اللهجة بتتحفظ النسخة القديمة هنا"))
        vs.forEachIndexed { i, v ->
            val tag = if (v.name.startsWith("نسخة") || v.name.startsWith("قبل") || v.name.startsWith("بعد")) " · ${v.name}" else ""
            col.addView(shRow("${v.dialect.ifBlank { "—" }}$tag", "${v.subs.size} جملة") { close(); restoreVersion(i) })
        }
        col.addView(shSection("خيارات"))
        col.addView(shRow("💾 احفظ الحالية") { close(); engine.saveVersion("نسخة " + fmtMs(player.currentPosition).substring(3)); say("اتحفظت النسخة الحالية") })
        col.addView(shRow("🗂 كل النسخ…", "", true) { close(); versionsDialog() })
        verPop = showSheet(anchor, col, 300, "versions") { pw -> if (verPop === pw) verPop = null }
    }

    fun versionsDialog() {
        val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(14)); background = ui.box(th.card, th.border, 18) }
        box.addView(ui.text("🗂 ترجمات الفيديو (نسخ محفوظة في الجلسة)", 16f, th.primary, true))
        box.addView(ui.noHint())
        box.addView(ui.button("💾 احفظ النسخة الحالية") { engine.saveVersion("نسخة " + fmtMs(player.currentPosition).substring(3)); d.dismiss(); versionsDialog() })
        val vs = engine.versions.toList()
        if (vs.isEmpty()) box.addView(ui.text("مفيش نسخ محفوظة لسه", 13f, th.muted))
        vs.forEachIndexed { i, v ->
            box.addView(ui.button("${v.name} — ${v.dialect.ifBlank { "—" }} — ${v.subs.size} جملة") { restoreVersion(i); d.dismiss() })
        }
        d.setContentView(android.widget.ScrollView(this).apply { addView(box) })
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        ui.fullPage(d)
        d.show()
    }

    fun sfTranslationsDialog(anchor: View) {
        val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(14)); background = ui.box(th.card, th.border, 18) }
        box.addView(ui.text("📝 ترجمات الفيديو", 16f, th.primary, true))
        box.addView(ui.noHint())
        val u = uri?.toString() ?: ""
        val softOn = sfShown && !preferNative
        if (::engine.isInitialized && engine.subs.isNotEmpty()) {
            box.addView(ui.button("💬 ترجمة البرنامج (الحالية) — " + engine.subs.size + " جملة" + (if (softOn) " · دي ترجمة السوفت سب" else "")) { preferNative = false; ccOn = true; curIdx = -2; d.dismiss(); Notice.show(this, "💬 ترجمة البرنامج", 1300L) })
        }
        if (sfSidecar() != null || sfDoneUri == u) {
            val nm = sfSideName().ifBlank { "ملف الترجمة" }
            val st = if (sfShown && preferNative) "مخفية — الأصلية ظاهرة" else if (sfShown) "ظاهرة" else "مش معروضة"
            box.addView(ui.button("💬 السوفت سب: " + nm + " (" + st + ") — دوس للإخفاء/الإظهار") {
                if (sfShown && !preferNative) {
                    try { player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, false).build() } } catch (_: Throwable) {}
                    sfHideNative = false; preferNative = true; ccOn = true; curIdx = -2
                    Notice.show(this, "💬 السوفت سب الأصلية ظاهرة", 1500L)
                } else if (sfShown) {
                    preferNative = false; ccOn = true; curIdx = -2
                    Notice.show(this, "💬 ترجمة السوفت سب ظاهرة", 1500L)
                } else {
                    val vi = try { engine.versions.indexOfFirst { it.name == "ترجمة السوفت سب" } } catch (_: Throwable) { -1 }
                    if (vi >= 0) { restoreVersion(vi); sfShown = true }
                    else { d.dismiss(); sfEngineChoice("السوفت سب") { e -> sfRun("soft", e) }; return@button }
                }
                d.dismiss()
            })
        }
        val tc = androidx.media3.common.C.TRACK_TYPE_TEXT
        val groups = try { (player.exo()?.currentTracks?.groups ?: emptyList<androidx.media3.common.Tracks.Group>()).filter { it.type == tc && it.length > 0 && it.isSupported } } catch (_: Throwable) { emptyList() }
        groups.forEachIndexed { i, g ->
            val f = g.getTrackFormat(0)
            val lang = (f.language ?: "").let { l -> if (l.isBlank() || l == "und") "" else try { java.util.Locale(l).getDisplayLanguage(java.util.Locale("ar")).ifBlank { l } } catch (_: Throwable) { l } }
            val name = listOf(f.label ?: "", lang).filter { it.isNotBlank() }.distinct().joinToString(" · ").ifBlank { "مسار " + (i + 1) }
            box.addView(ui.button("💬 " + name + " (من الفيديو)") {
                try {
                    player.exo()?.let { xp -> xp.trackSelectionParameters = xp.trackSelectionParameters.buildUpon().setTrackTypeDisabled(tc, false)
                        .setOverrideForType(androidx.media3.common.TrackSelectionOverride(g.mediaTrackGroup, 0)).build() }
                    sfHideNative = false; preferNative = true; ccOn = true; curIdx = -2
                    Notice.show(this, "💬 " + name, 1500L)
                } catch (e: Throwable) { LogStore.err("Player:pickText2", e) }
                d.dismiss()
            })
        }
        try {
            if (::engine.isInitialized) {
                val vs = engine.versions.toList()
                vs.forEachIndexed { i, v -> box.addView(ui.button("🗂 " + v.name + " — " + v.subs.size + " جملة (" + v.dialect.ifBlank { "فصحى" } + ")") { restoreVersion(i); d.dismiss() }) }
                if (engine.subs.isNotEmpty()) box.addView(ui.button("💾 احفظ النسخة الحالية") { engine.saveVersion("نسخة " + fmtMs(player.currentPosition).substring(3)); d.dismiss(); sfTranslationsDialog(anchor) })
            }
        } catch (e: Throwable) { LogStore.err("Player:sfTrans", e) }
        box.addView(ui.button("📝 الجمل المترجمة") { d.dismiss(); try { if (::sentDlg.isInitialized) sentDlg.show() } catch (_: Throwable) {} })
        d.setContentView(android.widget.ScrollView(this).apply { addView(box) })
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        ui.fullPage(d)
        d.show()
    }

    fun recapDialog() {
        say("📜 بجهّز الملخص…")
        engine.recap(player.currentPosition / 1000.0, { m -> runOnUiThread { giShowFn(m) } }) { txt ->
            runOnUiThread {
                val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(14)); background = ui.box(th.card, th.border, 18) }
                box.addView(ui.text("📜 ذكّرني بالأحداث", 16f, th.primary, true))
                box.addView(ui.text(txt, 14f, th.text).apply { setPadding(0, ui.dp(8), 0, ui.dp(8)); setTextIsSelectable(true) })
                box.addView(ui.button("تمام") { d.dismiss() })
                d.setContentView(android.widget.ScrollView(this).apply { addView(box) })
                d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
                ui.fullPage(d)
                d.show()
            }
        }
    }

    fun makeRetriever(): android.media.MediaMetadataRetriever? {
        return try {
            val r = android.media.MediaMetadataRetriever(); val u = uri; val l = url
            if (u != null) r.setDataSource(this, u) else if (l != null && !l.contains(".m3u8", true)) r.setDataSource(l, HashMap(hdr)) else return null
            r
        } catch (e: Exception) { try { visLog("👁 المسح من الملف مش ممكن (" + e.javaClass.simpleName + ": " + (e.message ?: "").take(70) + ") — بلقط الفريمات من الشاشة بدل كده") } catch (_: Throwable) {}; null }
    }


    /** (v676) زرار 👁 في ريموت الموبايل: بيرجع ثانية-ثانيتين (غالبًا الشخص بيدوس بعد ما الجملة ظهرت) ويلقط الفريم ويترجمه، وبعدين الفيديو يكمّل */
    fun visualSnapBack(backMs: Long = 1500L) {
        if (!::svRef.isInitialized || svRef.width <= 0 || svRef.height <= 0) { Notice.show(this, ("مفيش فيديو شغّال").toString(), 2300L); return }
        if (visBusy) { Notice.show(this, ("👁 لسه بترجم اللقطة اللي فاتت…").toString(), 2300L); return }
        val wasPlaying = try { player.playWhenReady } catch (_: Exception) { false }
        try { player.pause(); player.seekTo((player.currentPosition - backMs).coerceAtLeast(0L)) } catch (e: Exception) { LogStore.err("Player:visBack", e) }
        h.postDelayed({ if (!isFinishing && !isDestroyed) visualSnap(wasPlaying) }, 650L)   // الـseek مش لحظي: نستنى الفريم الجديد يترسم قبل اللقطة
    }

    fun visualSnap(resume: Boolean? = null) {
        if (!::svRef.isInitialized || svRef.width <= 0 || svRef.height <= 0) { Notice.show(this, ("مفيش فيديو شغّال").toString(), 2300L); return }
        if (visBusy) { Notice.show(this, ("👁 لسه بترجم اللقطة اللي فاتت…").toString(), 2300L); return }
        visBusy = true
        val tok = ++visTok
        h.postDelayed({ if (visBusy && visTok == tok) { visBusy = false;  } }, 60_000)
        val wasPlaying = resume ?: try { player.playWhenReady } catch (_: Exception) { false }
        try { player.pause() } catch (e: Exception) { LogStore.err("Main:2522", e) }
        val curUs = player.currentPosition * 1000
        val t0 = (player.currentPosition - offsetMs) / 1000.0
                val done = { runOnUiThread { visBusy = false; if (wasPlaying && !isFinishing && !isDestroyed) try { player.play() } catch (e: Exception) { LogStore.err("Main:2525", e) } } }
        fun fallback() {
            Thread {
                val r = makeRetriever()
                val b = try { r?.getFrameAtTime(curUs, android.media.MediaMetadataRetriever.OPTION_CLOSEST) } catch (_: Exception) { null }
                try { r?.release() } catch (e: Exception) { LogStore.err("Main:2530", e) }
                if (b != null) visual.snap(b, { t0 }, done) else { done() }
            }.start()
        }
        val bmp = android.graphics.Bitmap.createBitmap(svRef.width, svRef.height, android.graphics.Bitmap.Config.ARGB_8888)
        try {
            android.view.PixelCopy.request(svRef, bmp, { res -> if (res == android.view.PixelCopy.SUCCESS) visual.snap(bmp, { t0 }, done) else fallback() }, Handler(Looper.getMainLooper()))
        } catch (_: Exception) { fallback() }
    }
    private var visBusy = false
    /** (v182) تسجيل في اللوج من غير ما يلمس سطر الحالة بتاع الترجمة */
    private fun visLog(m: String) {
        try {
            synchronized(logBuf) { logBuf.append(fmtMs(cur)).append("  ").append(m).append('\n'); if (logBuf.length > 30000) logBuf.delete(0, 10000) }
            LogArchive.append(arcRun, fmtMs(cur) + "  " + m)
            LogStore.add(fmtMs(cur) + "  " + m)
        } catch (_: Throwable) {}
    }
    /** (v182) لقطة فريم من سطح الفيديو (PixelCopy) بحجم أقصاه 640 — بتتنادى من خيط الوضع البصري، فيديوهات m3u8 */
    fun grabSurface(maxDim: Int = 960): android.graphics.Bitmap? {
        if (!::svRef.isInitialized) return null
        val sw = svRef.width; val sh = svRef.height
        if (sw <= 0 || sh <= 0 || !svRef.holder.surface.isValid) return null
        val sc = minOf(1f, maxDim.toFloat() / maxOf(sw, sh))
        val bmp = android.graphics.Bitmap.createBitmap((sw * sc).toInt().coerceAtLeast(2), (sh * sc).toInt().coerceAtLeast(2), android.graphics.Bitmap.Config.ARGB_8888)
        val latch = java.util.concurrent.CountDownLatch(1); val ok = java.util.concurrent.atomic.AtomicBoolean(false)
        try {
            android.view.PixelCopy.request(svRef, bmp, { res -> ok.set(res == android.view.PixelCopy.SUCCESS); latch.countDown() }, Handler(Looper.getMainLooper()))
        } catch (_: Throwable) { bmp.recycle(); return null }
        val done = try { latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { false }
        if (!done || !ok.get()) { bmp.recycle(); return null }
        return bmp
    }
    private var visSayAt = 0L
    /** (v330) الوضع البصري كان بياخد نسخة الإعدادات القديمة (conf) من وقت فتح المشغّل → مفتاح ضفته بعدها ما كانش بيشوفه فالحلقة بتقف فورًا. دلوقتي نسخة جديدة كل ~1.5 ثانية (من غير ما نلمس conf بتاعة المحرك) */
    @Volatile private var visConfV: Conf? = null
    @Volatile private var visConfAt = 0L
    private fun visConfNow(): Conf {
        val n = android.os.SystemClock.uptimeMillis(); val c = visConfV
        if (c == null || n - visConfAt > 1500L) { try { visConfV = Cfg.snapshot(); visConfAt = n } catch (_: Throwable) {} }
        return visConfV ?: conf
    }
    private lateinit var visBar: TextView
    private var visBarTxt = ""
    private var visAutoRun = false
    private var visTok = 0

    /**
     * (v358) لوحة الوضع البصري الصغيرة: زرار تشغيل/إيقاف صغير + «⋯» للقايمة الكاملة، وتحتهم جمل الوضع البصري بتوقيتها —
     * دوسة على جملة بتنقلك لمكانها في الفيديو. بتتحدّث لوحدها وهي مفتوحة والجملة الحالية متظلّلة.
     */
    fun visualDialog() {
        val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        visual.mode = "scene"
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(10)); background = ui.box(th.card, th.border, 18) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
        val title = ui.text("👁 الوضع البصري", 15f, th.primary, true)
        fun chip(t: String, f: () -> Unit) = IconTextView(this).apply {
            text = t; textSize = 12.5f; gravity = Gravity.CENTER; setTextColor(th.text); minHeight = ui.dp(34)
            setPadding(ui.dp(12), ui.dp(4), ui.dp(12), ui.dp(4)); background = ui.box(th.surface, th.border, 10); setOnClickListener { f() }
        }
        val toggle = chip("") { }
        fun paintToggle() { toggle.text = if (visual.running) "⏹ إيقاف" else "▶ تشغيل" }
        toggle.setOnClickListener {
            if (visual.running) { visual.stop(); visLog("👁 الوضع البصري اتقفل (اللوحة)") } else { visual.mode = "scene"; visLog("👁 الوضع البصري اتشغّل (اللوحة)"); visualStart() }
            paintToggle()
        }
        paintToggle()
        val more = chip("⋯") { d.dismiss(); visualOptionsDialog() }
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(toggle, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = ui.dp(6) })
        head.addView(more, LinearLayout.LayoutParams(-2, -2))
        box.addView(head, LinearLayout.LayoutParams(-1, -2))
        val info = ui.text("", 11f, th.muted).apply { setPadding(0, ui.dp(4), 0, ui.dp(4)) }
        box.addView(info, LinearLayout.LayoutParams(-1, -2))
        updVis()
        val empty = ui.text("مفيش جمل بصرية لسه — شغّل الوضع البصري وهتظهر هنا بتوقيتها.", 13f, th.muted).apply { setPadding(ui.dp(4), ui.dp(10), ui.dp(4), ui.dp(10)) }
        val maxH = (resources.displayMetrics.heightPixels * 0.5f).toInt()
        val lst = object : ListView(this) { override fun onMeasure(w: Int, hh: Int) { super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST)) } }   // طول على قد الجمل لحد نص الشاشة
        var curV = -1
        val ad = object : BaseAdapter() {
            override fun getCount() = visList.size
            override fun getItem(i: Int): Any = visList[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, cv: View?, parent: ViewGroup): View {
                val ve = visList[i]
                val row = LinearLayout(this@PlayerActivity).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, ui.dp(2), 0, ui.dp(2)) }
                val bar = View(this@PlayerActivity).apply { setBackgroundColor(0xFF3B82F6.toInt()) }
                val col = LinearLayout(this@PlayerActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6)) }
                col.addView(ui.text("⏱ " + PlayerLogic.clock((ve.start * 1000).toLong()), 10f, th.muted))
                col.addView(ui.text(if (ve.translated.isEmpty()) ve.original else ve.translated, 14f, th.text))
                if (ve.original.isNotBlank() && ve.original != ve.translated) col.addView(ui.text(ve.original, 11f, th.muted))
                row.addView(bar, LinearLayout.LayoutParams(ui.dp(4), -1)); row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                row.setBackgroundColor(if (i == curV) (th.primary and 0x00FFFFFF) or 0x33000000 else Color.TRANSPARENT)
                return row
            }
        }
        lst.adapter = ad; lst.divider = android.graphics.drawable.ColorDrawable(th.border); lst.dividerHeight = 1
        lst.setOnItemClickListener { _, _, i, _ -> visList.getOrNull(i)?.let { player.seekTo((it.start * 1000).toLong()); d.dismiss() } }
        box.addView(lst, LinearLayout.LayoutParams(-1, -2))
        box.addView(empty, LinearLayout.LayoutParams(-1, -2))
        box.addView(chip("إغلاق") { d.dismiss() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ui.dp(6) })
        lateinit var tick: Runnable
        fun refresh() {
            updVis()
            val c = cur / 1000.0
            val nv = visList.indexOfLast { it.start <= c }
            if (nv != curV) curV = nv
            ad.notifyDataSetChanged()
            val none = visList.isEmpty()
            lst.visibility = if (none) View.GONE else View.VISIBLE; empty.visibility = if (none) View.VISIBLE else View.GONE
            info.text = "عدد الجمل: " + visList.size + (if (!visual.running && visual.status.isNotBlank() && !visual.status.startsWith("👁")) "  ·  " + visual.status.take(60) else "")
            paintToggle()
        }
        tick = Runnable { if (d.isShowing) { refresh(); h.postDelayed(tick, 1500L) } }
        d.setOnDismissListener { h.removeCallbacks(tick) }
        d.setContentView(box)
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        ui.fullPage(d)
        refresh(); d.show(); h.postDelayed(tick, 1500L)
        // أول ما تفتح: انزل للجملة الحالية
        if (curV >= 0) lst.post { try { lst.setSelection((curV - 1).coerceAtLeast(0)) } catch (_: Throwable) {} }
    }

    /** القايمة الكبيرة القديمة (إعادة من الأول / من مكان التشغيل / لقطة / سجل / مسح) — بتتفتح من «⋯» جوه اللوحة الصغيرة */
    fun visualOptionsDialog() {
        val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(14)); background = ui.box(th.card, th.border, 18) }
        box.addView(ui.text("👁 الوضع البصري", 17f, th.primary, true))
        box.addView(ui.noHint())
        visual.mode = "scene"
        val st = ui.text(if (visual.running) "الحالة: شغّال — " + visual.status else "الحالة: واقف", 13f, th.text)
        box.addView(st)
        box.addView(ui.button(if (visual.running) "⏹ إيقاف" else "▶ تشغيل", true) {
            if (visual.running) { visual.stop(); visLog("👁 الوضع البصري اتقفل (القايمة)") } else {
                visLog("👁 الوضع البصري اتشغّل (القايمة)"); visualStart()
            }
            d.dismiss()
        })
        // (v185) إعادة الوضع البصري: من الأول (يمسح كل النتايج المحفوظة) أو من مكان التشغيل وقدّام بس
        box.addView(ui.button("🔁 إعادة الوضع البصري من الأول") {
            visual.stop(); visual.clear(); visOv.showBoxes(emptyList()); visual.mode = "scene"; visualStart()
            visLog("👁 إعادة الوضع البصري من الأول (القايمة)"); Notice.show(this, "👁 بيعيد تحليل الفيديو من الأول", 2300L); d.dismiss()
        })
        box.addView(ui.button("↪ إعادة من مكان التشغيل وقدّام") {
            val t = cur / 1000.0
            visual.stop(); visual.clearFrom(t); visOv.showBoxes(emptyList()); visual.mode = "scene"; visualStart()
            visLog("👁 إعادة الوضع البصري من " + fmtMs(cur) + " (القايمة)"); Notice.show(this, "👁 بيعيد التحليل من مكان التشغيل", 2300L); d.dismiss()
        })
        box.addView(ui.button("📸 لقطة واحدة دلوقتي") { d.dismiss(); visualSnap() })
        box.addView(ui.button("📜 سجل الترجمات البصرية والأحداث") { d.dismiss(); visualLogDialog() })
        box.addView(ui.button("🗑 مسح النتائج") { visual.clear(); visOv.showBoxes(emptyList()); d.dismiss() })
        d.setContentView(android.widget.ScrollView(this).apply { addView(box) })
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        ui.fullPage(d)
        d.show()
    }

    /** (v206) سجل الوضع البصري: جدول الترجمات (من→إلى) + أحداث الظهور/التمديد/الرجوع/الاختفاء، مع نسخ */
    fun visualLogDialog() {
        val d = GDialog(this); d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(14)); background = ui.box(th.card, th.border, 18) }
        box.addView(ui.text("📜 سجل الوضع البصري", 17f, th.primary, true))
        val body = "🗺 الترجمات (" + visual.count + "):\n" + visual.tableText() + "\n\n🧬 الأحداث:\n" + visual.eventsText()
        box.addView(ui.text(body, 12f, th.text))
        box.addView(ui.button("📋 نسخ") {
            try { (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("visual", body)); Notice.show(this, "اتنسخ", 1500L) } catch (_: Throwable) {}
        })
        box.addView(ui.button("إغلاق") { d.dismiss() })
        d.setContentView(android.widget.ScrollView(this).apply { addView(box) })
        d.window?.apply { setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)); setLayout((resources.displayMetrics.widthPixels * 0.94f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT) }
        ui.fullPage(d)
        d.show()
    }

    /** الإعدادات من المشغّل: بتفتح شاشة الإعدادات فوق الفيديو من غير ما تقفله — الرجوع (Back) بيرجّعك للفيديو */
    private var settingsOpened = false
    /** (v124) تشغيل من تبويب متخفي: مفيش «فيديوهات الإنترنت المحفوظة» ولا «الأخيرة» ولا لقطة مصغّرة ولا ترجمة خلفية */
    private val incognito: Boolean by lazy { intent?.getBooleanExtra("incognito", false) == true }
    /** (v433) الفيديو جاي من موقع محجوب بزرار 🚨: بيتسجل في المصطادة مخفي (بالقفل) ومايدخلش «الأخيرة» ولا السجل العام */
    private val hiddenSite: Boolean by lazy {
        try {
            intent?.getBooleanExtra("hsite", false) == true ||
                listOf(intent?.getStringExtra("url"), intent?.getStringExtra("ref")).any { u -> SiteBlock.keyOf(u)?.let { k -> SiteBlock.has(this, k) } == true }
        } catch (_: Throwable) { false }
    }
    fun openSettings(tab: String? = null) {
        settingsOpened = true
        resumeAfterSettings = if (remote) false else try { player.isPlaying } catch (_: Exception) { false }
        if (!remote) try { player.pause() } catch (e: Exception) { LogStore.err("Main:2566", e) }   // (v568) وضع المتحكم: فتح الإعدادات ما بيوقّفش التلفزيون
        saveRecent(); Thread { engine.saveNow() }.start()
        // (v100) نفس اتجاه المشغّل بالظبط (من غير روتيشن) ومن غير حركة انتقال — كان بيجبر العرض فيعمل نتشة ويرجع
        startActivity(Intent(this, MainActivity::class.java).putExtra("from_player", true).putExtra("land", isLandNow()).apply { if (tab != null) putExtra("tab", tab) })
        try { overridePendingTransition(0, 0) } catch (e: Exception) { LogStore.err("Main:2570", e) }
    }
    override fun onResume() {
        super.onResume(); if (gone) return; NetUse.bindThread(); internalNav = false; resumedNow = true; h.removeCallbacks(pipExitCheck)
        tvWarmApply()   // (v462)
        mtParityAttach()   // (v1013) مطابقة فريمات + تحسين صورة (من مشغّل MeeTube)
        if (Cfg.bool("pip_hint_pending", false) && !canOverlay() && !DeviceUi.isTv(this)) {   // (v1010) آخر مرة خرجت عادي من غير PiP: اسأله دلوقتي
            Cfg.put("pip_hint_pending", "0")
            h.postDelayed({ try { if (!isFinishing && !isDestroyed) PermAsk.overlay(this, { }, { }) } catch (_: Throwable) {} }, 900L)
        }
        trEnsureBtn()   // (v463) زرار لوحة النص في وضع التابلت
        WebMute.pauseAll()   // (v149) أي صوت WebView (متصفح/يوتيوب) يتقفل أول ما المشغّل يظهر
        if (audioOnlyMode) {   // رجعنا من وضع «صوت بس»: المحرك كان موقوف، نجهّزه من جديد (الترجمة بتبدأ لما تدوس ترجم)
            audioOnlyMode = false; engineStarted = false
            try { window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } catch (_: Throwable) {}   // (v468) رجعنا لوضع الفيديو: الشاشة تفضل صاحية
            try { initEngine(); say("الترجمة كانت موقوفة في وضع الصوت — دوس ترجم لو عايز تكمّل") } catch (e: Throwable) { LogStore.err("Player:audioResume", e) }
        }
        if (Themes.current().id != th.id) { recreate(); return }   // (v891) byId ثابت ytglass على الموبايل — من غير لوب
        if (settingsOpened) {
            settingsOpened = false
            // (v122) رجعنا من الإعدادات: اللهجة / الأسلوب / الموديل / الشخصيات / المسرد لازم توصل للمحرك الشغّال فعلًا مش بس تتحفظ
            try {
                val nc = Cfg.snapshot(); conf = nc
                Extras.load()   // (v212) ميزات المشاهدة اتغيّرت من الإعدادات
                if (::engine.isInitialized) {
                    engine.applyConf(nc)
                    engine.toneStyle = Cfg.str("tone_style", ""); engine.toneStrength = Cfg.str("tone_strength", "متوسطة")
                    // (v212) تحويل اللهجة من الإعدادات: للباتشات الجاية (القديم من زرار اللغة 🌐)
                    val cd = Cfg.str("conv_dialect", "")
                    if (cd != engine.convDialect && !(cd.isNotEmpty() && cd == nc.lang)) engine.setConvDialect(cd, false)
                }
            } catch (e: Throwable) { LogStore.err("Player:applyConf", e) }
        }
        restyleFn()
        if (resumeAfterSettings) { resumeAfterSettings = false; try { player.play() } catch (e: Exception) { LogStore.err("Main:2576", e) } }
        // (v606) اتفتحنا بسبب خروج المستخدم من التطبيق والفيديو شغّال (يوتيوب بورتريه): ندخل PiP مرة واحدة أول ما نظهر
        if (!pipAutoDone && intent.getBooleanExtra("pip", false) && Build.VERSION.SDK_INT >= 26) {
            pipAutoDone = true
            h.postDelayed({ try { if (!isFinishing && !isDestroyed && !pipNow()) enterPip(false) } catch (e: Throwable) { LogStore.err("Player:autoPip", e) } }, 300L)
        }
    }
    private var pipAutoDone = false
    override fun onPause() { super.onPause(); if (gone) return; NetUse.unbindThread(); LogStore.add("⏸ onPause · ${LogStore.heapLine()}"); resumedNow = false; if (!handedOff && !remote) { saveRecent(); Thread { engine.saveNow() }.start() } }
    override fun onStart() { super.onStart(); stoppedNow = false }   // (v1364)
    override fun onStop() {
        super.onStop(); stoppedNow = true; if (gone) return; saveRecent()
        // ✕ على نافذة PiP: النظام بيوقف الأكتيفيتي وهي لسه في وضع PiP — نقفل الفيديو ونخرج (إلا لو الشاشة اتقفلت)
        val interactive = try { (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isInteractive } catch (_: Exception) { true }
        if (pipNow() && interactive && !isFinishing && !audioOnlyMode) closeAfterPip()
    }
    /** (v619) 📺 كمّل على التلفزيون القريب من نفس الثانية: يوصّل (لو مش متصل) ثم يبعت الفيديو بموضعه الحالي ويوقّف الموبايل */
    private fun sendToTv() {
        try {
            val ytid = intent.getStringExtra("ytid")?.takeIf { it.length == 11 }
            val ttl = intent.getStringExtra("title")?.takeIf { it.isNotBlank() } ?: Recents.titleOf(vid)
            val hd = mapOf("ref" to (intent.getStringExtra("ref") ?: ""), "ua" to (intent.getStringExtra("ua") ?: ""), "cookie" to (intent.getStringExtra("cookie") ?: ""))
            val spec = MediaSpec(uri = uri?.toString(), url = url, headers = hd, title = ttl, ytid = ytid, startMs = player.currentPosition.coerceAtLeast(0L))
            val go = { PlayTarget.force(this, spec) { try { player.pause() } catch (_: Throwable) {} } }
            if (RemoteClient.state == RemoteClient.St.CONNECTED || PlayTarget.enabled()) go() else TvModeFab.connectAndThen(this) { go() }
        } catch (e: Throwable) { LogStore.err("Player:toTv", e) }
    }

    override fun onDestroy() {
        if (gone) { super.onDestroy(); return }
        try { TvModeFab.listeners.remove(tvNearCb) } catch (_: Throwable) {}
        try { volWatch?.stop(); volWatch = null } catch (_: Throwable) {}
        LogStore.add("🔚 onDestroy (isFinishing=$isFinishing)")
        NoticeLog.detach(this)
        try { EndOverlay.hide(); ResumeAsk.dismiss() } catch (_: Throwable) {}   // (v1056)
        stopVoice()
        mtParityDetach()   // (v1013)
        try { TaskCenter.extra.remove(taskListener) } catch (_: Throwable) {}
        h.removeCallbacksAndMessages(null)
        pipOv?.hide(); pipOv = null
        saveRecent()
        try { visual.stop() } catch (e: Exception) { LogStore.err("Main:2590", e) }
        rmFrames = false; try { rmLsn?.let { LinkSession.removeListener(it) } } catch (_: Throwable) {}; rmLsn = null
        try { mirror?.release() } catch (_: Throwable) {}; mirror = null   // (v570)
        if (::realEngine.isInitialized && Live.engine === realEngine) Live.engine = null
        retireEngine()
        if (!handedOff && !remote) try { engine.saveNow() } catch (e: Exception) { LogStore.err("Main:2593", e) }
        if (incognito && isFinishing) try { File(File(filesDir, "progress"), Store.keyFor(vid) + ".json").delete() } catch (_: Throwable) {}   // (v124) المتخفي: الترجمة المحفوظة بتتمسح أول ما تقفل
        if (dockedAway) { try { loud?.release(); loud = null } catch (_: Throwable) {} } else player.release()   // (v1162) المشغّل اتسلّم للدوك السفلي: ما نقفلوش
        // (v564) فيديو الموبايل على التلفزيون: امسح الكاش أول ما نخرج (لو مفيش مشغّل تاني بيستخدمه)
        try { castSubFile?.delete() } catch (_: Throwable) {}   // (v676)
        try { mobileSub?.delete() } catch (_: Throwable) {}   // (v684)
        if (CastCache.isCast(url) && synchronized(liveList) { liveList.none { val a = it.get(); a != null && a !== this && !a.isFinishing && !a.isDestroyed } }) CastCache.purge(applicationContext)
        synchronized(liveList) { liveList.removeAll { it.get() == null || it.get() === this } }
        val cur0 = PlayerRemote.act?.get()
        if (cur0 === this) PlayerRemote.act = null
        if (cur0 == null || cur0 === this) KeepAliveService.stop(this)
        super.onDestroy()
    }
}

/**
 * (v606) المشغّل في Task لوحده على الموبايل/التابلت: لما يدخل PiP، نافذة الـPiP بتفضل شغّالة وإنت بتتنقّل في التطبيق والمتصفح (الاتنين مع بعض).
 * التلفزيون بيفضل زي ما هو (نفس الـTask).
 */
fun Intent.pipTask(ctx: android.content.Context): Intent {
    try {
        if (android.os.Build.VERSION.SDK_INT >= 21 && !DeviceUi.isTv(ctx))
            addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
    } catch (_: Throwable) {}
    return this
}

/** (v741) زرار ⏹: مربع أبيض مدوّر بيترسم مباشرة (مش أيقونة من باك) عشان يفضل باين فوق الخلفية الحمرا */
class StopSquareView(ctx: android.content.Context) : View(ctx) {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = android.graphics.Paint.Style.FILL }
    override fun onDraw(c: android.graphics.Canvas) {
        val sz = minOf(width, height) * 0.42f
        val cx = width / 2f; val cy = height / 2f
        val r = sz * 0.2f
        c.drawRoundRect(cx - sz / 2f, cy - sz / 2f, cx + sz / 2f, cy + sz / 2f, r, r, p)
    }
}

/** (v1187) عدّاد نت الفيديو ده: بايتات الشبكة الحقيقية اللي مصادر بيانات المشغّل بتسحبها (ستريمنج) — الكاش مابيتحسبش */
private val netStreamTl = object : androidx.media3.datasource.TransferListener {
    override fun onTransferInitializing(source: androidx.media3.datasource.DataSource, dataSpec: androidx.media3.datasource.DataSpec, isNetwork: Boolean) {}
    override fun onTransferStart(source: androidx.media3.datasource.DataSource, dataSpec: androidx.media3.datasource.DataSpec, isNetwork: Boolean) {}
    override fun onBytesTransferred(source: androidx.media3.datasource.DataSource, dataSpec: androidx.media3.datasource.DataSpec, isNetwork: Boolean, bytesTransferred: Int) { if (isNetwork) NetUse.streamed(bytesTransferred.toLong()) }
    override fun onTransferEnd(source: androidx.media3.datasource.DataSource, dataSpec: androidx.media3.datasource.DataSpec, isNetwork: Boolean) {}
}

/** (v1351) نسخة صفحة يوتيوب من المشغّل: نفس الأكتيفيتي بالظبط بس بتتعرّف في المانيفست بثيم شفاف (AppPlayerYtM) — قرار «خلي اللي تحتك ظاهر» بيتاخد من ثيم المانيفست مش من setTheme أثناء التشغيل (بطلب علي) */
class PlayerYtActivity : PlayerActivity()
