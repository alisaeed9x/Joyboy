# التغييرات في v1380

1. [إصلاح] إصلاح بيلد v1379: Unresolved reference 'imported' — المشغّل بيكلّم واجهة EngineBackend والعلم الجديد اتضاف على Engine الحقيقي، فبلوك فصل الترجمة المستوردة اتحوّل لـ realEngine مع حارس التهيئة
