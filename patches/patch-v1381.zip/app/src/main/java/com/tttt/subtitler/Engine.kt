package com.tttt.subtitler

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

interface Host {
    fun log(s: String)
    fun status(s: String)
    /** القائمة اتغيرت (الواجهة تحدّث الترجمة المعروضة) */
    fun changed()
    /** مكان التشغيل الحالي بالثواني */
    fun position(): Double
    /** مدة الفيديو من المشغّل (0 لو لسه مش معروفة) */
    fun playerDuration(): Double
    /** إشعار صغير للمستخدم (فشل/نجاح باتش) — الافتراضي مفيش */
    fun notice(s: String) {}
}

private class BadReply(msg: String) : Exception(msg)
/** (v151) مفتاح الباتش فشل ومفيش مفتاح فاضي دلوقتي: الباتش بيرجع للطابور ويستنى أقرب مفتاح يخلص باتشه (مش بيتحط فوق باتش شغال) */
private class RehomeEx(val avoid: String?) : Exception("rehome")

class Engine(
    @Volatile private var conf: Conf,
    private val openSource: () -> AudioSource,
    private val store: Store?,
    private val host: Host,
    private val pb: PromptBuilder
) {
    companion object {
        const val OVERLAP = 4.0          // ثواني تداخل بين المقاطع (زي الأصل)
        const val MAX_TRIES = 25
        const val MAX_FAILS = 3          // جولات فشل قبل ما المقطع يتحط كـ "فجوة"
        const val GAP_PASSES = 3         // كام مرة نعيد المحاولة في الفجوات تلقائيًا
        const val PRIOR_CAP = 400        // أقصى عدد جمل قديمة نبعتها للمراجعة
        const val CHAR_MIN_LINES = 12
        const val PRON_MIN_LINES = 20
        const val HOLE_MIN = 1.2         // أقل ثغرة صوتية من غير ترجمة نعيد طلبها (ثواني)
        const val HOLE_MAX = 14          // أقصى عدد ثغرات بنسدّها لكل مقطع
        const val TGROUP_MIN = 4         // (v210) الوضعين 3/4: أقل عدد باتشات منسوخة تتجمّع قبل ما تتبعت للترجمة (إلا لو الدنيا مستعجلة)
        const val TGROUP_MAX = 5         // (v210) أقصى عدد باتشات في طلب ترجمة واحد
        const val TR_MAX_WAIT_MS = 40_000L   // (v210) باتش منسوخ مستني الترجمة أكتر من كده يتبعت من غير ما يستنى التجميع
        const val QUAL_RETRY_BELOW = 60  // (v1178) باتش جودته أقل من كده بيتعاد تلقائي مرة واحدة
        const val TR_ROUNDS = 4          // (v210) جولات إعادة الجمل الناقصة قبل ما الباتش يرجع كطلب كامل (صوت ← ترجمة)
    }

    @Volatile private var engineStartMs = 0L   // (v1354) بداية الإنجن — للوج «أول باتش جه بعد قد إيه من الضغطة» (بطلب علي: الباتشات كانت بتقعد قبل ما تبدأ)
    @Volatile private var firstReqLogged = false
    private val lock = Any()
    /** المشغّل بيحمّل الترجمة المحفوظة في الخلفية: لحد ما يخلص ممنوع أي حفظ (عشان مانكتبش حالة فاضية فوق الترجمة المحفوظة) */
    @Volatile var persistBlocked = false
    /** (v139) بعد stop() الإنجن بيتقفل نهائيًا: أي رد متأخر من Gemini (طلب كان لسه في الجو) ما يقدرش يغيّر الترجمة ولا يتحفظ */
    @Volatile private var isClosed = false
    @Volatile var subs: List<Sub> = emptyList()
        private set(v) { if (!isClosed) field = v }
    private val chars = ArrayList<Chr>()
    private val gloss = ArrayList<Gloss>()
    private val tplCache = HashMap<String, String>()
    private val tplBusy = HashSet<String>()
    private val tplFails = HashMap<String, Int>()
    @Volatile private var srcLang = ""
    @Volatile private var detDone = false
    private val offSession = Offline.Session()   // (v267) قفل لغة الأوفلاين للفيديو ده
    private val groqRan = ThreadLocal<Boolean?>()   // (v1369) الباتش ده اتفرّغ بـ Groq
    private val groqLang = ThreadLocal<String?>()   // (v1369) لغة التفريغ اللي Groq اكتشفها
    private val chunkLang = ConcurrentHashMap<Int, String>()   // (v413) اللغة اللي اتفرّغ بيها كل باتش أوفلاين
    init { Offline.detectedLang = "" }
    private val langVote = OffLang.Vote()   // (v411) لغة المصدر للترجمة: Whisper + فحص الحروف (كانا/هانجول/هان)
    private val done = Ranges()
    private val failed = ConcurrentHashMap<Int, Int>()
    private val gapPass = ConcurrentHashMap<Int, Int>()
    @Volatile private var lastGapTry = 0L
    @Volatile private var basePool = Pool(conf)
    // (v210) الوضعين 3 و4: حوضين منفصلين — مفاتيح الترانسكريبشن (pool) ومفاتيح الترجمة (trPool). الاحتياطي مشترك. بيتبنوا من جديد بس لو المفاتيح/الوضع اتغيروا
    // (v220) تبديل وضع المفاتيح أثناء الترجمة: conf.keyMode = اللي اليوزر اختاره، activeMode = اللي الشغل الجاري ماشي بيه. لو اختلفوا: الباتشات الشغالة
    // (والمنسوخة المستنية ترجمة) بتخلص بالوضع القديم، مفيش باتشات جديدة بتتبعت، وبعدها activeMode بيتبدّل والباتشات الجديدة تمشي بالوضع الجديد.
    @Volatile private var activeMode: Int = conf.keyMode
    private val switching: Boolean get() = conf.keyMode != activeMode
    private fun drained(): Boolean = inflight.isEmpty() && tHold.isEmpty() && tTaken.isEmpty() && trBusy.get() == 0 && bkQ.isEmpty() && rehomeQ.isEmpty()
    private var splitSig = ""
    private var txP: Pool? = null
    private var trP: Pool? = null
    @Synchronized private fun splitPools(): Pair<Pool, Pool> {
        val c = conf
        val sig = activeMode.toString() + "|" + c.keys.joinToString(",") + "|" + c.backup.joinToString(",") + "|" + c.refine.joinToString(",")
        val a = txP; val b = trP
        if (a != null && b != null && sig == splitSig) return a to b
        val (nTx, nTr) = KeyMode.txTrCounts(c.keys.size, activeMode)
        val txKeys = c.keys.take(nTx)
        val trKeys = if (c.keys.size <= 1 || activeMode >= KeyMode.TRANSCRIBE_ALL) c.keys else c.keys.takeLast(nTr)   // (v219) الوضع 4: كل المفاتيح بتنسخ وكل المفاتيح بتترجم
        val p1 = Pool(c.withKeys(txKeys)); val p2 = Pool(c.withKeys(trKeys))
        txP = p1; trP = p2; splitSig = sig
        modeMsg = "🔑 وضع $activeMode: ${txKeys.size} مفتاح ترانسكريبشن + ${trKeys.size} مفتاح ترجمة" + (if (c.keys.size <= 1) " (مفتاح واحد بيعمل الاتنين)" else if (activeMode >= KeyMode.TRANSCRIBE_ALL) " (كل المفاتيح بتعمل الاتنين)" else "")   // (v413) مابتتطبعش إلا لما جيميناي يتنده فعلًا
        return p1 to p2
    }
    @Volatile private var modeMsg: String? = null
    private fun flushModeMsg() { val m = modeMsg ?: return; modeMsg = null; host.log(m) }
    // ===== (v1065) وضع الترجمة السريعة ⚡ =====
    /** مفعّل من الإعدادات (ترجمة سريعة). بيتثبّت وقت إنشاء المحرك: التغيير بيشتغل من أول ترجمة جديدة */
    @Volatile private var fastLatched: Boolean = try { Cfg.bool("fastmode", false) } catch (_: Throwable) { false }
    /** الباتش اللي بيتقسّم لخطوات بتكبر عشان أول ترجمة تظهر بدري؛ -1 = لسه مفيش */
    @Volatile private var rampChunk = -1
    @Volatile private var rampStep = 0
    @Volatile private var rampNext = -1.0
    private val RAMP_SECS = doubleArrayOf(10.0, 20.0, 30.0)
    /** (v1066) أول N باتشات في الوضع السريع بتروح ببرومبت خفيف ورد مختصر (start/end/original/translated بس) */
    private val FAST_LIGHT_N = 2
    /** (v1067) تسريع الصوت قبل الإرسال لأول خطوتين (1.0 = مطفي). الأوقات بترجع للأصل بالضرب */
    private val FAST_SPEED = 1.25
    /** (v1067) الخطوة الأولى = 30ث بتتقسم لطلبين بالتوازي على مفتاحين: 10ث + 20ث */
    private val FAST_FIRST_SECS = 10.0
    private val FAST_SPLIT_SECS = 30.0
    private class NoSplit : Exception()
    /** (v1141) تصاعد أول باتش (10←20←30←45←60ث) في الوضع الدقيق كمان (مش بس السريع). بيتثبّت وقت بداية الترجمة. في ٧٥/٢٥ (٣) خطوات أول باتش بتتفرّغ وتتترجم في نفس الطلب (زي fullChunks) عشان تظهر على طول؛ مش بيشتغل في الوضع ٤ (ترجمة سياقية بعد التفريغ كله) ولا المتوازن (محرك تاني) */
    @Volatile private var rampAllLatched = false
    private fun rampAllWanted(): Boolean = try { !Cfg.bool("fastmode", false) && !Cfg.bool("tr_bal", false) && Cfg.bool("ramp_all", true) } catch (_: Throwable) { false }
    private val rampOn: Boolean get() = (fastLatched || (rampAllLatched && activeMode < KeyMode.TRANSCRIBE_ALL)) && !groqTxOn()   // (v1379 — بطلب علي) مفيش ramp صغير في مود جروك: الباتش ٣٠ د من أول ضغطة
    private val RAMP_ALL = doubleArrayOf(10.0, 20.0, 30.0, 45.0, 60.0)
    private fun rampSizes(): DoubleArray = if (!fastLatched) RAMP_ALL else if (!Offline.on() && !groqTxOn() && pool.usableCount() >= 2) doubleArrayOf(FAST_SPLIT_SECS) else RAMP_SECS
    private fun scaleTimes(j: JSONObject, k: Double) {
        val a = j.optJSONArray("subtitles") ?: return
        for (x in 0 until a.length()) {
            val o = a.optJSONObject(x) ?: continue
            if (o.has("start")) o.put("start", Parse.sec(o, "start", 0.0) * k)
            if (o.has("end")) o.put("end", Parse.sec(o, "end", 0.0) * k)
        }
    }
    private val fastLight = ConcurrentHashMap.newKeySet<Int>()
    /** (v1152) السريع (موضع ≤ 2): كل الباتشات خفيفة (رد أقصر = أسرع). موضع 3 فوق بيرجع للأول باتشين بس */
    private fun lightAll(): Boolean = try { TrSlider.pos() <= 2 } catch (_: Throwable) { false }
    @Volatile private var lightAllLogged = false
    private fun lightOn(chunk: Int, hole: Boolean, tx: Boolean): Boolean = fastLatched && !hole && !tx && chunk >= 0 && !easternSrc() && !SongHint.on() &&   // (v1171) أغنية: مفيش برومبت خفيف   // (v1147) اللغات الشرقية: مفيش برومبت خفيف (السماع بيضعف)
        (chunk == rampChunk || chunk in fastLight || chunk in lightRetry)
    private val pool: Pool get() = if (activeMode >= KeyMode.SPLIT_A && !fastLatched) splitPools().first else basePool
    private val trPool: Pool get() = splitPools().second
    @Volatile private var running = true
    /** وقفة: المحرك مايبعتش مقاطع جديدة (مستني اختيار المستخدم: كمّل ولا ترجم من جديد) */
    @Volatile var paused = false
    /** إيقاف مؤقت بإيد المستخدم (زرار ⏸ في المشغّل): مفيش مقاطع جديدة بتتبعت لحد ما يتلغي — اللي شغال بيخلص عادي */
    @Volatile var userPaused = false
    /** لما الباتشات حوالين مكان التشغيل تخلص: كمّل ترجمة باقي الفيديو (قدّام ثم من الأول) بدل ما تقف */
    @Volatile var keepGoing = true
    /** ترجمة في الخلفية من غير مشغّل: بيمشي من أول مقطع ناقص وبيخلص لوحده */
    @Volatile var headless = false
    /** ترجمة باتشات محددة بس (0-based) — بعد ما تخلص المحرك بيستنى ومابيكمّلش لقدّام */
    @Volatile var onlyChunks: IntRange? = null
    /** لو اتحدد: المحرك يبدأ من المقطع ده بدل مكان التشغيل لحد ما المشاهدة توصله */
    @Volatile private var forcedCursor = -1
    @Volatile private var forcedSticky = false   // (v158) إعادة من باتش سابق: المؤشر يفضل عليه حتى لو مكان التشغيل بعده
    @Volatile private var fullRefineStarted = false
    /** (v160) مجالات الجمل اللي بتتنقّح دلوقتي (خط أزرق في شريط التقدم) */
    @Volatile var refiningSegs: List<DoubleArray> = emptyList()
    @Volatile private var fullRefineDone = false
    @Volatile private var finished = false
    @Volatile private var gapScanClean = false
    @Volatile var stoppedFlag = false
        private set
    var onFinished: ((Boolean) -> Unit)? = null
    @Volatile var fatal: String? = null
        private set
    @Volatile private var source: AudioSource? = null
    private val rr = AtomicInteger(0)
    private val bounds = ConcurrentHashMap<Int, Double>()      // بداية المقطع بعد تعديلها لأقرب صمت
    private val prepared = ConcurrentHashMap.newKeySet<Int>()
    private val trimLock = Any()
    private val inflight = ConcurrentHashMap.newKeySet<Int>()
    /** (v1139) باتشات الطلب بتاعها اتبعت لجيميناي فعلًا (inflight لوحده معناه «محجوز/بيتجهّز/في الطابور») — بيفرّق الأزرق الغامق من الفاتح في شريط التقدم */
    private val sentReq = ConcurrentHashMap.newKeySet<Int>()
    /** (v1139) السريع: باتش رجع فاضي ← إعادته ببرومبت خفيف (زي أول باتشين اللي بيطلعوا 100%) على مفتاح تاني */
    private val lightRetry = ConcurrentHashMap.newKeySet<Int>()
    // ===== توزيع الباتشات على المفاتيح + نسخة احتياطية للباتش المتأخر (كل باتش يتحسب مرة واحدة بس) =====
    private val startedAt = ConcurrentHashMap<Int, Long>()          // وقت بداية الباتش الشغال
    private val preps = ConcurrentHashMap<Int, Prep>()              // صوت الباتش الشغال (عشان النسخة الاحتياطية ماتفكوش تاني)
    private val prePrepped = ConcurrentHashMap<Int, Prep>()         // (v1370 — بطلب علي) صوت باتش اتفكّ مسبقًا أثناء إرسال اللي قبله — بيتبعت فورًا
    private val prePrepping = ConcurrentHashMap.newKeySet<Int>()    // (v1370) باتش صوته بيتفكّ في الخلفية دلوقتي
    private val offOf = ConcurrentHashMap<Int, Boolean>()               // (v413) الباتش ده ماشي على Whisper أوفلاين (مش جيميناي)
    private val groqOf = ConcurrentHashMap<Int, Boolean>()              // (v1369) الباتش ده ماشي على Groq
    private val keyOf = ConcurrentHashMap<Int, String>()            // المفتاح اللي الباتش شغال عليه دلوقتي
    private val hedged = ConcurrentHashMap.newKeySet<Int>()         // باتشات اتبعتلها نسخة احتياطية
    private val claimed = ConcurrentHashMap.newKeySet<Int>()        // باتشات نتيجتها اتطبّقت (أول نسخة تخلص تكسب)
    /** (v151) باتشات فاشلة مستنية أقرب مفتاح فاضي: avoid = المفتاح اللي فشلت عليه، prep = الصوت المفكوك (من غير فك تاني) */
    private class Rehome(val avoid: String?, val at: Long, val prep: Prep?)
    private val rehomeQ = ConcurrentHashMap<Int, Rehome>()
    /** (v420) الأوفلاين: الباتشات المتوازية = خانات الوشبر (Offline.par) حتى لو المفاتيح أقل */
    private val ppk: Int get() = if (Offline.on()) maxOf(conf.parallelPerKey, Offline.par()) else conf.parallelPerKey
    private val perKey get() = ppk.coerceIn(1, 4)
    private val hedgeBusy = AtomicInteger(0)
    private val recentMs = java.util.concurrent.ConcurrentLinkedDeque<Long>()   // أزمنة آخر باتشات خلصت
    // ===== مفتاح/موديل/زمن رد كل باتش =====
    class KeyRun(val keyNo: Int, val model: String, val ms: Long, val viaGemini: Boolean = true)
    private val runs = ConcurrentHashMap<Int, KeyRun>()                // آخر تنفيذ ناجح لكل باتش (مفتاح · موديل · زمن)
    private fun curModel(): String = conf.model
    private fun keyNo(k: String): Int = basePool.all().indexOf(k) + 1
    // (v1114) FIX 5: نقاط حالة المفاتيح — نقطة لكل مفتاح في الـ pool (العدد من الـ pool نفسه، من غير عدد ثابت) برقمه
    /** (v1373 — بطلب علي) حالة مفتاح جروك أثناء التفريغ: 0🔵 واقف · 4🟡 شغّال · 1🟢 نجح · 2🔴 فشل */
    private val groqDot = AtomicInteger(0)
    fun keyDots(): String {
        val dots = arrayOf("🔵", "🟢", "🔴", "🟠", "🟡")
        // (v1373 — بطلب علي) في التفريغ: حالة المزوّد الحقيقي بدل نقط مسبح جيميناي (بتتحرك وهو مش شغال فتبان كأن مفاتيح بتفشل وبتتبدّل)
        if (transOnly && groqTxOn()) return "⚡" + dots[groqDot.get()] + "1"
        if (transOnly && Offline.on()) return "🎙 ويسبر"
        val parts = pool.all().mapIndexed { idx, k -> dots[pool.dotState(k)] + (idx + 1) }
        return parts.joinToString(" ")
    }
    private fun shortModel(m: String) = m.removePrefix("gemini-")
    private fun fmtSec(ms: Long) = String.format(java.util.Locale.US, "%.1f", ms / 1000.0) + "ث"

    @Volatile private var maxApplied = -1                           // أعلى باتش اتطبّق (لو في باتش قبله لسه شغال يبقى متأخر)
    private val hedgeEx = Executors.newFixedThreadPool(2) { r -> Thread(r).also { it.isDaemon = true } }
    @Volatile private var anyApplied = false
    private val gapTried = Ranges()      // بتتحفظ بين الجلسات
    private val gapSession = Ranges()    // لجلسة التشغيل دي بس (للحد الأقصى)
    private val gapBusy = AtomicInteger(0)
    private val gapRetry = ConcurrentHashMap<Int, Int>()   // (v1304) فجوة فشلت بـ5xx بتتعاد 3 مرات بالكتير
    private val gapKeys = ConcurrentHashMap.newKeySet<String>()
    @Volatile private var lastGapScan = 0L
    private val gapEx = Executors.newFixedThreadPool(Gaps.MAX_PARALLEL) { r -> Thread(r).also { it.isDaemon = true } }
    private var exec: java.util.concurrent.ExecutorService? = null
    private var autoCharsAttempts = 0
    /** (v107) اسم الفيلم/المسلسل من اسم الملف + الفولدر — بنبحث بيه عن الشخصيات مرة واحدة */
    @Volatile var titleHint: String = ""
    @Volatile private var lookupState = 0   // 0 لسه · 1 شغال · 2 خلص
    /** (v170) العمل اتعرف عليه (من الاسم أو من الحوار) وشخصياته اتضافت */
    @Volatile private var castFound = false
    private var identTried = false
    private var chunksDone = 0; private var lastCharChunk = 0
    private var charsTrySize = 0
    private var charsBusy = false
    private var pronUpTo = 0
    private var pronBusy = false
    /** لهجة التحويل التلقائي: الترجمة بتتعمل بالفصحى الحرفية وكل ~3 باتشات بتتحوّل للهجة دي. "" = من غير تحويل */
    @Volatile var convDialect: String = ""
    /** (v280) «تفريغ بس»: النص بيتفرّغ ويتعرض بلغته الأصلية من غير ترجمة ولا تحويل لهجة ولا تنقيح ولا سدّ ثغرات.
     *  لما يتقفل بعد ما كان شغّال، الجمل الأجنبية بتتعالج بإصلاح اللغة الأجنبية التلقائي (جيميناي) زي ما بيحصل بعد الريستارت */
    @Volatile var transOnly: Boolean = false
        set(v) { val was = field; field = v; if (was && !v) previewChunks.clear() }
    /** (v467) اللغة الأساسية: المضيف بيظبط skipIfBaseLang في سياقات التشغيل التلقائي بس (فتح بـ autotr / مهام خلفية) — زرار «ترجم» اليدوي بيفرض الترجمة ويلغي التخطي */
    @Volatile var skipIfBaseLang = false
    @Volatile var baseLangCode = "ar"
    @Volatile var baseSkipped = false
    private fun langCodeOf(name: String): String { val n = name.trim().lowercase(); if (n.length <= 3 && n.all { it.code < 128 }) return n.substringBefore('-')
        return when { n.contains("arab") || n.contains("عرب") -> "ar"; n.contains("engl") || n.contains("إنجل") || n.contains("انجل") -> "en"; n.contains("french") || n.contains("français") || n.contains("فرنس") -> "fr"; n.contains("spanish") || n.contains("español") || n.contains("إسبان") || n.contains("اسبان") -> "es"; n.contains("german") || n.contains("deutsch") || n.contains("ألمان") || n.contains("المان") -> "de"; n.contains("turkish") || n.contains("türk") || n.contains("ترك") -> "tr"; n.contains("hindi") || n.contains("हिन्दी") || n.contains("هند") -> "hi"; n.contains("korean") || n.contains("한국") || n.contains("كور") -> "ko"; n.contains("japan") || n.contains("日本") || n.contains("يابان") -> "ja"; n.contains("chines") || n.contains("中文") || n.contains("صين") -> "zh"; n.contains("russian") || n.contains("روس") -> "ru"; n.contains("italian") || n.contains("إيطال") || n.contains("ايطال") -> "it"; n.contains("portugu") || n.contains("برتغال") -> "pt"; n.contains("persian") || n.contains("farsi") || n.contains("فارس") -> "fa"; n.contains("urdu") || n.contains("أردو") || n.contains("اردو") -> "ur"; else -> n.take(2) } }
    private fun checkBaseSkip() { if (!baseSkipped && skipIfBaseLang && detDone && srcLang.isNotEmpty() && langCodeOf(srcLang) == baseLangCode) { baseSkipped = true; transOnly = true; host.log("🏠 لغة الفيديو هي لغتك الأساسية ($srcLang) — الترجمة التلقائية اتخطّت والنص الأصلي هيظهر زي ما هو. عايز ترجمة غصب عنها؟ دوس زرار «ترجم»") } }
    /** (v468) كشف لغة احتياطي: لو جيميناي ما رجّعش detected_source_language، نستنتج من حروف أول نص متفرّغ — نسبة عربي > 60% من الحروف → عربية */
    private fun fallbackDetectLang(texts: List<Sub>) { if (detDone) return; val txt = texts.take(8).joinToString(" ") { it.original }; var ar = 0; var ko = 0; var ja = 0; var cy = 0; var tot = 0; for (ch in txt) { if (ch.isLetter()) { tot++; val c = ch.code; if (c in 0x0600..0x06FF || c in 0x0750..0x077F || c in 0xFB50..0xFDFF || c in 0xFE70..0xFEFF) ar++; if (c in 0xAC00..0xD7A3 || c in 0x1100..0x11FF) ko++; if (c in 0x3040..0x30FF) ja++; if (c in 0x0400..0x04FF) cy++ } }; val hit = when { tot >= 20 && ar * 100 / tot > 60 -> "عربية"; tot >= 20 && ko * 100 / tot > 60 -> "كورية"; tot >= 20 && ja * 100 / tot > 60 -> "يابانية"; tot >= 20 && cy * 100 / tot > 60 -> "روسية"; else -> "" }; if (hit.isNotEmpty()) { srcLang = hit; detDone = true; host.log("🌐 لغة الفيديو الأصلية (استنتاج احتياطي من النص): $hit"); checkBaseSkip() } } // (v468) البند 12: سكربتات مميزة بلا تداخل (هانغول/كانا/سيريلي) بجانب العربي
    /** أسلوب الترجمة الحي (تلقائي/حرفي/شعبي/جرئ) وشدته (خفيفة/متوسطة/شديدة): بيتحط في أول برومبت كل باتش جديد وكل تحويل لهجة */
    @Volatile var toneStyle: String = ""
    @Volatile var toneStrength: String = "متوسطة"
    /** (v1100) T2b: بلوك «أسلوب الترجمة» بيتحكم فيه السلايدر (يشتغل من الموضع 2)، أو لو اتختارت لهجة صريحة من سلايدر النوع (الشدة لازم تشتغل حتى في السريع) */
    private fun toneB(): String = toneBlock()   // (v1199) الأسلوب (حرفي/عائلي) بيتطبّق دايمًا مهما كان وضع السلايدر
    fun toneBlock(): String {
        // (v1199) أسلوبين بس: حرفي (زي ما اتقال بالملي) · عائلي (مناسب للمشاهدة العائلية). الشدة والأساليب القديمة اتشالت
        return if (TrNorm.style(toneStyle) == TrNorm.FAMILY)
            "\n═══ أسلوب الترجمة (إلزامي): مناسب للمشاهدة العائلية ═══\n- خفّف أي ألفاظ خارجة أو شتايم أو إيحاءات جنسية لألفاظ مهذّبة أو خفيفة تناسب كل الأعمار، مع الحفاظ على المعنى والقصد (مثلًا بدل اللفظ الصريح للجسم يتقال اللفظ الطبي أو المهذّب زي «ثدي»، وبدل الشتيمة الثقيلة تتقال شتيمة خفيفة زي «يا ابن الكلب» أو «يا حمار»).\n- متحذفش أي جملة ومتضيفش معاني أو ألفاظ مش موجودة في الأصل، وحافظ على جنس المتكلم والمخاطَب.\n\n"
        else
            "\n═══ أسلوب الترجمة (إلزامي): حرفي ═══\n- ترجم اللي اتقال زي ما هو بالملي: نفس الألفاظ ونفس حدّة الشتايم والإيحاءات من غير تخفيف ولا تنميق ولا مبالغة.\n- متضيفش ألفاظ أو معاني مش موجودة في الأصل، ومتشيلش اللي موجود، وحافظ على جنس المتكلم والمخاطَب.\n\n"
    }

    // ===== (v469) تحسينات المحرك والبرومبت: سياق باتش (A1) · أمثلة few-shot (A2) · ذاكرة موضوع (A3) · قاموس مقفول (A4) · أمانة أرقام (A5) · تحسين مرحلتين (A6) · كاش أسطر (A7) · تطبيع ASR (A8) · محسّن قراءة (A9) · وسوم غير كلام (A10) · ترتيب مفاتيح بالزمن (A11) · جودة ووقت متبقٍّ (A12) · إعادة سطر واحد (A13) =====
    /** ذاكرة الموضوع الجارية (A3): أول جمل اتترجمت فعلًا — بتتبعت مع الباتشات اللاحقة لاتساق الأسماء والمصطلحات */
    @Volatile private var topicDigest = ""
    /** أسماء علم/مصطلحات بتتكرر في أصول الجمل (A3) */
    private val termMemory = LinkedHashSet<String>()
    /** باتشات خلص فحص أمانتها خلاص — الفحص بيحصل مرة واحدة لكل باتش (A5) */
    private val fidDone = ConcurrentHashMap.newKeySet<Int>()
    /** درجة جودة آخر باتش اتطبّق (0..100، ‎-1 = لسه مفيش) — بتتعرض في سطر الحالة (A12) */
    @Volatile private var lastQuality = -1

    /** (v469) A4: قاموس المصطلحات المقفول من إعداد Cfg ‏"gloss" (أو "glossary" كبديل — الدمج مع واجهة المسرد القائمة) — كل سطر «مصدر=هدف» */
    private fun glossaryPairs(): List<Pair<String, String>> =
        try { Cfg.str("gloss", "").ifBlank { Cfg.str("glossary", "") }.lines().mapNotNull { ln -> val i = ln.indexOf('='); if (i <= 0) null else { val a = ln.substring(0, i).trim(); val b = ln.substring(i + 1).trim(); if (a.isEmpty() || b.isEmpty()) null else a to b } } } catch (_: Throwable) { emptyList() }

    private fun glossaryBlock(): String {
        val g = glossaryPairs(); if (g.isEmpty()) return ""
        return "\n═══ قاموس مصطلحات مقفول (إلزامي) ═══\n- المصطلحات دي تتترجم بالظبط زي ما هي مكتوبة، في كل مرة تظهر:\n" + g.joinToString("\n") { "- ${it.first} ← ${it.second}" } + "\n"
    }

    /** (v469) A4: تطبيق قسري بعد الاستلام — مصطلح مصدر فضل زي ما هو جوه الترجمة (الموديل سابه من غير ما يترجمه) بيتبدّل بهدفه من القاموس */
    private fun enforceGlossary(list: List<Sub>): List<Sub> {
        val g = glossaryPairs(); if (g.isEmpty()) return list
        var n = 0
        val out = list.map { s ->
            if (s.isSound || s.translated.isBlank()) s else {
                var t = s.translated; var hit = false
                for ((a, b) in g) { if (s.original.contains(a, true) && t.contains(a, true) && !t.contains(b)) { t = t.replace(a, b, true); hit = true } }
                if (hit) { n++; s.copy(translated = t) } else s
            }
        }
        if (n > 0) host.log("📖 قاموس مقفول: اتظبط $n سطر بمصطلحات القاموس")
        return out
    }

    /** (v469) A2: مثالان ترجمة جاهزان بلهجة الهدف الحالية — بيتظبط بيهم الأسلوب المطلوب */
    private fun fewShotBlock(): String {
        val lang = convDialect.ifBlank { conf.lang }
        val ex = when (lang) {
            "مصري" -> "EN: \"I didn't expect to see you here.\" ← «مكنتش متوقع أشوفك هنا.»\nEN: \"We have to leave right now, hurry up!\" ← «لازم نمشي دلوقتي حالًا، يلا بسرعة!»"
            "فصحى" -> "EN: \"I didn't expect to see you here.\" ← «لم أتوقّع أن أراك هنا.»\nEN: \"We have to leave right now, hurry up!\" ← «علينا أن نغادر الآن فورًا، أسرع!»"
            else -> "EN: \"I didn't expect to see you here.\" ← «لم أتوقّع أن أراك هنا.»\nEN: \"We have to leave right now, hurry up!\" ← «علينا أن نغادر الآن فورًا، أسرع!»\n(الأمثلة للتوضيح بس: طبّق نفس الأسلوب بلهجة $lang.)"
        }
        return "\n═══ أمثلة على الترجمة المطلوبة (للأسلوب فقط — ما تردّهاش في الرد) ═══\n$ex\n"
    }

    /** (v469) A3: تحديث ذاكرة الموضوع من جمل لسه متطبّقة (أول ترجمات + أسماء علم لاتينية متكررة) */
    private fun noteTopic(applied: List<Sub>) {
        try {
            synchronized(termMemory) {
                for (s in applied) for (w in s.original.split(Regex("[\\s,;:.!?؟،\"'()«»]+"))) { val t = w.trim(); if (t.length >= 3 && t.first().isUpperCase() && t.any { it.code in 65..122 }) termMemory.add(t) }
                while (termMemory.size > 30) termMemory.remove(termMemory.first())
            }
            if (topicDigest.isEmpty()) {
                val first = synchronized(lock) { subs.filter { !it.isSound && it.translated.isNotBlank() && it.translated != it.original }.take(5) }
                if (first.size >= 3) topicDigest = first.joinToString(" / ") { it.translated.trim() }.take(300)
            }
        } catch (_: Throwable) {}
    }

    private fun topicBlock(): String {
        val names = synchronized(termMemory) { termMemory.toList() }
        if (topicDigest.isEmpty() && names.isEmpty()) return ""
        var b = "\n═══ ذاكرة الموضوع (لاتساق الأسماء والمصطلحات) ═══\n"
        if (topicDigest.isNotEmpty()) b += "- بداية الفيديو اتترجمت كده (خليك على نفس الأسماء والمصطلحات): $topicDigest\n"
        if (names.isNotEmpty()) b += "- أسماء/مصطلحات بتتكرر في الكلام: " + names.joinToString("، ") + "\n"
        return b
    }

    /** (v469) A1: سطر قبل وسطر بعد الباتش الحالي، مميزين كسياق للاطّلاع بس */
    private fun ctxLinesBlock(prevLine: String, nextLine: String): String {
        if (prevLine.isBlank() && nextLine.isBlank()) return ""
        var b = "\n═══ سياق الباتش (للاطّلاع فقط — ما تترجموش وما تردّوش في الرد) ═══\n"
        if (prevLine.isNotBlank()) b += "- قبل: «${prevLine.trim().take(160)}»\n"
        if (nextLine.isNotBlank()) b += "- بعد: «${nextLine.trim().take(160)}»\n"
        return b
    }

    /** (v469) إضافات البرومبت في مكان واحد: سياق (A1) + ذاكرة موضوع (A3) + أمثلة (A2) + قاموس مقفول (A4) */
    private fun promptExtras(prevLine: String = "", nextLine: String = "", withCtx: Boolean = true): String =
        (if (withCtx && TrSlider.on("ctx")) ctxLinesBlock(prevLine, nextLine) else "") + (if (TrSlider.on("topic")) topicBlock() else "") + (if (TrSlider.on("fewshot")) fewShotBlock() else "") + glossaryBlock()   // (v1100) T2b: السلايدر

    /** (v469) A1: أقرب جملة معروفة قبل بداية الباتش (أصلها + ترجمتها لو موجودة) وأقرب جملة بعد نهايته — لبرومبتات الصوت */
    private fun chunkPrevLine(start: Double): String = try { synchronized(lock) { subs.lastOrNull { it.start < start - 0.01 } }?.let { s -> s.original.trim() + (if (s.translated.isNotBlank() && s.translated != s.original) " ← " + s.translated.trim() else "") } ?: "" } catch (_: Throwable) { "" }
    private fun chunkNextLine(start: Double, durSec: Double): String = try { synchronized(lock) { subs.firstOrNull { it.start >= start + durSec - 0.01 } }?.original?.trim() ?: "" } catch (_: Throwable) { "" }

    /** (v469) A8: تطبيع علامات ترقيم كلام ASR في النسخة اللي بتتبعت للترجمة بس (الأصل المحفوظ ما بيتلعبش فيه): مسافات مضغوطة، مفيش مسافة قبل علامة، علامات مكررة بتتلمّ */
    private fun normAsr(t: String): String {
        var s = t.replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) return s
        s = s.replace(Regex("\\s+([.,!?؟،;:])"), "$1")
        s = s.replace(Regex("\\.{3,}"), "…").replace(Regex("\\.{2}"), ".")
        s = s.replace(Regex("!{2,}"), "!").replace(Regex("؟{2,}"), "؟").replace(Regex("\\?{2,}"), "?")
        s = s.replace(Regex("([!?؟،,])\\1+"), "$1")
        // (v739) هلوسة وشبر الصغير: نفس الكلمة/الجملة 4 مرات فأكتر ورا بعض (زي «يلا يلا يلا…») بتتقص لتلات مرات في النسخة المبعوتة للترجمة بس (الأصل المحفوظ زي ما هو)
        s = s.replace(Regex("([^\\s,،、，.。!?؟]{2,24})(?:[\\s,،、，.。!?؟]+\\1){3,}"), "$1 $1 $1")
        s = s.replace(Regex("(\\S{3,24}?)\\1{4,}"), "$1$1$1")
        return s.trim()
    }

    /** (v469) A10: وسوم غير الكلام ([موسيقى] [ضحك] [تصفيق] وأخواتها) — بتتحجز قبل الإرسال وترجع زي ما هي */
    private val soundTagRe = Regex("\\[(موسيقى|ضحك|تصفيق|بكاء|صراخ|تنهّد|تنهد|همس|صفير|رعد|انفجار|طلقات|أغنية|غناء)[^\\]]*\\]")
    private fun protectTags(t: String): Pair<String, Map<String, String>> {
        if (!t.contains('[')) return t to emptyMap()
        val map = LinkedHashMap<String, String>(); var i = 0
        val out = soundTagRe.replace(t) { mr -> val ph = "⟦T${i++}⟧"; map[ph] = mr.value; ph }
        return out to map
    }
    private fun restoreTags(t: String, map: Map<String, String>): String {
        if (map.isEmpty()) return t
        var out = t
        for ((ph, tag) in map) out = out.replace(ph, tag)
        return out
    }
    /** (v469) A10 شبكة أمان: سطر أصله فيه وسم معروف وترجمته فقدته → الوسم بيرجع في أول الترجمة */
    private fun restoreKnownTags(orig: String, tr: String): String {
        if (tr.isBlank() || !orig.contains('[')) return tr
        val tags = soundTagRe.findAll(orig).map { it.value }.toList()
        if (tags.isEmpty()) return tr
        val missing = tags.filter { !tr.contains(it) }
        if (missing.isEmpty()) return tr
        return (missing.joinToString(" ") + " " + tr).trim()
    }

    // ===== (v469) A7: كاش أسطر دائم عبر الفيديوهات — hash(نص المصدر + اللهجة + الأسلوب) ← ترجمة، في ملف JSON في مجلد التطبيق =====
    // (v1177) كاش LRU محدود (20000): أقدم سطر استُخدم هو اللي يتشال — كل وصول لازم يتم جوه synchronized(lineCache)
    private val lineCache = object : LinkedHashMap<String, String>(1024, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean = size > 20000
    }
    @Volatile private var lineCacheLoaded = false
    private val lineCacheSavePending = AtomicBoolean(false)
    private fun cacheKey(orig: String, gender: String = "", prev: String = ""): String {
        val norm = orig.trim().replace(Regex("\\s+"), " ").lowercase()
        var raw = norm + "|" + convDialect.ifBlank { conf.lang } + "|" + conf.style + "|" + toneStyle
        // (v1177) السطور القصيرة (أقل من 4 كلمات: "Yes." / "What?") معناها بيتغيّر بالسياق ← المفتاح بيشمل جنس المتكلم والسطر اللي قبلها. الطويلة مفتاحها زي ما هو (الكاش القديم يفضل شغال)
        if (norm.split(' ').size < 4) raw += "|g=" + gender.lowercase() + "|p=" + prev.trim().replace(Regex("\\s+"), " ").lowercase().take(120)
        return try { val d = java.security.MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8)); d.map { "%02x".format(it) }.joinToString("") } catch (_: Throwable) { raw.hashCode().toString() }
    }
    private fun lineCacheFile(): java.io.File? = try { Offline.dir?.let { java.io.File(it, "trcache_v469.json") } } catch (_: Throwable) { null }
    private fun lineCacheLoad() {
        if (lineCacheLoaded) return
        synchronized(lineCache) {
            if (lineCacheLoaded) return
            lineCacheLoaded = true
            try {
                val f = lineCacheFile() ?: return
                if (!f.isFile) return
                val j = JSONObject(f.readText(Charsets.UTF_8))
                val ks = j.keys()
                while (ks.hasNext()) { val k = ks.next(); val v = j.optString(k, ""); if (v.isNotBlank()) lineCache[k] = v }
                if (lineCache.isNotEmpty()) host.log("💾 كاش الأسطر: اتحمّل ${lineCache.size} سطر من ترجمات قبل كده")
            } catch (e: Exception) { LogStore.err("Engine:lineCacheLoad", e) }
        }
    }
    private fun lineCacheSaveNow() {
        try {
            val f = lineCacheFile() ?: return
            val j = JSONObject()
            val snap = synchronized(lineCache) { lineCache.entries.map { it.key to it.value } }   // (v1177) لقطة تحت القفل، بالترتيب (الأقدم أولًا)
            for ((k, v) in snap) j.put(k, v)
            val tmp = java.io.File(f.parentFile, f.name + ".tmp")
            tmp.writeText(j.toString(), Charsets.UTF_8)
            if (!tmp.renameTo(f)) { try { f.writeText(j.toString(), Charsets.UTF_8); tmp.delete() } catch (_: Throwable) {} }
        } catch (e: Exception) { LogStore.err("Engine:lineCacheSave", e) }
    }
    private fun lineCacheSaveSoon() {
        if (!lineCacheSavePending.compareAndSet(false, true)) return
        try { persistEx.schedule({ lineCacheSavePending.set(false); lineCacheSaveNow() }, 15, java.util.concurrent.TimeUnit.SECONDS) }
        catch (_: Exception) { lineCacheSavePending.set(false); lineCacheSaveNow() }
    }
    private fun lineCacheGet(orig: String, gender: String = "", prev: String = ""): String? { if (orig.isBlank()) return null; lineCacheLoad(); val k = cacheKey(orig, gender, prev); return synchronized(lineCache) { lineCache[k] } }
    private fun lineCachePut(orig: String, tr: String, gender: String = "", prev: String = "") {
        val o = orig.trim(); val t = tr.trim()
        if (o.isEmpty() || t.isEmpty() || o == t) return
        lineCacheLoad()
        val k = cacheKey(o, gender, prev)
        val changed = synchronized(lineCache) { if (lineCache[k] == t) false else { lineCache[k] = t; true } }
        if (changed) lineCacheSaveSoon()
    }
    /** (v469) A7: تعبئة ترجمات جاهزة من الكاش في مصفوفة مجموعة قبل أي إرسال — بيرجع عدد الجمل اللي اتوفرت (مفاتيح API ما بتتصرفش عليها) */
    private fun cachePrefill(flat: List<Sub>, tr: Array<String?>): Int {
        if (!TrSlider.on("cache")) return 0   // (v1100) T2b: السلايدر
        var n = 0
        val gl = glossaryPairs()   // (v1177) سطر فيه مصطلح قاموس ما بيتسحبش من الكاش (القاموس ممكن يكون اتغيّر بعد ما اتخزّن)
        for (i2 in flat.indices) {
            val s = flat[i2]
            if (s.isSound || s.isSong || s.original.isBlank()) continue
            if (gl.isNotEmpty() && gl.any { s.original.contains(it.first, true) }) continue
            val c = lineCacheGet(s.original, s.gender, flat.getOrNull(i2 - 1)?.original ?: "")
            if (!c.isNullOrBlank()) { tr[i2] = c; n++ }
        }
        return n
    }

    /** (v469) A5: أرقام نص (مُطبّعة: أرقام عربية/هندية ← لاتينية) بترتيب ظهورها */
    private fun numTokens(t: String): List<String> {
        val norm = t.map { ch -> when (ch) { in '٠'..'٩' -> '0' + (ch - '٠'); in '۰'..'۹' -> '0' + (ch - '۰'); else -> ch } }.joinToString("")
        return Regex("\\d+(?:[.,]\\d+)?").findAll(norm).map { it.value.replace(",", "") }.toList()
    }
    /** (v469) A5: الأرقام الموجودة في الأصل وناقصة من الترجمة (مقارنة كمجموعة بعدّادات) */
    private fun missingNums(s: Sub): List<String> {
        val src = numTokens(s.original); if (src.isEmpty()) return emptyList()
        val dst = numTokens(s.translated).toMutableList(); val miss = ArrayList<String>()
        for (n in src) { if (!dst.remove(n)) miss.add(n) }
        return miss
    }
    /** (v469) A5+A13: إعادة ترجمة سطر واحد بسياق جيرانه (متزامن — بيتنادى من خيوط خلفية بس). null = فشل/مش متاح */
    private fun retranslateLineSync(s: Sub, prev: Sub?, next: Sub?): String? {
        if (transOnly || keyless) return null
        val sb = StringBuilder()
        sb.append("ترجم الجملة المستهدفة بس من لغة الفيديو الأصلية إلى ").append(convDialect.ifBlank { conf.lang }).append(" (أسلوب: ").append(conf.style).append(")، وحافظ على كل الأرقام والأسماء زي ما هي بالظبط من غير أي تغيير.\n")
        if (prev != null) sb.append("سياق قبل: «").append(prev.original.trim().take(160)).append("» ← ترجمته: «").append(prev.translated.trim().take(160)).append("»\n")
        if (next != null) sb.append("سياق بعد: «").append(next.original.trim().take(160)).append("»\n")
        sb.append("الجملة المستهدفة: «").append(normAsr(s.original).take(300)).append("»\n")
        sb.append(glossaryBlock())
        sb.append("رد JSON فقط: {\"t\":\"الترجمة\"}")
        val j = try { askJson(sb.toString(), 700, trPool, "إعادة سطر") } catch (_: Exception) { null } ?: return null
        val t = j.optString("t", "").trim()
        if (t.isEmpty() || LangGuard.foreign(s.copy(translated = t))) return null
        return restoreKnownTags(s.original, t)
    }
    /** (v469) A5: فحص أمانة بعد تطبيق مجموعة — سطر ناقصه رقم بيترجم من جديد مرة واحدة بس لكل باتش */
    private fun fidelityFix(chunk: Int, list: List<Sub>): List<Sub> {
        if (transOnly || keyless || list.isEmpty() || !TrSlider.on("fidelity")) return list   // (v1097) T2 السلايدر
        val bad = list.indices.filter { !list[it].isSound && list[it].translated.isNotBlank() && missingNums(list[it]).isNotEmpty() }
        if (bad.isEmpty()) return list
        if (!fidDone.add(chunk)) return list
        val out = list.toMutableList(); var fixed = 0
        for (ix in bad.take(3)) {
            val nt = try { retranslateLineSync(out[ix], out.getOrNull(ix - 1), out.getOrNull(ix + 1)) } catch (_: Exception) { null }
            if (!nt.isNullOrBlank()) { out[ix] = out[ix].copy(translated = nt); fixed++ }
        }
        host.log("🔢 أمانة الأرقام (باتش ${chunk + 1}): ${bad.size} سطر كان ناقصه رقم — اتعاد ترجمة $fixed منهم")
        return out
    }

    /** (v469) A6: وضع التحسين على مرحلتين (إعداد Cfg ‏refine2pass، افتراضي مطفي) — المسودة بترجع لنفس الموديل لمراجعة سلاسة بس، المعنى والأرقام والأسماء ثابتة */
    private fun refinePass2(chunk: Int, list: List<Sub>): List<Sub> {
        if (list.size < 2 || transOnly || keyless) return list
        val idx = list.indices.filter { !list[it].isSound && !list[it].isSong && list[it].translated.isNotBlank() }
        if (idx.size < 2) return list
        val arr = JSONArray()
        for (i2 in idx) { val o = JSONObject(); o.put("src", normAsr(list[i2].original).take(220)); o.put("tr", list[i2].translated.take(220)); arr.put(o) }
        val prompt = "دي ترجمة مسودة لجمل متتالية (src = الأصل، tr = المسودة). حسّن سلاسة وطبيعية tr بس: نفس المعنى بالظبط، من غير ما تغيّر أي رقم أو اسم أو معلومة، وبنفس اللهجة (" + convDialect.ifBlank { conf.lang } + ").\n" + arr.toString() + "\nرد JSON فقط بنفس العدد والترتيب: {\"lines\":[\"...\",\"...\"]}"
        val j = try { askJson(prompt, (idx.size * 120).coerceIn(1024, 8192), trPool, "تحسين مرحلتين") } catch (_: Exception) { null } ?: return list
        val lines = j.optJSONArray("lines") ?: return list
        if (lines.length() != idx.size) return list
        val out = list.toMutableList(); var n = 0
        for ((q, i2) in idx.withIndex()) { val t = lines.optString(q, "").trim(); if (t.isNotEmpty() && t != out[i2].translated && numTokens(t).containsAll(numTokens(out[i2].original))) { out[i2] = out[i2].copy(translated = t); n++ } }
        if (n > 0) host.log("✨ تحسين على مرحلتين (باتش ${chunk + 1}): اتحسّن $n سطر")
        return out
    }

    /** (v469) A12: درجة جودة بسيطة لباتش (فراغات + نسبة طول شاذة + أرقام ناقصة) — 0..100 */
    private fun batchQuality(fresh: List<Sub>): Int {
        val lines = fresh.filter { !it.isSound && it.original.isNotBlank() }
        if (lines.isEmpty()) return -1
        var pen = 0.0
        for (s in lines) {
            if (s.translated.isBlank()) { pen += 25; continue }
            val r = s.translated.length.toDouble() / maxOf(1, s.original.length)
            if (r < 0.25 || r > 3.0) pen += 12
            if (missingNums(s).isNotEmpty()) pen += 15
            if (try { LangGuard.foreign(s) } catch (_: Throwable) { false }) pen += 20   // (v1178) سطر لغته غلط/أجنبي
            val dur = s.end - s.start
            if (dur > 0.3 && s.translated.length / dur > 22.0) pen += 8   // (v1178) سرعة قراءة أعلى من ~22 حرف/ث
        }
        return (100 - (pen / lines.size) * 4).toInt().coerceIn(0, 100)
    }
    /** (v469) A12: وقت متبقٍّ تقريبي من متوسط أزمنة آخر باتشات × الباتشات الباقية ÷ التوازي */
    private fun etaText(d: Double): String {
        if (d <= 0 || recentMs.isEmpty()) return ""
        val total = chunkCount(); if (total <= 0) return ""
        var doneN = 0; var i = 0
        while (cStart(i) < d) { if (isDone(i, d)) doneN++; i++ }
        val left = total - doneN
        if (left <= 0) return ""
        val avg = recentMs.toList().average()
        if (avg <= 0) return ""
        val par = maxOf(1, minOf(pool.capacity(ppk), 8))
        val sec = (left * avg / 1000.0 / par).toInt()
        if (sec < 20) return ""
        return " — ⏱ متبقي ~" + (if (sec >= 90) "${(sec + 59) / 60} د" else "$sec ث")
    }
    private val convBusy = AtomicBoolean(false)
    @Volatile private var lastConvFail = 0L
    @Volatile private var convFailN = 0
    /** (v150) جمل conv=true لسه شكلها فصحى: بتتعاد مرة واحدة بس (عشان ما نلفّش في حلقة) */
    private val msaTried = ConcurrentHashMap.newKeySet<String>()
    private fun needsConv(s: Sub) = !s.conv || (Msa.fusha(s) && pk(s) !in msaTried)
    /** باتشات رجعت ناقصة (رد اتقطع / من غير جمل رغم وجود صوت) */
    private val incomplete = ConcurrentHashMap.newKeySet<Int>()
    private val bg = Executors.newFixedThreadPool(2) { r -> Thread(r).also { it.isDaemon = true } }
    private val ch get() = conf.chunkSec.toDouble()
    /** عدد المقاطع قدّام = الأكبر بين الإعداد وعدد الطلبات المتوازية، عشان كل المفاتيح تشتغل مع بعض */
    private val window get() = if (groqTxOn()) 1 else maxOf(conf.ahead.coerceAtLeast(1), pool.capacity(ppk))   // (v1379) جروك باتش-باتش (بطلب علي): باتش ٣٠د واحد بيرفع لوحده والتجهيز المسبق بيجهّز اللي بعده — رفع متوازي بيأخر أول جملة

    // ===== واجهة للـ UI =====
    fun failedCount() = failed.count { it.value >= MAX_FAILS }
    /** (v146) سطر لكل باتش + هل هو الأسرع في دفعته (بيتلوّن أخضر). الدفعة = الباتشات اللي بتتبعت مع بعض (عددها = عدد الطلبات المتوازية) */
    /** (دمج v1081) مجالات الباتشات اللي اتبعتت (أو اتفرّغت ومستنية الترجمة) ولسه ما اتكتبتش — خط/نقط زرقا في شريط التقدم */
    fun inflightSegs(): List<DoubleArray> {
        if (inflight.isEmpty() && tHold.isEmpty()) return emptyList()
        val d = currentDur(); if (d <= 0) return emptyList()
        val ids = java.util.TreeSet<Int>(); ids.addAll(inflight); ids.addAll(tHold.keys)
        val out = ArrayList<DoubleArray>()
        for (k in ids) { if (cStart(k) >= d || isDone(k, d)) continue; out.add(doubleArrayOf(cStart(k), cEnd(k, d), if (k in sentReq || tHold.containsKey(k)) 1.0 else 0.0)) }   // (v1139) العنصر التالت: 1 = اتبعت فعلًا · 0 = محجوز/بيتجهّز/في الطابور
        return out
    }

    fun batchRows(): List<Pair<String, Boolean>> {
        val d = host.playerDuration()
        val c = (host.position() / ch).toInt().coerceAtLeast(0)
        val cap = pool.capacity(ppk).coerceAtLeast(1)
        val out = ArrayList<Pair<String, Boolean>>()
        val fastest = HashMap<Int, Int>()   // الدفعة → رقم الباتش الأسرع
        val byWave = runs.entries.groupBy { it.key / cap }
        for ((wv, es) in byWave) if (es.size >= 2) fastest[wv] = es.minByOrNull { it.value.ms }!!.key
        for (i in maxOf(0, c - 1)..c + window + 1) {
            if (d > 0 && cStart(i) >= d) break
            val mark = when {
                i in inflight -> "⏳"
                tHold.containsKey(i) -> "📝"
                (failed[i] ?: 0) >= MAX_FAILS -> "❌"
                i in incomplete -> "⚠"
                isDone(i, d) -> if (subCount(i, d) == 0) "🔇" else "✅"
                (failed[i] ?: 0) > 0 -> "🔁"
                else -> "▫"
            }
            val a = cStart(i).toInt(); val b = cEnd(i, d).toInt()
            val sb = StringBuilder()
            sb.append(if (i == c) "▶ " else "  ").append("باتش ").append(i + 1).append(" ")
                .append("%d:%02d–%d:%02d".format(a / 60, a % 60, b / 60, b % 60)).append(" ").append(mark)
            if (mark == "✅" || mark == "🔁" || mark == "🔇") sb.append(" ").append(subCount(i, d)).append(" جملة")
            val k = keyOf[i]
            val r = runs[i]
            var fast = false
            if (mark == "⏳" && k != null) {
                if (offOf[i] == true) sb.append(" · 🎙 Whisper أوفلاين") else if (groqOf[i] == true) sb.append(" · ⚡ Groq") else sb.append(" · 🔑").append(keyNo(k)).append(" ").append(shortModel(conf.model))
                startedAt[i]?.let { sb.append(" · ").append(fmtSec(System.currentTimeMillis() - it)) }
            } else if (r != null && (mark == "✅" || mark == "🔇" || mark == "🔁")) {
                fast = fastest[i / cap] == i
                if (r.viaGemini) sb.append(" · 🔑").append(r.keyNo).append(" · ").append(fmtSec(r.ms)).append(" · ").append(shortModel(r.model)).append(if (fast) " ⚡" else "")
                else sb.append(" · 🎙 Whisper · ").append(fmtSec(r.ms)).append(if (fast) " ⚡" else "")
            }
            out.add(Pair(sb.toString(), fast))
        }
        return out
    }
    // ===== أشرطة التقدم (v56) =====
    /** جمل مستنية تتغيّر (تحويل لهجة / إعادة صياغة / تصحيح ضمائر) — مفتاحها start|original */
    private val pend = ConcurrentHashMap.newKeySet<String>()
    private fun pk(s: Sub) = "${s.start}|${s.original}"
    /** مجالات فيها جمل ترجمة فعلًا (الشريط الأخضر): بيتقطع عند الفجوات الحقيقية (> 2ث) مش عند حدود الباتشات */
    fun coverageSegs(): List<DoubleArray> = Coverage.spans(subs, 2.0)
    /** مجالات الجمل اللي لسه هتتغير (الشريط التالت)، فاضية لما كل الجمل تتغير */
    fun pendingSegs(): List<DoubleArray> { if (pend.isEmpty()) return emptyList(); return Coverage.spans(subs.filter { pk(it) in pend }, 3.0) }
    fun pendingCount(): Int = pend.size

    fun coveredSec() = done.total()
    fun durationSec(): Double = currentDur()
    fun chunkCount(): Int { val d = currentDur(); if (d <= 0) return 0; var i = 0; while (cStart(i) < d) i++; return i }
    fun awaitStopped(ms: Long) { val t0 = System.currentTimeMillis(); while (!stoppedFlag && System.currentTimeMillis() - t0 < ms) try { Thread.sleep(50) } catch (_: InterruptedException) { return } }

    class BatchInfo(val idx: Int, val start: Double, val end: Double, val mark: String, val count: Int = 0)
    /** كل الباتشات بحالتها (✅ خلص · ⏳ بيترجم · ❌ فشل · 🔁 بيعيد · ▫ لسه) — لقايمة إعادة الترجمة */
    fun batches(): List<BatchInfo> {
        val d = currentDur(); if (d <= 0) return emptyList()
        val out = ArrayList<BatchInfo>(); var i = 0
        while (cStart(i) < d) {
            val mark = when {
                i in inflight -> "⏳"
                tHold.containsKey(i) -> "📝"
                (failed[i] ?: 0) >= MAX_FAILS -> "❌"
                i in incomplete -> "⚠"
                isDone(i, d) -> if (subCount(i, d) == 0) "🔇" else "✅"
                (failed[i] ?: 0) > 0 -> "🔁"
                else -> "▫"
            }
            out.add(BatchInfo(i, cStart(i), cEnd(i, d), mark, subCount(i, d))); i++
        }
        return out
    }
    /** الباتشات اللي ما اترجمتش (❌) أو رجعت ناقصة (⚠) وملهاش طلب شغال دلوقتي */
    fun problems(): List<BatchInfo> {
        // بتتنادي من الواجهة كل ~0.7ث: ما نلفّش على كل باتشات الفيديو ونعدّ الجمل لكل واحد — بس على الباتشات الفاشلة/الناقصة
        val idx = java.util.TreeSet<Int>()
        for ((k, v) in failed) if (v >= MAX_FAILS) idx.add(k)
        idx.addAll(incomplete)
        if (idx.isEmpty()) return emptyList()
        val d = currentDur(); if (d <= 0) return emptyList()
        return idx.filter { it !in inflight && cStart(it) < d }
            .map { BatchInfo(it, cStart(it), cEnd(it, d), if ((failed[it] ?: 0) >= MAX_FAILS) "❌" else "⚠", 0) }
    }
    // ===== إعادة تلقائية للباتشات الفاشلة/الناقصة (من غير ما المستخدم يدوس حاجة) =====
    private val autoTries = ConcurrentHashMap<Int, Int>()
    private val autoAt = ConcurrentHashMap<Int, Long>()
    private val announced = ConcurrentHashMap.newKeySet<Int>()
    private var lastAutoTick = 0L
    private fun autoRetryTick() {
        val now = System.currentTimeMillis()
        if (now - lastAutoTick < 4000L) return
        lastAutoTick = now
        val d = currentDur(); if (d <= 0) return
        // باتش اتبلّغ إنه فشل واتترجم دلوقتي → إشعار نجاح صغير
        for (i in announced.toList()) {
            if (i in inflight || i in incomplete || (failed[i] ?: 0) >= MAX_FAILS || !isDone(i, d)) continue
            announced.remove(i); autoTries.remove(i); autoAt.remove(i)
            host.notice("✅ تمت ترجمة باتش ${i + 1}")
            host.log("✅ باتش ${i + 1}: اتترجم بعد الإعادة التلقائية")
        }
        for (b in problems()) {
            val i = b.idx
            // (v1377) وi !in extractNull: فشل الفك مش «رجع من غير جمل» — مابتتختمش «فاضي» بعد إعادة واحدة، يفضل ⚠ ويكمل مسار الـ٣ محاولات وإشعار ⛔ ظاهر بدل الاختفاء الصامت
            val zero = b.mark == "⚠" && subCount(i, d) == 0 && i !in extractNull
            val limit = if (zero) 1 else 3
            val n = autoTries[i] ?: 0
            if (n >= limit) {
                if (zero) { incomplete.remove(i); announced.remove(i); host.notice("🔇 باتش ${i + 1}: اتأكدت إن مفيهوش جمل"); host.log("🔇 باتش ${i + 1}: اتعاد وبرضه من غير جمل — اتأكد إنه فعلاً فاضي") }
                else if (announced.remove(i)) { host.notice("⛔ باتش ${i + 1} لسه فاشل بعد $n محاولات"); host.log("⛔ باتش ${i + 1}: الإعادة التلقائية خلصت ($n) وبرضه فاشل") }
                continue
            }
            if (now < (autoAt[i] ?: 0L)) continue
            autoTries[i] = n + 1; autoAt[i] = now + 12_000L * (n + 1)
            if (announced.add(i)) host.notice(if (zero) "⚠ باتش ${i + 1} رجع من غير جمل — بعيده للتأكد" else if (b.mark == "❌") "❌ باتش ${i + 1} فشل — بعيده تلقائي" else "⚠ باتش ${i + 1} رجع ناقص — بعيده تلقائي")
            host.log("🔁 إعادة تلقائية لباتش ${i + 1} (${n + 1}/$limit)")
            failed.remove(i); incomplete.remove(i); priorityRetry.add(i)
        }
    }

    /** إعادة مجموعة باتشات على المفاتيح الاحتياطية بالتوالي (واحد ورا التاني: الأقدم فالأحدث) في خيط واحد — مش كلهم في نفس الوقت */
    fun retryOnBackupSeq(list: List<Int>) {
        val todo = list.distinct().sorted().filter { inflight.add(it) }
        if (todo.isEmpty()) return
        host.log("🔁 إعادة ${todo.size} باتش على المفاتيح الاحتياطية بالتوالي (الأقدم فالأحدث): " + todo.joinToString("، ") { (it + 1).toString() })
        Thread {
            for (i in todo) {
                try {
                    if (!running) { continue }
                    incomplete.remove(i); failed.remove(i)
                    host.log("🔁 إعادة باتش ${i + 1} على المفاتيح الاحتياطية…")
                    val p = prepare(i, true)
                    if (p != null) { send(i, p, true); host.log("✅ باتش ${i + 1}: خلصت إعادة الترجمة") }
                    else host.log("⚠ باتش ${i + 1}: مفيش صوت اتفك — جرّب تاني بعد شوية")
                } catch (e: Exception) {
                    failed[i] = MAX_FAILS
                    host.log("⚠ إعادة باتش ${i + 1} فشلت: " + (e.message ?: e.toString()).take(160))
                } finally { inflight.remove(i); host.changed(); persist() }
            }
        }.apply { isDaemon = true }.start()
    }

    /** باتشات فاشلة/ناقصة مطلوب إعادتها بالأولوية على المفاتيح الأساسية (لما تكون أكتر من 3) */
    private val priorityRetry = java.util.concurrent.ConcurrentSkipListSet<Int>()
    private val qualRetried = ConcurrentHashMap.newKeySet<Int>()   // (v1178) باتشات اتعادت مرة بسبب الجودة — مرة واحدة بس لكل باتش
    /** عدد الباتشات اللي مستنية دورها في الإعادة بالأولوية */

    /**
     * زرار «إعادة» في الشريط الأحمر: بيعيد كل الباتشات المشكلة.
     * - 3 أو أقل: على المفاتيح الاحتياطية بالتوالي (الأقدم فالأحدث).
     * - أكتر من 3: مش هتتزحم على الاحتياطي — الترجمة العادية بتقف عن إرسال باتشات جديدة (اللي شغّال بيخلص)،
     *   والفاشلين بيتترجموا الأول على المفاتيح الأساسية بالترتيب، وبعدها الترجمة بتكمّل باقي الباتشات.
     * بيرجّع عدد الباتشات.
     */
    fun retryProblems(): Int {
        val idx = problems().map { it.idx }.sorted()
        if (idx.isEmpty()) return 0
        if (idx.size <= 3 || !running) retryOnBackupSeq(idx)   // لو حلقة الترجمة مش شغالة مفيش مين يستلم الأولوية، فبالتوالي على الاحتياطي
        else {
            for (i in idx) { failed.remove(i); incomplete.remove(i); priorityRetry.add(i) }
            host.log("🔁 ${idx.size} باتش فاشل: هترجمهم الأول على المفاتيح الأساسية بالترتيب وبعدها أكمّل باقي الباتشات")
            host.changed(); persist()
        }
        return idx.size
    }

    // ===== (v1099) T4: تطبيق بأثر رجعي من ⚙ الترجمة — الجمل اللي اتغيّرت بتتعرض بين أقواس (عرض بس — مابتتحفظش ولا بتتصدّر) =====
    /** مفاتيح الجمل (pk) اللي اتغيّرت بأثر رجعي */
    val applied: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    /** تفريغ بأثر رجعي: كل الجمل بتتعرض بنصها الأصلي بين أقواس */
    @Volatile var origView = false
    /** الأداة الجاية (تحويل لهجة / إعادة صياغة) تعلّم اللي بتغيّره — بيتصفّر أول ما الأداة تبدأ */
    @Volatile var markRetro = false
    fun isApplied(s: Sub): Boolean = pk(s) in applied
    fun markAllApplied() { synchronized(lock) { for (x in subs) applied.add(pk(x)) } }
    fun clearMarks() { applied.clear() }
    /** اختيار لهجة التحويل. existing=true: بيحوّل كمان اللي اتترجم قبل كده — من مكان المشاهدة وللقدّام الأول، وبعدين اللي قبله. بيحفظ نسخة باللهجة القديمة قبل التحويل (🗂) */
    fun setConvDialect(d: String, existing: Boolean) {
        if (Strict.noGemKeys()) { convDialect = ""; pend.clear(); return }   // (v410) فصحى بس في نص-أونلاين والأوفلاين
        val prev = convDialect
        if (existing && subs.isNotEmpty() && prev != d) { val lb = if (prev.isBlank()) "فصحى" else prev; saveVersion("ترجمة $lb", lb) }
        convDialect = d
        if (d.isBlank() || d == "فصحى") { pend.clear(); return }
        lastConvFail = 0L; convFailN = 0
        if (existing) synchronized(lock) { subs = subs.map { it.copy(conv = false) }; pend.addAll(subs.map { pk(it) }) }
        maybeConvert(true)
    }
    /** تبديل اللهجة من غير تحويل (لما نرجّع نسخة محفوظة): الجمل الجديدة تتحوّل للهجة دي */
    fun adoptDialect(d: String) {
        convDialect = d
        synchronized(lock) { subs = subs.map { it.copy(conv = true) } }; pend.clear()
    }
    /** بيحوّل الجمل اللي لسه ما اتحوّلتش كل ~3 باتشات (أو الباقي لما الترجمة تهدى) على المفاتيح الاحتياطية */
    fun maybeConvert(force: Boolean = false) {
        if (Strict.noGemKeys()) return   // (v436) · (v410) تحويل اللهجة بجيميناي — أونلاين بس
        if (transOnly || (keyless && convLlm() == null)) return   // (v280) تفريغ بس: مفيش تحويل لهجة · (v281) من غير مفتاح جيميناي التحويل بيشتغل لو فيه محرك LLM مختار
        // (v259) تحويل اللهجة محتاج جيميناي — من غير مفتاح الترجمة بتفضل فصحى (الإشعار اتعرض قبل البداية)
        val tgt = convDialect
        if (tgt.isBlank() || tgt == "فصحى" || tgt == conf.lang) return
        if (System.currentTimeMillis() - lastConvFail < minOf(60_000L, 10_000L shl minOf(convFailN, 3))) return
        val todo = synchronized(lock) { subs.filter { needsConv(it) } }
        if (todo.isEmpty()) return
        val span = todo.maxOf { it.end } - todo.minOf { it.start }
        if (!force && span < ch * 0.5) return
        if (!convBusy.compareAndSet(false, true)) return
        try { bg.submit { try { convertSubs(tgt) } finally { convPct = 0f; convBusy.set(false) } } } catch (e: Exception) { LogStore.err("Engine:convSubmit", e); convBusy.set(false) }   // (v468) تسجيل الأخطاء الصامتة
    }
    /** (v281) محرك LLM اللي اخترته لتحويل اللهجة (Cfg conv_via = id بريست)، لو جاهز ومش موقوف. null = جيميناي */
    private fun convLlm(): ExtLlm.Preset? = null   // (v395) المحركات الخارجية اتشالت — جيميناي بس
    private fun convViaLlm(p: ExtLlm.Preset, batch: List<Int>, snap: List<Sub>, tgt: String): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        for (part in batch.chunked(25)) {
            val orig = part.map { snap[it].original }; val msa = part.map { snap[it].translated }
            val meta = part.map { k -> val s = snap[k]; listOfNotNull(s.gender.takeIf { it.isNotBlank() }?.let { "speaker=$it" }, s.addressee.takeIf { it.isNotBlank() }?.let { "addressee=$it" }).joinToString(", ") }
            val r = ExtLlm.convert(p, orig, msa, meta, tgt, pb.dialectBlock(tgt) + toneBlock())
            for ((q, k) in part.withIndex()) r.getOrNull(q)?.takeIf { it.isNotBlank() }?.let { out.add(k to it) }
        }
        return out
    }
    private fun convertSubs(tgt: String): Int {
        var changed = 0
        val mk = markRetro; markRetro = false   // (v1099) T4
        val snap = synchronized(lock) { subs }
        val idx0 = snap.indices.filter { needsConv(snap[it]) }
        if (idx0.isEmpty()) return 0
        for (k in idx0) if (snap[k].conv) msaTried.add(pk(snap[k]))
        // من أول الباتش اللي المشاهد فيه ولقدّام الأول، وبعدين اللي قبله
        val focus = try { cStart(maxOf(0, (host.position() / ch).toInt())) } catch (_: Exception) { 0.0 }
        val idx = idx0.filter { snap[it].start >= focus - 0.05 } + idx0.filter { snap[it].start < focus - 0.05 }
        val batches = idx.chunked(40)
        host.log("🌐 تحويل ${idx.size} جملة للهجة $tgt (من ${(focus / 60).toInt()}:%02d وللقدّام الأول)…".format(focus.toInt() % 60))
        batches.forEachIndexed { bi, batch ->
            convPct = bi.toFloat() / batches.size
            if (!running) return@forEachIndexed
            val list = JSONArray()
            for (k in batch) { val s = snap[k]; list.put(JSONObject().put("idx", k).put("original", s.original).put("translated", s.translated).put("speaker_gender", s.gender).put("addressee_gender", s.addressee)) }
            val prompt = PromptStore.fill(PromptStore.pick("eng:conv", EnginePrompts.CONV), "TGT" to tgt, "DIALECT" to pb.dialectBlock(tgt), "TONE" to toneBlock(), "LIST" to list.toString())
            try {
                // (v281) محرك LLM مختار (ChatGPT / Claude / …): بيحوّل هو، ولو وقف بيكمّل جيميناي (إلا لو مفيش مفتاح جيميناي)
                var rw: List<Pair<Int, String>>? = null
                val via = convLlm()
                if (via != null) {
                    try { rw = convViaLlm(via, batch, snap, tgt) }
                    catch (e: Exception) {
                        if (e is ExtLlm.LlmErr) ExtTranslate.noteFail("llm_" + via.id, ExtLlm.key(via).hashCode(), e)
                        host.log("⚠ تحويل اللهجة بـ ${via.label} فشل: " + (e.message ?: e.javaClass.simpleName).take(110))
                        if (keyless) throw e
                        warnUser("convvia", "🔄 فشل ${via.label} في تحويل اللهجة — تم التحويل لجيميناي")
                    }
                }
                if (rw == null) {
                    val r = bgCall(prompt, 8192, 0.3, true, bi)
                    val arr = (Parse.json(r.text) ?: throw BadReply("رد التحويل مش JSON")).optJSONArray("rewrites") ?: throw BadReply("رد التحويل من غير rewrites")
                    rw = (0 until arr.length()).mapNotNull { q -> val c = arr.optJSONObject(q) ?: return@mapNotNull null; val ix = c.optInt("idx", -1); if (ix !in batch) null else ix to c.optString("translated").trim() }
                }
                val rws: List<Pair<Int, String>> = rw ?: emptyList()
                synchronized(lock) {
                    val cur = subs.toMutableList(); val got = HashSet<Int>()
                    for ((ix, tr) in rws) {
                        if (tr.isEmpty()) continue
                        val t = snap[ix]
                        val at = cur.indexOfFirst { Math.abs(it.start - t.start) < 0.05 && it.original == t.original }
                        if (at >= 0) { cur[at] = cur[at].copy(translated = tr, conv = true); got.add(ix); if (tr != t.translated) { changed++; if (mk) applied.add(pk(cur[at])) } }   // (v1099) T4
                    }
                    // اللي ما رجعش في الرد يفضل غير محوّل (هيتحاول تاني)، مش بيتعلّم
                    subs = cur
                    for (ix in got) pend.remove(pk(snap[ix]))
                }
                host.changed(); convFailN = 0
            } catch (e: Exception) { lastConvFail = System.currentTimeMillis(); convFailN++; warnUser("conv", "⚠ التحويل للهجة فشل — الترجمة فضلت زي ما هي وهيتحاول تاني"); host.log("⚠ التحويل للهجة فشل: " + (e.message ?: "").take(130)) }
        }
        if (changed > 0) { persist(); host.log("✅ اتحوّلت $changed جملة للهجة $tgt") }
        return changed
    }
    fun chunkOfSec(sec: Double): Int { var i = 0; while (cStart(i + 1) <= sec) i++; return i }
    fun chunkStartSec(i: Int) = cStart(i)

    /**
     * (v1165) تصدير الصوت مقسّم لنفس الباتشات (blocking — من خيط خلفي بس). onEach(رقم الباتش من 0، العدد الكلي، بداية، نهاية، بايتات الصوت، mime).
     * الصوت بيتضغط بنفس بريسيت الإرسال (AAC أو WAV) فالحجم هو اللي بيروح لجيميناي فعلًا. بيرجّع عدد الباتشات اللي اتصدّرت.
     */
    fun exportBatchAudio(onFail: (Int, String) -> Unit = { _, _ -> }, onEach: (Int, Int, Double, Double, ByteArray, String) -> Unit): Int {
        val d = currentDur(); val n = chunkCount(); var ok = 0
        host.log("🎧 تنزيل الباتشات: $n باتش")
        for (i in 0 until n) {
            val st = cStart(i); val en = cEnd(i, d)
            // (v1195) نفس فك الصوت بتاع الترجمة: بيبدأ قبل الباتش بـ OVERLAP وبيعيد لحد 3 مرات (أول فك ساعات بيرجع فاضي مؤقتًا) — كان بيتخطّى الباتش من غير ما يقول ليه
            val from = if (i == 0 && st < 0.05) 0.0 else maxOf(0.0, st - OVERLAP)
            var w: WavChunk? = null; var err = ""
            for (t in 1..3) {
                try { w = src().wav(from, en) } catch (e: Throwable) { w = null; err = (e.message ?: e.javaClass.simpleName).take(80) }
                if (w != null) break
                try { Thread.sleep(700) } catch (_: InterruptedException) { break }
            }
            val wv = w
            if (wv == null) {
                val why = if (err.isNotEmpty()) "فك الصوت فشل: $err" else "فك الصوت رجّع فاضي (3 محاولات)"
                host.log("⚠ تنزيل الباتشات: باتش ${i + 1} — $why"); onFail(i, why); continue
            }
            try {
                val pk = AudioEnc.pack(wv.bytes)
                onEach(i, n, st, en, pk.bytes, pk.mime); ok++
            } catch (e: Throwable) {
                val why = "ضغط/كتابة الصوت فشل: " + (e.message ?: e.javaClass.simpleName).take(80)
                host.log("⚠ تنزيل الباتشات: باتش ${i + 1} — $why"); onFail(i, why)
            }
        }
        host.log("🎧 تنزيل الباتشات: خلص — $ok من $n")
        return ok
    }

    /** (v1202) نص برومبت الترجمة الكامل (للباتش الأول) — بيتحط في ملف البرومبت اللي بيتنسخ مع رفع الصوت للريبو */
    fun promptText(): String = try { buildPrompt(currentDur(), 0.0) } catch (e: Throwable) { "" }

    /** يمسح ترجمة الباتشات من..إلى (شاملة، to < 0 = لحد النهاية) عشان تتترجم من جديد. بيحفظ نسخة قبلها (🗂 ترجمات الفيديو) */
    /** (v1237) نسخة من الجمل قبل ما إعادة الترجمة تمسحها — لو اتلغت قبل ما تخلص بنرجّع القديم في الأماكن اللي لسه ما اتترجمتش */
    @Volatile private var redoBackup: List<Sub>? = null
    fun restoreBackup(): Int {
        val old = redoBackup ?: return 0
        var n = 0
        synchronized(lock) {
            val cur = subs
            val back = old.filter { o -> cur.none { c -> c.start < o.end && c.end > o.start } }
            n = back.size
            if (n > 0) subs = Subs.merge(Subs.dedup(cur + back)).sortedBy { it.start }
        }
        redoBackup = null
        if (n > 0) { host.changed(); persist(); host.log("↩ رجّعت $n جملة من الترجمة القديمة (الإعادة اتلغت قبل ما تخلص)") }
        return n
    }
    fun redo(from: Int, to: Int, keep: Boolean = true) {
        if (subs.isNotEmpty()) redoBackup = subs
        val d = currentDur()
        val hi = if (to < 0) Int.MAX_VALUE else to
        val a = cStart(from); val b = if (to < 0) Double.MAX_VALUE else cEnd(to, d)
        if (keep && subs.isNotEmpty()) saveVersion("قبل إعادة الترجمة من باتش ${from + 1}")
        synchronized(lock) { subs = subs.filter { !(it.chunk in from..hi) && !(it.start >= a && it.start < b) } }
        done.remove(a, b); gapTried.remove(a, b)
        val last = if (to < 0) (if (d > 0) chunkCount() else from + 1000) else to
        for (i in from..last) { failed.remove(i); gapPass.remove(i); holeTried.remove(i); claimed.remove(i); rehomeQ.remove(i); tHold.remove(i); fullChunks.remove(i) }
        pool.clear(); lastGapTry = 0L; gapScanClean = false
        qualRetried.clear()   // (v1178)
        fullRefineStarted = false; fullRefineDone = false
        host.changed(); persist()
    }
    /**
     * (v413) اليوزر غيّر لغة الكلام من ⚙: بنفك قفل اللغة، وبنعيد الباتشات اللي اتفرّغت بلغة غير الجديدة (اللي باظت)،
     * وبنكمّل الترجمة من المكان اللي واقف عليه المشغّل.
     */
    fun langChanged(newLang: String, posSec: Double) {
        offSession.lang = ""; offSession.hint = ""; offSession.badRun = 0
        Offline.detectedLang = ""
        if (newLang.isNotEmpty()) {
            val bad = chunkLang.entries.filter { it.value.isNotEmpty() && it.value != newLang }.map { it.key }.sorted()
            for ((n, i) in bad.withIndex()) { redo(i, i, keep = n == 0); chunkLang.remove(i) }
            if (bad.isNotEmpty()) host.log("🌐 اللغة اتغيّرت لـ $newLang: هتتعاد ${bad.size} باتش اتفرّغت بلغة غلط (" + bad.take(8).joinToString("، ") { (it + 1).toString() } + (if (bad.size > 8) "…" else "") + ")")
            else host.log("🌐 اللغة اتغيّرت لـ $newLang — مفيش باتشات قديمة محتاجة إعادة")
        }
        translateFrom(posSec)
    }
    /** باتش ده وبعده كله (بيبدأ منه ويكمل) */
    fun redoFrom(i: Int, keep: Boolean = true) { redo(i, -1, keep); onlyChunks = null; forcedSticky = true; forcedCursor = i; paused = false }
    /** باتش ده لوحده وخلاص */
    fun redoOnly(i: Int, keep: Boolean = true) { redo(i, i, keep); onlyChunks = i..i; paused = false }
    /** من الأول خالص */
    /** (v1167) بيتنادى قبل ما «ترجم من الأول» تمسح الجمل: المشغّل بيحفظ منه لوج + ترجمات التشغيلة الحالية في سجل اللوجات وبيبدأ لوج جديد */
    @Volatile var onFreshRun: (() -> Unit)? = null
    fun redoAll(keep: Boolean = true) { try { onFreshRun?.invoke() } catch (_: Throwable) {}; redo(0, -1, keep); onlyChunks = null; forcedSticky = true; forcedCursor = 0; paused = false }
    /** (v1167) «شغّل بالترجمة دي» من سجل اللوجات: بيحط جمل اللوج المحفوظ مكان جمل الفيديو في الذاكرة بس (والمشغّل بيمنع الحفظ والترجمة) */
    fun loadSnapshot(list: List<Sub>) { synchronized(lock) { subs = list }; host.changed() }
    /** كمّل الترجمة من المكان ده (من غير مسح حاجة): بيقفز بالمؤشر لباتش الوقت ده ويلغي الإيقاف */
    /** (v224) ابدأ من أول الفيديو: أول باتش لسه ناقص من الأول، بغض النظر عن مكان الفيديو دلوقتي (ثابت لحد ما يوصل لمكان التشغيل) */
    fun translateFromStart() { onlyChunks = null; forcedSticky = true; forcedCursor = 0; paused = false; userPaused = false; rampChunk = -1; fastLight.clear(); lightRetry.clear() }
    fun translateFrom(sec: Double) { onlyChunks = null; forcedSticky = false; forcedCursor = chunkOfSec(sec.coerceAtLeast(0.0)); paused = false; userPaused = false; rampChunk = -1; fastLight.clear(); lightRetry.clear() }
    fun stop() { isClosed = true; running = false; bg.shutdownNow(); gapEx.shutdownNow(); exec?.shutdownNow(); try { trEx.shutdownNow() } catch (_: Exception) {}; try { hedgeEx.shutdownNow() } catch (_: Exception) {}; try { holeEx.shutdownNow() } catch (_: Exception) {}; try { persistEx.shutdownNow() } catch (_: Exception) {}; try { if (lineCacheSavePending.getAndSet(false)) Thread { lineCacheSaveNow() }.start() } catch (_: Throwable) {} }   // (v1177) آخر تعديلات الكاش ما تضيعش لو الإنجن اتقفل قبل التأجيل
    /** (v122) إعدادات اتغيّرت من شاشة الإعدادات (لهجة / أسلوب / موديل / شخصيات…): تتطبّق على الباتشات والتحويلات الجاية من غير إعادة تشغيل المحرك */
    fun applyConf(c: Conf) {
        val keysChanged = c.keys != conf.keys || c.backup != conf.backup || c.refine != conf.refine
        val lookChanged = c.lang != conf.lang || c.style != conf.style || c.model != conf.model   // (v468) لهجة/أسلوب/مترجم اتغيّروا
        conf = c; dialConf.clear()
        if (keysChanged) basePool = Pool(c)   // (v259) المفاتيح اتغيّرت (مثلًا مفتاح محلي للأوفلاين+جوجل): الحوض لازم يتبني من جديد
        if (lookChanged && exec != null && !isClosed) try { host.notice("ℹ️ الإعدادات الجديدة هتتطبق على اللي جاي بس — اللي اتترجم خلاص مش هيتغيّر") } catch (_: Throwable) {}   // (v468) تنبيه واحد والمحرك شغّال
    }
    /** (v259) مفيش ولا مفتاح جيميناي حقيقي — بس المفتاح المحلي الوهمي (أوفلاين + جوجل). المهام اللي محتاجة جيميناي بتتخطّى */
    private val keyless: Boolean get() = conf.keys.isNotEmpty() && conf.keys.all { it == LocalKey.ID } && conf.backup.isEmpty() && conf.refine.isEmpty()
    fun saveNow() = doPersist(true)
    /** (v1379 — بطلب علي) الجمل الحالية مستوردة من ملف ترجمة (SRT) مش من تفريغ المحرك — عند ضغطة ترجم/تفريغ بتتفصل (نسخة في 🗂) ومابتدمجش مع الجديد */
    @Volatile var imported = false
    /** استيراد ترجمة جاهزة (SRT) لفيديو من غير ترجمة */
    fun importSubs(l: List<Sub>) { subs = l; imported = l.isNotEmpty() }
    /** (v685) ترجمة جاهزة اتحطت من ملف ترجمة: الفيديو كله يتعلّم «مخلّص» — عشان تتحفظ كاملة وتتحمّل أوفلاين، و«ترجم»/البدء التلقائي ما يعيدوهاش */
    fun markAllDone(lastEnd: Double) { val d = currentDur(); done.add(0.0, if (d > 0) maxOf(d, lastEnd) else lastEnd + 1.0) }
    fun retryFailed() {
        pool.clear(); gapPass.clear(); gapTried.clear(); lastGapTry = 0L
        for (k in failed.keys) failed[k] = MAX_FAILS
        host.log("🔁 هعيد محاولة المقاطع الفاشلة (${failedCount()})")
    }
    fun charactersNow(): List<Chr> = effectiveChars()

    /**
     * (v151) زرار 🧑 في المشغّل: بيحلّل الشخصيات من الترجمة الحالية دلوقتي (حتى لو التحليل التلقائي مقفول، أو الفيديو اتترجم قبل كده
     * ومفيش ولا باتش جديد يشغّل التحليل). الشخصيات اليدوية من الإعدادات هي المرجع ومبتتلمسش.
     * done بتتنادى مرة واحدة بالقايمة النهائية (من خيط تاني).
     */
    fun analyzeCharsNow(report: (String) -> Unit, done: (List<Chr>) -> Unit) {
        if (conf.manualChars.isNotEmpty()) { done(conf.manualChars); return }
        if (subs.size < 4) { report("لسه مفيش جمل مترجمة كفاية للتحليل"); done(effectiveChars()); return }
        val go = synchronized(lock) { if (charsBusy) false else { charsBusy = true; true } }
        if (!go) { report("التحليل شغّال دلوقتي — استنى لحظة"); done(effectiveChars()); return }
        Thread {
            try { analyzeChars() } catch (e: Exception) {
                host.log("⚠ تحليل الشخصيات فشل: " + (e.message ?: e.toString()).take(100))
                report("التحليل فشل: " + (e.message ?: "").take(80))
            } finally { synchronized(lock) { charsBusy = false }; persist() }
            done(effectiveChars())
        }.apply { isDaemon = true }.start()
    }

    /** يسترجع التقدم المحفوظ. يرجع آخر مكان تشغيل (بالثواني) أو 0. */
    fun load(): Double {
        val s = store?.load() ?: return 0.0
        synchronized(lock) {
            subs = Subs.unifyOverlaps(Subs.dedup((if (s.chunkSec == conf.chunkSec) s.subs else s.subs.map { it.copy(chunk = -1) }).map { Subs.collapseSelfRepeat(it) }))
            if (s.subs.isNotEmpty()) { for (r in s.done) done.add(r[0], r[1]) }
            else if (s.done.isNotEmpty()) host.log("♻ التقدم المحفوظ فيه دقايق «مخلّصة» من غير ولا جملة — هتتعاد الترجمة من الأول (v263)")
            for (r in s.failed) failed[Math.round(r[0] / ch).toInt()] = MAX_FAILS
            // (v999 ملاحظة 4) تحميل تاني لنفس الملف (بعد اختيار ترجمة الاستوديو) مبيكررش القوايم
            chars.clear()
            gloss.clear()
            chars.addAll(s.chars)
            gloss.addAll(s.gloss)
            tplCache.putAll(s.tpl)
            srcLang = s.srcLang; detDone = s.detDone; autoCharsAttempts = s.charsTried
            if (s.detDone) anyApplied = true
            pronUpTo = subs.size
            if (s.chunkSec == conf.chunkSec) bounds.putAll(s.bounds)
            for (r in s.gapTried) gapTried.add(r[0], r[1])
        }
        imported = s.imp
        host.log("♻ استرجعت ${s.subs.size} جملة و${(done.total() / 60).toInt()} دقيقة مترجمة من الجلسة اللي فاتت")
        host.changed()
        return s.pos
    }

    // ===== الحلقة الرئيسية =====
    // ملحوظة: فك الصوت (والتقصير لأقرب صمت) بيتم بالترتيب في الخيط ده، وإرسال الطلبات لجيميناي بيتم بالتوازي.
    private fun cStart(i: Int): Double = bounds[i] ?: (i * ch)
    private fun cEnd(i: Int, d: Double): Double { val e = cStart(i + 1); return if (d > 0) minOf(e, d) else e }

    fun run() {
        if (conf.keys.isEmpty() && conf.backup.isEmpty()) { host.status("⚠ ادخل مفتاح Gemini في الإعدادات"); host.log("⚠ مفيش مفاتيح Gemini"); host.notice("⚠ مفيش مفتاح جيميناي — ضيف واحد من الإعدادات ← المفاتيح"); return }
        fastLatched = try { Cfg.bool("fastmode", false) } catch (_: Throwable) { false }; rampAllLatched = rampAllWanted(); rampChunk = -1; fastLight.clear(); lightRetry.clear()   // (v1068) الوضع السريع بيتأخد من الإعداد وقت بداية الترجمة (مش وقت فتح المشغّل) — عشان صف «⚡ سريع» في قايمة جيميناي يشتغل على طول
        Api.onSlow = { m -> try { host.status(m) } catch (_: Throwable) {} }   // (v468) مؤشر «باتش بيحاول» في شريط الحالة
        NetWait.reset()
        engineStartMs = System.currentTimeMillis()   // (v1354) قياس زمن أول باتش من ضغطة الزرار
        val netSink = object : NetWait.Sink {   // (v1101) إشعار واحد لما النت يقع وواحد لما يرجع
            override fun netDown() { host.log("📵 النت واقع — الترجمة واقفة (مفيش فشل ولا تكرار)"); host.notice("📵 النت واقع — الترجمة واقفة وهتكمّل لوحدها لما يرجع") }
            override fun netUp(downMs: Long) { host.log("✅ النت رجع بعد ${downMs / 1000}ث — بكمّل الترجمة"); host.notice("✅ النت رجع — بكمّل الترجمة") ; host.status("✅ النت رجع — بكمّل الترجمة") }
        }
        NetWait.sink = netSink
        val capMax = basePool.capacity(ppk)
        val ex = Executors.newFixedThreadPool(maxOf(capMax, Offline.MAX_PAR) + 2) { r -> Thread(r).also { it.isDaemon = true } }   // +2: باتش اتنسخ واتحسب من نسخته الاحتياطية ممكن يفضل خيطه الأصلي شغال شوية من غير ما يحجز مكان باتش جديد
        exec = ex
        if (capMax > 1) host.log("⚡ ترجمة متوازية: لحد $capMax طلب في نفس الوقت")
        try { sideNotice() } catch (_: Throwable) {}
        try {
            if (headless) try { src() } catch (e: Exception) { host.log("⚠ معرفتش أفتح الفيديو: " + (e.message ?: e.toString()).take(120)) }
            while (running) {
                val d = currentDur()
                val cap = capNow(pool.capacity(ppk))   // (v227: 429 يقلّلها لـ 2) (v210) بيتغيّر لو الوضع اتبدّل أثناء الشغل (3/4 = مفاتيح الترانسكريبشن بس)
                translateTick(userPaused || paused)            // (v210) الباتشات المنسوخة بتتجمّع وتتترجم حتى وقت الإيقاف المؤقت
                if (headless && d <= 0 && (failed[0] ?: 0) >= MAX_FAILS) { fatal = "معرفتش أفتح الفيديو أو أقرأ مدته"; host.log("⛔ " + fatal); host.status("⛔ " + fatal); running = false; break }
                if (headless && !anyApplied && failedCount() >= 5) { fatal = "المقاطع بتفشل ورا بعض — راجع المفاتيح والنت"; host.log("⛔ " + fatal); host.status("⛔ " + fatal); running = false; break }
                if (userPaused) { host.status("⏸ الترجمة واقفة مؤقتًا — دوس «إلغاء الإيقاف» تكمّل"); nap(300); continue }
                if (paused) { host.status("⏸ مستني اختيارك: كمّل على الترجمة الحالية ولا ترجم من جديد"); nap(300); continue }
                // (v1101) بوابة النت: النت واقع (أو الداتا خلصت) → مفيش باتشات جديدة تتبعت ومفيش فشل ولا تكرار؛ بتكمّل لوحدها أول ما فحص حقيقي للسيرفر ينجح
                if (!Offline.on() && NetWait.gateDown()) { host.status(NetWait.statusText()); nap(500); continue }
                val posNow = if (headless) 0.0 else try { host.position() } catch (_: Throwable) { 0.0 }
                val pcNow = if (headless) 0 else (posNow / ch).toInt().coerceAtLeast(0)
                val hotNow = playheadHot()
                // (v1094) سحب المشاهد لمكان تاني في الوضع السريع: الباتش اللي نزل عليه يبدأ بخطوات سريعة تاني (بعد ما الشغّال دلوقتي يخلص — مفيش إلغاء)
                if (rampOn && !headless) {
                    val jumped = lastLoopPos >= 0 && Math.abs(posNow - lastLoopPos) > 8.0
                    if (jumped && pcNow != rampChunk && rampChunk !in inflight && pcNow !in inflight && d > 0 && !isDone(pcNow, d)) {
                        rampChunk = -1; rampStep = 0; rampNext = -1.0; fastLight.clear(); lightRetry.clear()
                        host.log("⚡ سحبت لمكان تاني: الباتش ${pcNow + 1} هيبدأ بخطوات سريعة بعد ما الشغّال دلوقتي يخلص")
                    }
                }
                lastLoopPos = posNow
                hedgeTick()
                autoRetryTick()
                holeDeferTick()
                if (groqTxOn() && !userPaused && !paused) prePrepTick(d)   // (v1370 — بطلب علي: «عايزه يبعت باتش باتش») فك صوت الباتش الجاي أثناء إرسال الحالي
                // (v151) باتش فشل: يتبعت الأول لأقرب مفتاح خلّص باتشه (مفيش باتشين على مفتاح واحد) وبعدين الترجمة تكمّل باقي الباتشات عادي
                val riPick = rehomeQ.keys.filter { !(hotNow && it < pcNow) }.minOrNull()   // (v1094) إعادة باتش ورا المشاهد تستنى لحد ما اللي قدامه يتترجم
                if (rehomeQ.isNotEmpty() && riPick != null) {
                    val ri: Int? = riPick
                    val re = ri?.let { rehomeQ[it] }
                    if (ri == null || re == null || ri in inflight || isDone(ri, d)) { if (ri != null) rehomeQ.remove(ri); continue }
                    var rk = pool.pickIdle(ri, re.avoid, perKey)
                    if (rk == null && System.currentTimeMillis() - re.at > 20_000L) rk = pool.pickIdle(ri, null, perKey)
                    if (rk == null) { nap(150); continue }
                    rehomeQ.remove(ri)
                    host.log("🔁 باتش ${ri + 1} (فاشل) → أقرب مفتاح فاضي ${pool.tail(rk)} — قبل باقي الباتشات")
                    dispatch(ri, ex, true, rk, re.prep); continue
                }
                // (v220) تبديل الوضع أثناء الترجمة: خلّص اللي شغّال الأول (من غير باتشات جديدة) وبعدين بدّل
                if (switching) {
                    if (drained()) {
                        val from = activeMode; activeMode = conf.keyMode
                        host.log("🔑 الباتشات الشغالة خلصت — الوضع اتبدّل من $from لـ ${KeyMode.name(activeMode)} والباتشات الجديدة هتمشي بيه")
                        host.notice("🔑 الوضع الجديد شغّال: " + KeyMode.short(activeMode) + "\n" + whoLine())   // (v1371 — بطلب علي) العداد بيتبع المزوّد الشغّال فعلًا مش جيميناي على طول
                        if (activeMode < KeyMode.ALL_PARALLEL && detDone) try { maybeTranslateTemplate() } catch (_: Throwable) {}
                    } else {
                        host.status("🔑 بخلّص الباتشات الشغالة قبل ما أبدّل للوضع " + KeyMode.short(conf.keyMode) + "…")
                        nap(200); continue
                    }
                }
                // إعادة الباتشات الفاشلة بالأولوية (أكتر من 3): مفيش باتشات جديدة تتبعت لحد ما الفاشلين يتبعتوا، وبعدين الترجمة تكمّل عادي
                if (priorityRetry.any { !(hotNow && it < pcNow) }) {   // (v1094) أولوية الإعادة للباتشات قدام المشاهد بس؛ اللي وراه بيستنى
                    val nx = priorityRetry.firstOrNull { it !in inflight && !(hotNow && it < pcNow) }
                    if (nx == null) { nap(150); continue }
                    if (activeInflight() >= cap) { nap(150); continue }
                    priorityRetry.remove(nx)
                    host.log("🔁 باتش ${nx + 1} (أولوية) — على المفاتيح الأساسية، باقي ${priorityRetry.size}")
                    dispatch(nx, ex, true); continue
                }
                var c = if (headless) firstUndone(d) else (host.position() / ch).toInt().coerceAtLeast(0)
                val fc = forcedCursor
                if (fc >= 0) {
                    var k = fc
                    while (!(d > 0 && cStart(k) >= d) && (isDone(k, d) || (failed[k] ?: 0) >= MAX_FAILS)) k++
                    forcedCursor = k
                    if (d > 0 && cStart(k) >= d) forcedCursor = -1
                    else if (forcedSticky) { c = k; if (k > (host.position() / ch).toInt()) forcedCursor = -1 }
                    else if (c >= k) forcedCursor = -1 else c = k
                }
                val only = onlyChunks
                val lo = only?.first ?: c
                val hi = only?.last ?: (c + window - 1)
                var next = -1
                for (i in lo..hi) {
                    if (d > 0 && cStart(i) >= d) break
                    if (isDone(i, d) || (failed[i] ?: 0) >= MAX_FAILS || i in inflight || tHold.containsKey(i) || rehomeQ.containsKey(i) || prePrepping.contains(i)) continue   // (v1370) اللي بيتجهز في الخلفية يتخطّاه لحد ما يجهز ويتبعت بنسخته
                    next = i; break
                }
                if (next < 0 && only == null && keepGoing && d > 0) next = nextUndone(c + window, d)
                if (next < 0 && only == null && keepGoing && d > 0) next = nextUndone(0, d)
                if (next < 0 && translateTick(inflight.isEmpty())) { nap(100); continue }   // (v210) مفيش ترانسكريبشن جاي: ابعت اللي اتجمّع للترجمة مهما كان عدده
                if (next >= 0) {
                    // أول مقطع لوحده (عشان نعرف لغة الفيديو ونختار القالب الصح)، وبعدين بالتوازي — إلا الوضع 2+ (برومبت إنجليزي ثابت: مفيش قالب يتختار)
                    if (activeInflight() >= cap || (activeMode < KeyMode.ALL_PARALLEL && !anyApplied && !detDone && inflight.isNotEmpty())) { gapTick(); nap(150); continue }   // (v209) الوضع 2+: كل المفاتيح بالتوازي من الأول · (v1354) وفي كل الأوضاع: أول ما لغة الفيديو تتحدد (detDone) الباتشات كلها بتتبعت بالتوازي — مفيش استنى لحد أول باتش يتطبّق بالكامل (بطلب علي: زرار الباتش كان بيفتح مفتاح واحد ويقعد)
                    dispatch(next, ex, prep0 = prePrepped.remove(next)); continue   // (v1370) صوت جاهز من التجهيز المسبق بينعدي مرحلة الفك
                }
                if (inflight.isEmpty() && retryGaps()) continue
                if (inflight.isEmpty() && repairForeignTick()) continue
                if (inflight.isEmpty() && noteTick()) continue   // (v408) 📖 نبذة عن المصطلحات
                if (gapTick(headless || keepGoing)) continue
                if (txIdle() && gapBusy.get() == 0 && holeBusy.get() == 0 && finalRefineTick()) { nap(300); continue }   // (v140) تنقيح نهائي قبل ما نقول «خلصت»
                // (v158) كل المقاطع خلصت: تنقيح كامل واحد بالفيديو كله (بعد التنقيح الجزئي مقطع مقطع)
                if (!transOnly && txIdle() && gapBusy.get() == 0 && holeBusy.get() == 0 && conf.partialRefine && TrSlider.on("refine") && d > 0 && cStart(firstUndone(d)) >= d && !fullRefineStarted && subs.size >= 12 && toolBusy == null) {   // (v1097) T2: TrSlider
                    fullRefineStarted = true; host.log("✍ تنقيح كامل نهائي (الفيديو كله في طلب واحد)…")
                    refineWholeNow({ host.status(it) }, { fullRefineDone = true }); nap(300); continue
                }
                if (fullRefineStarted && !fullRefineDone && toolBusy != null) { nap(300); continue }
                if (headless && txIdle() && gapBusy.get() == 0 && holeBusy.get() == 0 && (gapScanClean || !conf.gapFill || !TrSlider.on("holes")) && !hasRepairable() && d > 0 && cStart(firstUndone(d)) >= d) {   // (v1097) T2: TrSlider
                    finished = true; host.status("✅ خلصت الترجمة"); break
                }
                if (inflight.isEmpty()) maybeConvert(true)
                idleStatus(d)
                nap(if (inflight.isEmpty()) 700 else 200)
            }
        } finally {
            if (NetWait.sink === netSink) NetWait.sink = null   // (v1101)
            ex.shutdownNow()
            try { source?.close() } catch (_: Exception) {}
            doPersist()
            stoppedFlag = true
            try { onFinished?.invoke(finished && fatal == null) } catch (_: Exception) {}
        }
    }

    /** (v203) الفيديو كله مترجم فعلًا (كل المقاطع مخلّصة، من غير الفاشل) — بيتستخدم عشان «▶ ترجمة» ما تعيدش شغل مخلّص */
    fun fullyDone(): Boolean {
        val d = currentDur(); if (d <= 0) return false
        var i = 0
        while (cStart(i) < d) { if (!isDone(i, d)) return false; i++ }
        if (!transOnly && hasRepairable()) return false   // (v399) فيه جمل متفرّغة بس (لسه بلغتها الأصلية) — لسه ناقصها ترجمة
        return true
    }

    /** (v399) المحرك خلّص ووقف (مثلًا «تفريغ بس» خلص) وبعدين الوضع اتغيّر: بيجهّزه يشتغل تاني. true = لازم المشغّل يبدأ الحلقة من جديد */
    fun reopen(): Boolean {
        if (!stoppedFlag || isClosed) return false
        stoppedFlag = false; finished = false; fatal = null; source = null; running = true
        return true
    }

    /** أول مقطع ناقص من i وطالع (بيتخطّى المخلّص والفاشل والشغّال دلوقتي) أو -1 */
    private fun nextUndone(from: Int, d: Double): Int {
        var i = maxOf(0, from)
        while (cStart(i) < d) {
            if (!(isDone(i, d) || (failed[i] ?: 0) >= MAX_FAILS || i in inflight || tHold.containsKey(i) || rehomeQ.containsKey(i))) return i
            i++
        }
        return -1
    }

    /** أول مقطع لسه ناقص (الفاشلين بيتخطّوا وبتتعالج في retryGaps) — للترجمة في الخلفية */
    private fun firstUndone(d: Double): Int {
        if (d <= 0) return 0
        var i = 0
        while (true) {
            if (d > 0 && cStart(i) >= d) return i
            if (!(isDone(i, d) || (failed[i] ?: 0) >= MAX_FAILS)) return i
            i++
        }
    }

    /** عدد الجمل اللي رجعت لباتش (بالوقت مش بالـ tag عشان يشتغل بعد التحميل من الملف) */
    fun subCount(i: Int, d: Double): Int { val a = cStart(i) - 0.001; val b = cEnd(i, d) - 0.001; return subs.count { it.start >= a && it.start < b } }
    private fun isDone(i: Int, d: Double): Boolean = done.covers(cStart(i), cEnd(i, d))

    @Volatile private var durCache = 0.0
    private fun currentDur(): Double {
        if (durCache > 0) return durCache
        val a = try { source?.durationSec() ?: 0.0 } catch (_: Exception) { 0.0 }
        if (a > 0) durCache = a
        return if (a > 0) a else host.playerDuration()
    }

    private val gateLock = Object()
    @Volatile private var gateOn = false
    @Volatile private var gateThread: Thread? = null
    @Volatile private var gateAt = 0L
    /** (v1246) لما جيميناي يدّي 503 على المفاتيح ورا بعض: كل الطلبات بتقف، واحد بس (القائد) بيستنى دقيقة وبعدها يعيد الباتش الفاشل نفسه كباتش حقيقي كامل. لو نجح الكل يكمّل (pressureClear)، وإلا دقيقة كمان. المستخدم بيشوف رسالة وقت الضغط ورسالة لما يخلص */
    private fun pressureGate(key: String) {
        var leader = false
        synchronized(gateLock) { if (!gateOn) { gateOn = true; leader = true; gateThread = Thread.currentThread() } else if (gateThread === Thread.currentThread()) leader = true }
        if (!leader) { while (running && !isClosed && gateOn && System.currentTimeMillis() - gateAt < 150_000L) nap(500); return }
        val again = gateAt > 0L && System.currentTimeMillis() - gateAt < 150_000L
        gateAt = System.currentTimeMillis()
        host.log(if (again) "⏸ لسه عليه ضغط — دقيقة كمان وبعدين أعيد الباتش الفاشل" else "⏸ جيميناي عليه ضغط على المفاتيح — هستنى دقيقة وبعدها أعيد الباتش الفاشل كباتش كامل")
        host.status("⏸ جيميناي عليه ضغط دلوقتي — استراحة دقيقة")
        host.notice("⏸ جيميناي عليه ضغط دلوقتي — الترجمة هتكمّل لوحدها")
        nap(60_000L)
        gateAt = System.currentTimeMillis()
    }
    /** (v1246) أول باتش حقيقي ينجح بعد الضغط: الضغط خلص، الباقي يكمّل عادي */
    private fun pressureClear() {
        var was = false
        synchronized(gateLock) { if (gateOn) { gateOn = false; gateThread = null; gateAt = 0L; was = true } }
        if (was) { host.log("✅ جيميناي رجع بعد الضغط — بكمّل باقي الباتشات"); host.status("✅ الضغط خلص — بكمّل الترجمة"); host.notice("✅ ضغط جيميناي خلص — الترجمة كملت") }
    }

    private fun nap(ms: Long) {
        var t = 0L
        while (running && t < ms) { try { Thread.sleep(minOf(200L, ms - t)) } catch (_: InterruptedException) { return }; t += 200 }
    }

    private var lastIdle = ""
    private fun idleStatus(d: Double) {
        val pct = if (d > 0) (done.total() * 100 / d).toInt().coerceAtMost(100) else 0
        val f = failedCount()
        val s = "✅ مترجم $pct% — ${subs.size} جملة" + (if (f > 0) " — ⚠ $f مقطع فاشل" else "") + etaText(d) + (if (lastQuality >= 0) " — جودة آخر باتش $lastQuality%" else "")   // (v469) A12: وقت متبقٍّ + جودة
        if (s != lastIdle) { lastIdle = s; host.status(s) }
    }

    /**
     * (v1101) NetWait: طلب فشل بخطأ شكله نت. لو النت واقع فعلًا (فحص حقيقي للسيرفر) بيستنى هنا لحد ما يرجع ويرجّع true (الطلب يتعاد من غير ما يتحسب فشل).
     * false = مش فصل نت (النت شغّال أو الخطأ عادي) → المعالجة القديمة.
     */
    fun netHold(e: Throwable, tag: String): Boolean {
        if (!running || isClosed) return false
        if (!NetWait.stillDown(e)) return false
        host.log("📵 $tag: النت واقع — الطلب واقف في مكانه ومش بيتحسب فاشل، هيكمّل لما النت يرجع")
        NetWait.waitUp({ running && !isClosed }) { host.status(NetWait.statusText()) }
        return running && !isClosed
    }

    /** بينفّذ خطوة خاصة بمقطع ويسجّل الفشل. بيرجع true لو نجحت. */
    private fun guard(i: Int, block: () -> Unit): Boolean {
        try {
            block(); return true
        } catch (e: Unsupported) {
            fatal = e.message
            host.log("⛔ ${e.message}"); host.status("⛔ ${e.message}")
            running = false
        } catch (e: RehomeEx) {
            if (!running) return false
            rehomeQ[i] = Rehome(e.avoid, System.currentTimeMillis(), preps[i])
            host.log("↪ باتش ${i + 1}: مفتاح ${pool.tail(e.avoid ?: "")} فشل ومفيش مفتاح فاضي — الباتش مستني أقرب مفتاح يخلص باتشه" + (if (transOnly && groqTxOn()) " (مفتاح جيميناي محجوز — التفريغ نفسه بـ Groq ⚡)" else ""))
        } catch (e: Exception) {
            if (!running) return false
            // (v1101) خطأ نت والنت واقع فعلًا: الباتش مش بيتحسب فاشل ولا بيروح لمفتاح تاني — بيرجع للطابور والحلقة الرئيسية مستنية النت
            if (NetWait.looksNet(e) && NetWait.stillDown(e)) { host.log("📵 مقطع ${i + 1}: النت واقع — مش هتحسب فشل، هيتعاد لما النت يرجع"); nap(1000); return false }
            val n = (failed[i] ?: 0) + 1
            failed[i] = n
            val failedKey = keyOf[i]
            val where = e.stackTrace.filter { it.className.startsWith("com.tttt") || it.className.startsWith("android.media") }.take(3).joinToString(" ← ") { it.className.substringAfterLast('.') + "." + it.methodName + ":" + it.lineNumber }
            host.log("⚠ مقطع ${i + 1} فشل ($n/$MAX_FAILS): " + (e.message ?: e.javaClass.simpleName).take(160) + (if (where.isNotEmpty()) " [$where]" else ""))
            if (n >= MAX_FAILS) host.log("🕳 المقطع ${i + 1} اتسجل كفجوة — هعيد محاولته تلقائيًا بعد شوية")
            persist()
            // (v151) باتش فشل على مفتاح: يروح لأقرب مفتاح تاني خلّص باتشه، والمفتاح اللي فشل يكمّل باتشاته عادي
            if (n < MAX_FAILS && failedKey != null && pool.usableCount() >= 2) {
                rehomeQ[i] = Rehome(failedKey, System.currentTimeMillis(), preps[i])
                nap(1000)
            } else nap(4000)
        }
        return false
    }

    /**
     * (v1370 — بطلب علي: «عايزه يبعت باتش باتش») خط أنابيب Groq: باتش واحد قدام بيتفكّ صوته في خيط خلفي أثناء إرسال الباتش الحالي.
     * قبل كده مع مفتاح واحد كان الشغل تناوبي: فك ١ ← بعت ١ ← فك ٢ ← بعت ٢ — فالفك باين مرحلة واحدة طويلة والمستخدم مستني كل الباتشات من غير ما يشوف تفريغ.
     * دلوقتي: فك ١ ← بعت ١ (وفي نفس الوقت فك ٢) ← بعت ٢ فورًا لأن صوته جاهز — والتفريغ بيظهر على الشاشة باتش باتش بدري.
     * باتش الانطلاقة (ramp) مستثنى لأن خطواته السريعة ليها تجهيز خاص، والباتش اللي بيتجهز بيتخطّاه منتقي الحلقة لحد ما يجهز ويتبعت بنسخته من prePrepped.
     */
    private fun prePrepTick(d: Double) {
        if (!running || isClosed || d <= 0.0) return
        if (rampOn && rampChunk < 0) return   // باتش الانطلاقة لسه ما اتحددش — سيبه للمسار العادي
        for (e in prePrepped.entries) if (isDone(e.key, d) || e.key in inflight || (failed[e.key] ?: 0) >= MAX_FAILS) prePrepped.remove(e.key)   // نضّف الجاهز المنسي
        if (prePrepped.size + prePrepping.size >= 1) return   // باتش واحد قدام يكفي — الذاكرة
        val c = if (headless) firstUndone(d) else (try { host.position() } catch (_: Throwable) { 0.0 } / ch).toInt().coerceAtLeast(0)
        val only = onlyChunks
        val lo = only?.first ?: c
        val hi = minOf(only?.last ?: (c + window + 1), c + window + 1)
        var k = -1
        for (i in lo..hi) {
            if (cStart(i) >= d) break
            if (i == rampChunk) continue   // الانطلاقة ليها تجهيز خاص (خطوات بتكبر) — متتفكش مسبقًا
            if (isDone(i, d) || (failed[i] ?: 0) >= MAX_FAILS || i in inflight || tHold.containsKey(i) || rehomeQ.containsKey(i) || prePrepped.containsKey(i) || prePrepping.contains(i)) continue
            k = i; break
        }
        if (k < 0 || !prePrepping.add(k)) return
        val ki = k
        Thread {
            try {
                val p = prepare(ki, caller = "تجهيز مسبق")
                if (p != null && running && !isClosed && groqTxOn() && ki !in inflight && !isDone(ki, d)) prePrepped[ki] = p
            } catch (e: Throwable) { try { LogStore.err("Engine:preprep", e) } catch (_: Throwable) {} }
            finally { prePrepping.remove(ki); try { host.changed() } catch (_: Throwable) {} }
        }.apply { isDaemon = true }.start()
    }

    /** فك صوت المقطع + الإرسال لجيميناي كله في خيط من الحوض: عدة باتشات بتفك صوتها وتتبعت بالتوازي على كل المفاتيح (قبل كده الفك كان بالترتيب في حلقة واحدة فالباتشات كانت بتمشي واحد ورا التاني) */
    private fun dispatch(i: Int, ex: java.util.concurrent.ExecutorService, force: Boolean = false, firstKey: String? = null, prep0: Prep? = null) {
        if (!inflight.add(i)) return
        if (rampOn && rampChunk < 0 && !force) { rampChunk = i; rampStep = 0; rampNext = -1.0 }   // (v1065) أول باتش بيتبعت = اللي بيتقسّم لخطوات بتكبر
        if (fastLatched && !force && !SongHint.on() && TrSlider.on("light") && (fastLight.size < FAST_LIGHT_N || lightAll())) { fastLight.add(i); if (lightAll() && !lightAllLogged) { lightAllLogged = true; host.log("⚡ (v1152) السريع: كل الباتشات بالبرومبت الخفيف والرد المختصر (أسرع) — اللغات الشرقية بتفضل بالكامل") } }   // (v1097) T2 برومبت خفيف لأول باتشين · (v1152) ولكل الباتشات في «أسرع/سريع» (موضع ≤ 2)
        startedAt[i] = System.currentTimeMillis(); hedged.remove(i)
        // (v151) المفتاح بيتحجز للباتش من لحظة الإرسال (قبل فك الصوت) عشان باتشين ما يتحطوش على نفس المفتاح
        val fk = firstKey ?: pool.pickIdle(i, null, perKey)
        try {
            ex.submit {
                try {
                    var p: Prep? = prep0
                    val tPrep0 = System.currentTimeMillis()   // (v1031 — م0) توقيت فك/تجهيز الصوت لكل باتش
                    val ok = if (prep0 != null) { preps[i] = prep0; true } else guard(i) { val got = prepare(i, force, "توزيع"); p = got; if (got != null) preps[i] = got }
                    if (prep0 == null) LogStore.add("⏱ [مشغّل-توقيت] باتش ${i + 1}: فك+تجهيز الصوت " + (System.currentTimeMillis() - tPrep0) + "ms")
                    if (prep0 == null && p == null && prepBusy.contains(i)) nap(800)   // (v1376) الباتش بيتفك في خيط التجهيز المسبق — مهلة بدل ما اللوب يلف يبعته كل ~150ms (سبام «فك+تجهيز 1ms» في اللوج)
                    if (ok) {
                        val pp = p
                        if (pp == null) failed.remove(i)
                        else { startedAt[i] = System.currentTimeMillis(); if (guard(i) { sendOrBackup(i, pp, fk) }) failed.remove(i) }
                    }
                } finally { if (i !in bkQueued) inflight.remove(i); sentReq.remove(i); preps.remove(i); startedAt.remove(i); keyOf.remove(i); pool.unreserve(i); host.changed() }   // (v216) باتش في طابور الاحتياطي يفضل «شغّال» لحد ما يخلص
            }
        } catch (_: RejectedExecutionException) { inflight.remove(i); sentReq.remove(i); preps.remove(i); startedAt.remove(i); pool.unreserve(i) }
    }

    /**
     * باتش اتأخر (شغال أطول من ~2× المعتاد) وفي باتش بعده خلص: يبقى غالبًا واقع على مفتاح بطيء.
     * بنبعت نسخة منه على مفتاح تاني — أول نسخة تخلص هي اللي بتتطبّق والتانية بتتجاهل. نسخة واحدة بس في نفس الوقت.
     */
    private fun hedgeTick() {
        if (quotaCooling() || Overload.busy()) return   // (v1094) 429 / (v1237) ضغط جيميناي: ماتبعتش نسخ تانية من الباتشات
        if (!TrSlider.on("hedge") || inflight.isEmpty() || hedgeBusy.get() >= 1 || pool.usableCount() < 2 || Offline.on() || groqTxOn()) return   // (v1100) T2b: السلايدر · (v253) الأوفلاين: نسخة احتياطية بتستنى نفس المعالج
        val now = System.currentTimeMillis()
        val ms = recentMs.toList().sorted()
        val med = if (ms.isEmpty()) 0L else ms[ms.size / 2]
        val limit = if (fastLatched) (if (med > 0) med * 17 / 10 else 25_000L).coerceIn(12_000L, 90_000L) else (if (med > 0) med * 22 / 10 else 40_000L).coerceIn(25_000L, 120_000L)   // (v1151) السريع: الباتش المتأخر بيتنسخ على مفتاح تاني أبكر (~1.7× المعتاد، أدنى 12ث بدل 25ث)
        val i = inflight.filter { it < maxApplied && it !in hedged && preps.containsKey(it) && (startedAt[it]?.let { s -> now - s > limit } ?: false) }.minOrNull() ?: return
        val p = preps[i] ?: return
        if (!hedged.add(i)) return
        hedgeBusy.incrementAndGet()
        host.log("⚡ باتش ${i + 1} اتأخر عن اللي بعده — بعتّه على مفتاح تاني (أول نسخة تخلص هي اللي تتحسب)")
        try {
            hedgeEx.submit {
                try { send(i, p, avoidKey = keyOf[i], hedge = true) } catch (e: Exception) { LogStore.err("Engine:hedgeSend", e) } finally { hedgeBusy.decrementAndGet() }   // (v468)
            }
        } catch (_: RejectedExecutionException) { hedgeBusy.decrementAndGet() }
    }

    /** إعادة محاولة المقاطع الفاشلة لما نخلص الشغل اللي قدام المشاهد. */
    private fun retryGaps(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastGapTry < 30_000) return false
        val cand = failed.filter { it.value >= MAX_FAILS && (gapPass[it.key] ?: 0) < GAP_PASSES }.keys.sorted()
        if (cand.isEmpty()) return false
        lastGapTry = now
        host.log("🕳 إعادة محاولة ${cand.size} مقطع فاشل…")
        for (i in cand) {
            if (!running) break
            gapPass[i] = (gapPass[i] ?: 0) + 1
            try {
                if (translateChunk(i)) { failed.remove(i); host.log("✅ المقطع ${i + 1} اتترجم في إعادة المحاولة") }
                else host.log("⏳ المقطع ${i + 1}: صوته بيتفك في خيط تاني — الإعادة هتتجرّب اللفة الجاية")   // (v1376) مفيش «✅ اتترجم» كدابة والفشل بيفضل متسجل
            }
            catch (e: Unsupported) { fatal = e.message; host.log("⛔ ${e.message}"); running = false; break }
            catch (e: Exception) { host.log("⚠ المقطع ${i + 1} لسه فاشل: " + (e.message ?: e.toString()).take(120)) }
        }
        return true
    }

    // ===== ترجمة مقطع =====
    @Synchronized private fun src(): AudioSource = source ?: openSource().also { it.setPreRoll(if (conf.hiTiming || TrSlider.on("hitiming")) 3.0 else 0.0); source = it }

    private class Prep(val w: WavChunk, val rawStart: Double, val rawEnd: Double)

    private fun translateChunk(i: Int): Boolean {
        val pr = prepare(i, caller = "ثغرة") ?: return !prepBusy.contains(i)   // (v1376) فكّ مشغول في خيط تاني ≠ اتفرّغ ولا فشل — ميتحسبش نجاح
        if (!firstReqLogged && engineStartMs > 0) { firstReqLogged = true; host.log("⏱ أول طلب جيميناي اتبعت بعد ${System.currentTimeMillis() - engineStartMs}ms من ضغطة الزرار") }   // (v1354)
        send(i, pr)
        return true
    }
    /**
     * (v1065) خطوات الباتش الأول في الوضع السريع: 10ث ← 20ث ← 30ث ← الباقي. أول خطوة بتبدأ من مكان التشغيل (مش من أول الباتش)،
     * وبعد ما توصل لآخر الباتش بترجع تغطّي الجزء اللي قبل مكان التشغيل. الباتش بيفضل «مش مخلّص» لحد ما المجالات تغطّيه كله،
     * فالمحرك بيبعت الخطوة اللي بعدها لوحده. null = الباتش كله مرة واحدة.
     */
    private fun rampWindow(cs: Double, ce: Double): DoubleArray? {
        val size = rampSizes().getOrNull(rampStep) ?: Double.MAX_VALUE
        var a: Double
        if (rampStep == 0) {
            val pos = try { host.position() } catch (_: Throwable) { cs }
            a = done.nextGap(maxOf(cs, minOf(pos - 1.0, ce - 3.0)), ce)
        } else {
            a = done.nextGap(maxOf(cs, rampNext), ce)
            if (a >= ce - 0.05) a = done.nextGap(cs, ce)
        }
        if (a >= ce - 0.05) return null
        val g = done.gapEnd(a, ce)
        var b = minOf(g, a + size)
        if (g - b < 8.0) b = g
        return doubleArrayOf(a, b)
    }


    /** يفك الصوت (ويقصّر المقطع لأقرب لحظة صمت). null = مفيش حاجة تتبعت (صامت / مفيش صوت). */
    /** (v1373 — بطلب علي) فكّ الصوت بيحصل مرة واحدة بس للباتش: لو خيط تاني بيفك نفس الباتش في نفس اللحظة، النداء التاني بيتخطى وصاحبه بيكمّل شغله (الفك المزدوج كان بيبوّظ صوت أول باتش أحيانًا). force=true بيتجاوز المنع عمدًا (إعادة المحاولة) */
    // (v1381 — بطلب علي: «أول باتش مبيتفرغش أول 30 ثانية أو دقيقة») سدّ رأس الباتش: لو الصوت بدأ متأخر عن المطلوب (الفك بلع أول الصوت) أو أول جملة جت بعد وقت طويل من بداية باتش 1،
    // بنفك الجزء الناقص على حتت ≤ 20ث (الفك الصغير شغّال) ونفرّغه لوحده بنفس مسار سدّ الفجوات — ومحاولات فك متكررة لو الفك رجّع null (كان بيسيب الفجوة ساكتة)
    private val headTried = ConcurrentHashMap<Int, Long>()
    private fun headRecover(i: Int, a: Double, b: Double, why: String) {
        if (b - a < 3.0 || !running || isClosed) return
        val nw = System.currentTimeMillis()
        val prev = headTried.put(i, nw)
        if (prev != null && nw - prev < 120_000L) { headTried[i] = prev; return }
        host.log("🧩 باتش ${i + 1}: أول ${"%.0f".format(java.util.Locale.US, b - a)}ث ($why) من غير جمل — بسدّها لوحدها")
        Thread {
            try {
                val off = offFill()
                for (pt in Gaps.parts(a, b, 20.0)) {
                    var k = 0
                    while (running && !isClosed && k++ < 4) {
                        val probe = try { src().wav(pt[0], pt[1]) } catch (_: Throwable) { null }
                        if (probe == null) { host.log("… رأس باتش ${i + 1}: فك ${"%.0f".format(java.util.Locale.US, pt[0])}ث رجّع فاضي — محاولة ${k}/4"); nap(1500); continue }
                        if (probe.silent) { host.log("🔇 رأس باتش ${i + 1}: ${"%.0f".format(java.util.Locale.US, pt[0])}ث صامت فعلًا"); break }
                        val key = if (off) "off" else (pool.gapKey(gapKeys, rr.getAndIncrement()) ?: run { nap(2000); null })
                        if (key == null) continue
                        gapKeys.add(key)
                        try { fillGap(pt[0], pt[1], key) } finally { gapKeys.remove(key) }
                        break
                    }
                }
            } catch (e: Throwable) { try { LogStore.err("Engine:headRecover", e) } catch (_: Throwable) {} }
        }.apply { isDaemon = true; name = "head-recover" }.start()
    }
    private val prepJobs = ConcurrentHashMap.newKeySet<Int>()
    private val prepBusy = ConcurrentHashMap.newKeySet<Int>()   // (v1376) null بسبب «خيط تاني بيفك» ≠ null بسبب «مفيش صوت» — الاتنين كانوا بيرجعوا null فالنداءات كانت بتفسرهم غلط
    private val skipLogAt = ConcurrentHashMap<Int, Long>()   // (v1377) خنق سبام «اتخطّى الفكّ المزدوج»: نفس الباتش كان بيتسجّل ~١٠ مرات في الثانية
    private val extractNull = ConcurrentHashMap.newKeySet<Int>()   // (v1377) باتشات آخر فشل ليها كان «الفك رجّع فاضي» — ماتتختمش «اتأكد إنه فاضي» في الإعادة التلقائية
    private fun prepare(i: Int, force: Boolean = false, caller: String = "?"): Prep? {
        if (force) return prepareInner(i, force)
        if (!prepJobs.add(i)) {   // (v1376) اسم النداء بيتمرر ثابت — stackTrace methodName بيتعمّى في الريليز ($r8$lambda$…) وبقى عديم الفايدة في اللوج
            prepBusy.add(i)
            val nw = System.currentTimeMillis()   // (v1377) مرة كل ٣ ثواني لكل باتش بس
            if (nw - (skipLogAt[i] ?: 0L) > 3000L) { skipLogAt[i] = nw; host.log("🔊 باتش ${i + 1}: فكّ صوته شغّال بالفعل في خيط تاني (النداء من $caller) — اتخطّى الفكّ المزدوج") }
            return null
        }
        try { return prepareInner(i, force).also { prepBusy.remove(i) } } finally { prepJobs.remove(i) }
    }
    private fun prepareInner(i: Int, force: Boolean = false): Prep? {
        claimed.remove(i)   // محاولة جديدة للباتش ده من الأول
        val d = currentDur()
        // بنحجز الباتش ونقرا حدوده في خطوة واحدة: لو باتش قبله بيقصّر حدّه بالتوازي ماينفعش يسيب ثغرة
        val rawStart: Double; var rawEnd: Double
        synchronized(trimLock) {
            prepared.add(i)
            val cs = cStart(i); val ce = cEnd(i, d)
            val rw = if (rampOn && i == rampChunk) rampWindow(cs, ce) else null   // (v1065) خطوة صغيرة من الباتش بدل الباتش كله
            rawStart = rw?.get(0) ?: cs; rawEnd = rw?.get(1) ?: ce
        }
        val start = if (i == 0 && rawStart < 0.05) 0.0 else maxOf(0.0, rawStart - OVERLAP)
        host.status("⏳ ترجمة المقطع ${i + 1}…")
        if (i == 0 && engineStartMs > 0) host.log("⏱ باتش 1 بدأ تجهيز صوته بعد ${System.currentTimeMillis() - engineStartMs}ms من ضغطة الزرار")   // (v1354)
        val t0 = System.currentTimeMillis()
        val s0 = src()
        var w = s0.wav(start, rawEnd)
        // فك الصوت ساعات بيرجع null مؤقتًا (المصدر لسه بيفتح / شبكة) — نعيد قبل ما نعتبر المقطع من غير صوت
        // (v1374 — بطلب علي: «أول باتش مبيتفرغش») الفك ساعات بيبقى مش جاهز في أول ~١٥ ثانية بعد ضغطة الزرار (ويسبر وجروك) — نعيد محاولات أكتر وبرده أطول في فترة البداية قبل ما نحكم إن المقطع فاضي
        // (v1377) باتش 1 ميزانيته ٦٠ث من ضغطة الزرار مش ١٥: تجهيزه ممكن يتأخر بالتزاحم (جهاز علي بدأ بعد 20.6ث) فياخد ٣ محاولات بس ويتحكم عليه فاضي وهو فيه كلام
        val startup = engineStartMs > 0 && System.currentTimeMillis() - engineStartMs < (if (i == 0) 60_000 else 15_000)
        val maxTry = if (startup) 9 else 2
        val waitMs = if (startup) 1400L else 700L
        var retry = 0
        while (w == null && running && retry++ < maxTry) { host.log("… المقطع ${i + 1}: الصوت لسه ما طلعش — محاولة ${retry + 1}/${maxTry + 1}"); nap(waitMs); w = s0.wav(start, rawEnd) }
        if (w == null) {
            if (isClosed || !running) return null   // (v1376 — بطلب علي: «جروك أول باتش مجاش كامل») الإلغاء أثناء محاولات فك الصوت كان بيدخل فرع «مفيش صوت» ويعلّم المجال done ويحفظه نهائي — أول خطوات الباتش كانت بتضيع
            host.log("… المقطع ${i + 1} مفيهوش صوت")
            // لو ده مش آخر ذيل الفيديو يبقى غالبًا فشل فك مش صمت حقيقي: نعلّمه ⚠ عشان يتعاد بدل ما يبان ✅ فاضي
            if (d <= 0 || (rawEnd - rawStart > 5.0 && rawStart < d - 3.0)) { incomplete.add(i); extractNull.add(i); host.log("⚠ باتش ${i + 1}: مقدرتش أفك صوته — أعده من علامة التحذير") }
            done.add(rawStart, rawEnd); persist(); return null
        }
        extractNull.remove(i)   // (v1377) فك ناجح — امسح علامة فشل الفك
        // (v1381) تشخيص: الطلب مقابل اللي الفك رجّعه فعلًا (اللي بيفرق بينهم = صوت ضايع)
        val lead0 = w.startSec - start
        host.log("🧭 فك باتش ${i + 1}: طلب ${"%.1f".format(java.util.Locale.US, start)}→${"%.1f".format(java.util.Locale.US, rawEnd)}ث · الصوت بدأ ${"%.1f".format(java.util.Locale.US, w.startSec)}ث · طوله ${"%.1f".format(java.util.Locale.US, w.durSec)}ث")
        if (lead0 > 3.0) headRecover(i, start, w.startSec - 0.3, "الفك بدأ متأخر")
        if (rampOn && i == rampChunk && rampStep < 2 && !w.silent) {   // (v1067) ✂ قص صمت أول/آخر الخطوات الأولى
            val tr = try { AudioTools.trimSilence(w.bytes) } catch (_: Throwable) { null }
            if (tr != null) { host.log("✂ المقطع ${i + 1}: اتقص صمت ${"%.1f".format(w.durSec - tr.durSec)}ث من الأطراف"); w = WavChunk(tr.bytes, w.startSec + tr.leadSec, tr.durSec, false, w.gain, w.activeSec) }
        }
        host.log("🎧 صوت المقطع ${i + 1}: ${w.bytes.size / 1024}KB في ${System.currentTimeMillis() - t0}ms")
        // (v166) نضغط الصوت هنا (نفس خيط التجهيز) عشان الرفع يبدأ بحجم أصغر ونشوف النسبة في اللوج
        try { val pk = AudioEnc.pack(w.bytes); host.log("📦 المقطع ${i + 1}: ${pk.srcSize / 1024}KB ← ${pk.bytes.size / 1024}KB (${pk.mime.removePrefix("audio/")})") } catch (_: Throwable) {}
        return Prep(w, rawStart, rawEnd)
    }

    /**
     * (v1066) ⚡ سباق مفتاحين لأول خطوتين من الباتش الأول: الأصلي بالـ stream (بيعرض الجمل وهي بتوصل) والتاني نسخة عادية على مفتاح تاني.
     * أول رد ناجح يكسب، والتاني بيتجاهل. لو الاتنين فشلوا بيترمي خطأ الأصلي (عشان تحويل المفتاح/الكوتة يشتغل زي الأول).
     */
    private fun fastRace(i: Int, p: Prep, mdl: String, key: String, k2: String, prompt: String, bytes: ByteArray, durSec: Double, tmp: Double, scale: Double): Api.Result {
        val decided = java.util.concurrent.atomic.AtomicBoolean(false)
        val q = java.util.concurrent.LinkedBlockingQueue<Triple<Int, Api.Result?, Throwable?>>()
        val mt = Api.outTokens(durSec)
        host.log("⚡ باتش ${i + 1}: أول خطوات الوضع السريع على مفتاحين مع بعض — الأسرع يكسب")
        Thread {
            try {
                val sc = StreamSubs()
                q.add(Triple(1, Api.generateStream(mdl, key, prompt, bytes, mt, tmp) { acc -> if (!decided.get()) streamPreview(i, p, sc, acc, scale) }, null))
            } catch (e: Throwable) { q.add(Triple(1, null, e)) }
        }.apply { isDaemon = true; name = "fast-race-a" }.start()
        Thread {
            val t0 = System.currentTimeMillis()
            pool.begin(k2)
            try {
                val r = Api.generate(mdl, k2, prompt, bytes, maxTokens = mt, temp = tmp)
                pool.end(k2, System.currentTimeMillis() - t0, true)
                q.add(Triple(2, r, null))
            } catch (e: Throwable) {
                pool.end(k2, 0, false)
                if (e is ApiErr && e.code == 429) { noteQuota(); pool.block(k2, 60_000) }
                q.add(Triple(2, null, e))
            }
        }.apply { isDaemon = true; name = "fast-race-b" }.start()
        var errA: Throwable? = null; var errB: Throwable? = null
        var got = 0
        while (got < 2 && running) {
            val t = q.poll(500, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
            got++
            val res = t.second
            if (res != null) {
                decided.set(true)
                if (t.first == 2) host.log("⚡ باتش ${i + 1}: المفتاح التاني رجع الأول")
                return res
            }
            if (t.first == 1) errA = t.third else errB = t.third
        }
        decided.set(true)
        throw (errA ?: errB ?: Exception("الوضع السريع: الطلب اتلغى"))
    }

    /**
     * (v1067) ⚡ الخطوة الأولى (30ث) بتتقسم لطلبين بالتوازي على مفتاحين: أول 10ث + الباقي (مع تداخل 0.5ث عند الحد).
     * كل طلب بالـ stream وبيعرض جمله فورًا في نافذته؛ الرد النهائي بيتدمج (أوقات نسبة لأول الباتش بعد إرجاع التسريع) وبيتطبّق مرة واحدة.
     * NoSplit = مش ينفع نقسّم (مفتاح تاني/طول) فنكمل بطلب واحد.
     */
    private fun fastSplit(i: Int, p: Prep, mdl: String, key: String, promptFor: (Double) -> String, w: WavChunk, tmp: Double, spd: Double): Api.Result {
        val k2 = pool.pickFree(key, rr.getAndIncrement())?.takeIf { it != key } ?: throw NoSplit()
        val total = w.durSec
        val spAbs = maxOf(p.rawStart, w.startSec) + FAST_FIRST_SECS
        val sp = spAbs - w.startSec
        val ov = 0.5
        if (sp < 3.0 || sp > total - 4.0) throw NoSplit()
        val parts = listOf(
            doubleArrayOf(0.0, minOf(total, sp + ov)),
            doubleArrayOf(sp - ov, total))
        val pws = listOf(Prep(w, p.rawStart, spAbs), Prep(w, spAbs, p.rawEnd))
        val res = arrayOfNulls<Api.Result>(2); val err = arrayOfNulls<Throwable>(2)
        val latch = java.util.concurrent.CountDownLatch(2)
        host.log("⚡ باتش ${i + 1}: الخطوة الأولى طلبين بالتوازي (${"%.0f".format(sp)}ث + ${"%.0f".format(total - sp)}ث) على مفتاحين")
        for (ix in 0..1) {
            val k = if (ix == 0) key else k2
            Thread {
                val t0 = System.currentTimeMillis()
                if (ix == 1) pool.begin(k)
                try {
                    val a = parts[ix]; val dur = a[1] - a[0]
                    var bs = AudioTools.cut(w.bytes, a[0], a[1])
                    if (spd > 1.0) bs = try { AudioTools.speedUp(bs, spd) } catch (_: Throwable) { bs }
                    val sc = StreamSubs()
                    res[ix] = Api.generateStream(mdl, k, promptFor(dur / spd), bs, Api.outTokens(dur), tmp) { acc -> streamPreview(i, pws[ix], sc, acc, spd, a[0]) }
                    if (ix == 1) pool.end(k, System.currentTimeMillis() - t0, true)
                } catch (e: Throwable) {
                    if (ix == 1) { pool.end(k, 0, false); if (e is ApiErr && e.code == 429) { noteQuota(); pool.block(k, 60_000) } }
                    err[ix] = e
                } finally { latch.countDown() }
            }.apply { isDaemon = true; name = "fast-split-$ix" }.start()
        }
        while (running && !latch.await(500, java.util.concurrent.TimeUnit.MILLISECONDS)) { }
        if (!running) throw Exception("الوضع السريع: اتلغى")
        (err[0] ?: err[1])?.let { e -> throw (err.firstOrNull { it is ApiErr } ?: e) }
        val out = JSONArray(); var lang = ""; var trunc = false
        for (ix in 0..1) {
            val r = res[ix] ?: throw NoSplit()
            if (r.finish == "MAX_TOKENS") trunc = true
            if (r.text.isBlank()) continue
            val j = Parse.json(r.text) ?: throw BadReply("رد Gemini مش JSON صالح")
            if (lang.isEmpty()) lang = j.optString("detected_source_language")
            val arr = j.optJSONArray("subtitles") ?: continue
            for (x in 0 until arr.length()) {
                val o = arr.optJSONObject(x) ?: continue
                val s0 = Parse.sec(o, "start", 0.0) * spd + parts[ix][0]
                val e0 = if (o.has("end")) Parse.sec(o, "end", 0.0) * spd + parts[ix][0] else s0 + 1.0
                if (ix == 0 && s0 >= sp) continue
                if (ix == 1 && s0 < sp) continue
                out.put(JSONObject(o.toString()).put("start", s0).put("end", e0))
            }
        }
        val merged = JSONObject().put("subtitles", out)
        if (lang.isNotEmpty()) merged.put("detected_source_language", lang)
        return Api.Result(merged.toString(), if (trunc) "MAX_TOKENS" else "STOP")
    }

    private fun send(i: Int, p: Prep, backupFirst: Boolean = false, avoidKey: String? = null, hedge: Boolean = false, firstKey: String? = null) {
        val w = p.w; val rawStart = p.rawStart; val rawEnd = p.rawEnd
        val prior = subs
        // المفتاح الأقل شغلًا ثم الأسرع (مش تبادل بالدور): الباتشات بتمشي ورا بعض بدل ما الزوجية تتحبس على مفتاح بطيء
        fun nextKey(avoid: String?): String? = if (backupFirst) (pool.pickBackup(avoid) ?: pool.pickFree(avoid, rr.getAndIncrement())) else pool.pickFree(avoid, rr.getAndIncrement())
        // (v151) تغيير المفتاح أثناء الباتش: لأقرب مفتاح فاضي بس. لو كلهم مشغولين الباتش بيرجع للطابور (RehomeEx) بدل ما يتحط على مفتاح شغّال
        fun switchKey(cur: String): String? {
            if (hedge || backupFirst) return nextKey(cur)
            pool.pickIdle(i, cur, perKey)?.let { return it }
            if (nextKey(cur) == null) return null
            throw RehomeEx(cur)
        }
        var key = firstKey?.takeIf { pool.ok(it) } ?: (pool.pickIdle(i, avoidKey, perKey) ?: nextKey(avoidKey)) ?: throw Exception("كل المفاتيح معطلة مؤقتًا — راجع المفاتيح")   // (v459) أول اختيار = مفتاح فاضي فعلًا (الاحتياطي داخل لما الأساسيين مشغولين): كل مفتاح ليه باتش بالتوازي
        var partial = false
        var trunc = 0; var empties = 0; var bad = 0; var net = 0; var tries = 0; var langBad = 0
        val maxTries = if (groqTxOn()) 4 else MAX_TRIES   // (v1379) كل إعادة في جروك بتحرق ثواني صوت من حصة ASH/ASD (باتش ٣٠د = ١٨٠٠ث) — ٤ محاولات كفاية
        // (v1114) الرد الفاسد (BadReply) بيعيد الطلب من غير stream — الـ stream هو اللي بيرجّع JSON مكسور
        var badStream = false
        var langRetry = 0; var langSwitchRetry = 0
        var fbModel: String? = null   // (v1237) موديل احتياطي بعد خطأين ضغط ورا بعض
        var srv = 0   // (v459) مفيش موديل بديل: أخطاء السيرفر بتتعاد على نفس الموديل الواحد (كان في v227 بيبدّل لموديل تاني)
        val fastStep = fastLatched && !hedge && !backupFirst && i == rampChunk && rampStep < 2
        val spd = if (fastStep && FAST_SPEED > 1.0 && w.durSec >= 4.0 && !easternSrc() && !SongHint.on()) FAST_SPEED else 1.0   // (v1171) أغنية: من غير تسريع صوت   // (v1147) من غير تسريع صوت للغات الشرقية   // (v1067) تسريع الصوت
        val canSplit = fastStep && !Overload.busy() && rampStep == 0 && w.durSec >= 16.0 && !Offline.on() && !groqTxOn() && pool.usableCount() >= 2 && TrSlider.on("race")   // (v1067) طلبين بالتوازي   // (v1097) T2: TrSlider
        val sendBytes = if (spd > 1.0) { try { AudioTools.speedUp(w.bytes, spd) } catch (_: Throwable) { w.bytes } } else w.bytes
        val spdEff = if (sendBytes === w.bytes) 1.0 else spd
        val tx = activeMode >= KeyMode.SPLIT_A && i !in fullChunks && !fastLatched && !(rampOn && i == rampChunk)   // (v1141) خطوات التصاعد: تفريغ+ترجمة في طلب واحد // (v210) ترانسكريبشن بس، والترجمة بعدين مجمّعة على مفاتيح الترجمة
        while (running && tries++ < maxTries) {
            if (claimed.contains(i)) return   // نسخة تانية من الباتش ده خلصت وطُبّقت قبلنا
            if (!hedge) { keyOf[i] = key; offOf[i] = (tx && Offline.on()); groqOf[i] = (tx && groqTxOn()) }
            val prompt = buildPrompt(w.durSec / spdEff, w.startSec, langBad > 0 || (tx && empties > 0), i, tx = tx)
            try {
                val t0 = System.currentTimeMillis()
                val mdl = fbModel ?: curModel()   // (v459) موديل واحد بس دايمًا (v1237: إلا وقت ضغط جيميناي)
                var resScale = 1.0   // (v1067) معامل إرجاع الأوقات للأصل (الصوت المتسرّع)
                var gemCalled = false   // (v413) هل جيميناي اتنده فعلًا للباتش ده؟ (false = Whisper لوحده)
                groqRan.set(false); groqLang.set("")   // (v1369) تصفير علامة Groq قبل كل محاولة
                val r = run {
                    sentReq.add(i); pool.begin(key, i)
                    try {
                        val gem = {
                            gemCalled = true
                            val tmp = if (tx && empties == 0 && bad == 0 && trunc == 0) 0.0 else 0.1
                            if (fastLatched && !hedge && !tx && !badStream) {   // (v1065) ⚡ الجمل بتظهر أول ما تتقفل في الـ stream
                                var done: Api.Result? = null
                                if (canSplit) {
                                    try {
                                        done = fastSplit(i, p, mdl, key, { d -> buildPrompt(d, w.startSec, langBad > 0, i, tx = tx) }, w, tmp, spdEff)
                                        resScale = 1.0
                                    } catch (e: ApiErr) { throw e } catch (e: NoSplit) { } catch (e: BadReply) { throw e } catch (e: Exception) { host.log("⚠ الطلبين بالتوازي فشلوا (${(e.message ?: "").take(60)}) — طلب واحد") }
                                }
                                val sd = done
                                if (sd != null) sd
                                else {
                                    resScale = spdEff
                                    // (v1114) الكوتة واقعة (429): مفيش سباق مفتاحين — الباتش بيتبعت على مفتاح واحد بس لحد ما الكوتة ترجع
                                    val k2 = if (i == rampChunk && rampStep < 2 && !Overload.busy() && !Offline.on() && pool.usableCount() >= 2 && !quotaCooling() && TrSlider.on("race")) pool.pickFree(key, rr.getAndIncrement()) else null   // (v1097) T2: TrSlider
                                    if (k2 != null && k2 != key) fastRace(i, p, mdl, key, k2, prompt, sendBytes, w.durSec, tmp, spdEff)   // (v1066) أول خطوتين: نفس الطلب على مفتاحين والأسرع يكسب
                                    else {
                                        val sc = StreamSubs()
                                        Api.generateStream(mdl, key, prompt, sendBytes, Api.outTokens(w.durSec), tmp) { acc -> streamPreview(i, p, sc, acc, spdEff) }
                                    }
                                }
                            } else Api.generate(mdl, key, prompt, w.bytes, maxTokens = Api.outTokens(w.durSec), temp = tmp)
                        }   // (v331) التفريغ بحرارة 0 (أدق وثابت)؛ الإعادة بعد فشل بحرارة 0.1 عشان ما يرجعش نفس الرد
                        // (v253) ترانسكريبشن أوفلاين (Whisper على الجهاز) — لو فشل جيميناي (gem) بيكمّل الباتش
                        (if (tx && Offline.on()) { Offline.batchTag.set(i); Offline.transcribe(w.bytes, w.durSec, effectiveGloss().joinToString(", ") { it.term }, { host.log(it) }, gem, { host.notice(it) }, offSession) }
                            else if (tx && groqTxOn()) { if (tries <= 1) host.log("⚡ باتش " + (i + 1) + ": التفريغ بـ Groq (" + Cfg.str("groq_model", "whisper-large-v3-turbo") + ")"); groqResult(w.bytes, w.durSec) }   // (v1369 — بطلب علي) بلوك التفريغ ⚡ جروك · (v1371) سطر واضح بالمزوّد في اللوج
                            else { if (tx) Offline.whyOff()?.let { m -> host.log(m); Offline.softNotice(m) { host.notice(it) } }; if (tx && Cfg.str("mt_tr_mode", "") == "groq") host.log("⚠ بلوك التفريغ ⚡ جروك مختار بس مفيش مفتاح محفوظ — باتش " + (i + 1) + " اتفرّغ بجيميناي"); gem() }).also { pool.end(key, System.currentTimeMillis() - t0, true) }   // (v1371) لو جروك مختار والمفتاح ناقص اللوج يوضّح ليه جيميناي اشتغل
                    } catch (e: Throwable) { pool.end(key, 0, false); throw e }
                }
                val took = System.currentTimeMillis() - t0
                LogStore.add("⏱ [مشغّل-توقيت] باتش ${i + 1}: طلب الموديل " + took + "ms (" + (if (tx && groqRan.get() == true) "groq:" + Cfg.str("groq_model", "whisper-large-v3-turbo") else mdl) + (if (tx) ", تفريغ" else ", تفريغ+ترجمة") + (if (hedge) ", نسخة احتياطية" else "") + ", محاولة " + tries + ", من أول إرسال " + (startedAt[i]?.let { System.currentTimeMillis() - it } ?: -1L) + "ms)")   // (v1031 — م0)
                if (isClosed) return
                if (gemCalled) { Overload.ok(); pressureClear() }
                if (gemCalled) { flushModeMsg(); noteWho("🔑 جيميناي شغّال", " — باتش ${i + 1} بمفتاح " + pool.tail(key) + " (" + conf.keys.size + " أساسي)") }   // (v278)   // الإنجن اتقفل أثناء الطلب (خرجت من الفيديو): ارمي الرد
                if (r.finish == "MAX_TOKENS" && trunc >= 2) partial = true
                if (r.finish == "MAX_TOKENS" && trunc < 2) { trunc++; host.log("⚠ الرد اتقطع — إعادة المحاولة"); nap(600); continue }
                if (r.finish.isNotEmpty() && r.finish != "STOP" && r.finish != "MAX_TOKENS") throw Exception("رد Gemini اتوقف: ${r.finish}")
                var j: JSONObject? = null
                if (r.text.isNotBlank()) { j = Parse.json(r.text); if (j == null) throw BadReply("رد Gemini مش JSON صالح"); if (resScale != 1.0) scaleTimes(j, resScale) }
                var fresh = if (j == null) emptyList() else if (tx) TParse.transcript(j, w.startSec, w.durSec) else Parse.subs(j, w.startSec, w.durSec)
                // حارس اللغة: لو 30%+ من الجمل translated فيها مش بالعربي → إعادة المحاولة بتشديد، وبعدها إصلاح الباقي نصيًا (الترانسكريبشن مفيهوش translated فمالوش حارس هنا — الحارس بيشتغل بعد الترجمة)
                val off = if (tx) emptyList() else LangGuard.foreignOf(fresh)
                if (off.isNotEmpty() && off.size * 10 >= fresh.size * 3 && langBad < 2) {
                    langBad++; host.log("🌐 المقطع ${i + 1}: ${off.size}/${fresh.size} جملة مش بـ${conf.lang} — إعادة المحاولة")
                    nap(400); continue
                }
                if (off.isNotEmpty()) fresh = fixForeign(fresh)
                // (v267) الباتش اتفرّغ أوفلاين وطلع فاضي: Whisper بيرجّع نفس النتيجة لو أعدناه — بنعيد مرة واحدة بس لو اللغة اتقفلت بعد ما بدأ، وإلا بنقبله (مفيهوش كلام/موسيقى)
                val offRan = tx && (Offline.ranOffline.get() == true || groqRan.get() == true)   // (v1369) Groq بيتحسب زي الويشبر هنا
                if (offRan) {   // (v413) سجّل لغة التفريغ؛ ولو اليوزر غيّر اللغة والباتش شغّال بالقديمة: أعده بالجديدة
                    val ul = Offline.usedLang.get().orEmpty(); val man = Offline.lang()
                    if (!hedge && groqRan.get() != true && man.isNotEmpty() && ul != man && langSwitchRetry++ < 1) { host.log("🌐 المقطع ${i + 1}: اللغة اتغيّرت أثناء التفريغ (${ul.ifEmpty { "تلقائي" }} ← $man) — إعادة بالجديدة"); continue }
                    chunkLang[i] = if (groqRan.get() == true) groqLang.get().orEmpty() else ul.ifEmpty { Offline.gotLang.get().orEmpty() }
                }
                if (fresh.isEmpty() && offRan) {
                    val lk = offSession.lang
                    if (!w.silent && !hedge && groqRan.get() != true && lk.isNotEmpty() && lk != Offline.usedLang.get().orEmpty() && langRetry++ < 1) { host.log("🌐 المقطع ${i + 1}: فاضي — إعادة واحدة باللغة المقفولة ($lk)"); continue }
                    host.log("🔇 المقطع ${i + 1}: " + (if (groqRan.get() == true) "Groq" else "Whisper") + " ما لقاش كلام — اتقبل من غير إعادة")
                }
                // (v1094) الوضع السريع: خطوة جزئية من الباتش الأول رجعت فاضية وفيه جمل متترجمة قبلها = موسيقى/صمت. بتتقبل «خلصانة» بدل ما تتعاد 4 مرات وتتحط أولوية وتاخد مفاتيح الباتشات 2 و3 و4
                if (!offRan && !tx && !hedge && fresh.isEmpty() && rampOn && i == rampChunk && (rawStart > cStart(i) + 0.05 || rawEnd < cEnd(i, currentDur()) - 0.05) && subCount(i, currentDur()) > 0) {
                    pool.good(key)
                    host.log("🔇 باتش ${i + 1}: الخطوة ${"%.0f".format(java.util.Locale.US, rawStart)}ث → ${"%.0f".format(java.util.Locale.US, rawEnd)}ث مفيهاش كلام — اتقبلت من غير إعادة")
                    done.add(rawStart, rawEnd); failed.remove(i); incomplete.remove(i)
                    rampStep++; rampNext = rawEnd
                    persist(); return
                }
                if (!offRan && fresh.isEmpty() && !w.silent && !hedge && !backupFirst && (!fastLatched || empties >= 1) && queueBackup(i, p, "رجع من غير جمل")) return   // (v216) صفر جمل: على المفتاح الاحتياطي بالترتيب في كل الأوضاع
                if (!offRan && fresh.isEmpty() && empties < (if (w.silent) 1 else 3)) {
                    empties++
                    if (fastLatched && !tx && !w.silent && !SongHint.on() && TrSlider.on("light") && lightRetry.add(i)) host.log("⚡ باتش ${i + 1}: رجع فاضي — إعادة ببرومبت خفيف على مفتاح تاني (قبل الطابور الاحتياطي)")   // (v1139)
                    pool.markBad(key)
                    if (!w.silent) host.log("⚠ المقطع ${i + 1} رجع من غير جمل رغم وجود صوت — إعادة محاولة ($empties/3)")
                    switchKey(key)?.let { key = it }
                    nap(400); continue
                }
                // (دمج v1070) باتش فاضي مابقاش يتعلّم «خلص» — قبل كده applyChunk كان بيمسح failed وبيعلّم done فالثغرة كانت بتضيع نهائي
                if (!offRan && fresh.isEmpty() && !w.silent) {
                    pool.markBad(key)
                    failed[i] = MAX_FAILS
                    incomplete.add(i)
                    host.log("🕳 المقطع ${i + 1} رجع من غير جمل — اتسجل كفجوة وهيتعاد تلقائيًا")
                    persist()
                    return
                }
                pool.good(key)
                if (!claimed.add(i)) { host.log("↩ باتش ${i + 1}: نسخة تانية خلصته قبلها — اتجاهلت دي"); return }
                if (i > maxApplied) maxApplied = i
                runs[i] = KeyRun(keyNo(key), if (tx && groqRan.get() == true) "groq:" + Cfg.str("groq_model", "whisper-large-v3-turbo") else mdl, took, gemCalled)   // (v1369) موديل Groq يظهر باسمه في سجل الباتشات
                if (i == 0 && !hedge && fresh.isNotEmpty()) {   // (v1381) أول جملة جت متأخرة بعد بداية باتش 1 — غالبًا أول نافذة اتسقطت (الفك أو Whisper): نسدّ الرأس
                    val fs = fresh.minOf { it.start }
                    if (fs - rawStart > 12.0 && w.startSec <= rawStart + 3.0) headRecover(i, rawStart, fs - 0.5, "أول جملة بعد ${"%.0f".format(java.util.Locale.US, fs - rawStart)}ث")
                }
                if (tx && fresh.isNotEmpty()) {
                    // (v210) الباتش ما بيتطبّقش دلوقتي: بيتحط في المجمّع لحد ما يتترجم (applyChunk + سدّ الثغرات بيحصلوا بعد الترجمة)
                    val xc = crossCheck(i, w, fresh, key)   // (v742) تسميع مزدوج: مفتاح تاني يسمع نفس الباتش وأي اختلاف يتحسم بسماع تالت على الجملة
                    val txSrc = if (groqRan.get() == true) "groq" else if (gemCalled) "gemini" else if (Offline.ranOffline.get() == true) "whisper" else "gemini"   // (v1372) مصدر تفريغ الباتش ده (علامات ThreadLocal بتتصفّر قبل كل محاولة)
                    holdTranscript(i, p, j, relistenLow(i, xc.first, key, xc.second), prior, key, partial, txSrc)   // (v331) الجمل واطية الثقة بتتسمع تاني قبل الترجمة
                    startedAt[i]?.let { recentMs.addLast(System.currentTimeMillis() - it); while (recentMs.size > 8) recentMs.pollFirst() }
                    if (hedge) { inflight.remove(i); host.log("⚡ باتش ${i + 1}: النسخة الاحتياطية خلصت الأول") }
                    return
                }
                val rampWin = rampOn && i == rampChunk
                applyChunk(i, rawStart, rawEnd, w, j, fresh, prior)
                if (rampWin) { rampStep++; rampNext = rawEnd }   // (v1065) الخطوة الجاية أكبر
                if (!rampWin) startedAt[i]?.let { recentMs.addLast(System.currentTimeMillis() - it); while (recentMs.size > 8) recentMs.pollFirst() }   // خطوات التسخين القصيرة ما تقلّلش حد «الباتش المتأخر»
                if (hedge) { inflight.remove(i); host.log("⚡ باتش ${i + 1}: النسخة الاحتياطية خلصت الأول") }
                if (rampWin) holeTried.remove(i)   // (v1065) كل خطوة من الباتش السريع ليها سدّ ثغراتها
                scheduleHoleFill(i, rawStart, rawEnd, w, key)   // برّه خانة الباتش: الباتش الجاي مايستناش سدّ الثغرات
                if (partial) { incomplete.add(i); host.log("⚠ باتش ${i + 1} رجع ناقص — تقدر تعيده من علامة التحذير") }
                return
            } catch (e: BadReply) {
                if (bad++ < 2) {
                    badStream = true
                    pool.markBad(key)
                    host.log("⚠ ${e.message} — إعادة المحاولة")
                    nap(600)
                    continue
                }
                throw e
            } catch (e: ApiErr) {
                val invalid = e.code == 401 || e.code == 403 || (e.code == 400 && (e.message ?: "").contains("API key", true))
                if (e.code == 404 && fbModel != null && fbModel != curModel()) {   // (v1241) الموديل الاحتياطي مش متاح: بنعلّمه ميت ونختار غيره
                    val dm = fbModel!!; Models.markDead(dm)
                    val nx = Models.alt(curModel(), key)
                    host.log("⚠ الموديل $dm مش متاح لمفتاحك (404) — " + (if (nx == curModel()) "هكمّل على الأساسي" else "بجرّب $nx"))
                    fbModel = if (nx == curModel()) null else nx
                    srv = 0; continue
                }
                if (e.code == 429) {
                    noteQuota()
                    pool.block(key, 60_000)
                    val alt = switchKey(key)
                    if (alt != null) { host.log("⏳ ${(e.message ?: "").take(130)} على ${pool.tail(key)} — تحويل لمفتاح ${pool.tail(alt)}"); key = alt; continue }
                    val s = pool.streakUp(); val wait = minOf(60, 10 * s)
                    host.log("⏳ كل المفاتيح في كوتة (${(e.message ?: "").take(130)}) — انتظار ${wait}ث"); nap(wait * 1000L)
                    pool.clear(); continue
                }
                if (invalid) {
                    pool.block(key, 3_600_000)
                    val alt = switchKey(key)
                    if (alt != null) { host.log("🔑 ${(e.message ?: "").take(110)} — مفتاح ${pool.tail(key)} غير صالح — تحويل"); key = alt; continue }
                    throw Exception("مفتاح API غير صالح أو الموديل مش متاح — ${(e.message ?: "").take(120)}")
                }
                if (e.code >= 500) {
                    srv++
                    Overload.hit(); pool.markOver(key)
                    if (Models.FALLBACK && srv >= 2 && fbModel == null) { fbModel = Models.alt(curModel(), key).let { if (it == curModel()) null else it } ?: curModel(); host.log("⚠ جيميناي عليه ضغط (${e.code}) على كل المفاتيح — بجرّب موديل ${fbModel}") }
                    if ((srv >= 2 || (gateOn && gateThread === Thread.currentThread())) && Overload.active()) { pressureGate(key); srv = 0 }   // (v1244) ضغط جيميناي: استراحة دقيقة + طلب خفيف قبل ما نكمّل
                    else if (srv >= 2 || Overload.pressured()) nap(minOf(8000L, 1000L * (1L shl minOf(srv, 3))) + (Math.random() * 900).toLong())   // (v1304) ضغط ممتد: انتظار متصاعد بدل إعادة فورية تضرب نفس الموديل
                    // (v1114) 503 — تصحيح: إعادة فورية من غير أي انتظار — الأولوية لمفتاح تاني فاضي، ولو مفيش مفتاح فاضي الإعادة فورًا على نفس المفتاح
                    val alt = try { switchKey(key) } catch (_: RehomeEx) { null }
                    if (alt != null) {
                        key = alt
                        host.log("⚠ خطأ من السيرفر (${e.code}) — تحويل لمفتاح ${pool.tail(alt)} وإعادة المحاولة على نفس الموديل")
                    } else {
                        host.log("⚠ خطأ من السيرفر (${e.code}) — إعادة المحاولة على نفس الموديل")
                    }
                    continue
                }
                throw e
            } catch (e: Unsupported) { throw e
            } catch (e: IOException) {
                if (netHold(e, "باتش ${i + 1}")) { tries--; continue }   // (v1101) النت واقع فعلًا: استنى في مكانك (مش فشل ولا احتياطي) وكمّل أول ما يرجع
                if (++net > 4) throw e
                host.log("📶 مشكلة اتصال: ${(e.message ?: "").take(80)} — إعادة المحاولة"); nap(2000L * net)
            }
        }
        if (running) throw Exception("استنفدت المحاولات")
    }

    // ===== (v216) طابور المفتاح الاحتياطي (كل الأوضاع) =====
    // أي باتش يرجع من غير جمل أو يفشل على مفتاح أساسي بيتحط هنا، والمفتاح الاحتياطي بيترجمهم واحد ورا التاني بالترتيب (الأقدم الأول):
    // لو باتش 1 فشل وباتش 2 رجع صفر → باتش 1 الأول، ولما جمله ترجع يبدأ باتش 2. الباتش بيتبعت كطلب كامل (صوت ← ترجمة) بنفس الصوت المفكوك.
    private val bkQ = java.util.concurrent.ConcurrentSkipListMap<Int, Prep>()
    private val bkQueued = ConcurrentHashMap.newKeySet<Int>()
    private val bkRunning = AtomicBoolean(false)
    private fun activeInflight(): Int = inflight.count { it !in bkQueued }

    /** true = الباتش اتسلّم للاحتياطي (الأساسي يسيبه). false = مفيش مفتاح احتياطي → السلوك القديم */
    private fun queueBackup(i: Int, p: Prep, why: String): Boolean {
        if (!running || isClosed) return false
        if (pool.pickBackup(null) == null) return false
        if (claimed.contains(i)) return true
        if (bkQueued.add(i)) {
            bkQ[i] = p; inflight.add(i)
            host.log("🛟 باتش ${i + 1}: $why — اتحط في طابور المفتاح الاحتياطي (بالترتيب، في الطابور ${bkQ.size})")
            host.notice("🛟 باتش ${i + 1} رايح للمفتاح الاحتياطي")
        }
        startBkLane()
        return true
    }

    private fun sendOrBackup(i: Int, p: Prep, fk: String?) {
        try { send(i, p, firstKey = fk) }
        catch (e: Unsupported) { throw e }
        catch (e: RehomeEx) { throw e }
        catch (e: Exception) {
            if (!running || isClosed || !queueBackup(i, p, "فشل: " + (e.message ?: e.javaClass.simpleName).take(80))) throw e
        }
    }

    private fun startBkLane() {
        if (!bkRunning.compareAndSet(false, true)) return
        Thread {
            try {
                nap(1500)   // مهلة صغيرة عشان باتشات تانية فاشلة في نفس اللحظة تدخل الطابور وتترتب
                while (running && !isClosed) {
                    val e = bkQ.pollFirstEntry() ?: break
                    val i = e.key
                    try {
                        if (claimed.contains(i)) continue
                        host.log("🛟 باتش ${i + 1} ← المفتاح الاحتياطي (باقي ${bkQ.size} في الطابور)")
                        fullChunks.add(i)
                        send(i, e.value, true)
                        failed.remove(i)
                        host.log("🛟 باتش ${i + 1}: خلص على الاحتياطي — ${subCount(i, currentDur())} جملة")
                    } catch (x: Unsupported) {
                        fatal = x.message; host.log("⛔ ${x.message}"); host.status("⛔ ${x.message}"); running = false
                    } catch (x: Exception) {
                        failed[i] = MAX_FAILS
                        host.log("⚠ باتش ${i + 1} فشل برضه على الاحتياطي: " + (x.message ?: x.javaClass.simpleName).take(120))
                    } finally {
                        bkQueued.remove(i); inflight.remove(i); sentReq.remove(i); host.changed(); persist()
                    }
                }
            } finally {
                bkRunning.set(false)
                if (running && !isClosed && bkQ.isNotEmpty()) startBkLane()
            }
        }.apply { isDaemon = true; name = "backup-lane" }.start()
    }

    /** لهجة الباتش اللي بيتبعت: لو اتختارت لهجة، الباتش بيتترجم بيها مباشرة (من غير فصحى ثم تحويل — توفير على المفاتيح) */
    private val dialOf = ConcurrentHashMap<Int, String>()
    private val dialConf = ConcurrentHashMap<String, Conf>()
    /** (v742) كل طلب صوت لجيميناي بياخد بلوك «دقة السماع» في الآخر (لغات غير الإنجليزي بتتسمع غلط كتير بالصوت المضغوط) */
    private fun buildPrompt(durSec: Double, start: Double, strict: Boolean = false, chunk: Int = -1, hole: Boolean = false, holeNear: Boolean = false, tx: Boolean = false): String =
        buildPromptCore(durSec, start, strict, chunk, hole, holeNear, tx) + (if (lightOn(chunk, hole, tx) || !TrSlider.on("listen")) "" else listenBlock()) + (if (easternSrc() && !hole) easternBlock() else "") + songBlockLogged(tx)   // (v1097) T2 الخفيف من غير بلوك دقة السماع الطويل

    /** (v1171) 🎵 وضع الأغاني: بلوك آخر البرومبت (غنا = كلام حتى فوق الموسيقى + كلمات مرجعية من LRCLIB) — واللوج بيقول مرة واحدة ليه اشتغل */
    @Volatile private var songLogged = ""
    private fun songBlockLogged(tx: Boolean): String {
        if (!SongHint.on()) return ""
        val b = SongHint.block(tx, try { currentDur() } catch (_: Throwable) { 0.0 })
        val st = SongHint.state()
        if (st != songLogged) { songLogged = st; try { host.log("🎵 وضع الأغاني — $st · البرومبت الخفيف وتسريع الصوت متقفلين · قاعدة «تجاهل الموسيقى» متلغية") } catch (_: Throwable) {} }
        return b
    }

    private fun listenBlock(): String {
        val lang = if (detDone && srcLang.isNotBlank()) " The spoken language is $srcLang (the language name is written in Arabic)." else ""
        return "\n\n═══ LISTENING ACCURACY (applies to every \"original\") ═══\n" +
            "- 🔴 The audio is compressed speech: weak consonants, word endings and short function words are easy to lose. Listen to each phrase as a whole and use the grammar of the spoken language and the neighbouring sentences to choose between similar-sounding words.$lang\n" +
            "- 🔴 Write words that really exist in the spoken language and match the sounds. Never replace an unfamiliar word with a more common or English-sounding one, and never write English for non-English speech.\n" +
            "- 🔴 Names: use the spelling from the names list above when it is given; otherwise one consistent spelling for the whole segment.\n" +
            "- If a word is truly unclear, write your best phonetic reading and set low_confidence=true on that sentence. Never leave a gap and never invent words that were not said.\n"
    }

    /** (v742) المصدر مش إنجليزي (بعد ما اللغة اتحددت — الاسم بالعربي) */
    /** (v1147) لغة الكلام شرقية (يابانية/كورية/صينية/هندية/تايلاندية/فيتنامية…) — بعد ما اللغة اتحددت من أول باتش */
    private fun easternSrc(): Boolean {
        if (!detDone || srcLang.isBlank()) return false
        val n = srcLang.trim().lowercase()
        val keys = listOf("ياباني", "كوري", "صيني", "ماندرين", "كانتون", "هندي", "تايلاند", "فيتنام", "بنغال", "تاميل", "أردو", "اردو", "إندونيس", "اندونيس", "ملاو", "japan", "korean", "chines", "mandarin", "cantones", "hindi", "thai", "vietnam", "bengal", "tamil", "urdu", "indonesian", "malay", "日本", "한국", "中文")
        if (keys.any { n.contains(it) }) return true
        return langCodeOf(srcLang) in setOf("ja", "ko", "zh", "hi", "th", "vi", "bn", "ta", "ur", "id", "ms")
    }
    private fun easternBlock(): String =
        "\n\n═══ EASTERN-LANGUAGE HEARING ═══\n" +
        "- 🔴 Write every \"original\" in the language's NATIVE script (Japanese: kanji + kana · Korean: hangul · Chinese: hanzi · Hindi: devanagari · Thai: thai script). Never romanize and never write English in \"original\".\n" +
        "- 🔴 Listen to the WHOLE phrase before writing it: sentence-final particles/endings, short interjections and one-word replies are real sentences — do not skip, merge or drop them.\n" +
        "- 🔴 Do not paraphrase while listening: first write exactly what was said, then translate. If a word is unclear, give your best phonetic reading and set low_confidence=true.\n"

    private fun nonEnglishSrc(): Boolean = detDone && srcLang.isNotBlank() && !srcLang.contains("إنجليز") && !srcLang.contains("english", ignoreCase = true)

    private fun buildPromptCore(durSec: Double, start: Double, strict: Boolean = false, chunk: Int = -1, hole: Boolean = false, holeNear: Boolean = false, tx: Boolean = false): String {
        val dl = convDialect.let { if (it.isBlank() || it == "فصحى") "" else it }
        if (chunk >= 0) { if (dl.isEmpty()) dialOf.remove(chunk) else dialOf[chunk] = dl }
        val c = if (dl.isEmpty() || dl == conf.lang) conf else dialConf.getOrPut(dl) { conf.withLang(dl) }
        if (lightOn(chunk, hole, tx)) return ModePrompts.fast(pb, c, durSec, effectiveGloss(), if (detDone) srcLang else "", strict)   // (v1066) ⚡ برومبت خفيف للباتشات الأولى
        // (v209) الوضع 2+ (وكمان 3 و4 في طلبات الصوت): برومبت إنجليزي بدل القالب العربي — نفس شكل الرد فـ Parse.subs بيقراه عادي
        if (activeMode >= KeyMode.ALL_PARALLEL || tx) {   // (v239) tx يشتغل في كل الأوضاع (سدّ الثغرات بأسلوب الوضع 4)
            val prev = if (hole) "" else Subs.prevContext(subs, start)
            // (v210) tx = طلب ترانسكريبشن بس (الوضعين 3/4، الباتشات العادية). الثغرات والفجوات وإعادة الباتش الكامل بتفضل صوت ← ترجمة مباشرة
            val sl = if (detDone) srcLang else ""   // (v331) لغة الكلام الأصلية بعد ما تتحدد من أول باتش
            val base = if (tx) toneB() + ModePrompts.transcribe(pb, c, durSec, prev, effectiveChars(), effectiveGloss(), strict, hole, holeNear, sl, notes = !hole)
            else toneB() + ModePrompts.english(pb, c, durSec, prev, effectiveChars(), effectiveGloss(), strict, hole, holeNear, sl)
            return if (tx || hole) base else base + promptExtras(chunkPrevLine(start), chunkNextLine(start, durSec))   // (v469) سياق/أمثلة/ذاكرة/قاموس لبرومبتات الترجمة بس
        }
        val case = pb.caseOf(srcLang, detDone)
        val tf = if (case == "other") synchronized(tplCache) { tplCache[tplKey(pb.templateId(c, "other"))] } else null
        val built = toneB() + pb.build(c, srcLang, detDone, durSec, if (hole) "" else Subs.prevContext(subs, start), effectiveChars(), effectiveGloss(), tf, strict, hole)
        val built2 = if (hole && holeNear) built.replace(PromptBuilder.holeBlock(), PromptBuilder.holeNearBlock()) else built
        return if (hole) built2 else built2 + promptExtras(chunkPrevLine(start), chunkNextLine(start, durSec))   // (v469)
    }

    /** إصلاح الجمل اللي translated بتاعتها مش عربي: ترجمة نصية سريعة من original (وpivot) للهجة المختارة */
    private fun fixForeign(list: List<Sub>): List<Sub> {
        val bad = list.indices.filter { LangGuard.foreign(list[it]) }
        if (bad.isEmpty()) return list
        return try {
            val arr = JSONArray()
            for (k in bad) arr.put(JSONObject().put("idx", k).put("original", list[k].original).put("english", list[k].pivot).put("speaker_gender", list[k].gender).put("addressee_gender", list[k].addressee))
            val target = if (conf.lang == "فصحى") "العربية الفصحى" else "اللهجة ${conf.lang}"
            val prompt = "ترجم كل جملة من الجمل دي إلى $target بالحروف العربية فقط (الأسلوب: ${conf.style}). ماتسيبش أي جملة بلغتها الأصلية ولا بالإنجليزي. حافظ على المعنى كامل وعلى جنس المتكلم speaker_gender والمخاطَب addressee_gender.\n\nالجمل:\n$arr\n\n" +
                "أرجع JSON فقط: {\"rewrites\":[{\"idx\":0,\"translated\":\"...\"}]}"
            val r = bgCall(prompt, 4096, 0.3, true, 0)
            val rw = (Parse.json(r.text) ?: return list).optJSONArray("rewrites") ?: return list
            val out = list.toMutableList(); var n = 0
            for (q in 0 until rw.length()) {
                val c = rw.optJSONObject(q) ?: continue
                val ix = c.optInt("idx", -1); if (ix !in bad) continue
                val tr = c.optString("translated").trim()
                if (tr.isEmpty()) continue
                val ns = out[ix].copy(translated = tr)
                if (!LangGuard.foreign(ns)) { out[ix] = ns; n++ }
            }
            if (n > 0) host.log("🌐 اتصلّحت $n جملة كانت مش بـ${conf.lang}")
            out
        } catch (e: Exception) { host.log("⚠ إصلاح اللغة فشل: " + (e.message ?: "").take(80)); list }
    }

    private fun tplKey(id: String) = "$srcLang|$id"

    private fun effectiveChars(): List<Chr> = if (conf.manualChars.isNotEmpty()) conf.manualChars else synchronized(lock) { chars.toList() }
    private fun effectiveGloss(): List<Gloss> = synchronized(lock) { gloss.toList() }

    // ===== (v210) الوضعين 3 و4: ترانسكريبشن على مفاتيح + ترجمة جماعية (3–5 باتشات) على مفاتيح تانية =====
    // الباتش بعد الترانسكريبشن بيقعد في tHold (مش done، فالحلقة ماتبعتوش تاني ومحدش يعتبره خلص) لحد ما يتترجم ويتطبّق بتوقيته الأصلي.
    // لو الترجمة فشلت أو رجعت ناقصة بعد TR_ROUNDS جولات: الباتش يتبعت من جديد كطلب كامل (صوت ← ترجمة) — مفيش باتش بيتخطّى.
    private class TItem(val i: Int, val p: Prep, val j: JSONObject?, val fresh: List<Sub>, val prior: List<Sub>, val key: String, val partial: Boolean, val at: Long)
    private val tHold = ConcurrentHashMap<Int, TItem>()
    private val tTaken = ConcurrentHashMap.newKeySet<Int>()
    /** (v748) عدد الأجزاء اللي اتبعتت للترجمة؛ أول جزء بيتبعت بعد باتش واحد */
    private val partsSent = java.util.concurrent.atomic.AtomicInteger(0)
    private val fullChunks = ConcurrentHashMap.newKeySet<Int>()
    private val trBusy = AtomicInteger(0)
    private val trEx = Executors.newFixedThreadPool(4) { r -> Thread(r).also { it.isDaemon = true; it.name = "translate-group" } }

    // (v224) الوضع 4: النص المنسوخ بيظهر فورًا بلغته الأصلية (من غير ترجمة) لحد ما الترجمة السياقية تحلّ محلّه.
    // مابيتحسبش «مخلّص» (done) ومابيتحفظش على الديسك، وكل باتش بيتشال من القايمة دي أول ما يتطبّق بترجمته (applyChunk).
    private val previewChunks = ConcurrentHashMap.newKeySet<Int>()

    // (v227) حماية من أخطاء جوجل: 429 = الطلبات المتوازية تقلّ لـ 2 لمدة 5 دقايق + الاستعلامات الجانبية (اسم العمل/الشخصيات) تقف
    @Volatile private var quotaCapUntil = 0L
    private fun quotaCooling(): Boolean = System.currentTimeMillis() < quotaCapUntil
    // ===== (v1094) المشاهد أولًا =====
    /** الجزء اللي قدام المشاهد (من مكانه لـ 30ث قدام) لسه فيه باتش ناقص ممكن يتبعت: كل الشغل الجانبي (بحث الشخصيات · سدّ الثغرات والفجوات · نسخ احتياطية) واقف عشان المفاتيح تخدم المشاهد بس */
    private fun playheadHot(): Boolean {
        if (headless) return false
        val d = currentDur(); if (d <= 0) return false
        val pos = try { host.position() } catch (_: Throwable) { return false }
        val to = minOf(d, pos + 30.0)
        var i = (pos / ch).toInt().coerceAtLeast(0)
        while (cStart(i) < to) { if (!isDone(i, d) && (failed[i] ?: 0) < MAX_FAILS) return true; i++ }
        return false
    }
    private class HoleJob(val i: Int, val rawStart: Double, val rawEnd: Double, val w: WavChunk, val key: String)
    private val holeDefer = java.util.concurrent.ConcurrentLinkedQueue<HoleJob>()
    private val holeRetry = ConcurrentHashMap<Int, Int>()
    /** (v1304) ثغرة فشلت بـ5xx: ما تتحسبش «اتجرّبت» — بترجع للطابور وتتعاد لما الضغط يهدى (3 مرات بالكتير للمقطع) */
    private fun holeRequeue(i: Int, rs: Double, re: Double, w: WavChunk, key: String) {
        val n = (holeRetry[i] ?: 0) + 1; holeRetry[i] = n
        if (n > 3) return
        holeTried.remove(i)
        if (holeDefer.none { it.i == i }) { holeDefer.add(HoleJob(i, rs, re, w, key)); while (holeDefer.size > 4) holeDefer.poll() }
    }
    private fun holeDeferTick() {
        if (holeDefer.isEmpty() || playheadHot() || quotaCooling() || Overload.busy()) return
        val h = holeDefer.poll() ?: return
        scheduleHoleFill(h.i, h.rawStart, h.rawEnd, h.w, h.key)
    }
    @Volatile private var lastLoopPos = -1.0
    private fun capNow(c: Int): Int = if (System.currentTimeMillis() < quotaCapUntil) minOf(c, 2).coerceAtLeast(1) else c
    private fun noteQuota() {
        val now = System.currentTimeMillis()
        if (now >= quotaCapUntil) { warnUser("quota", "⚠ كوتة جيميناي خلصت (429) — الترجمة هتبطّأ 5 دقايق وبترجع لوحدها"); host.log("⚠ كوتة (429): الطلبات المتوازية اتقلّلت لـ 2 لمدة 5 دقايق، والبحث عن العمل/الشخصيات واقف لحد ما المفاتيح ترجع") }
        quotaCapUntil = now + 5 * 60_000L
    }
    /** الاستعلامات الجانبية (بحث اسم العمل · الشخصيات) بتشتغل بس لو فيه مفتاح شغّال ومفيش 429 جديد — عشان ماتاخدش كوتة من الترجمة نفسها */
    /** (v267) في «أوفلاين + جوجل» مهام جيميناي الجانبية (سدّ الفجوات · الضمائر · الشخصيات/اسم العمل) واقفة — إلا لو side_in_google=1 */
    /** (v283→v285) المهام الجانبية النصية (ضمائر · شخصيات): تشتغل بجيميناي، أو بمحرك LLM اللي اخترته في كارت ③ («يحوّل اللهجة بـ») لو مفيش جيميناي أو في مسار جوجل المجاني. محرك LLM مختار = موافقة منك على استهلاك مفتاحه */
    private fun sideOff(): Boolean {
        if (transOnly) return true
        val optIn = Cfg.bool("side_in_google", false) || convLlm() != null
        if (keyless) return convLlm() == null
        if (TrWizard.googleOn()) return !optIn
        return false
    }
    private fun sideOk(): Boolean = !sideOff() && System.currentTimeMillis() >= quotaCapUntil && !playheadHot() && (basePool.all().any { basePool.ok(it) } || convLlm() != null)
    @Volatile private var sideNoted = false
    /** (v285) إشعار واحد لكل تشغيل: إيه اللي اتقفل ولسه ليه وإزاي يتفتح — بدل ما يتقفل بصمت */
    private fun sideNotice() {
        if (transOnly || sideNoted) return
        sideNoted = true
        val closed = ArrayList<String>()
        if (sideOff()) { closed.add("تصحيح الضمائر"); closed.add("تحليل الشخصيات") }
        if (keyless) closed.add("التنقيح")
        if (!fillOk()) closed.add("سدّ الفجوات والثغرات")
        if (closed.isEmpty()) return
        val why = if (keyless) "مفيش مفتاح جيميناي" else "مسار جوجل المجاني"
        val hint = ""
        val msg = "ℹ واقف ($why): " + closed.joinToString(" · ") + hint
        host.log(msg); try { host.notice(msg) } catch (_: Throwable) {}
    }
    /** (v283) سدّ الثغرات/الفجوات بالأوفلاين نفسه (Whisper / SenseVoice / السحابي) بدل صوت جيميناي: في «تفريغ بس» وفي مسار جوجل/الخارجي وبدون مفتاح جيميناي. جيميناي مترجم = الطريقة القديمة (جيميناي) */
    private fun offFill(): Boolean = (Offline.configured() || groqTxOn()) && (transOnly || keyless || TrWizard.googleOn())   // (v1369) Groq زي الويشبر

    /** (v1369 — بطلب علي) تفريغ Groq سحابي شغّال؟ (بلوك التفريغ = ⚡ جروك + المفتاح موجود) */
    private fun groqTxOn(): Boolean = try { Cfg.groqTx() } catch (_: Throwable) { false }

    /** (v1371 — بطلب علي) سطر «مين شغّال»: في التفريغ بيذكر المفرّغ الحقيقي (جروك/وشبر/جيميناي) بعدّاد مفاتيحه بدل «جيميناي — 6 مفتاح» على طول */
    private fun whoLine(): String {
        if (!transOnly) return ExtTranslate.setupLine()
        if (groqTxOn()) return "المفرّغ: ⚡ جروك — مفتاح واحد (" + Cfg.str("groq_model", "whisper-large-v3-turbo") + ")"
        return if (Offline.on()) "المفرّغ: 🎙 وشبر على الجهاز" else "المفرّغ: 🔑 جيميناي — " + (Cfg.keys("keys").size + Cfg.keys("extra").size) + " مفتاح"
    }

    /** (v1369 — بطلب علي) تفريغ باتش واحد بـ Groq — نفس عقد Offline.transcribe بالظبط: Api.Result بـJSON التفريغ، واللغة المكتشفة بتتسجّل. بيرمي IOException/Unsupported عند الفشل (لوب المحاولات العادي بيتصرف) */
    private fun groqResult(bytes: ByteArray, durSec: Double): Api.Result {
        groqDot.set(4)   // (v1373) 🟡 طلب Groq شغّال دلوقتي
        val key = Cfg.str("groq_key", "").trim()
        val model = Cfg.str("groq_model", "whisper-large-v3-turbo").trim().ifEmpty { "whisper-large-v3-turbo" }
        val lang = try { Offline.lang() } catch (_: Throwable) { "" }   // لغة الكلام اليدوية (لو متحددة) بتتبعت لـ Groq، غير كده بيكتشف لوحده
        val wav = bytes.size > 4 && bytes[0] == 'R'.toByte() && bytes[1] == 'I'.toByte() && bytes[2] == 'F'.toByte() && bytes[3] == 'F'.toByte()   // RIFF
        val stylePrompt = "Transcribe the audio exactly as spoken, in its own language. لو الكلام عربي، فرّغه بالعامية الطبيعية زي ما بيتقال بالظبط — من غير تحويله لفصحى رسمية ولا ألفاظ قديمة."   // (v1375 — بطلب علي: «التفريخ في الجروك عربي سيء جدا وطالع باشا»)
        val (dl, segs) = try { GhAudio.groqTranscribeAudio(key, model, lang, if (wav) "chunk.wav" else "chunk.m4a", if (wav) "audio/wav" else "audio/mp4", bytes, stylePrompt) { host.log(it) } } catch (e: Throwable) { groqDot.set(2); throw e }   // (v1373) 🔴 عند فشل الطلب
        groqRan.set(true); groqLang.set(dl); groqDot.set(1); host.log("⚡ Groq (" + model + "): رجّع " + segs.size + " مقطع" + (if (dl.isNotEmpty()) " · اللغة: " + dl else ""))   // (v1371) إثبات واضح إن Groq هو اللي فرّغ
        val out = JSONArray()
        for (g in segs) {
            val t = g.third.trim()
            if (t.isEmpty() || t.startsWith("[") && t.endsWith("]") || t.startsWith("(") && t.endsWith(")")) continue   // [موسيقى] (تصفيق) — مش كلام
            out.put(JSONObject().put("start", g.first).put("end", g.second).put("original", t)
                .put("gender", "unknown").put("addressee", "unknown").put("topic_gender", "none")
                .put("people", JSONArray()).put("places", JSONArray()).put("is_song", false).put("emotion", "neutral")
                .put("low_confidence", false).put("overlap", false).put("speaker_tag", "").put("is_continuation", false).put("faint", false))
        }
        return Api.Result(JSONObject().put("subtitles", out).apply { if (dl.isNotEmpty()) put("detected_source_language", dl) }.toString(), "STOP")
    }
    private fun fillOk(): Boolean = !isClosed && (!sideOff() || offFill())
    /**
     * (v1065) ⚡ عرض الجمل المترجمة وهي لسه بتوصل من الـ stream (قبل ما الباتش يخلص): بتتعرض مؤقتًا بنفس شكل معاينة التفريغ،
     * وبعدين applyChunk بيحلّ محلّها بالنسخة النهائية. مفيش done ولا persist هنا — الباتش لسه ماخلصش.
     */
    private fun streamPreview(i: Int, p: Prep, sc: StreamSubs, acc: String, scale: Double = 1.0, shift: Double = 0.0) {
        if (isClosed || claimed.contains(i)) return
        if (sc.feed(acc) == 0) return
        try {
            val w = p.w
            val raw = sc.all.mapNotNull { o -> try { Parse.sub(if (scale == 1.0 && shift == 0.0) o else JSONObject(o.toString()).also { c -> c.put("start", Parse.sec(c, "start", 0.0) * scale + shift); if (c.has("end")) c.put("end", Parse.sec(c, "end", 0.0) * scale + shift) }, w.startSec) } catch (_: Throwable) { null } }
                .filter { it.original.isNotEmpty() && it.translated.isNotBlank() && !it.isSound && !LangGuard.foreign(it) && it.start >= p.rawStart - 1.0 && it.start < minOf(w.startSec + w.durSec, p.rawEnd) + 1.0 }
                .map { if (it.end > it.start) it else it.copy(end = it.start + 2.0) }
            if (raw.isEmpty()) return
            var tagged = Subs.splitAll(raw).map { Subs.capPace(it).copy(chunk = i) }
            synchronized(lock) {
                tagged = Subs.dropOverlapZone(tagged, subs.filter { it.chunk != i }, p.rawStart)
                val keep = subs.filter { !(it.chunk == i && it.start >= p.rawStart - 0.5 && it.start < p.rawEnd + 0.5) && !(it.chunk == -1 && it.start >= p.rawStart && it.start < p.rawEnd) && tagged.none { n -> Subs.straddlerCovers(n, it, p.rawStart) } }   // (v1376) الممتدة عبر الحد بتشيل المقطوعة القديمة
                subs = (keep + tagged).sortedBy { it.start }
            }
            previewChunks.add(i)
            host.changed()
        } catch (t: Throwable) { host.log("⚠ عرض الجمل الجاية فشل: " + (t.message ?: "").take(80)) }
    }

    private fun showTranscriptPreview(i: Int, p: Prep, fresh: List<Sub>, src: String = "") {
        if (isClosed || fresh.isEmpty()) return
        try {
            var tagged = Subs.splitAll(fresh.map { it.copy(translated = it.original, pivot = "", src = src) }).map { Subs.capPace(it).copy(chunk = i) }   // (v1372) الجمل المعروضة كتفريغ بتحمل مصدرها للتلوين
            synchronized(lock) {
                tagged = Subs.dropOverlapZone(tagged, subs.filter { it.chunk != i }, p.rawStart)
                val keep = subs.filter { it.chunk != i && !(it.chunk == -1 && it.start >= p.rawStart && it.start < p.rawEnd) && !Subs.inMyZone(it, tagged, i, p.rawEnd) && tagged.none { n -> Subs.straddlerCovers(n, it, p.rawStart) } }   // (v1376) الممتدة عبر الحد بتشيل المقطوعة القديمة
                subs = (keep + tagged).sortedBy { it.start }
            }
            previewChunks.add(i)
            // (v227) النص المنسوخ يتحفظ على الديسك قبل الترجمة السياقية ويتحسب «اتنسخ» — لو التطبيق اتقفل أو الترجمة فشلت ما بيتنسخش من الأول
            // (بعد الريستارت جمله بتتترجم بإصلاح اللغة الأجنبية التلقائي لحد ما الترجمة السياقية تحلّ محلها)
            done.add(p.rawStart, p.rawEnd)
            persist()
        } catch (e: Throwable) { host.log("⚠ عرض النص المنسوخ فشل: " + (e.message ?: "").take(80)) }
    }

    /** مفيش طلب ترانسكريبشن شغال ومفيش باتش منسوخ مستني الترجمة */
    private fun txIdle() = inflight.isEmpty() && tHold.isEmpty()

    // ===== (v742) التسميع المزدوج =====
    private class XcCand(val ix: Int, val a: Sub?, val b: Sub?, val score: Double)

    private fun tnorm(t: String): String { val sb = StringBuilder(t.length); for (ch in t.lowercase()) if (ch.isLetterOrDigit()) sb.append(ch); return sb.toString() }

    /** تشابه 0..1 بين نصين (Levenshtein على الحروف بعد التطبيع) */
    private fun tsim(a: String, b: String): Double {
        val x = tnorm(a); val y = tnorm(b)
        if (x.isEmpty() && y.isEmpty()) return 1.0
        if (x.isEmpty() || y.isEmpty()) return 0.0
        var prev = IntArray(y.length + 1) { it }; var cur = IntArray(y.length + 1)
        for (r in 1..x.length) {
            cur[0] = r
            for (c in 1..y.length) cur[c] = minOf(prev[c] + 1, cur[c - 1] + 1, prev[c - 1] + (if (x[r - 1] == y[c - 1]) 0 else 1))
            val t = prev; prev = cur; cur = t
        }
        return 1.0 - prev[y.length].toDouble() / maxOf(x.length, y.length)
    }

    /** أ موجودة جوه ب؟ (أقل تعديل بين أ وأي جزء متصل من ب) — بتمنع علامة اختلاف كدابة لما التاني دمج جملتين */
    private fun tcontain(a: String, b: String): Double {
        val x = tnorm(a); val y = tnorm(b)
        if (x.isEmpty()) return 1.0
        if (y.isEmpty()) return 0.0
        var prev = IntArray(y.length + 1); var cur = IntArray(y.length + 1)
        for (r in 1..x.length) {
            cur[0] = r
            for (c in 1..y.length) cur[c] = minOf(prev[c] + 1, cur[c - 1] + 1, prev[c - 1] + (if (x[r - 1] == y[c - 1]) 0 else 1))
            val t = prev; prev = cur; cur = t
        }
        return 1.0 - (prev.minOrNull() ?: x.length).toDouble() / x.length
    }

    /**
     * (v742) مفتاحين يسمعوا نفس الباتش: المفتاح التاني بيفرّغه تاني (حرارة 0.3 عشان ما يكررش نفس الغلطة)، وبنقارن الجمل بالتوقيت.
     * اتفقوا ← تمام (والثقة بتزيد). اختلفوا / واحد سمع جملة التاني ما سمعهاش ← سماع تالت على مقطع الجملة بس (WAV خام ±1.8ث) والحكم بيشوف القراءتين.
     * بيشتغل مع جيميناي بس (مش الأوفلاين). الإعداد dual_listen: 0 مقفول · 1 ذكي (لغة غير إنجليزي — الافتراضي) · 2 دايمًا.
     * بيرجّع (الجمل، توقيتات الجمل اللي اتحكم فيها — relistenLow بيتخطّاها).
     */
    private fun crossCheck(i: Int, w: WavChunk, fresh: List<Sub>, key0: String): Pair<List<Sub>, Set<Double>> {
        val none: Pair<List<Sub>, Set<Double>> = fresh to emptySet()
        val mode = try { Cfg.int("dual_listen", 1) } catch (_: Throwable) { 1 }
        if (mode == 0 || !TrSlider.on("cross") || Offline.on() || groqTxOn() || !running || isClosed || w.silent || fresh.isEmpty()) return none   // (v1100) T2b: السلايدر
        if (mode == 1 && !nonEnglishSrc() && !TrSlider.on("crossall")) return none   // (v1097) T2: TrSlider
        if (pool.usableCount() < 2) return none
        val keyB = pool.pickFree(key0, rr.getAndIncrement()) ?: return none
        if (keyB == key0) return none
        val t0 = System.currentTimeMillis()
        val rB = try {
            pool.begin(keyB)
            try { Api.generate(curModel(), keyB, buildPrompt(w.durSec, w.startSec, false, i, tx = true), w.bytes, maxTokens = Api.outTokens(w.durSec), temp = 0.3).also { pool.end(keyB, System.currentTimeMillis() - t0, true) } }
            catch (e: Throwable) { pool.end(keyB, 0, false); throw e }
        } catch (e: ApiErr) {
            if (e.code == 429) pool.block(keyB, 60_000)
            host.log("🎯 باتش ${i + 1}: التسميع المزدوج اتخطّى (${e.code})"); return none
        } catch (e: Throwable) { LogStore.err("Engine:dual", e); return none }
        if (isClosed || !running) return none
        if (rB.finish.isNotEmpty() && rB.finish != "STOP") return none   // رد ناقص: المقارنة هتبقى كدابة
        val jB = if (rB.text.isBlank()) null else Parse.json(rB.text)
        val hearB = if (jB == null) emptyList() else TParse.transcript(jB, w.startSec, w.durSec).filter { !it.isSound && it.original.isNotBlank() }
        if (hearB.isEmpty()) return none

        fun ov(a: Sub, b: Sub): Double { val o = minOf(a.end, b.end) - maxOf(a.start, b.start); return if (o <= 0.0) 0.0 else o / maxOf(0.2, minOf(a.end - a.start, b.end - b.start)) }
        val out = fresh.toMutableList()
        val cands = ArrayList<XcCand>()
        var agreeN = 0
        for (ix in fresh.indices) {
            val a = fresh[ix]
            if (a.isSound || a.isSong || a.original.isBlank()) continue
            val mates = hearB.filter { ov(a, it) >= 0.35 }
            val bt = mates.joinToString(" ") { it.original }
            val s = if (bt.isBlank()) 0.0 else maxOf(tsim(a.original, bt), tcontain(a.original, bt))
            if (s >= 0.78) { agreeN++; if (s >= 0.85 && a.lowConf) out[ix] = a.copy(lowConf = false) }
            else cands.add(XcCand(ix, a, mates.firstOrNull()?.copy(original = bt), s))
        }
        for (b in hearB) if (!b.isSong && fresh.none { ov(it, b) >= 0.35 }) cands.add(XcCand(-1, null, b, 0.0))   // جملة سمعها التاني بس
        if (cands.isEmpty()) { host.log("🎯 باتش ${i + 1}: تسميع مزدوج — المفتاحين اتفقوا في $agreeN جملة"); return out to emptySet() }

        var keyJ = pool.pickFree(keyB, rr.getAndIncrement()) ?: keyB
        val gl = effectiveGloss().joinToString(", ") { it.term }.take(400)
        val lang = if (detDone && srcLang.isNotBlank()) " in $srcLang" else ""
        val adj = HashSet<Double>(); var fixed = 0; var added = 0
        for (c in cands.sortedBy { it.score }.take(6)) {
            if (!running || isClosed) break
            val ref = c.a ?: c.b ?: continue
            try {
                val wv = src().wav(maxOf(0.0, ref.start - 1.8), ref.end + 1.8) ?: continue
                if (wv.silent) continue
                val heard = (if (c.a != null) "Listener 1 heard: «${c.a.original}». " else "Listener 1 heard nothing here. ") +
                    (if (c.b != null) "Listener 2 heard: «${c.b.original}». " else "Listener 2 heard nothing here. ")
                val pr = "You are a meticulous verbatim transcriber acting as the final judge between two independent listeners. This short audio contains one spoken sentence (with a little context before and after). $heard" +
                    "They disagree. Listen again very carefully and write exactly the words that are said$lang, using the sound only (never what the story would suggest). You may keep one reading, combine them, or write a different one if the sound says so. Keep it one sentence. " +
                    (if (gl.isNotBlank()) "Names and terms that appear in this video: $gl. " else "") +
                    "If it stays unclear, give your best reading and set low_confidence=true. If you hear no speech at all, return an empty original. " +
                    "Return JSON only: {\"original\":\"\",\"low_confidence\":false}"
                AudioEnc.lossless.set(true)
                val r = try { Api.generate(curModel(), keyJ, pr, wv.bytes, 512, 0.0) } finally { AudioEnc.lossless.set(false) }
                val j2 = if (r.text.isBlank()) null else Parse.json(r.text)
                val nt = j2?.optString("original", "")?.trim().orEmpty()
                val low = j2?.optBoolean("low_confidence", false) ?: false
                val ca = c.a; val cb = c.b
                if (ca != null) {
                    adj.add(ca.start)
                    if (nt.isEmpty()) { out[c.ix] = ca.copy(lowConf = true); continue }   // الحكم ما سمعش حاجة: منمسحش الجملة، بس نعلّم عليها
                    if (nt.length > ca.original.length * 2 + 20) continue
                    out[c.ix] = ca.copy(original = nt, lowConf = low)
                    if (nt != ca.original) fixed++
                } else if (cb != null && nt.isNotEmpty() && nt.length <= cb.original.length * 2 + 20 && tsim(nt, cb.original) >= 0.5) {
                    out.add(cb.copy(original = nt, lowConf = low)); added++   // جملة الأول فاتته والحكم أكّدها
                }
            } catch (e: ApiErr) {
                if (e.code == 429) { pool.block(keyJ, 60_000); keyJ = pool.pickFree(keyJ, rr.getAndIncrement()) ?: break } else break
            } catch (e: Throwable) { LogStore.err("Engine:dualJudge", e) }
        }
        host.log("🎯 باتش ${i + 1}: تسميع مزدوج بمفتاحين — اتفقوا في $agreeN جملة · اختلفوا في ${cands.size} · اتصحّح $fixed · اتضاف $added")
        return (if (added > 0) out.sortedBy { it.start } else out) to adj
    }

    /**
     * (v331) الجمل اللي جيميناي علّم عليها low_confidence: سماع تاني لنافذة ضيقة حواليها (±1.2ث) بمفتاح تاني، ومعاها قراءة المرة الأولى كمرجع.
     * بنستبدل النص بس لو الرد منطقي (مش فاضي ولا أطول بكتير)؛ التوقيت والباقي زي ما هو. أقصى 4 جمل للباتش. مش بيشتغل مع التفريغ الأوفلاين.
     */
    private fun relistenLow(i: Int, fresh: List<Sub>, key0: String, skip: Set<Double> = emptySet()): List<Sub> {
        if (!TrSlider.on("relisten") || Offline.on() || groqTxOn() || !running || isClosed) return fresh
        val idx = fresh.indices.filter { fresh[it].lowConf && !fresh[it].isSound && !fresh[it].isSong && fresh[it].original.isNotBlank() && fresh[it].start !in skip }.take(if (nonEnglishSrc()) 8 else 4)   // (v742) 8 للغات غير الإنجليزي · اللي اتحكم فيه بالتسميع المزدوج بيتخطّى
        if (idx.isEmpty()) return fresh
        val out = fresh.toMutableList()
        var key = pool.pick(key0, rr.getAndIncrement()) ?: key0
        var fixed = 0
        for (ix in idx) {
            if (!running || isClosed) break
            val s = fresh[ix]
            try {
                val wv = src().wav(maxOf(0.0, s.start - 1.8), s.end + 1.8) ?: continue   // (v742) ±1.8ث بدل ±1.2 (سياق أوسع)
                if (wv.silent) continue
                val lang = if (detDone && srcLang.isNotBlank()) " in $srcLang" else ""
                val nb = listOfNotNull(fresh.getOrNull(ix - 1)?.original?.takeIf { it.isNotBlank() }?.let { "before: «$it»" }, fresh.getOrNull(ix + 1)?.original?.takeIf { it.isNotBlank() }?.let { "after: «$it»" }).joinToString(" · ")
                val gl = effectiveGloss().joinToString(", ") { it.term }.take(400)
                val pr = "You are a meticulous verbatim transcriber. This short audio contains one spoken sentence (with a little context before and after). A first pass heard it as: «${s.original}» but was NOT sure. " +
                    "Listen again very carefully and write exactly the words that are said$lang, using the sound only (never what the story would suggest). Keep it one sentence. " +
                    (if (gl.isNotBlank()) "Names and terms that appear in this video: $gl. " else "") +
                    (if (nb.isNotBlank()) "Neighbouring sentences, for context only (do not transcribe them): $nb. " else "") +
                    "If it stays unclear, give your best reading and set low_confidence=true. If you hear no speech at all, return an empty original. " +
                    "Return JSON only: {\"original\":\"\",\"low_confidence\":false}"
                AudioEnc.lossless.set(true)   // (v742) المقطع قصير: WAV خام بدل AAC
                val r = try { Api.generate(curModel(), key, pr, wv.bytes, 512, 0.0) } finally { AudioEnc.lossless.set(false) }
                val j = if (r.text.isBlank()) null else Parse.json(r.text)
                val nt = j?.optString("original", "")?.trim().orEmpty()
                if (nt.isEmpty() || nt.length > s.original.length * 2 + 20) continue
                out[ix] = s.copy(original = nt, lowConf = j?.optBoolean("low_confidence", false) ?: s.lowConf)
                if (nt != s.original) fixed++
            } catch (e: ApiErr) {
                if (e.code == 429) { pool.block(key, 60_000); key = pool.pick(key, rr.getAndIncrement()) ?: break } else break
            } catch (e: Throwable) { LogStore.err("Engine:relisten", e) }   // (v468)
        }
        if (fixed > 0) host.log("🎧 باتش ${i + 1}: سماع تاني لـ ${idx.size} جملة واطية الثقة — اتصحّحت $fixed")
        return out
    }

    private fun holdTranscript(i: Int, p: Prep, j: JSONObject?, fresh: List<Sub>, prior: List<Sub>, key: String, partial: Boolean, txSrc: String = "") {
        if (j != null && !detDone) {
            val dl = j.optString("detected_source_language", "").trim()
            if (dl.isNotEmpty()) { srcLang = dl; detDone = true; host.log("🌐 لغة الفيديو الأصلية: $dl"); checkBaseSkip() } else try { fallbackDetectLang(fresh) } catch (_: Throwable) {}
        }
        try { SongHint.vote(fresh.count { it.isSong }, fresh.size) } catch (_: Throwable) {}   // (v1171) كشف الأغنية من الموديل
        if (transOnly) {   // (v280) تفريغ بس: النص الأصلي بيتعرض ويتحفظ ويتحسب «اتنسخ» من غير ما يدخل مجمّع الترجمة
            showTranscriptPreview(i, p, fresh, txSrc)
            host.log("✍ باتش ${i + 1}: ${fresh.size} جملة اتفرّغت — تفريغ بس (من غير ترجمة)")
            host.changed()
            scheduleHoleFill(i, p.rawStart, p.rawEnd, p.w, key)   // (v283) الثغرات بتتسدّ بالتفريغ الأوفلاين نفسه (مفيش ترجمة)
            return
        }
        tHold[i] = TItem(i, p, j, fresh, prior, key, partial, System.currentTimeMillis())
        if (activeMode >= KeyMode.TRANSCRIBE_ALL) showTranscriptPreview(i, p, fresh, txSrc)   // (v224) الوضع 4: اعرض النص الأصلي فورًا
        host.log("📝 باتش ${i + 1}: ${fresh.size} جملة منسوخة — مستني الترجمة (في المجمّع ${tHold.size - tTaken.size})")
        host.changed()
    }

    private fun releaseToFull(t: TItem, why: String) {
        if (keyless) {   // (v399) من غير مفتاح جيميناي: «طلب كامل» مستحيل (NoKey) — الباتش يفضل في المجمّع ويتعاد ترجمته بجوجل بعد شوية، وبعد 4 محاولات يفضل بنصه الأصلي والإصلاح التلقائي بيكمّله
            val n = trRetryN.merge(t.i, 1, Int::plus) ?: 1
            if (n < 4) {
                trRetryAt[t.i] = System.currentTimeMillis() + 8_000L * n
                host.log("🔁 باتش ${t.i + 1}: $why — هعيد الترجمة بجوجل ($n/3)"); host.changed(); return
            }
            trRetryN.remove(t.i); trRetryAt.remove(t.i); tHold.remove(t.i)
            host.log("⚠ باتش ${t.i + 1}: جوجل ماترجمش بعد 3 محاولات — فضل بنصه الأصلي ومحاولة الإصلاح التلقائي هتكمّله"); host.changed(); return
        }
        fullChunks.add(t.i); claimed.remove(t.i); tHold.remove(t.i)
        if (queueBackup(t.i, t.p, why)) { host.changed(); return }   // (v216) على المفتاح الاحتياطي بالترتيب
        host.log("↩ باتش ${t.i + 1}: $why — هيتبعت تاني كطلب كامل (صوت ← ترجمة) عشان ما يتخطّاش")
        host.changed()
    }

    /**
     * بيبعت للترجمة أقدم 3–5 باتشات منسوخة. بيستنى التجميع (TGROUP_MIN) إلا لو: [flush] (مفيش ترانسكريبشن جاي) أو الباتش مستني أكتر من
     * TR_MAX_WAIT_MS أو المشاهد واصل له تقريبًا أو الوضع اتبدّل لـ 1/2. بيرجع true لو بعت مجموعة.
     */
    private fun translateTick(flush: Boolean): Boolean {
        if ((activeMode >= KeyMode.TRANSCRIBE_ALL || Strict.mt()) && !switching) return contextTick()   // (v696) أوفلاين كامل: الترجمة بعد ما كل الباتشات تتفرّغ (رام)   // (v219) الوضع 4: ترجمة سياقية واحدة بعد ما كل الباتشات تتنسخ
        if (tHold.isEmpty() || !running || isClosed) return false
        if (trBusy.get() >= maxOf(1, trPool.capacity(1))) return false
        val avail = tHold.keys.filter { it !in tTaken }.sorted()
        if (avail.isEmpty()) return false
        val now = System.currentTimeMillis()
        val oldest = avail.minOf { tHold[it]?.at ?: now }
        val viewer = if (headless) -1 else (host.position() / ch).toInt()
        val urgent = activeMode < KeyMode.SPLIT_A || flush || switching || now - oldest > TR_MAX_WAIT_MS || (viewer >= 0 && avail.first() <= viewer + 1)
        if (!urgent && avail.size < TGROUP_MIN) return false
        val take = avail.take(TGROUP_MAX)
        val group = take.mapNotNull { tHold[it] }
        if (group.isEmpty()) return false
        tTaken.addAll(take); trBusy.incrementAndGet()
        try {
            trEx.submit {
                try { translateGroup(group) }
                catch (e: Exception) { host.log("⚠ ترجمة مجمّعة فشلت: " + (e.message ?: e.javaClass.simpleName).take(120)) }
                finally { tTaken.removeAll(take.toSet()); trBusy.decrementAndGet(); host.changed() }
            }
        } catch (_: RejectedExecutionException) { tTaken.removeAll(take.toSet()); trBusy.decrementAndGet(); return false }
        return true
    }

    private fun translateGroup(group: List<TItem>) {
        val dl = convDialect.let { if (it.isBlank() || it == "فصحى") "" else it }
        val c = if (dl.isEmpty() || dl == conf.lang) conf else dialConf.getOrPut(dl) { conf.withLang(dl) }
        val flat = ArrayList<Sub>(); val off = IntArray(group.size)
        group.forEachIndexed { g, t -> off[g] = flat.size; flat.addAll(t.fresh) }
        val tr = arrayOfNulls<String>(flat.size); val pv = arrayOfNulls<String>(flat.size)
        val tp = trPool
        val lastIdx = group.last().i
        host.log("🌍 ترجمة مجمّعة: باتشات " + group.joinToString("، ") { (it.i + 1).toString() } + " — ${flat.size} جملة")
        val cachedN = cachePrefill(flat, tr)   // (v469) A7: جمل جاهزة من كاش الأسطر ما بتتبعتش ولا بتكلّف مفاتيح
        if (cachedN > 0) host.log("💾 كاش الأسطر: $cachedN جملة من الكاش")
        var key: String? = null
        var round = 0; var langBad = 0; var swapped = false; var emptyRounds = 0   // (v1196)
        try {
            while (running && !isClosed && round < TR_ROUNDS) {
                val missing = flat.indices.filter { tr[it].isNullOrBlank() }
                if (missing.isEmpty()) break
                round++
                val tagMaps = HashMap<Int, Map<String, String>>()
                val items = missing.map { o -> val (pt, pm2) = protectTags(normAsr(flat[o].original)); if (pm2.isNotEmpty()) tagMaps[o] = pm2; flat[o].copy(original = pt) }   // (v469) A8 تطبيع ASR + A10 حجز الوسوم في نسخة الإرسال بس
                val first = items.first().start
                val before = synchronized(lock) { subs.filter { it.start < first && it.translated.isNotBlank() && !(it.isSound && (it.original.startsWith("📖") || it.original.startsWith("💡"))) }.takeLast(20) }   // (v425) الترانسكريبشن القديم + ترجمته (من غير سطور الشرح)
                val after = tHold.values.filter { it.i > lastIdx }.sortedBy { it.i }.flatMap { it.fresh }.take(6)
                val prompt = toneB() + ModePrompts.translate(pb, c, items, before, after, effectiveChars(), effectiveGloss(), langBad > 0) + promptExtras(before.lastOrNull()?.let { it.original.trim() + " ← " + it.translated.trim() } ?: "", after.firstOrNull()?.original?.trim() ?: "")   // (v469) A1 سياق صريح + A2/A3/A4
                var reply: JSONObject? = null
                var attempts = 0; var net = 0; var bad = 0
                while (running && !isClosed && reply == null && attempts++ < 6) {
                    val k = key?.takeIf { tp.ok(it) } ?: tp.pickFree(null, rr.getAndIncrement()) ?: pool.pickFree(null, rr.getAndIncrement())
                    if (k == null) { nap(1500); continue }
                    key = k
                    val t0 = System.currentTimeMillis()
                    try {
                        tp.begin(k)
                        val r = try { Api.generate(curModel(), k, prompt, null, maxTokens = (items.size * 150).coerceIn(4096, 16384), temp = 0.2).also { tp.end(k, System.currentTimeMillis() - t0, true) } }
                                catch (e: Throwable) { tp.end(k, 0, false); throw e }
                        if (isClosed) return
                        val jj = if (r.text.isBlank()) null else Parse.json(r.text)
                        if (jj == null) { if (++bad > 2) break; host.log("⚠ ترجمة مجمّعة: رد مش JSON صالح — إعادة"); nap(600); continue }
                        tp.good(k); reply = jj; flushModeMsg()
                    } catch (e: ApiErr) {
                        val invalid = e.code == 401 || e.code == 403 || (e.code == 400 && (e.message ?: "").contains("API key", true))
                        if (e.code == 429) { noteQuota(); tp.block(k, 60_000); key = null; host.log("⏳ ترجمة مجمّعة: كوتة على ${tp.tail(k)} — تحويل لمفتاح تاني"); nap(800); continue }
                        if (invalid) { tp.block(k, 3_600_000); key = null; host.log("🔑 ترجمة مجمّعة: مفتاح ${tp.tail(k)} غير صالح — تحويل"); continue }
                        if (e.code >= 500) { host.log("⚠ ترجمة مجمّعة: خطأ سيرفر (${e.code}) — إعادة"); nap(3000); continue }
                        throw e
                    } catch (e: Unsupported) { throw e
                    } catch (e: IOException) {
                        if (netHold(e, "ترجمة مجمّعة")) { attempts--; continue }   // (v1101)
                        if (++net > 4) throw e
                        host.log("📶 ترجمة مجمّعة: مشكلة اتصال — إعادة"); nap(2000L * net)
                    }
                }
                val rep0 = reply
                if (rep0 == null) { if (swapTranslate(items, missing, tr, pv) > 0) { swapped = true; continue } else break }   // (v286) بديل تلقائي
                val rep = rep0
                val got = TParse.translations(rep, items.size)
                // (v1196) رد جيميناي رجع JSON سليم لكن من غير ولا ترجمة (غالبًا خطأ 503/ضغط جوه الرد) — كان بيعيد نفس الطلب 4 مرات ورا بعض (حوالي دقيقة وربع ضايعة) قبل ما يروح للمفتاح الاحتياطي
                if (got.isEmpty() && items.isNotEmpty()) {
                    emptyRounds++
                    val errTxt = try { rep.optJSONObject("error")?.optString("message", "").orEmpty().take(60) ?: "" } catch (_: Throwable) { "" }
                    host.log("⚠ ترجمة مجمّعة: الرد رجع فاضي" + (if (errTxt.isNotBlank()) " ($errTxt)" else "") + " — تحويل لمفتاح تاني")
                    key?.let { tp.block(it, 20_000) }; key = null
                    if (emptyRounds >= 2) { host.log("🛟 ترجمة مجمّعة: رد فاضي مرتين — بسيبها للمفتاح الاحتياطي فورًا من غير تكرار"); break }
                    nap(1200); continue
                }
                val okMap = LinkedHashMap<Int, Pair<String, String>>()
                var offCount = 0
                for ((ix, pr) in got) { val o = missing[ix]; if (LangGuard.foreign(flat[o].copy(translated = pr.first))) offCount++; okMap[o] = pr }
                if (offCount > 0 && offCount * 10 >= got.size * 3 && langBad < 2) {
                    langBad++; host.log("🌐 ترجمة مجمّعة: $offCount/${got.size} جملة مش بالعربي — إعادة بتشديد"); continue
                }
                for ((o, pr) in okMap) { tr[o] = tagMaps[o]?.let { restoreTags(pr.first, it) } ?: pr.first; pv[o] = pr.second }   // (v469) A10: رجوع الوسوم المحجوزة
                if (got.size < items.size) host.log("↩ ترجمة مجمّعة: رجع ناقص ${items.size - got.size} جملة — هعيد الناقص بس")
            }
        } catch (e: Unsupported) {
            fatal = e.message; host.log("⛔ ${e.message}"); host.status("⛔ ${e.message}"); running = false; return
        } catch (e: Exception) {
            host.log("⚠ ترجمة مجمّعة: " + (e.message ?: e.javaClass.simpleName).take(120))
        }
        if (!running || isClosed) return
        applyGroupTranslated(group, off, tr, pv, if (swapped) "" else dl)
    }

    /** كل باتش بيتطبّق بجمله كلها بتوقيتها الأصلي بالترتيب (idx)، أو يرجع كطلب كامل (v219: اتفصلت عشان الترجمة السياقية تستخدمها كمان) */
    private fun applyGroupTranslated(group: List<TItem>, off: IntArray, tr: Array<String?>, pv: Array<String?>, dl: String) {
        // كل باتش بيتطبّق بجمله كلها بتوقيتها الأصلي بالترتيب (idx)، أو يرجع كطلب كامل
        var released = 0
        for ((g, t) in group.withIndex()) {
            if (tHold[t.i] !== t) continue   // اتعمله redo أثناء الترجمة
            val a = off[g]
            if ((a until a + t.fresh.size).any { tr[it].isNullOrBlank() }) { releaseToFull(t, "الترجمة رجعت ناقصة"); released++; continue }
            try {
                var list = t.fresh.mapIndexed { q, s -> s.copy(translated = tr[a + q]!!.trim(), pivot = pv[a + q].orEmpty()) }
                if (LangGuard.foreignOf(list).isNotEmpty()) list = fixForeign(list)
                if (Cfg.bool("refine2pass", false) || TrSlider.on("refine2")) list = refinePass2(t.i, list)   // (v1100) T2b: السلايدر (أو إعداد refine2pass القديم) ·   // (v469) A6: تحسين على مرحلتين (مطفي افتراضيًا)
                list = fidelityFix(t.i, list)   // (v469) A5: أمانة الأرقام والأسماء قبل التطبيق
                if (dl.isEmpty()) dialOf.remove(t.i) else dialOf[t.i] = dl
                applyChunk(t.i, t.p.rawStart, t.p.rawEnd, t.p.w, t.j, list, t.prior)
                tHold.remove(t.i); trRetryN.remove(t.i); trRetryAt.remove(t.i)
                if (t.partial) { incomplete.add(t.i); host.log("⚠ باتش ${t.i + 1} رجع ناقص — تقدر تعيده من علامة التحذير") }
                scheduleHoleFill(t.i, t.p.rawStart, t.p.rawEnd, t.p.w, t.key)
            } catch (e: Exception) { releaseToFull(t, "فشل تطبيق الترجمة: " + (e.message ?: "").take(80)) }
        }
        if (released > 0 && TrWizard.googleOn()) {   // (v274) المحركات الخارجية وجوجل ماكمّلوش: الباتشات دي بترجع كطلب كامل (احتياطي ثم صوت ← ترجمة) بمفاتيح جيميناي
            // (v389) إشعار واحد «فشل ← اتحوّل» وبس؛ لو مفيش تحويل (مفيش مفتاح جيميناي) مفيش إشعار (اللوج بس)
            if (keyless) { host.log("⚠ محركات الترجمة وقفت ومفيش مفتاح جيميناي — $released باتش هيتعاد لما تشتغل"); swapNotice("⚠ محركات الترجمة وقفت ومفيش مفتاح جيميناي يكمّل — $released باتش مستنيين (ضيف مفتاح أو شغّل محرك تاني)") }   // (v741) كان في اللوج بس
            else if (!Strict.noGemKeys()) swapNotice("🔄 فشلت محركات الترجمة (${ExtTranslate.chainLabel().substringBeforeLast(" ← ")}) — تم التحويل لجيميناي ($released باتش)")
        }
    }

    // ===== (v219) الوضع 4: ترانسكريبشن بكل المفاتيح، وبعدها ترجمة سياقية لكل النص (مرة واحدة أو أجزاء) =====
    private val CTX_PART_MAX = 260     // أقصى عدد جمل في الجزء الواحد (الأجزاء بتتقسم على حدود الباتشات)
    private val CTX_FULL_MAX = 1500    // لحد العدد ده بنبعت النص الكامل كسياق مع كل جزء، وفوقه بنبعت نافذة حوالين الجزء
    private val CTX_WINDOW = 300
    /** (v400) وضع «وشبر + جيميناي بالسياق»: عدد الباتشات في كل طلب ترجمة (2 أو 3)، 0 = الوضع مش شغّال */
    private fun ctxBatches(): Int = if (Cfg.str("tr_mode_id", "") == "loc_ctx" && Offline.configured() && !TrWizard.googleOn()) Cfg.int("ctx_batches", 3).coerceIn(2, 3) else 0
    private val GT_CTX_LINES = 30      // (v399) أقصى عدد سطور سياق (من الباتشات اللي قبل) مع كل طلب جوجل
    private val GT_CTX_CHARS = 2500    // (v399) وأقصى عدد حروف — الطلب ما بيكبرش مع طول الفيديو
    private val trRetryAt = ConcurrentHashMap<Int, Long>()   // (v399) باتش جوجل فشل في ترجمته: ميعاد المحاولة الجاية
    private val trRetryN = ConcurrentHashMap<Int, Int>()
    @Volatile private var ctxMsg = ""
    private val warnAtMap = java.util.concurrent.ConcurrentHashMap<String, Long>()
    /** (v258) إشعار للمستخدم بدل ما الخطأ يفضل في اللوج بس. [key] بيحدّد النوع — نفس النوع مرة كل 60 ث بالكتير */
    private fun warnUser(key: String, msg: String) {
        // (v389) إشعارات «فشل من غير تحويل» مابتظهرش (اللوج بس) — الإشعار الوحيد هو «فشل ← تم التحويل»
        if (key in quietFailKeys) { host.log(msg); return }
        if (keyless) return   // (v259) من غير مفتاح: خطوات جيميناي الجانبية بتتخطّى بهدوء (الإشعار الأساسي بيتعرض مرة واحدة)
        val n = System.currentTimeMillis()
        val last = warnAtMap[key] ?: 0L
        if (n - last < 60_000L) return
        warnAtMap[key] = n
        try { host.notice(msg) } catch (_: Throwable) {}
    }
    @Volatile private var whoKind = ""; @Volatile private var whoAt = 0L
    /** (v278) «مين اللي بيترجم فعلًا»: سطر لوج كل مرة، وإشعار لما النوع يتغيّر (أو كل 3 دقايق) — مش كل باتش */
    private fun noteWho(kind: String, detail: String) {
        host.log(kind + detail)
        val n = System.currentTimeMillis()
        if (kind == whoKind && n - whoAt < 180_000L) return
        whoKind = kind; whoAt = n
        try { host.notice(kind + detail) } catch (_: Throwable) {}
    }
    private val quietFailKeys = setOf("conv", "refine")   // (v741) ctx/part شالناهم: فشل الترجمة السياقية لازم يظهر (مرة/دقيقة بالكتير) مش في اللوج بس
    @Volatile private var swapNoticeAt = 0L   // (v274) آخر إشعار «محرك وقف ← التاني كمّل» (مرة كل 20 ث بالكتير)
    private val skipNoted = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()   // (v274) مزوّدين اتقال إنهم موقوفين (بيتشالوا لما يرجعوا)
    /** (v274) إشعار تبديل محرك الترجمة + سطر في اللوج */
    /** (v286) بديل تلقائي: جيميناي وقف في الترجمة النصية (كوتة / مفاتيح / رد غلط) ← الجمل الناقصة بتتترجم بسلسلة المترجمين (المحرك الخارجي/LLM ← جوجل) بدل ما تستنى. بيتقفل من «⋯ أكتر». مش بيشتغل في مسار جوجل (هو أصلًا بالسلسلة) */
    private fun autoSwapOn(): Boolean = Cfg.str("tr_autoswap", "on") != "off" && !transOnly && !TrWizard.googleOn() && TrWizard.online()
    private fun swapTranslate(items: List<Sub>, missing: List<Int>, tr: Array<String?>, pv: Array<String?>): Int {
        if (missing.isEmpty() || !running || isClosed) return 0
        if (!autoSwapOn()) {
            // (v741) البديل مقفول بإيدك: بلّغ بدل ما الجمل تفضل من غير ترجمة بصمت
            if (Cfg.str("tr_autoswap", "on") == "off" && !transOnly && !TrWizard.googleOn() && TrWizard.online())
                swapNotice("⚠ جيميناي فشل في " + missing.size + " جملة — البديل التلقائي مقفول (⚙ إعدادات الترجمة ← 🔄 بديل تلقائي)")
            return 0
        }
        val g = try { googleItems(items.map { it.original }) } catch (e: Throwable) { host.log("⚠ البديل التلقائي رمى خطأ: " + (e.message ?: e.javaClass.simpleName).take(100)); emptyList<String?>() }
        var n = 0
        for ((q, o) in missing.withIndex()) g.getOrNull(q)?.takeIf { it.isNotBlank() }?.let { tr[o] = it.trim(); pv[o] = ""; n++ }
        val chain = ExtTranslate.chainLabel().substringBeforeLast(" ← ")
        // (v741) الفول باك كان بيفشل بصمت لو البديل ماترجمش حاجة (مفيش إشعار) — دلوقتي بيقول إيه اللي حصل
        if (n >= missing.size) swapNotice("🔄 فشل جيميناي في الترجمة — تم التحويل لـ " + chain + " ($n جملة، فصحى؛ اللهجة بتتحوّل بعدين)")
        else if (n > 0) swapNotice("⚠ فشل جيميناي — البديل (" + chain + ") ترجم " + n + " من " + missing.size + " جملة، والباقي من غير ترجمة لحد ما يتعاد")
        else swapNotice("⚠ فشل جيميناي والبديل (" + chain + ") فشل كمان — " + missing.size + " جملة من غير ترجمة، هتتعاد تلقائي")
        return n
    }

    private fun swapNotice(msg: String) {
        host.log(msg)
        val n = System.currentTimeMillis()
        if (n - swapNoticeAt < 20_000L) return
        swapNoticeAt = n
        try { host.notice(msg) } catch (_: Throwable) {}
    }
    @Volatile private var gtNoticeAt = 0L   // (v255) آخر إشعار «جوجل فشل» (مرة كل 30 ث بالكتير)

    // (v265) حالة الأوفلاين للعرض (الكبسولة + اللوج الصغير): بيفرّغ إيه، اتفرّغ كام، مستني إيه، بيترجم إيه
    @Volatile private var offAt = 0L
    @Volatile private var offB = ""
    @Volatile private var offD = ""
    private fun offRefresh() {
        val now = System.currentTimeMillis()
        if (now - offAt < 800L) return
        offAt = now
        val d = currentDur(); val tot = if (d > 0) Math.ceil(d / ch).toInt() else 0
        val k0 = ctxBatches().takeIf { it > 0 } ?: if (Offline.live() || (TrWizard.googleOn() && Cfg.str("ctx_min", "").isEmpty())) 1 else maxOf(1, (Offline.partMin() * 60.0 / ch).toInt())
        val k = if (partsSent.get() == 0) 1 else k0   // (v748) أول جزء باتش واحد (الترجمة تظهر بدري)
        val doneN = if (tot > 0) (0 until tot).count { isDone(it, d) } else 0
        val held = tHold.size
        val txN = minOf(tot, doneN + held)
        val cur = inflight.minOrNull(); val trN = trBusy.get()
        val who = if (Strict.mt()) "HY-MT1.5 (أوفلاين)" else if (TrWizard.googleOn()) (if (ExtTranslate.semiLibre()) "LibreTranslate" else "جوجل") else "جيميناي"
        offB = "📴 $txN/$tot" + (if (trN > 0) " 🌍" else if (cur != null) " ⏳" else "")
        val sb = StringBuilder("📴 أوفلاين: اتفرّغ $txN من $tot باتش (الباتش ${ch.toInt()}ث)")
        val live = Offline.liveLine()
        if (live != null) { sb.append("\n").append(live); if (inflight.size > 1) sb.append(" (+${inflight.size - 1} مستنيين دورهم)") }   // (v415) تقدم Whisper الفعلي
        else if (cur != null) sb.append("\n⏳ بيفرّغ دلوقتي باتش ${cur + 1} على الجهاز")
        if (trN > 0) sb.append("\n🌍 بيترجم دلوقتي بـ$who")
        else if (held > 0) sb.append("\n⏸ جاهز $held باتش — الترجمة بتبدأ أول ما يجهز $k" + (if (Offline.live()) " (لحظي)" else " (≈ ${Offline.partMin()} د)"))
        else if (cur == null && txN < tot) sb.append("\n… مستني الباتش الجاي")
        offD = sb.toString()
    }
    fun offlineBrief(): String? { if (!Offline.configured() || !running) return null; offRefresh(); return offB }
    fun offlineDetail(): String? { if (!Offline.configured() || !running) return null; offRefresh(); return offD }

    /** كل الباتشات المطلوبة اتنسخت (مفيش حاجة شغالة ولا مستنية ولا مستنية إعادة) */
    private fun ctxReady(): Boolean {
        val d = currentDur()
        if (d <= 0 || inflight.isNotEmpty() || rehomeQ.isNotEmpty() || priorityRetry.isNotEmpty() || bkQ.isNotEmpty()) return false
        val only = onlyChunks
        val win = !keepGoing && !headless && only == null
        val cur = if (win) (host.position() / ch).toInt().coerceAtLeast(0) else 0
        var i = only?.first ?: cur
        val end = only?.last ?: if (win) cur + window - 1 else Int.MAX_VALUE
        while (i <= end && cStart(i) < d) {
            if (!(isDone(i, d) || (failed[i] ?: 0) >= MAX_FAILS || tHold.containsKey(i))) return false
            i++
        }
        return true
    }

    private fun contextTick(): Boolean {
        if (tHold.isEmpty() || !running || isClosed) return false
        if (trBusy.get() > 0) return false
        val nowT = System.currentTimeMillis()
        val avail = tHold.keys.filter { it !in tTaken && (trRetryAt[it] ?: 0L) <= nowT }.sorted()   // (v399) باتش جوجل فشل: بيستنى شوية قبل المحاولة الجاية
        if (avail.isEmpty()) return false
        if (!ctxReady() && (Offline.configured() || groqTxOn()) && !Strict.mt() && partTick(avail)) return true   // (v253) جزء كامل اتنسخ ← يتترجم فورًا
        if (!ctxReady()) {
            val m = if (Offline.configured()) { offRefresh(); offD.replace("\n", " · ") } else "📝 ترانسكريبشن: ${avail.size} باتش جاهز — الترجمة السياقية بتبدأ لما كل الباتشات تتنسخ"
            if (m != ctxMsg) { ctxMsg = m; host.status(m) }
            return false
        }
        val group = avail.mapNotNull { tHold[it] }
        if (group.isEmpty()) return false
        tTaken.addAll(avail); trBusy.incrementAndGet()
        try {
            trEx.submit {
                try { translateContextual(group) }
                catch (e: Exception) { warnUser("ctx", "⚠ الترجمة السياقية فشلت — جمل ممكن تفضل من غير ترجمة لحد ما تتعاد"); host.log("⚠ ترجمة سياقية فشلت: " + (e.message ?: e.javaClass.simpleName).take(120)) }
                finally { tTaken.removeAll(avail.toSet()); trBusy.decrementAndGet(); host.changed() }
            }
        } catch (_: RejectedExecutionException) { tTaken.removeAll(avail.toSet()); trBusy.decrementAndGet(); return false }
        return true
    }

    /**
     * (v253) الأوفلاين بطيء (دقايق للفيلم)، فمش بنستنى الفيلم كله: أول ما k باتش ورا بعض (= 5/10/20 دقيقة) يتنسخوا وماحدش قبلهم لسه شغّال
     * بيتبعتوا لجيميناي يترجمهم. الباقي (اللي أقل من جزء) بيتترجم لما كل الباتشات تخلص زي الوضع 4 العادي.
     */
    private fun partTick(avail0: List<Int>): Boolean {
        val k0 = ctxBatches().takeIf { it > 0 } ?: if (groqTxOn() && !TrWizard.googleOn()) 3 else if (Offline.live() || (TrWizard.googleOn() && Cfg.str("ctx_min", "").isEmpty())) 1 else maxOf(1, (Offline.partMin() * 60.0 / ch).toInt())   // (v399) جوجل: باتش بباتش · (v400) وضع السياق: 2–3 باتشات · (v1369) Groq: كل 3 باتشات (بطلب علي)
        val k = if (partsSent.get() == 0) 1 else k0   // (v748) أول جزء باتش واحد (الترجمة تظهر بدري)
        // (v739) الترجمة بتبدأ من مكان المشاهد ومن بعده (مش من أقدم باتش في الفيديو): قبل كده الجزء كان بيتاخد من الأقدم، فلو التفريغ ماشي عند مكانك والجزء ده مستني جاره
        // كان المحرك يترجم جزء قديم/بعيد الأول وبعدين يرجع لمكانك. ولو الباتش اللي المشاهد واصله جاهز بيتترجم على طول من غير ما يستنى يكمّل الجزء.
        val viewer = if (headless) -1 else (host.position() / ch).toInt()
        val fromViewer = if (viewer >= 0) avail0.filter { it >= viewer - 1 } else emptyList()
        val avail = if (fromViewer.isNotEmpty()) fromViewer else avail0
        val first = avail.first()
        var run = 1
        while (run < k && (first + run) in avail) run++
        val urgent = viewer >= 0 && first <= viewer + 1
        if (run < k && !urgent) return false      // فيه باتش ناقص في النص (لسه بيتنسخ أو متأخر) ومفيش مشاهد مستني
        val head = (first until first + run).toList()
        if (inflight.any { it < head.last() && it >= head.first() - 1 }) return false   // الباتش اللي قبله مباشرة لسه بيتنسخ: استنى عشان السياق
        val group = head.mapNotNull { tHold[it] }
        if (group.size != head.size) return false
        tTaken.addAll(head); trBusy.incrementAndGet(); partsSent.incrementAndGet()
        try {
            trEx.submit {
                try { translateContextual(group) }
                catch (e: Exception) { warnUser("part", "⚠ ترجمة جزء من الفيديو فشلت — هتتعاد تلقائي"); host.log("⚠ ترجمة جزء فشلت: " + (e.message ?: e.javaClass.simpleName).take(120)) }
                finally { tTaken.removeAll(head.toSet()); trBusy.decrementAndGet(); host.changed() }
            }
        } catch (_: RejectedExecutionException) { tTaken.removeAll(head.toSet()); trBusy.decrementAndGet(); return false }
        host.log("📴 جزء جاهز (${head.size} باتش" + (if (k > 1 && ctxBatches() == 0) " ≈ " + (if (Offline.configured()) Offline.partMin().toString() else maxOf(1, (head.size * ch / 60.0).toInt()).toString()) + " دقيقة" else "") + ") — اتبعت " + (if (TrWizard.googleOn()) (if (ExtTranslate.semiLibre()) "لـ LibreTranslate" else "لجوجل") else "لجيميناي") + " يترجمه")
        return true
    }

    /** (v254) ترجمة جوجل غير الرسمية لقايمة نصوص (لغة المصدر من إعداد الأوفلاين). بترجّع نفس الطول، والفاشل null */
    /** (v411) لغة المصدر لجوجل/ML Kit: اللي اخترتها بإيدك، وإلا (في مسار Whisper) لغة Whisper متراجعة بحروف النص، وإلا "auto" */
    private fun resolveSl(src: List<String>): String {
        val manual = Offline.lang()
        if (manual.isNotEmpty()) return if (manual == "zh") "zh-CN" else manual
        if (!OffLang.mergeOn()) return TrWizard.googleLang()
        langVote.add(src)
        val d = langVote.decide(srcLang.ifEmpty { offSession.hint })
        if (d != langVote.lastAnnounced) {
            langVote.lastAnnounced = d
            if (d.isNotEmpty()) {
                val c = langVote.conflict(srcLang.ifEmpty { offSession.hint })
                host.log("🌐 لغة الترجمة: ${OffLang.nameOf(d)}" + (c?.let { " ($it — اخترت بالحروف)" } ?: ""))
                if (c != null) try { host.notice("🌐 اللغة: ${OffLang.nameOf(d)} — $c") } catch (_: Throwable) {}
            }
        }
        return when { d.isEmpty() -> "auto"; d == "zh" -> "zh-CN"; else -> d }
    }

    /**
     * (v411) دمج الجمل المقطّعة: Whisper بيقطّع الجملة نصين، وML Kit/جوجل بيترجموا كل سطر لوحده فبيطلع مكسّر.
     * بنضم الأسطر المتتالية اللي مش واقفة بعلامة نهاية في جملة واحدة، نترجمها، وبعدين نقسم الترجمة على نفس الأسطر (والتوقيتات بتفضل زي ما هي لأن بنرجّع نص كل سطر بس).
     */
    private fun googleItems(src0: List<String>, ctx: List<String> = emptyList()): List<String?> {
        if (!OffLang.mergeOn() || src0.size < 2) return googleItemsRaw(src0, ctx)
        val clean = src0.map { normAsr(it.replace(Regex("\\s*\n\\s*"), " ")) }   // (v469) A8: تطبيع ترقيم ASR قبل الترجمة
        val groups = OffLang.group(clean)
        if (groups.all { it.size == 1 }) return googleItemsRaw(src0, ctx)
        val merged = groups.map { g -> OffLang.join(g.map { clean[it] }) }
        val tr = googleItemsRaw(merged, ctx)
        val out = arrayOfNulls<String>(src0.size)
        val redo = ArrayList<Int>()   // مجموعات الترجمة بتاعتها أقصر من عدد أسطرها — بتتترجم سطر سطر
        for ((gi, g) in groups.withIndex()) {
            val t = tr.getOrNull(gi)?.takeIf { it.isNotBlank() } ?: continue
            if (g.size == 1) { out[g[0]] = t; continue }
            val parts = OffLang.split(t, g.map { clean[it].length.coerceAtLeast(1) })
            if (parts == null) { redo.addAll(g); continue }
            for ((q, k) in g.withIndex()) out[k] = parts[q]
        }
        if (redo.isNotEmpty() && running && !isClosed) {
            val r = googleItemsRaw(redo.map { src0[it] }, ctx)
            for ((q, k) in redo.withIndex()) r.getOrNull(q)?.takeIf { it.isNotBlank() }?.let { out[k] = it }
        }
        val n = groups.count { it.size > 1 }
        if (n > 0) host.log("🔗 دمج الجمل: $n جملة مقطّعة اتترجمت كاملة وانقسمت على أسطرها")
        return out.toList()
    }

    private fun googleItemsRaw(src0: List<String>, ctx: List<String> = emptyList()): List<String?> {
        val src = src0.map { normAsr(it.replace(Regex("\\s*\n\\s*"), " ")) }   // (v469) A8: تطبيع ترقيم ASR قبل الترجمة
        val out = arrayOfNulls<String>(src.size)
        val sl = resolveSl(src)
        /** جوجل الداخلي (gtCall): 25 جملة في الطلب */
        // (v399) سياق جوجل: سطور الباتشات اللي قبل (ctx) + الجمل اللي قبلها في نفس الباتش بتتبعت قدام الطلب عشان جوجل يترجم بالسياق،
        // وبعدين بنشيل رد سطور السياق ونرجّع رد الجمل المطلوبة بس بنفس ترتيبها (يعني بنفس توقيتاتها). لو عدد الأسطر اختلف: نرجع للطلب من غير سياق
        val ctxL = ctx.map { it.replace(Regex("\\s*\n\\s*"), " ").trim() }.filter { it.isNotBlank() }
        fun lead(firstIdx: Int): List<String> {
            val pre = ArrayList<String>(ctxL)
            for (q in 0 until firstIdx) if (src[q].isNotBlank()) pre.add(src[q])
            val keep = ArrayList<String>(); var chars = 0
            for (s in pre.asReversed()) { if (keep.size >= GT_CTX_LINES || chars + s.length > GT_CTX_CHARS) break; keep.add(s); chars += s.length }
            return keep.asReversed()
        }
        fun viaGoogle(idx: List<Int>) {
            var failedB = 0
            for (b in idx.chunked(25)) {
                if (!running || isClosed) break
                try {
                    val ld = lead(b.first())
                    var r: List<String>? = null
                    if (ld.isNotEmpty()) r = gtCall(ld + b.map { src[it] }, "ar", sl)?.drop(ld.size)
                    if (r == null || r.size != b.size) r = gtCall(b.map { src[it] }, "ar", sl)
                    if (r != null) { for ((q, k) in b.withIndex()) out[k] = r[q] }
                    else for (k in b) { gtCall(listOf(src[k]), "ar", sl)?.firstOrNull()?.let { out[k] = it } }   // عدد الأسطر اختلف: جملة جملة
                } catch (e: Exception) { failedB++; host.log("⚠ ترجمة جوجل: " + (e.message ?: e.toString()).take(80)); if (failedB >= 3) break }
            }
        }
        /** (v272) مزوّد خارجي (MyMemory / Lingva / LibreTranslate / LLM…) للجمل اللي لسه ماترجمتش */
        fun viaExt(p: ExtTranslate.Prov, idx: List<Int>) {
            val r = ExtTranslate.run(p, idx.map { src[it] }, sl) { running && !isClosed }
            var n = 0
            for ((q, k) in idx.withIndex()) r.getOrNull(q)?.let { out[k] = it; n++ }
            host.log("🔀 ${p.label}: ترجم $n/${idx.size} جملة")
            if (n < idx.size && ExtTranslate.lastError.isNotEmpty()) host.log("⚠ ${p.label}: ${ExtTranslate.lastError}")
            ExtTranslate.lastNote.takeIf { it.isNotEmpty() }?.let { ExtTranslate.lastNote = ""; host.log(it); try { host.notice(it) } catch (_: Throwable) {} }   // (v274) مثلًا: الموديل اتغيّر لوحده
        }
        // (v696) 📴 أوفلاين كامل: Hy-MT2 على الجهاز بدل السلسلة كلها. Whisper يتحرر الأول، وجملة تفشل تفضل بأصلها (بتفضل null هنا فالباقي بيتعامل معاها)
        if (Strict.mt()) {
            val idx = src.indices.filter { src[it].isNotBlank() }
            if (idx.isNotEmpty() && running && !isClosed) {
                try {
                    Offline.releaseWhisper()
                    host.status("📴 بترجم أوفلاين (${idx.size} جملة)…")
                    val r = if (Offload.wanted()) Offload.translate(idx.map { src[it] }, Offline.lang(), { host.log(it) }) { d, n -> host.status("📱 ترجمة على الموبايل $d/$n") }   // (v698) م7
                    else LocalMt.translateAll(idx.map { src[it] }, Offline.lang(), { host.log(it) }) { d, n -> if (d % 10 == 0 || d == n) host.status("📴 ترجمة أوفلاين $d/$n") }
                    var n = 0
                    for ((q, k) in idx.withIndex()) { val t = r.getOrNull(q); if (!t.isNullOrBlank() && t != src[k]) { out[k] = t; n++ } }
                    host.log("📴 HY-MT1.5: ترجم $n/${idx.size} جملة")
                } catch (e: Throwable) {
                    host.log("⚠ ترجمة أوفلاين فشلت: " + (e.message ?: e.javaClass.simpleName).take(100))
                    try { LogStore.add("LocalMt: " + (e.message ?: e.javaClass.simpleName).take(120)) } catch (_: Throwable) {}
                    try { host.notice("⚠ موديل الترجمة الأوفلاين مش جاهز — " + (e.message ?: "").take(60)) } catch (_: Throwable) {}
                }
            }
            return out.toList()
        }
        // (v274) السلسلة: [المحرك الأساسي لو متحدد] ← باقي الخارجيين ← جوجل (حسب سويتش الترتيب) ← (لو كله فشل) الباتش بيتحوّل لجيميناي بمفاتيحك
        val steps = ExtTranslate.chain()   // null = جوجل الداخلي
        val who = LinkedHashMap<String, Int>()   // (v278) مين ترجم كام جملة في اللفة دي
        fun nm(st: ExtTranslate.Prov?): String = st?.label ?: "جوجل"
        for ((si, st) in steps.withIndex()) {
            if (!running || isClosed) break
            val need = src.indices.filter { out[it].isNullOrBlank() && src[it].isNotBlank() }
            if (need.isEmpty()) break
            val nextName = if (si + 1 < steps.size) nm(steps[si + 1]) else "جيميناي (مفاتيحك)"
            if (st != null) {   // مزوّد واقف (مفتاح مرفوض / كوتة / رصيد): بنعدّيه من غير ما نبعتله حاجة، وبنقول مرة واحدة بس
                val bw = ExtTranslate.blockedWhy(st.id, st.keyHash())
                if (bw != null) { if (skipNoted.add(st.id)) swapNotice("🔄 فشل ${st.label} ($bw) — تم التحويل لـ $nextName"); continue }
                skipNoted.remove(st.id)
            }
            if (st == null) viaGoogle(need) else viaExt(st, need)
            need.count { !out[it].isNullOrBlank() }.let { g -> if (g > 0) who[ExtTranslate.whoLabel(st)] = g }
            val left = src.indices.count { out[it].isNullOrBlank() && src[it].isNotBlank() }
            if (left > 0) {
                val why = if (st == null) "ما ردّش" else ExtTranslate.lastError.ifEmpty { "ما كمّلش" }
                if (st != null) skipNoted.add(st.id)
                swapNotice("🔄 فشل ${nm(st)} ($why) — تم التحويل لـ $nextName ($left جملة)")
            }
        }
        if (who.isNotEmpty()) noteWho("✅ بيترجم بـ " + who.keys.joinToString(" + "), " — " + who.entries.joinToString(" · ") { it.value.toString() + " جملة" })
        return out.toList()
    }

    /** طلب Gemini نصي واحد (من غير صوت) بإعادة المحاولة وتحويل المفتاح عند الكوتة/الخطأ. null = فشل */
    private fun askJson(prompt: String, maxTok: Int, tp: Pool, tag: String): JSONObject? {
        var key: String? = null
        var attempts = 0; var net = 0; var bad = 0
        while (running && !isClosed && attempts++ < 6) {
            val k = key?.takeIf { tp.ok(it) } ?: tp.pickFree(null, rr.getAndIncrement()) ?: pool.pickFree(null, rr.getAndIncrement())
            if (k == null) { nap(1500); continue }
            key = k
            val t0 = System.currentTimeMillis()
            try {
                tp.begin(k)
                val r = try { Api.generate(curModel(), k, prompt, null, maxTokens = maxTok, temp = 0.2).also { tp.end(k, System.currentTimeMillis() - t0, true) } }
                        catch (e: Throwable) { tp.end(k, 0, false); throw e }
                if (isClosed) return null
                val jj = if (r.text.isBlank()) null else Parse.json(r.text)
                if (jj == null) { if (++bad > 2) return null; host.log("⚠ $tag: رد مش JSON صالح — إعادة"); nap(600); continue }
                tp.good(k); flushModeMsg(); return jj
            } catch (e: ApiErr) {
                val invalid = e.code == 401 || e.code == 403 || (e.code == 400 && (e.message ?: "").contains("API key", true))
                if (e.code == 429) { noteQuota(); tp.block(k, 60_000); key = null; host.log("⏳ $tag: كوتة على ${tp.tail(k)} — تحويل لمفتاح تاني"); nap(800); continue }
                if (invalid) { tp.block(k, 3_600_000); key = null; host.log("🔑 $tag: مفتاح ${tp.tail(k)} غير صالح — تحويل"); continue }
                if (e.code >= 500) { host.log("⚠ $tag: خطأ سيرفر (${e.code}) — إعادة"); nap(3000); continue }
                throw e
            } catch (e: Unsupported) { throw e
            } catch (e: IOException) {
                if (netHold(e, tag)) { attempts--; continue }   // (v1101)
                if (++net > 4) throw e
                host.log("📶 $tag: مشكلة اتصال — إعادة"); nap(2000L * net)
            }
        }
        return null
    }

    /**
     * الباتشات المنسوخة كلها بتتترجم بالسياق: النص الكامل بيتبعت كسياق مع كل جزء، والجزء (لحد CTX_PART_MAX جملة) بيتترجم بعد اللي قبله بالترتيب
     * (الأجزاء ورا بعض عشان الأسماء والضمائر تفضل ثابتة)، وكل جزء بيتطبّق بمجرد ما يخلص. باتش رجع ناقص = يرجع كطلب كامل (احتياطي ثم صوت ← ترجمة).
     */
    private fun translateContextual(group0: List<TItem>) {
        val dl = convDialect.let { if (it.isBlank() || it == "فصحى") "" else it }
        val c = if (dl.isEmpty() || dl == conf.lang) conf else dialConf.getOrPut(dl) { conf.withLang(dl) }
        val group = group0.sortedBy { it.i }
        val flatAll = group.flatMap { it.fresh }
        val parts = ArrayList<List<TItem>>(); var cur = ArrayList<TItem>(); var n = 0
        for (t in group) {
            val pm = if (ctxBatches() > 0) 0 else Offline.partMin()   // (v253) 5/10/20 دقيقة للجزء (0 = بعدد الجمل بس) · (v400) وضع السياق: بعدد الباتشات بس
            if (cur.isNotEmpty() && (n + t.fresh.size > CTX_PART_MAX || (pm > 0 && (t.i - cur.first().i + 1) * ch > pm * 60.0))) { parts.add(cur); cur = ArrayList(); n = 0 }
            cur.add(t); n += t.fresh.size
        }
        if (cur.isNotEmpty()) parts.add(cur)
        host.log("🧠 ترجمة سياقية: ${flatAll.size} جملة من ${group.size} باتش — " + (if (parts.size == 1) "طلب واحد" else "${parts.size} أجزاء ورا بعض"))
        host.status("🧠 بترجم بالسياق الكامل (${flatAll.size} جملة)…")
        val tp = trPool
        val doneTr = ArrayList<Sub>()
        if ((Offline.configured() || groqTxOn()) && flatAll.isNotEmpty()) {   // (v253) الأجزاء بتتترجم أول بأول: آخر جمل اتترجمت قبل الجزء ده بتتبعت كسياق · (v1369) Groq زي الويشبر
            val f0 = flatAll.first().start
            doneTr.addAll(synchronized(lock) { subs.filter { it.start < f0 && it.translated.isNotBlank() && it.translated != it.original }.takeLast(if (ctxBatches() > 0) 40 else 12) })
        }
        var base = 0
        for ((pn, part) in parts.withIndex()) {
            if (!running || isClosed) return
            val flat = ArrayList<Sub>(); val off = IntArray(part.size)
            part.forEachIndexed { g, t -> off[g] = flat.size; flat.addAll(t.fresh) }
            val tr = arrayOfNulls<String>(flat.size); val pv = arrayOfNulls<String>(flat.size)
            val cachedN = cachePrefill(flat, tr)   // (v469) A7
            if (cachedN > 0) host.log("💾 كاش الأسطر: $cachedN جملة من الكاش (ترجمة سياقية)")
            var round = 0; var langBad = 0; var swapped = false
            try {
                while (running && !isClosed && round < TR_ROUNDS) {
                    val missing = flat.indices.filter { tr[it].isNullOrBlank() }
                    if (missing.isEmpty()) break
                    round++
                    val tagMaps = HashMap<Int, Map<String, String>>()
                    val items = missing.map { o -> val (pt, pm2) = protectTags(normAsr(flat[o].original)); if (pm2.isNotEmpty()) tagMaps[o] = pm2; flat[o].copy(original = pt) }   // (v469) A8 + A10 في نسخة الإرسال بس
                    if (TrWizard.googleOn()) {   // (v254) الترجمة بجوجل (من غير API): 25 جملة في الطلب؛ اللي فشل بيتعاد في اللفة الجاية، ولو الكل فشل الباتشات بتتسلّم لجيميناي
                        val gf = flat.first().start
                        val gctx = synchronized(lock) { subs.filter { it.start < gf && it.original.isNotBlank() && !it.isSound }.takeLast(GT_CTX_LINES).map { it.original } }   // (v399) الباتشات اللي قبل كسياق
                        val g = googleItems(missing.map { normAsr(flat[it].original) }, gctx)   // (v469) جوجل بياخد الأصل المُطبّع من غير حجز الوسوم (شبكة الأمان في applyChunk بترجّعها)
                        var okN = 0
                        for ((q, o) in missing.withIndex()) g.getOrNull(q)?.takeIf { it.isNotBlank() }?.let { tr[o] = it; pv[o] = ""; okN++ }
                        if (okN == 0) {
                            host.log("⚠ ترجمة جوجل: مفيش جملة اترجمت (النت أو جوجل واقف) — الباتشات هتتسلّم لجيميناي")
                            val now = System.currentTimeMillis()
                            if (now - gtNoticeAt > 30_000L) { gtNoticeAt = now; (if (!TrWizard.online()) TrWizard.NO_NET_MSG else if (keyless) null else "🔄 فشلت محركات الترجمة (${ExtTranslate.chainLabel().substringBeforeLast(" ← ")}) — تم التحويل لجيميناي")?.let { m -> host.notice(m) } }   // (v255)
                            break
                        }
                        continue
                    }
                    val full = flatAll.size <= CTX_FULL_MAX
                    val lo = if (full) 0 else (base - CTX_WINDOW).coerceAtLeast(0)
                    val hi = if (full) flatAll.size else (base + flat.size + CTX_WINDOW).coerceAtMost(flatAll.size)
                    val prompt = toneB() + ModePrompts.contextual(pb, c, flatAll.subList(lo, hi), lo, missing.map { base + it }, items, doneTr, effectiveChars(), effectiveGloss(), pn + 1, parts.size, langBad > 0, beforeMax = if (ctxBatches() > 0) 40 else 20) + promptExtras(withCtx = false)   // (v469) A2/A3/A4 (السياق الكامل موجود أصلًا في الوضع ده)
                    val rep0 = askJson(prompt, (items.size * 90).coerceIn(4096, 32768), tp, "ترجمة سياقية")
                    if (rep0 == null) { if (swapTranslate(items, missing, tr, pv) > 0) { swapped = true; continue } else break }   // (v286) بديل تلقائي
                    val rep = rep0
                    val got = TParse.translations(rep, items.size)
                    val okMap = LinkedHashMap<Int, Pair<String, String>>()
                    var offCount = 0
                    for ((ix, pr) in got) { val o = missing[ix]; if (LangGuard.foreign(flat[o].copy(translated = pr.first))) offCount++; okMap[o] = pr }
                    if (offCount > 0 && offCount * 10 >= got.size * 3 && langBad < 2) {
                        langBad++; host.log("🌐 ترجمة سياقية: $offCount/${got.size} جملة مش بالعربي — إعادة بتشديد"); continue
                    }
                    for ((o, pr) in okMap) { tr[o] = tagMaps[o]?.let { restoreTags(pr.first, it) } ?: pr.first; pv[o] = pr.second }   // (v469) A10: رجوع الوسوم المحجوزة
                    if (got.size < items.size) host.log("↩ ترجمة سياقية (جزء ${pn + 1}): رجع ناقص ${items.size - got.size} جملة — هعيد الناقص بس")
                }
            } catch (e: Unsupported) {
                fatal = e.message; host.log("⛔ ${e.message}"); host.status("⛔ ${e.message}"); running = false; return
            } catch (e: Exception) {
                warnUser("ctx", "⚠ الترجمة السياقية (جزء ${pn + 1}) فشلت — الجمل دي هتتعاد"); host.log("⚠ ترجمة سياقية (جزء ${pn + 1}): " + (e.message ?: e.javaClass.simpleName).take(120))
            }
            if (!running || isClosed) return
            applyGroupTranslated(part, off, tr, pv, if (swapped) "" else dl)
            for (k in flat.indices) tr[k]?.takeIf { it.isNotBlank() }?.let { doneTr.add(flat[k].copy(translated = it)) }
            base += flat.size
            host.log("🧠 ترجمة سياقية: خلص جزء ${pn + 1}/${parts.size}")
        }
    }

    private fun applyChunk(i: Int, rawStart: Double, rawEnd: Double, w: WavChunk, j: JSONObject?, fresh0: List<Sub>, prior: List<Sub>) {
        if (isClosed) return
        previewChunks.remove(i)   // (v224) الترجمة الحقيقية حلّت محلّ العرض المؤقت للنص الأصلي
        var fresh = if (baseSkipped) fresh0.map { it.copy(translated = it.original) } else fresh0   // (v467) اللغة الأساسية: أي باتش اتترجم قبل ما اللغة تتكشف بيعدّي بنصه الأصلي
        if (!baseSkipped) { fresh = enforceGlossary(fresh); fresh = fresh.map { s -> if (s.translated.isNotBlank()) s.copy(translated = restoreKnownTags(s.original, s.translated)) else s } }   // (v469) A4 قاموس قسري عند الاستلام + A10 رجوع وسوم غير الكلام
        if (j != null && !detDone) {
            val d = j.optString("detected_source_language", "").trim()
            if (d.isNotEmpty()) { srcLang = d; detDone = true; host.log("🌐 لغة الفيديو الأصلية: $d"); checkBaseSkip(); maybeTranslateTemplate() } else try { fallbackDetectLang(fresh0) } catch (_: Throwable) {}
        }
        if (j != null) applyPrevCorrections(j)
        try { SongHint.vote(fresh0.count { it.isSong }, fresh0.size) } catch (_: Throwable) {}   // (v1171) كشف الأغنية من الموديل
        val spansAbs = Speech.activeSpans(w.bytes, w.gain)?.let { Speech.absolute(it, w.startSec) }
        val direct = dialOf[i]?.let { it == convDialect } ?: false
        var tagged = Subs.splitAll(fresh).map { Subs.capPace(it).copy(chunk = i, conv = direct) }
        // (v177) لو الكاشف ماطلّعش ولا مجال صوت والمقطع مش صامت (صوت واطي جدًا) ماينفعش نشيل جمل على أساسه
        if (spansAbs != null && (spansAbs.isNotEmpty() || w.silent)) {
            val n0 = tagged.size
            tagged = tagged.mapNotNull { Speech.fit(it, spansAbs) }
            if (tagged.size < n0) host.log("🔕 المقطع ${i + 1}: اتشالت ${n0 - tagged.size} جملة كانت فوق صمت تام")
        }
        tagged = Subs.harmonize(tagged, subs)   // توحيد ترجمة سطور الكورَس المتكررة في الأغاني
        // (v1065) خطوة جزئية من باتش الوضع السريع: جمل الباتش نفسه برّه نافذة الخطوة دي (خطوات سابقة) بتفضل
        val partialWin = rampOn && i == rampChunk && (rawStart > cStart(i) + 0.05 || rawEnd < cEnd(i, currentDur()) - 0.05)
        synchronized(lock) {
            tagged = Subs.dropOverlapZone(tagged, subs.filter { it.chunk != i }, rawStart)
            val keep = subs.filter { (it.chunk != i || (partialWin && (it.start < rawStart - 0.5 || it.start >= rawEnd + 0.5))) && !(it.chunk == -1 && it.start >= rawStart && it.start < rawEnd) && !Subs.inMyZone(it, tagged, i, rawEnd) && tagged.none { n -> Subs.straddlerCovers(n, it, rawStart) } }   // (v1376) الممتدة عبر الحد بتشيل المقطوعة القديمة
            subs = Subs.merge(Subs.dedup(keep + tagged)).sortedBy { it.start }
            Subs.refreshMain(subs)
        }
        // (v177) دفتر الفقد: لو جمل رجعت من Gemini واختفت بعد التنضيف (تكرار/تداخل) نسجّل العدد عشان أي رجوع للمشكلة يبان في اللوج
        try {
            val lost = tagged.count { t -> val k = t.original.trim().take(10); k.length >= 4 && subs.none { it.start in (t.start - 3.0)..(t.end + 3.0) && it.original.contains(k) } }
            if (lost > 0 || fresh.size != tagged.size) host.log("📊 المقطع ${i + 1}: Gemini رجّع ${fresh.size} · بعد الفلاتر ${tagged.size} · اختفى بالتنضيف ~$lost")
        } catch (_: Throwable) {}
        try { for ((ti, s) in tagged.withIndex()) if (s.translated.isNotBlank() && s.translated != s.original && !s.isSound && !s.isSong && !s.lowConf && missingNums(s).isEmpty() && !LangGuard.foreign(s) && (convDialect.isBlank() || convDialect == "فصحى" || s.conv)) lineCachePut(s.original, s.translated, s.gender, tagged.getOrNull(ti - 1)?.original ?: "") } catch (_: Throwable) {}   // (v1177) بوابة جودة: سطر ناقصه رقم أو لغته غلط أو ضعيف الثقة ما بيتخزّنش   // (v469) A7: تعبئة كاش الأسطر من الترجمات المطبّقة باللهجة الصح بس
        try { noteTopic(tagged) } catch (_: Throwable) {}   // (v469) A3: تحديث ذاكرة الموضوع
        lastQuality = batchQuality(tagged)   // (v469) A12
        done.add(rawStart, rawEnd)
        failed.remove(i); incomplete.remove(i)
        try {   // (v1178) جودة ضعيفة جدًا ← إعادة واحدة تلقائية بالأولوية (نفس مسار الإعادة التلقائية الموجود)
            if (lastQuality in 0 until QUAL_RETRY_BELOW && !isClosed && Cfg.bool("auto_requal", true) && qualRetried.add(i)) {
                priorityRetry.add(i); host.log("🔎 باتش ${i + 1}: جودة $lastQuality% — إعادة تلقائية مرة واحدة")
            }
        } catch (_: Throwable) {}
        if (!anyApplied && engineStartMs > 0) host.log("⏱ أول باتش اتطبّق بعد ${System.currentTimeMillis() - engineStartMs}ms من ضغطة الزرار")   // (v1354)
        anyApplied = true
        host.changed()
        Stats.addSec(rawEnd - rawStart)
        host.log("✅ المقطع ${i + 1}: ${fresh.size} جملة — الإجمالي ${subs.size}" + (if (lastQuality >= 0) " — جودة $lastQuality%" else ""))   // (v469) A12
        persist()
        afterChunk(w, fresh, prior)
        maybeConvert(false)
    }

    private fun applyPrevCorrections(j: JSONObject) {
        val pc = j.optJSONArray("prev_corrections") ?: return
        var n = 0
        synchronized(lock) {
            val cur = subs.toMutableList()
            for (k in 0 until pc.length()) {
                val c = pc.optJSONObject(k) ?: continue
                val snip = c.optString("original_snippet").trim()
                if (snip.length < 3) continue
                val idx = cur.indexOfLast { it.original.contains(snip) }
                if (idx < 0) continue
                var s = cur[idx]
                c.optString("gender").lowercase().takeIf { it == "male" || it == "female" }?.let { s = s.copy(gender = it) }
                c.optString("addressee").lowercase().takeIf { it in listOf("male", "female", "plural", "unknown") }?.let { s = s.copy(addressee = it) }
                c.optString("topic_gender").lowercase().takeIf { it in listOf("male", "female", "plural", "none") }?.let { s = s.copy(topicGender = it) }
                c.optString("translated").trim().takeIf { it.isNotEmpty() }?.let { s = s.copy(translated = it) }
                cur[idx] = s; n++
            }
            if (n > 0) subs = cur
        }
        if (n > 0) host.log("🩺 تصحيح $n جملة قديمة (جنس/ضمير)")
    }

    // ===== المهام الخلفية بعد كل مقطع =====
    private fun afterChunk(w: WavChunk, fresh: List<Sub>, prior: List<Sub>) {
        if (isClosed) return
        synchronized(lock) { chunksDone++ }
        maybeAnalyze()
        maybePronouns()
        maybeGenre()
        maybeRefine()
    }

    // (v108) نوع العمل (أكشن/كوميدي/رعب…) من أول جمل مترجمة — للفلتر التلقائي
    @Volatile var genreWanted = false
    @Volatile var onGenre: ((String) -> Unit)? = null
    @Volatile private var genreBusy = false
    private fun maybeGenre() {
        if (!genreWanted || genreBusy) return
        val sample: String
        synchronized(lock) {
            if (subs.size < 40) return
            genreBusy = true
            sample = subs.filter { !it.isSound && !it.isSong }.take(70).joinToString("\n") { it.translated.ifEmpty { it.original } }
        }
        try {
            bg.submit {
                try {
                    val prompt = "دي أول جمل من فيلم أو مسلسل مترجم:\n$sample\n\nحدد نوع العمل بدقة من القائمة دي بس: action (أكشن/قتال/مطاردات)، comedy (كوميدي)، horror (رعب/إثارة مظلمة)، romance (رومانسي)، scifi (خيال علمي/فانتازيا)، drama (دراما عادية)، other (مش واضح أو وثائقي).\nلو مش متأكد رجّع other. رد JSON فقط: {\"genre\":\"...\"}"
                    val r = bgCall(prompt, 128, 0.1)
                    val g = Parse.json(r.text)?.optString("genre", "")?.trim()?.lowercase() ?: ""
                    if (g in setOf("action", "comedy", "horror", "romance", "scifi", "drama", "other")) { genreWanted = false; host.log("🎨 نوع العمل: $g"); onGenre?.invoke(g) }
                } catch (e: Exception) { host.log("⚠ تحديد نوع العمل فشل: " + (e.message ?: "").take(80)) }
                finally { genreBusy = false }
            }
        } catch (_: Exception) { genreBusy = false }
    }

    private fun helperKey(i: Int = 0): String? {
        if (keyless) return null
        val pref = (conf.refine + conf.backup).distinct().ifEmpty { conf.keys }
        val ok = pref.filter { pool.ok(it) }
        if (ok.isNotEmpty()) {
            // (v469) A11: المهام الجانبية تروح للأسرع المعروف (زمن استجابة الـ Pool) بدل التدوير الأعمى — داخل نفس مجموعة المفاتيح المسموحة بس
            val known = ok.mapNotNull { pool.latencyOf(it).takeIf { l -> l >= 0 } }
            val avg = if (known.isEmpty()) 0.0 else known.average()
            val sorted = ok.sortedBy { val l = pool.latencyOf(it); if (l < 0) avg else l }
            return sorted[Math.floorMod(i, sorted.size)]
        }
        return pool.helper()
    }

    /** (v285) محرك النص الاحتياطي للمهام الجانبية: محرك LLM المختار في كارت ③ بس (مش أي محرك مضبوط) — null لو مفيش أو الطلب أكبر من حدّ المحركات */
    private fun textViaLlm(prompt: String, maxTokens: Int, json: Boolean): Api.Result? {
        val p = convLlm() ?: return null
        if (maxTokens > 8192) return null
        return try { Api.Result(ExtLlm.chat(p, if (json) "Reply with one valid JSON object only: no markdown, no explanation." else "", prompt, maxTokens), "STOP") }
        catch (e: Exception) {
            if (e is ExtLlm.LlmErr) ExtTranslate.noteFail("llm_" + p.id, ExtLlm.key(p).hashCode(), e)
            host.log("⚠ ${p.label} (مهمة جانبية) فشل: " + (e.message ?: e.javaClass.simpleName).take(100)); null
        }
    }

    /** (v285) طلب نص للمهام الجانبية: جيميناي الأول، ولو مفيش مفتاح أو فشل ← محرك LLM المختار. البحث بجوجل (search) جيميناي بس */
    private fun bgCall(prompt: String, maxTokens: Int, temp: Double, json: Boolean = true, i: Int = 0, search: Boolean = false): Api.Result {
        if (!search && helperKey(i) == null) textViaLlm(prompt, maxTokens, json)?.let { return it }
        try { return bgGemini(prompt, maxTokens, temp, json, i, search) }
        catch (e: Exception) {
            if (!search && !keyless) textViaLlm(prompt, maxTokens, json)?.let { host.log("↪ جيميناي وقف في مهمة جانبية — اتكمّلت بـ ${convLlm()?.label}"); return it }
            throw e
        }
    }

    private fun bgGemini(prompt: String, maxTokens: Int, temp: Double, json: Boolean = true, i: Int = 0, search: Boolean = false): Api.Result {
        var key = helperKey(i) ?: throw Exception("مفيش مفتاح")
        var tries = 0
        while (true) {
            try { return Api.generate(curModel(), key, prompt, null, maxTokens, temp, json, search) }
            catch (e: ApiErr) {
                if (e.code >= 500) { if (++tries > 2) throw e; nap(2000L * tries); helperKey(i + tries)?.let { key = it }; continue }   // (v150) 503 مؤقت: جرّب تاني على مفتاح تاني
                if (e.code == 429) { noteQuota(); pool.block(key, 60_000) } else if (e.code == 403) pool.block(key, 3_600_000) else throw e
                val alt = helperKey(i + 1)
                if (alt == null || alt == key || ++tries > 2) throw e
                key = alt
            }
        }
    }

    // --- تحليل الشخصيات تلقائيًا (_maybeAutoAnalyzeCharacters / analyzeCharacters) ---
    private fun maybeAnalyze() {
        if (sideOff()) return
        if (!conf.autoChars || conf.manualChars.isNotEmpty() || !TrSlider.on("chars")) return   // (v1097) T2
        maybeLookup()
        maybeIdentify()
        synchronized(lock) {
            if (charsBusy || lookupState == 1 || subs.size < CHAR_MIN_LINES || !sideOk()) return
            // أول تحليل: لما مفيش شخصيات. بعد كده: تحديث كل 5 باتشات (لو الترجمة زادت 20 جملة على الأقل)
            val first = chars.isEmpty() && autoCharsAttempts == 0
            val refresh = chunksDone - lastCharChunk >= 5 && subs.size >= charsTrySize + 20
            val retry = chars.isEmpty() && autoCharsAttempts in 1..1 && subs.size >= charsTrySize + 30
            if (!first && !refresh && !retry) return
            charsBusy = true; charsTrySize = subs.size; lastCharChunk = chunksDone
        }
        try {
            bg.submit {
                try { val tAc = System.currentTimeMillis(); analyzeChars(); LogStore.add("⏱ [مشغّل-توقيت] تحليل الشخصيات " + (System.currentTimeMillis() - tAc) + "ms") } catch (e: Exception) { host.log("⚠ تحليل الشخصيات فشل: " + (e.message ?: "").take(100)) }
                finally { synchronized(lock) { charsBusy = false; autoCharsAttempts++ }; persist() }
            }
        } catch (_: Exception) { synchronized(lock) { charsBusy = false } }
    }

    /** (v107) بحث تلقائي عن شخصيات الفيلم/المسلسل بالاسم الكامل (بحث جوجل عبر Gemini). لو الاسم مش واضح أو مش متأكد: مفيش تخمين والشخصيات بتتطلع من الترجمة. */
    private fun maybeLookup() {
        val hint = titleHint.trim()
        synchronized(lock) {
            if (lookupState != 0 || hint.length < 3 || chars.isNotEmpty() || !sideOk()) return
            lookupState = 1
        }
        try {
            bg.submit {
                try { lookupCast(hint) } catch (e: Exception) { host.log("⚠ البحث عن الشخصيات فشل: " + (e.message ?: "").take(100)) }
                finally { synchronized(lock) { lookupState = 2 }; persist() }
            }
        } catch (_: Exception) { synchronized(lock) { lookupState = 2 } }
    }

    private fun lookupCast(hint: String) {
        host.log("🔎 بدور على الشخصيات باسم: $hint")
        val prompt = "اسم ملف الفيديو واسم الفولدر بتاعه: «$hint».\n" +
            "مهمتك: تحدد لو ده اسم فيلم أو مسلسل أو أنمي كامل وواضح، وتدوّر عليه في جوجل وتجيب شخصياته الرئيسية.\n" +
            "🔴 ممنوع التخمين: لو الاسم ناقص أو عام أو فيه رقم حلقة بس أو لقيت أكتر من عمل بنفس الاسم ومش قادر تحدد بثقة، أو ملقيتش مصدر موثوق، رجّع found=false وخلاص.\n" +
            "لو لقيته بثقة: رجّع الشخصيات الرئيسية والمهمة (حد أقصى 15) بأسمائها المعروفة مكتوبة بالعربي، وجنس كل شخصية، ودورها في سطر قصير (حد أقصى 12 كلمة) من غير حرق أحداث.\n" +
            "رد JSON فقط بدون أي شرح أو markdown:\n" +
            "{\"found\":true,\"title\":\"الاسم الكامل للعمل\",\"characters\":[{\"name\":\"...\",\"gender\":\"male\",\"role\":\"...\"}]}\n" +
            "أو {\"found\":false}"
        val r = bgCall(prompt, 2048, 0.1, true, 0, true)
        val j = Parse.json(r.text)
        if (j == null || !j.optBoolean("found", false)) { host.log("🔎 الاسم مش واضح أو مش متأكد — هطلّع الشخصيات من الترجمة نفسها"); return }
        val n = applyCast(j)
        host.log("🔎 لقيت العمل «" + j.optString("title") + "» — اتضافت $n شخصية هتتحط في الـ prompt من المقطع الجاي")
    }

    /** يضيف شخصيات العمل اللي اتلقى (من البحث) لجدول الشخصيات. يرجع عدد الجديد. */
    private fun applyCast(j: JSONObject): Int {
        var n = 0
        synchronized(lock) {
            val ca = j.optJSONArray("characters")
            for (k in 0 until (ca?.length() ?: 0)) {
                val o = ca!!.optJSONObject(k) ?: continue
                val name = o.optString("name").trim(); if (name.isEmpty() || chars.any { it.name == name }) continue
                val g = if (o.optString("gender").lowercase().startsWith("f")) "female" else "male"
                chars.add(Chr(name, g, o.optString("role").trim())); n++
            }
            castFound = true
        }
        return n
    }

    /**
     * (v170) مفيش اسم ملف مفيد (أو البحث بالاسم ملقاش حاجة): نتعرّف على العمل من الحوار نفسه (أسماء الشخصيات والأحداث) ونطابقه بجوجل.
     * لو لقينا عمل بثقة عالية: شخصياته الرئيسية بتتضاف جاهزة بجنسها ودورها، ومن المقطع الجاي جيميناي بيربط الأصوات بيها.
     */
    private fun maybeIdentify() {
        synchronized(lock) {
            if (identTried || castFound || subs.size < 30 || !sideOk()) return
            val pending = titleHint.trim().length >= 3 && lookupState != 2   // لسه بنجرّب الاسم الأول
            if (pending) return
            identTried = true
        }
        try {
            bg.submit { try { identifyFromDialogue() } catch (e: Exception) { host.log("⚠ التعرف على العمل من الحوار فشل: " + (e.message ?: "").take(100)) } }
        } catch (e: Exception) { LogStore.err("Engine:identifySubmit", e) }   // (v468)
    }

    private fun identifyFromDialogue() {
        val snap = subs.filter { !it.isSound && it.original.isNotBlank() }
        if (snap.size < 20) return
        val step = maxOf(1, snap.size / 45)
        val lines = snap.filterIndexed { i, _ -> i % step == 0 }.take(45).joinToString("\n") { s ->
            "[" + (if (s.gender == "female") "أنثى" else "ذكر") + "] " + s.original.take(140) + (if (s.translated.isNotBlank()) "  ←  " + s.translated.take(140) else "")
        }
        val names = snap.flatMap { it.people }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(25).joinToString("، ") { it.key }
        val known = synchronized(lock) { chars.map { it.name } }.joinToString("، ")
        val hint = titleHint.trim()
        host.log("🔎 مفيش اسم عمل واضح — بحاول أتعرّف عليه من الحوار نفسه (${snap.size} جملة)…")
        val prompt = "ده حوار من فيديو (فيلم أو مسلسل أو أنمي؟) اتسمع واتترجم. لغة الصوت: ${srcLang.ifEmpty { "غير محددة" }}. اسم الملف/الفولدر (ممكن يكون ناقص أو عام): «${hint.ifEmpty { "مفيش" }}».\n" +
            "أسماء ظهرت في الحوار: ${names.ifEmpty { "مفيش" }}\n" + (if (known.isNotEmpty()) "شخصيات معروفة عندنا: $known\n" else "") +
            "\nمقتطفات من الحوار (متكلم + الأصل + الترجمة):\n$lines\n\n" +
            "مهمتك: تتعرّف على العمل ده، وتدوّر عليه في جوجل وتتأكد إنه عمل حقيقي وإن أسماء الشخصيات والأحداث دي بتاعته فعلًا.\n" +
            "🔴 ممنوع التخمين: لو مش متأكد بثقة عالية (أسماء شخصيات وأحداث متطابقة مع مصدر موثوق)، أو لقيت أكتر من عمل محتمل، أو ده شكله فيديو يوتيوب/مقطع شخصي/برنامج/بودكاست — رجّع found=false وخلاص.\n" +
            "لو لقيته بثقة: رجّع الشخصيات الرئيسية والمهمة (حد أقصى 15) بأسمائها العربية بنفس كتابتها في الترجمة (ولو الشخصية في «شخصيات معروفة عندنا» استخدم نفس الكتابة بالظبط)، وجنس كل شخصية، ودورها في سطر قصير (حد أقصى 12 كلمة) من غير حرق أحداث.\n" +
            "رد JSON فقط بدون أي شرح أو markdown:\n{\"found\":true,\"title\":\"الاسم الكامل للعمل\",\"characters\":[{\"name\":\"...\",\"gender\":\"male\",\"role\":\"...\"}]}\nأو {\"found\":false}"
        val r = bgCall(prompt, 2048, 0.1, true, 0, true)
        val j = Parse.json(r.text)
        if (j == null || !j.optBoolean("found", false)) { host.log("🔎 مقدرتش أتأكد من اسم العمل — هكمّل بالشخصيات اللي بتتطلّع من الترجمة والأصوات"); return }
        val n = applyCast(j)
        host.log("🔎 اتعرّفت على العمل من الحوار: «" + j.optString("title") + "» — اتضافت $n شخصية جاهزة")
        persist()
    }


    private fun analyzeChars() {
        val snap = subs
        val stride = if (snap.size > 400) Math.ceil(snap.size / 400.0).toInt() else 1
        val sample = snap.filterIndexed { i, _ -> i % stride == 0 }
        val dialogue = sample.joinToString("\n") { s ->
            val g = if (s.gender == "female") "أنثى" else "ذكر"
            val names = if (s.people.isNotEmpty()) " [أسماء مذكورة: ${s.people.joinToString("، ")}]" else ""
            "[متكلم:$g]$names ${s.translated.ifEmpty { s.original }}"
        }
        val known = synchronized(lock) { chars.map { it.name } }
        val dialogueK = if (known.isEmpty()) dialogue else "(شخصيات معروفة مسبقًا — لو نفس الشخصية اتذكرت استخدم نفس الاسم بالظبط ومتكررهاش: " + known.joinToString("، ") + ")\n" + dialogue
        host.log("🧑‍🤝‍🧑 بحلل الشخصيات من ${sample.size} جملة…")
        val r = bgCall(pb.read("prompts/analyze_chars.txt").replace("§DIALOGUE§", dialogueK), 3072, 0.2)
        val j = Parse.json(r.text) ?: throw Exception("رد غير صالح")
        var nc = 0; var ng = 0
        synchronized(lock) {
            val ca = j.optJSONArray("characters")
            for (k in 0 until (ca?.length() ?: 0)) {
                val o = ca!!.optJSONObject(k) ?: continue
                val name = o.optString("name").trim(); if (name.isEmpty()) continue
                val g = if (o.optString("gender").lowercase().startsWith("f")) "female" else "male"
                val role = o.optString("role").trim()
                val ix = chars.indexOfFirst { it.name == name }
                if (ix >= 0) chars[ix] = Chr(name, g, role.ifEmpty { chars[ix].role }) else chars.add(Chr(name, g, role))
                nc++
            }
            val ga = j.optJSONArray("glossary")
            for (k in 0 until (ga?.length() ?: 0)) {
                val o = ga!!.optJSONObject(k) ?: continue
                val term = (o.optString("term").ifEmpty { o.optString("name") }).trim(); if (term.isEmpty()) continue
                val note = (o.optString("note").ifEmpty { o.optString("translation") }).trim()
                if (gloss.none { it.term == term }) { gloss.add(Gloss(term, note)); ng++ }
            }
        }
        host.log("🧑‍🤝‍🧑 اتحددت $nc شخصية و$ng مصطلح — هتتحط في الـ prompt من المقطع الجاي")
    }

    // --- تصحيح الضمائر تلقائيًا (_maybeAutoCorrectPronouns) ---
    private fun maybePronouns() {
        if (sideOff() || !conf.autoPronouns || !TrSlider.on("pron")) return   // (v1097) T2
        if (effectiveChars().isEmpty()) return
        synchronized(lock) {
            if (pronBusy || subs.size < PRON_MIN_LINES || pronUpTo >= subs.size) return
            pronBusy = true
        }
        try {
            bg.submit {
                try { pronounPass() } catch (e: Exception) { host.log("⚠ تصحيح الضمائر فشل: " + (e.message ?: "").take(100)) }
                finally { synchronized(lock) { pronBusy = false } }
            }
        } catch (_: Exception) { synchronized(lock) { pronBusy = false } }
    }

    private fun pronounPass() {
        val cs = effectiveChars(); if (cs.isEmpty()) return
        val snap = subs
        val cand = (pronUpTo until snap.size).toList()
        var fixed = 0
        for (batch in cand.chunked(40)) {
            if (!running) return
            fixed += runPronounCorrection(snap, batch, cs)
        }
        if (fixed > 0) { host.log("🩺 تصحيح ضمائر: $fixed جملة"); host.changed(); persist() }
        pronUpTo = maxOf(pronUpTo, snap.size)
    }

    private fun runPronounCorrection(snap: List<Sub>, batch: List<Int>, cs: List<Chr>): Int {
        val want = LinkedHashSet<Int>()
        for (i in batch) for (k in i - 2..i + 2) if (k in snap.indices) want.add(k)
        val list = JSONArray()
        for (k in want) {
            val s = snap[k]
            list.put(JSONObject().put("idx", k).put("review", k in batch).put("original", s.original).put("translated", s.translated).put("speaker_gender", s.gender).put("addressee_gender", s.addressee))
        }
        val table = cs.joinToString("\n") { "- \"${it.name}\": ${if (it.gender == "female") "أنثى (مؤنث)" else "ذكر (مذكر)"}" }
        val prompt = pb.read("prompts/pronoun_fix.txt").replace("§TABLE§", table).replace("§LIST§", list.toString())
        val r = bgCall(prompt, 8192, 0.1)
        val j = Parse.json(r.text) ?: return 0
        val arr = j.optJSONArray("corrections") ?: return 0
        var n = 0
        synchronized(lock) {
            val cur = subs.toMutableList()
            for (q in 0 until arr.length()) {
                val c = arr.optJSONObject(q) ?: continue
                if (!c.has("idx")) continue
                val idx = c.optInt("idx", -1)
                if (idx !in batch) continue
                val tr = c.optString("translated").trim(); if (tr.isEmpty()) continue
                val target = snap[idx]
                val at = cur.indexOfFirst { Math.abs(it.start - target.start) < 0.05 && it.original == target.original }
                if (at >= 0 && cur[at].translated != tr) { cur[at] = cur[at].copy(translated = tr); n++ }
            }
            if (n > 0) subs = cur
        }
        return n
    }

    // ===== (v109) تنقيح الترجمة بالسياق — (v140) اتحسّن: بيشتغل كل مقطعين بعدّاد مش بباقي القسمة (كان بيفوّت لما مقطعين يخلصوا مع بعض)،
    // وبيعمل تنقيح نهائي لما كل المقاطع تخلص (كان آخر مقاطع الفيديو عمرها ما بتتراجع)، وبيراجع الجمل الجديدة بس مع 25 جملة قبلها كسياق (كان بيبعت الفيديو كله كل مرة) =====
    private val refineEvery = 1   // (v154) كل مقطع يخلص (التنقيح الجزئي على مفتاح مخصوص مش بيزاحم الترجمة)
    @Volatile private var partialWarned = false
    @Volatile private var partialKeyTail = ""
    @Volatile private var refineBusy = false
    private var refineSaved = false
    private var refinedAt = 0
    private val refinedKeys = HashSet<String>()   // جمل اتراجعت وفي بعدها سياق كفاية (بتتحمي بـ lock)

    /** (v154) مفاتيح التنقيح الجزئي: الاحتياطي (وأي مفتاح إضافي اتحط على «احتياطي») الأول، وبعدين مفاتيح الصور — بس لو الوضع البصري مش شغّال دلوقتي. مفاتيح الترجمة الأساسية ماتتلمسش أبدًا. */
    private fun partialKeys(): List<String> {
        val l = ArrayList<String>()
        l.addAll(conf.refine.filter { it.length > 10 && pool.ok(it) })   // (v158) مفاتيح التنقيح المخصوصة الأول
        // (v238) الاحتياطي بقى بيساعد في التنقيح الجزئي حتى لو فيه مفاتيح تنقيح (كان بيقعد فاضي لحد ما باتش يفشل)
        l.addAll(conf.backup.filter { it.length > 10 && pool.ok(it) })
        if (!VisualMode.anyActive()) l.addAll(conf.visKeys.filter { it.length > 10 && pool.ok(it) })
        return l.distinct()
    }

    /** طلب تنقيح جزئي على المفاتيح المخصوصة بس (429 → يعطّل المفتاح ويجرّب اللي بعده، 5xx → يعيد) */
    private fun partialCall(prompt: String, maxTokens: Int, temp: Double, i: Int): Api.Result {
        var last: Exception? = null
        for (tries in 0 until 3) {
            val ks = partialKeys()
            if (ks.isEmpty()) throw last ?: Exception("مفيش مفتاح احتياطي/صور فاضي للتنقيح الجزئي")
            val key = ks.sortedBy { pool.loadOf(it) * 100 + Math.floorMod(ks.indexOf(it) - (i + tries), ks.size) }.first()
            try {
                partialKeyTail = pool.tail(key)
                pool.refineBegin(key)   // (v160) المفتاح يتحجز: مفيش باتش ترجمة جديد يتبعت عليه، والباتش الشغّال يخلص الأول
                var w = 0; while (pool.loadOf(key) > 0 && w < 90_000 && running) { nap(300); w += 300 }
                return Api.generate(curModel(), key, prompt, null, maxTokens, temp, true, false) }
            catch (e: ApiErr) {
                last = e
                if (e.code >= 500) nap(2000L * (tries + 1))
                else if (e.code == 429) pool.block(key, 60_000)
                else if (e.code == 401 || e.code == 403) pool.block(key, 3_600_000)
                else throw e
            } finally { pool.refineEnd(key) }
        }
        throw last ?: Exception("فشل التنقيح الجزئي")
    }

    private fun maybeRefine() {
        if (keyless) return
        if (!conf.partialRefine || !TrSlider.on("refine")) return   // (v1097) T2
        val keysOk = partialKeys().isNotEmpty()
        if (!keysOk) {
            if (!partialWarned && chunksDone >= 2) { partialWarned = true; host.log("✍ التنقيح الجزئي واقف: محتاج 3 مفاتيح على الأقل عشان البرنامج يخصّص مفتاح للتنقيح — هيتنقّح في الآخر بالمفاتيح العادية") }
            return
        }
        synchronized(lock) {
            if (refineBusy || chunksDone - refinedAt < refineEvery || subs.size < 12) return
            refineBusy = true; refinedAt = chunksDone
        }
        runRefine(false)
    }

    private var finalAt = -1   // (v154) آخر chunksDone اتعمل عنده تنقيح نهائي (مرة واحدة لكل قيمة — مايتعادش لو فشل)
    /** من حلقة run() وقت الهدوء (مفيش باتش في الجو): لو في مقاطع خلصت بعد آخر تنقيح، نقّح الباقي. بيرجّع true لو التنقيح شغال — الحلقة تستنى */
    private fun finalRefineTick(): Boolean {
        if (isClosed || transOnly || !TrSlider.on("refine")) return false   // (v1097) T2
        synchronized(lock) {
            if (refineBusy) return true
            if (subs.size < 8 || finalAt == chunksDone) return false
            // (v154) التنقيح الجزئي بيعلّم refinedAt مع كل مقطع، فلازم نشوف كمان لو لسه فيه جمل (آخر 8) ماخدتش سياق بعدها
            val pending = subs.any { !it.isSound && it.original.isNotBlank() && it.translated.isNotBlank() && !it.translated.startsWith("«") && pk(it) !in refinedKeys }
            if (chunksDone <= refinedAt && !pending) return false
            refineBusy = true; refinedAt = chunksDone; finalAt = chunksDone
        }
        runRefine(true)
        return true
    }

    private fun runRefine(isFinal: Boolean) {
        try {
            bg.submit {
                try { val tRf = System.currentTimeMillis(); refinePass(isFinal); LogStore.add("⏱ [مشغّل-توقيت] تنقيح بالسياق (نهائي=" + isFinal + ") " + (System.currentTimeMillis() - tRf) + "ms") } catch (e: Exception) { warnUser("refine", "⚠ تنقيح الترجمة فشل — الترجمة سليمة بس من غير تنقيح"); host.log("⚠ تنقيح الترجمة فشل: " + (e.message ?: "").take(100)) }
                finally { refineBusy = false }
            }
        } catch (e: Exception) { LogStore.err("Engine:refineSubmit", e); refineBusy = false }   // (v468)
    }

    private fun refinePass(isFinal: Boolean) {
        val snap = subs.filter { !it.isSound && it.original.isNotBlank() && it.translated.isNotBlank() && !it.translated.startsWith("«") }.sortedBy { it.start }
        if (snap.size < 8) return
        val reviewed = synchronized(lock) { HashSet(refinedKeys) }
        val firstNew = snap.indexOfFirst { pk(it) !in reviewed }
        if (firstNew < 0) return
        val roster = pb.rosterText(effectiveChars(), effectiveGloss())
        val WIN = 400; val STEP = 360; val LEAD = 25
        var fixedTotal = 0; var from = maxOf(0, firstNew - LEAD); var win = 0
        var okAll = true
        while (from < snap.size && running) {
            val part = snap.subList(from, minOf(snap.size, from + WIN))
            val arr = JSONArray()
            for ((k, q) in part.withIndex()) {
                val prevEnd = if (k > 0) part[k - 1].end else if (from > 0) snap[from - 1].end else q.start
                val o = JSONObject().put("i", k).put("original", q.original).put("translated", q.translated)
                if (q.pivot.isNotBlank()) o.put("en", q.pivot)
                o.put("speaker", q.gender)
                if (q.addressee != "unknown") o.put("to", q.addressee)
                o.put("gap", Math.round(maxOf(0.0, q.start - prevEnd) * 10) / 10.0)
                arr.put(o)
            }
            val prompt = PromptStore.fill(PromptStore.pick("eng:refine", EnginePrompts.REFINE), "ROSTER" to (if (roster.isNotBlank()) "\nمعلومات الشخصيات والمصطلحات:\n$roster\n" else ""), "ARR" to arr.toString(), "LANG" to conf.lang, "STYLE" to conf.style)
            refiningSegs = listOf(doubleArrayOf(part.first().start, part.last().end))
            val r = try { if (isFinal) bgCall(prompt, 8192, 0.1, true, win) else partialCall(prompt, 8192, 0.1, win) } catch (e: Exception) { okAll = false; refiningSegs = emptyList(); throw e }
            refiningSegs = emptyList()
            val ca = Parse.json(r.text)?.optJSONArray("corrections")
            if (ca != null && ca.length() > 0) {
                var n = 0
                synchronized(lock) {
                    val cur = subs.toMutableList()
                    if (!refineSaved) { refineSaved = true; versions.add(Version("قبل التنقيح", subs, convDialect.ifBlank { "فصحى" })); while (versions.size > 12) versions.removeAt(0) }
                    for (q in 0 until ca.length()) {
                        val c = ca.optJSONObject(q) ?: continue
                        val k = c.optInt("i", -1); if (k < 0 || k >= part.size) continue
                        val nt = c.optString("translated").trim(); if (nt.isEmpty()) continue
                        val t = part[k]
                        if (nt == t.translated || nt.length > t.translated.length * 3 + 20 || nt.length * 3 + 20 < t.translated.length) continue
                        val at = cur.indexOfFirst { Math.abs(it.start - t.start) < 0.05 && it.original == t.original }
                        if (at < 0 || cur[at].translated != t.translated) continue   // اتغيّرت في الأثناء (تعديل تاني): ماندوسش عليها
                        cur[at] = cur[at].copy(translated = nt); n++
                    }
                    if (n > 0) subs = cur
                }
                fixedTotal += n
            }
            win++
            if (from + WIN >= snap.size) break
            from += STEP; nap(2000)
        }
        // علّم الجمل اللي اتراجعت — وآخر 8 جمل مش بتتعلّم إلا في التنقيح النهائي (لسه ماعندهاش سياق بعدها)
        if (okAll && running) synchronized(lock) {
            val upto = if (isFinal) snap.size else maxOf(0, snap.size - 8)
            for (k in 0 until upto) refinedKeys.add(pk(snap[k]))
        }
        host.log((if (isFinal) "✍ تنقيح الترجمة بالسياق" else "✍ تنقيح جزئي (مفتاح $partialKeyTail)") + ": راجعت ${snap.size - maxOf(0, firstNew - LEAD)} جملة وصحّحت $fixedTotal")
        if (fixedTotal > 0) { host.changed(); persist() }
    }

    // --- ترجمة قالب الـ prompt للغات اللي ملهاش قالب جاهز (_translatePromptTemplate) ---
    // ===== أدوات يدوية من المشغّل (أزرار الشاشة الكاملة في نسخة الـ HTML) =====
    class Version(val name: String, val subs: List<Sub>, val dialect: String = "")
    val versions = java.util.concurrent.CopyOnWriteArrayList<Version>()

    fun saveVersion(name: String, dialect: String = convDialect.ifBlank { "فصحى" }) { versions.add(Version(name, subs, dialect)); while (versions.size > 12) versions.removeAt(0) }
    /** يرجّع نص الترجمة (translated) بس من نسخة محفوظة على الجمل المطابقة (نفس البداية والأصل)، والجمل الجديدة بتفضل زي ما هي */
    fun applyVersion(i: Int): Int {
        val v = versions.getOrNull(i) ?: return 0
        var n = 0
        synchronized(lock) {
            val cur = subs.toMutableList()
            for (k in cur.indices) {
                val m = v.subs.firstOrNull { Math.abs(it.start - cur[k].start) < 0.05 && it.original == cur[k].original } ?: continue
                if (m.translated != cur[k].translated) { cur[k] = cur[k].copy(translated = m.translated); n++ }
            }
            subs = cur
        }
        host.changed(); persist(); return n
    }

    @Volatile var toolBusy: String? = null
        private set
    /** (v709) تقدّم الأداة الشغّالة (0..1) وتقدّم تحويل اللهجة — الريموت بيملّي بيهم الزرار زي الكوباية */
    @Volatile var toolPct = 0f
    @Volatile var convPct = 0f
    /** (v709) مفتاح الأداة الشغّالة (pron/refine/dial/family/explicit/tone/other/dialect) + نسبتها 0..1، أو "" لو مفيش */
    fun toolState(): Pair<String, Float> {
        val l = toolBusy
        if (l != null) {
            val k = when { l == "تصحيح الضمائر" -> "pron"; l == "تنقيح بالسياق" -> "refine"; l == "زيادة شدة اللهجة" -> "dial"; l == "عائلي" -> "family"; l.startsWith("أسلوب") -> "tone"; else -> "other" }
            return Pair(k, toolPct)
        }
        if (convBusy.get()) return Pair("dialect", convPct)
        return Pair("", 0f)
    }

    /** 🔧 تصحيح الضمائر لكل الجمل (من جدول الشخصيات + جنس الصوت) */
    fun correctPronounsNow(report: (String) -> Unit, done: (Int) -> Unit) {
        if (toolBusy != null) { report("في عملية شغالة: " + toolBusy); return }
        val cs = effectiveChars()
        if (cs.isEmpty()) { report("مفيش شخصيات متحللة لسه — شغّل الترجمة لحد ما تتحلل الأول"); done(0); return }
        toolBusy = "تصحيح الضمائر"
        Thread {
            var fixed = 0
            val mine = HashSet<String>()
            try {
                saveVersion("قبل تصحيح الضمائر")
                val snap = subs
                val all = snap.indices.toList()
                for (k in all) mine.add(pk(snap[k])); pend.addAll(mine)
                val batches = all.chunked(40)
                batches.forEachIndexed { bi, batch ->
                    if (!running) return@forEachIndexed
                    toolPct = bi.toFloat() / batches.size; report("🔧 ضمائر ${bi + 1}/${batches.size}")
                    fixed += try { runPronounCorrection(snap, batch, cs) } catch (e: Exception) { host.log("⚠ ضمائر: " + (e.message ?: "").take(80)); 0 }
                    for (k in batch) pend.remove(pk(snap[k]))
                }
                if (fixed > 0) { host.changed(); persist() }
            } finally { pend.removeAll(mine); toolPct = 0f; toolBusy = null }
            done(fixed)
        }.start()
    }

    /** إعادة صياغة الترجمة الحالية بتعليمة (لهجة أقوى / عائلي / صريح / لهجة لايف) من نقطة معينة لآخر الفيديو */
    fun rewriteAll(label: String, instruction: String, fromSec: Double, report: (String) -> Unit, done: (Int) -> Unit) {
        if (toolBusy != null) { report("في عملية شغالة: " + toolBusy); return }
        toolBusy = label
        val mk = markRetro; markRetro = false   // (v1099) T4
        Thread {
            var changed = 0
            val mine = HashSet<String>()
            try {
                saveVersion("قبل $label")
                val snap = subs
                val idx = snap.indices.filter { snap[it].end >= fromSec }
                for (k in idx) mine.add(pk(snap[k])); pend.addAll(mine)
                val table = effectiveChars().joinToString("\n") { "- \"${it.name}\": ${if (it.gender == "female") "أنثى" else "ذكر"}" }.ifEmpty { "(مفيش)" }
                val batches = idx.chunked(40)
                batches.forEachIndexed { bi, batch ->
                    if (!running) return@forEachIndexed
                    toolPct = bi.toFloat() / batches.size; report("$label ${bi + 1}/${batches.size}")
                    val list = JSONArray()
                    for (k in batch) { val s = snap[k]; list.put(JSONObject().put("idx", k).put("original", s.original).put("translated", s.translated).put("speaker_gender", s.gender).put("addressee_gender", s.addressee)) }
                    val prompt = "أنت محرر ترجمة محترف. اللغة/اللهجة الحالية: ${convDialect.ifBlank { conf.lang }} — الأسلوب: ${conf.style}.\n" +
                        "المطلوب بالظبط: $instruction\n" +
                        "قواعد ثابتة: حافظ على المعنى وعلى عدد الجمل وترتيبها (ماتدمجش ولا تقسّم). ماتقلبش ذكر لأنثى ولا العكس: جنس المتكلم = speaker_gender، وجنس المخاطَب = addressee_gender، وجنس الشخصيات المسماة من الجدول:\n$table\n" +
                        "ماتلمسش الجملة لو مش محتاجة تغيير.\n\nالجمل:\n$list\n\n" +
                        "أرجع JSON فقط بالجمل اللي اتغيّرت: {\"rewrites\":[{\"idx\":0,\"translated\":\"النص الجديد كامل\"}]}"
                    try {
                        val r = bgCall(prompt, 8192, 0.4, true, bi)
                        val arr = (Parse.json(r.text) ?: return@forEachIndexed).optJSONArray("rewrites") ?: return@forEachIndexed
                        synchronized(lock) {
                            val cur = subs.toMutableList()
                            for (q in 0 until arr.length()) {
                                val c = arr.optJSONObject(q) ?: continue
                                val ix = c.optInt("idx", -1); if (ix !in batch) continue
                                val tr = c.optString("translated").trim(); if (tr.isEmpty()) continue
                                val t = snap[ix]
                                val at = cur.indexOfFirst { Math.abs(it.start - t.start) < 0.05 && it.original == t.original }
                                if (at >= 0 && cur[at].translated != tr) { cur[at] = cur[at].copy(translated = tr); changed++; if (mk) applied.add(pk(cur[at])) }   // (v1099) T4
                            }
                            subs = cur
                        }
                        host.changed()
                    } catch (e: Exception) { host.log("⚠ $label: " + (e.message ?: "").take(80)) }
                    finally { for (k in batch) pend.remove(pk(snap[k])) }
                }
                if (changed > 0) persist()
            } finally { pend.removeAll(mine); toolPct = 0f; toolBusy = null }
            done(changed)
        }.start()
    }

    /**
     * (v151) ✍ تنقيح كامل بطلب واحد: الأصل المستخرج + الترجمة الحالية لكل الجمل المترجمة بتتبعت مرة واحدة (مش باتش باتش)
     * للمفتاح الاحتياطي، ولو مفيش فلأي مفتاح أساسي فاضي. الموديل بيصلّح الترجمة بالسياق (والكلمات الحرفية اللي معناها
     * بيتغيّر مع المشهد) وبيرجّع الجمل اللي اتغيّرت بس، وإحنا بنطبّقها مكانها. فيه نسخة محفوظة قبل التنقيح للرجوع.
     */
    fun refineWholeNow(report: (String) -> Unit, done: (Int) -> Unit) {
        if (toolBusy != null) { report("في عملية شغالة: " + toolBusy); return }
        toolBusy = "تنقيح بالسياق"
        Thread {
            var fixed = 0
            try {
                val snap = subs.filter { !it.isSound && it.original.isNotBlank() && it.translated.isNotBlank() && !it.translated.startsWith("«") }.sortedBy { it.start }
                if (snap.size < 3) report("مفيش جمل مترجمة كفاية للتنقيح")
                else {
                    saveVersion("قبل التنقيح بالسياق"); refiningSegs = listOf(doubleArrayOf(snap.first().start, snap.last().end))
                    val roster = pb.rosterText(effectiveChars(), effectiveGloss())
                    val parts = snap.chunked(3000)
                    for ((pi, part) in parts.withIndex()) {
                        toolPct = pi.toFloat() / parts.size; report("✍ تنقيح ${pi + 1}/${parts.size} — ${part.size} جملة في طلب واحد")
                        val arr = JSONArray()
                        for ((k, q) in part.withIndex()) arr.put(JSONArray().put(k).put(q.original).put(q.translated).put(q.gender))
                        val prompt = "أنت مراجع ترجمة محترف. دي كل جمل فيلم/مسلسل/فيديو بالترتيب. كل عنصر: [رقم، الأصل، الترجمة الحالية، جنس المتكلم]. الترجمة الحالية اتعملت على مقاطع صوتية منفصلة من غير ما كل مقطع يشوف باقي الفيديو، فغالبًا فيها جمل حرفية أو غلط في السياق.\n" +
                            (if (roster.isNotBlank()) "\nمعلومات الشخصيات والمصطلحات:\n$roster\n" else "") +
                            "\nالجمل:\n$arr\n\n" +
                            "اقرا الفيديو كله كأنك بتتفرج عليه، وصحّح الترجمة (النقاط دي بس):\n" +
                            "1) كلمة أو تعبير اتترجم حرفي ومعناه في المشهد مختلف (اصطلاح، سخرية، تلميح، مجاز، رد على جملة قبلها).\n" +
                            "2) ضمير/فاعل/مفعول أو جنس غلط، أو اسم ومصطلح متترجم بأكتر من شكل.\n" +
                            "3) جملة مقطوعة بين مقطعين وترجمتها مش متصلة بجارتها، أو ترجمة بتتناقض مع اللي حواليها.\n" +
                            "القواعد: حافظ على لهجة ${conf.lang} وأسلوب ${conf.style}؛ الجملة قصيرة قد الأصلية تقريبًا؛ ماتغيّرش جملة سليمة ولا تحسّن أسلوب بس؛ ممنوع تضيف أو تحذف أو تدمج جمل.\n" +
                            "رجّع JSON فقط بالجمل اللي اتغيّرت: {\"corrections\":[{\"i\":12,\"translated\":\"النص المصحح الكامل\"}]} — لو كله سليم: {\"corrections\":[]}"
                        var key: String = (conf.refine + conf.backup).firstOrNull { pool.ok(it) } ?: pool.pickIdle(-1000, null, perKey) ?: helperKey() ?: throw Exception("مفيش مفتاح")
                        pool.unreserve(-1000)
                        var r: Api.Result? = null; var tries = 0
                        while (r == null) {
                            try { r = Api.generate(curModel(), key, prompt, null, 30000, 0.1, true, false) }
                            catch (e: Exception) {
                                val code = (e as? ApiErr)?.code ?: 0
                                if (++tries > 3 || code == 400 || e is Unsupported) throw e
                                if (code == 429) pool.block(key, 60_000) else if (code == 401 || code == 403) pool.block(key, 3_600_000)
                                nap(2000L * tries)
                                key = pool.pickIdle(-1000, key, perKey)?.also { pool.unreserve(-1000) } ?: helperKey(tries) ?: key
                            }
                        }
                        val ca = Parse.json(r!!.text)?.optJSONArray("corrections")
                        if (ca == null) { report("رد التنقيح مش صالح (ممكن اتقطع) — جرّب تاني"); continue }
                        var n = 0
                        synchronized(lock) {
                            val cur = subs.toMutableList()
                            for (q in 0 until ca.length()) {
                                val c = ca.optJSONObject(q) ?: continue
                                val k = c.optInt("i", -1); if (k < 0 || k >= part.size) continue
                                val nt = c.optString("translated").trim(); if (nt.isEmpty()) continue
                                val t = part[k]
                                if (nt == t.translated || nt.length > t.translated.length * 3 + 20 || nt.length * 3 + 20 < t.translated.length) continue
                                val at = cur.indexOfFirst { Math.abs(it.start - t.start) < 0.05 && it.original == t.original }
                                if (at < 0 || cur[at].translated != t.translated) continue
                                cur[at] = cur[at].copy(translated = nt); n++
                            }
                            if (n > 0) subs = cur
                            for (q in part) refinedKeys.add(pk(q))
                        }
                        fixed += n
                    }
                    if (fixed > 0) { host.changed(); persist() }
                    host.log("✍ تنقيح بالسياق (طلب واحد): ${snap.size} جملة — اتصحّح $fixed")
                }
            } catch (e: Exception) {
                host.log("⚠ التنقيح بالسياق فشل: " + (e.message ?: e.toString()).take(120)); report("التنقيح فشل: " + (e.message ?: "").take(80))
            } finally { toolPct = 0f; toolBusy = null; refiningSegs = emptyList() }
            done(fixed)
        }.apply { isDaemon = true }.start()
    }

    /**
     * (v153) 🌍 ترجمة جوجل (الرابط غير الرسمي translate.googleapis.com — من غير مفتاح ولا API): بتترجم النص الأصلي لكل الجمل
     * (25 جملة في الطلب) وتحطه مكان الترجمة الحالية، فيتعرض على الفيديو عادي. جوجل بيترجم لـ«العربية» بس (مش لهجة).
     * بيتحفظ نسخة «قبل ترجمة جوجل» للرجوع.
     */
    private fun gtCall(texts: List<String>, tl: String, sl: String = "auto"): List<String>? {
        val body = "client=gtx&sl=" + sl + "&tl=" + tl + "&dt=t&q=" + java.net.URLEncoder.encode(texts.joinToString("\n"), "UTF-8")
        var last: Exception? = null
        for (t in 1..4) {
            try {
                val c = java.net.URL("https://translate.googleapis.com/translate_a/single").openConnection() as java.net.HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 25000
                c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                if (code == 429 || code >= 500) { c.disconnect(); nap(3000L * t); continue }
                if (code != 200) { c.disconnect(); throw IOException("HTTP $code") }
                val txt = c.inputStream.use { String(it.readBytes(), Charsets.UTF_8) }; c.disconnect()
                NetUse.api(body.length.toLong() + 200, txt)
                val segs = JSONArray(txt).optJSONArray(0) ?: return null
                val sb = StringBuilder()
                for (k in 0 until segs.length()) sb.append(segs.optJSONArray(k)?.optString(0, "") ?: "")
                val parts = sb.toString().split("\n")
                return if (parts.size == texts.size) parts.map { it.trim() } else null
            } catch (e: Exception) { last = e; nap(1500L * t) }
        }
        if (last != null) throw last
        return null
    }

    fun googleTranslateAll(report: (String) -> Unit, done: (Int) -> Unit) {
        if (toolBusy != null) { report("في عملية شغالة: " + toolBusy); return }
        toolBusy = "ترجمة جوجل"
        Thread {
            var changed = 0
            try {
                val snap = subs.sortedBy { it.start }
                val idx = snap.indices.filter { !snap[it].isSound && snap[it].original.isNotBlank() }
                if (idx.isEmpty()) report("مفيش نص أصلي لسه للترجمة")
                else {
                    saveVersion("قبل ترجمة جوجل")
                    val out = HashMap<Int, String>()
                    val batches = idx.chunked(25)
                    var failedB = 0
                    for ((bi, b) in batches.withIndex()) {
                        if (!running || isClosed) break   // (v1377) كان &&: إلغاء المحرك (running=false) لوحده مابيوقفش اللوب — باقي المواضع كلها ||
                        if (bi % 8 == 0) report("🌍 جوجل ${bi + 1}/${batches.size}")
                        val src = b.map { snap[it].original.replace(Regex("\\s*\n\\s*"), " ").trim() }
                        try {
                            val r = gtCall(src, "ar")
                            if (r != null) { for ((q, k) in b.withIndex()) out[k] = r[q] }
                            else for ((q, k) in b.withIndex()) { gtCall(listOf(src[q]), "ar")?.firstOrNull()?.let { out[k] = it } }   // عدد الأسطر اختلف: جملة جملة
                        } catch (e: Exception) { failedB++; host.log("⚠ ترجمة جوجل: " + (e.message ?: e.toString()).take(80)); if (failedB >= 5) { report("جوجل واقف أو النت فاصل — وقفت"); break } }
                    }
                    synchronized(lock) {
                        val cur = subs.toMutableList()
                        for ((k, tr) in out) {
                            if (tr.isBlank()) continue
                            val t = snap[k]
                            val at = cur.indexOfFirst { Math.abs(it.start - t.start) < 0.05 && it.original == t.original }
                            if (at >= 0 && cur[at].translated != tr) { cur[at] = cur[at].copy(translated = tr); changed++ }
                        }
                        if (changed > 0) subs = cur
                    }
                    if (changed > 0) { host.changed(); persist() }
                    host.log("🌍 ترجمة جوجل: ${idx.size} جملة — اتغيّرت $changed")
                }
            } catch (e: Exception) {
                host.log("⚠ ترجمة جوجل فشلت: " + (e.message ?: e.toString()).take(120)); report("ترجمة جوجل فشلت: " + (e.message ?: "").take(80))
            } finally { toolBusy = null }
            done(changed)
        }.apply { isDaemon = true }.start()
    }

    /** 🧠 دمج الجمل المكررة المتداخلة زمنيًا (محلي بدون Gemini): جملتين متداخلتين ومتشابهتين جدًا = واحدة بأطول وقت */
    fun removeDuplicates(): Int {
        var removed = 0
        synchronized(lock) {
            val cur = subs.sortedBy { it.start }.toMutableList()
            fun toks(x: String) = x.replace(Regex("[\\p{P}\\s]+"), " ").trim().split(" ").filter { it.isNotEmpty() }.toSet()
            var i = 0
            while (i < cur.size - 1) {
                val a = cur[i]; val b = cur[i + 1]
                val ov = minOf(a.end, b.end) - maxOf(a.start, b.start)
                val ta = toks(a.translated); val tb = toks(b.translated)
                val inter = ta.intersect(tb).size; val uni = ta.union(tb).size
                val sim = if (uni == 0) 0.0 else inter.toDouble() / uni
                if (ov > 0.3 && a.faint == b.faint && !(a.overlap && b.overlap && a.gender != b.gender) && (sim >= 0.7 || a.translated.contains(b.translated) || b.translated.contains(a.translated))) {
                    val keep = if (b.translated.length >= a.translated.length) b else a
                    cur[i] = keep.copy(start = minOf(a.start, b.start), end = maxOf(a.end, b.end))
                    cur.removeAt(i + 1); removed++
                } else i++
            }
            val cleaned = Subs.dropEchoes(cur)
            removed += cur.size - cleaned.size
            if (removed > 0) subs = cleaned.map { Subs.collapseSelfRepeat(it) }
        }
        if (removed > 0) { saveVersion("بعد دمج المكرر"); host.changed(); persist() }
        return removed
    }

    /** 📜 ذكّرني: ملخص لكل الأحداث من أول الفيديو لحد المكان الحالي */
    fun recap(upToSec: Double, report: (String) -> Unit, done: (String) -> Unit) {
        Thread {
            try {
                val snap = subs.filter { it.start <= upToSec }
                if (snap.isEmpty()) { done("لسه مفيش ترجمة قبل المكان ده"); return@Thread }
                val stride = if (snap.size > 500) Math.ceil(snap.size / 500.0).toInt() else 1
                val text = snap.filterIndexed { i, _ -> i % stride == 0 }.joinToString("\n") { it.translated.ifEmpty { it.original } }
                report("📜 بلخّص…")
                val r = bgCall("ده حوار فيديو من أوله لحد اللحظة الحالية. لخّص بالعامية المصرية في 6 لـ 10 أسطر قصيرة أهم اللي حصل وإيه الشخصيات وإيه اللي كان بيحصل في آخر مشهد، من غير حرق للي هيجي بعد كده ومن غير مقدمات:\n\n$text", 1500, 0.4, false)
                done(r.text.trim().ifEmpty { "ملقيتش ملخص" })
            } catch (e: Exception) { done("⚠ فشل التلخيص: " + (e.message ?: "").take(100)) }
        }.start()
    }

    private fun maybeTranslateTemplate() {
        if (!conf.autoTemplate || activeMode >= KeyMode.ALL_PARALLEL) return   // (v209) الوضع 2+: البرومبت إنجليزي ثابت، مفيش قالب يتترجم
        if (pb.caseOf(srcLang, detDone) != "other") return
        val lang = srcLang
        if (lang.contains("عرب")) return
        val id = pb.templateId(conf, "other")
        val k = "$lang|$id"
        synchronized(tplCache) { if (tplCache.containsKey(k) || tplBusy.contains(k) || (tplFails[k] ?: 0) >= 2) return; tplBusy.add(k) }
        try {
            bg.submit {
                try { translateTemplate(id, lang, k) }
                catch (e: Exception) { synchronized(tplCache) { tplFails[k] = (tplFails[k] ?: 0) + 1 }; host.log("⚠ ترجمة قالب الـ prompt فشلت: " + (e.message ?: "").take(100)) }
                finally { synchronized(tplCache) { tplBusy.remove(k) } }
            }
        } catch (_: Exception) { synchronized(tplCache) { tplBusy.remove(k) } }
    }

    private fun translateTemplate(id: String, lang: String, k: String) {
        val token = "[[ROSTER_BLOCK]]"
        val text = pb.fixedPart(id).replace("§ROSTER§", token)
        val prompt = pb.read("prompts/tpl_translate.txt").replace("§LANG§", lang).replace("§TEXT§", text)
        host.log("🈯 بترجم قالب الـ prompt للغة $lang…")
        val r = bgCall(prompt, 32768, 0.0, false)
        val t = r.text.trim()
        if (r.finish != "STOP" || t.length < 200) throw Exception("الترجمة ناقصة (${r.finish})")
        val fin = if (t.contains(token)) t.replace(token, "§ROSTER§") else "$t\n§ROSTER§"
        synchronized(tplCache) { tplCache[k] = fin }
        host.log("🈯 قالب الـ prompt بقى بلغة $lang من المقطع الجاي")
        persist()
    }

    // ===== إصلاح الجمل اللي فضلت بلغتها الأصلية (بتتفحص كل الجمل بعد كل مقطع، حتى القديمة المحفوظة) =====
    private val fixTries = ConcurrentHashMap<String, Int>()
    @Volatile private var lastFix = 0L
    private fun fixKey(s: Sub) = "${s.start}|${s.original}"
    /** (v399) إصلاح جمل نصها لسه بلغتها الأصلية بجوجل (من غير مفتاح)، والتوقيت بيفضل زي ما هو لأن بنغيّر النص بس */
    private fun fixViaGoogle(list: List<Sub>): List<Sub> {
        if (list.isEmpty()) return list
        val first = list.minOf { it.start }
        val ctx = synchronized(lock) { subs.filter { it.start < first && it.original.isNotBlank() && !it.isSound }.takeLast(GT_CTX_LINES).map { it.original } }
        val g = googleItems(list.map { it.original }, ctx)
        return list.mapIndexed { k, s ->
            val t = g.getOrNull(k)?.takeIf { it.isNotBlank() }
            if (t == null) s else s.copy(translated = t).takeIf { !LangGuard.foreign(it) } ?: s
        }
    }
    private fun hasRepairable(): Boolean = !transOnly && synchronized(lock) { subs.any { it.chunk !in previewChunks && LangGuard.foreign(it) && (fixTries[fixKey(it)] ?: 0) < 3 } }
    private fun repairForeignTick(): Boolean {
        if (!running || transOnly) return false
        val now = System.currentTimeMillis()
        if (now - lastFix < 12_000) return false
        val viaG = TrWizard.googleOn() || keyless   // (v399) من غير مفتاح جيميناي (أو مسار جوجل): الإصلاح بجوجل بالسياق بدل جيميناي
        val bad = synchronized(lock) { subs.filter { it.chunk !in previewChunks && LangGuard.foreign(it) && (fixTries[fixKey(it)] ?: 0) < 3 } }.take(if (viaG) 100 else 30)
        if (bad.isEmpty()) return false
        lastFix = now
        bad.forEach { fixTries.merge(fixKey(it), 1, Int::plus) }
        host.log("🌐 بصلّح ${bad.size} جملة لسه مش بـ${conf.lang}" + (if (viaG) " (بجوجل)" else "") + "…")
        val fixed = if (viaG) fixViaGoogle(bad) else fixForeign(bad)
        val map = HashMap<String, Sub>()
        bad.indices.forEach {
            if (fixed[it].translated != bad[it].translated) {
                val wrapped = bad[it].translated.startsWith("«") && !fixed[it].translated.startsWith("«")
                map[fixKey(bad[it])] = if (wrapped) fixed[it].copy(translated = "«" + fixed[it].translated + "»") else fixed[it]
            }
        }
        if (map.isNotEmpty()) {
            synchronized(lock) { subs = subs.map { map[fixKey(it)] ?: it } }
            host.changed(); persist()
        }
        return true
    }

    // ===== (v408) 📖 نبذة عن المصطلحات الطبية/الصعبة: سطر شرح فوق الترجمة (بيتعرض زي أوصاف الأصوات isSound) =====
    // بيشتغل في مسار الترجمة من غير جيميناي (جوجل/ML Kit/خارجي) — جيميناي بيعمل الشرح ده بنفسه من البرومبت. القاموس أوفلاين، وويكيبيديا للمصطلح المجهول (بالنت).
    @Volatile private var noteAt = 0L
    private var noteSeeded = false
    private val noteShown = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val noteScanned = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private fun noteTick(): Boolean {
        if (transOnly || !(TrWizard.googleOn() || keyless) || !TermNotes.enabled() || !running || isClosed) return false
        val now = System.currentTimeMillis()
        if (now - noteAt < 2500L) return false
        noteAt = now
        if (!noteBusy.compareAndSet(false, true)) return false
        Thread { try { noteWork() } catch (e: Exception) { host.log("⚠ النبذة: " + (e.message ?: e.javaClass.simpleName).take(80)) } finally { noteBusy.set(false) } }.apply { isDaemon = true }.start()
        return false   // في خيط لوحده (ويكيبيديا/جوجل ممكن يبطّأوا) — عشان لفة المحرك ماتستناش
    }
    private val noteBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private fun noteWork() {
        if (!noteSeeded) {
            noteSeeded = true
            synchronized(lock) { subs.filter { it.isSound && it.original.startsWith("📖 ") }.forEach { s -> s.original.removePrefix("📖 ").split(" · ").forEach { k -> noteShown.add(k.trim()) } } }
        }
        val snap = synchronized(lock) { subs.filter { !it.isSound && it.original.isNotBlank() && it.translated.isNotBlank() && it.chunk !in previewChunks && fixKey(it) !in noteScanned } }.take(60)
        if (snap.isEmpty()) return
        val add = ArrayList<Sub>()
        var wikiLeft = 2
        for (s in snap) {
            noteScanned.add(fixKey(s))
            val lines = ArrayList<Pair<String, String>>()   // (مفتاح المصطلح، سطر العرض)
            for (en in TermNotes.match(s.original + "\n" + s.translated).take(2)) if (noteShown.add(en.ar)) lines.add(en.ar to ("📖 " + en.ar + ": " + en.note))
            if (lines.isEmpty() && wikiLeft > 0 && TrWizard.online()) {
                for (w in TermNotes.candidates(s.original)) {
                    if (wikiLeft <= 0) break
                    if (!noteShown.add("w:" + w.lowercase())) continue
                    wikiLeft--
                    val wk = TermNotes.wiki(w) ?: continue
                    val tr = (try { gtCall(listOf(wk.first, wk.second), "ar", "en") } catch (_: Exception) { null }) ?: continue
                    if (tr.size < 2 || tr[0].isBlank() || tr[1].isBlank()) continue
                    if (!noteShown.add(wk.first)) continue
                    lines.add(wk.first to ("📖 " + tr[0] + " (" + wk.first + "): " + tr[1]))
                    break
                }
            }
            if (lines.isEmpty()) continue
            add.add(Sub(s.start, maxOf(s.end, s.start + 3.5), "📖 " + lines.joinToString(" · ") { it.first }, lines.joinToString("\n") { it.second },
                "unknown", "unknown", "none", emptyList(), emptyList(), false, false, s.chunk, isSound = true))
        }
        if (add.isEmpty()) return
        synchronized(lock) { subs = (subs + add).sortedBy { it.start } }
        host.log("📖 نبذة: اتضاف شرح لـ ${add.size} جملة فيها مصطلحات")
        host.changed(); persist()
    }

    // ===== سدّ الفجوات تلقائيًا أثناء المشاهدة (autoGapFill) =====
    /** مناطق اتترجمت بس مفيهاش جمل لمدة طويلة، قريبة من مكان التشغيل: بتتبعت بمفاتيح المراقبين/الاحتياطي وبتتعلّم بـ «» */
    private fun gapTick(all: Boolean = false): Boolean {
        if (!fillOk()) return false
        if (!conf.gapFill || !running || !TrSlider.on("holes")) return false   // (v1097) T2
        if (playheadHot() || quotaCooling()) return false   // (v1094) المشاهد أولًا + راحة للمفاتيح بعد 429
        val off = offFill()
        if (!off && Overload.busy()) return false   // (v1304) ضغط على الموديل: الفجوات تستنى
        val maxPar = if (off) 1 else Gaps.MAX_PARALLEL   // (v283) الأوفلاين بينسخ واحد في المرة
        val now = System.currentTimeMillis()
        if (now - lastGapScan < Gaps.COOLDOWN_MS) return false
        lastGapScan = now
        if (gapBusy.get() >= maxPar) return false
        val d = currentDur(); val pos = if (headless) d else host.position()
        val atEnd = d > 0 && pos >= d - 2
        val elig = Gaps.find(subs, done.list(), Gaps.MIN_SEC).filter {
            !gapTried.covers(it[0], it[1]) && (atEnd || all || (pos >= it[0] - Gaps.LOOKAHEAD && pos < it[1]))
        }
        if (elig.isEmpty()) { if (all || atEnd) gapScanClean = true; return false }
        var started = false
        for (g in elig) {
            if (gapBusy.get() >= maxPar || gapSession.total() >= Gaps.MAX_TOTAL * ch) break
            val key = if (off) "off" else (pool.gapKey(gapKeys, rr.getAndIncrement()) ?: break)
            gapTried.add(g[0], g[1]); gapSession.add(g[0], g[1]); gapKeys.add(key); gapBusy.incrementAndGet()
            host.log("🔁 سدّ فجوة تلقائي: ${"%.0f".format(java.util.Locale.US, g[0])}ث → ${"%.0f".format(java.util.Locale.US, g[1])}ث")
            try {
                gapEx.submit {
                    try { for (pt in Gaps.parts(g[0], g[1], minOf(ch, Coverage.PIECE_SEC))) { if (!running) break; fillGap(pt[0], pt[1], key) } }
                    catch (e: Exception) { host.log("⚠ سدّ الفجوة فشل: " + (e.message?.takeIf { it.isNotBlank() } ?: e.javaClass.simpleName).take(100)) }
                    finally { gapKeys.remove(key); gapBusy.decrementAndGet() }
                }
                started = true
            } catch (_: RejectedExecutionException) { gapKeys.remove(key); gapBusy.decrementAndGet() }
        }
        if (all || atEnd) gapScanClean = !started
        return started
    }

    private val holeTried = ConcurrentHashMap.newKeySet<Int>()
    private val holeBusy = AtomicInteger(0)
    private val holeEx = Executors.newSingleThreadExecutor { r -> Thread(r).also { it.isDaemon = true; it.name = "holefill" } }
    /** سدّ الثغرات كان شغال جوه خانة الباتش (inflight) فكل باتش بيستنى طلبات الثغرات قبل ما الباتش اللي بعده يتبعت = تأخير. دلوقتي على خيط لوحده */
    private fun scheduleHoleFill(i: Int, rawStart: Double, rawEnd: Double, w: WavChunk, key: String) {
        if (!fillOk() || !TrSlider.on("holes")) return   // (v283) من غير أوفلاين ومن غير جيميناي مفيش حاجة تسدّ الثغرة · (v1097) T2 السلايدر
        if (holeTried.contains(i)) return
        if (playheadHot() || quotaCooling() || Overload.busy()) {   // (v1094) المشاهد أولًا: سدّ الثغرات يتأجّل لحد ما الجزء اللي قدام المشاهد يتترجم ومفيش 429
            if (holeDefer.none { it.i == i }) { holeDefer.add(HoleJob(i, rawStart, rawEnd, w, key)); while (holeDefer.size > 4) holeDefer.poll() }
            return
        }
        holeBusy.incrementAndGet()
        try {
            holeEx.submit {
                try { val tHf = System.currentTimeMillis(); holeFill(i, rawStart, rawEnd, w, key); val dHf = System.currentTimeMillis() - tHf; if (dHf > 300) LogStore.add("⏱ [مشغّل-توقيت] سدّ ثغرات المقطع ${i + 1}: " + dHf + "ms") }
                catch (e: Exception) { host.log("⚠ سدّ الثغرات في المقطع ${i + 1} فشل: " + (e.message ?: "").take(80)) }
                finally { holeBusy.decrementAndGet() }
            }
        } catch (_: RejectedExecutionException) { holeBusy.decrementAndGet() }
    }

    /**
     * بعد ما المقطع يتطبّق: نقيس الصوت الفعلي ونشوف فيه كلام/غنا مسموع (>= HOLE_MIN ثانية) من غير ولا جملة فوقه.
     * الموديل بيرجّع جزء من المقطع وبيفوّت الباقي (خصوصًا الكورس المتكرر) — فبنعيد طلب الجزء الناقص بس
     * على أجزاء صغيرة (<= 20ث) وبسياق الجمل اللي قبله. مرة واحدة لكل مقطع.
     */
    private fun holeFill(i: Int, rawStart: Double, rawEnd: Double, w: WavChunk, key0: String) {
        val spans = Speech.activeSpans(w.bytes, w.gain)?.let { Speech.absolute(it, w.startSec) } ?: return
        if (!holeTried.add(i)) return
        val holes = Speech.holes(spans, subs, maxOf(rawStart, w.startSec), minOf(rawEnd, w.startSec + w.durSec), HOLE_MIN).take(HOLE_MAX)
        if (holes.isEmpty()) return
        host.log("🧩 المقطع ${i + 1}: ${holes.size} ثغرة فيها صوت من غير ترجمة — بعيد طلبها")
        var key = key0
        val off = offFill()
        for (h in holes) {
            // (v177) ثغرة ملزوقة في جملة اتترجمت (≤1.5ث) = غالبًا كلام ناقص مش موسيقى: بنطلبها بتعليمات «كمّل الناقص» وبنقبل الخافت
            val near = nearSpeech(h[0], h[1])
            for (pt in Gaps.parts(maxOf(0.0, h[0] - 0.5), h[1] + 0.5, 20.0)) {
                if (!running) return
                val w2 = src().wav(pt[0], pt[1]) ?: continue
                if (w2.silent) continue
                var tries = 0; var got = false
                while (running && !got && tries++ < 3) {
                    try {
                        // (v239) أسلوب الوضع 4 في كل الأوضاع: ترانسكريبشن بس من الصوت (بيسمع أكتر لأنه مش مشغول بالترجمة) ثم ترجمة نصية منفصلة. لو فشلت الترجمة: الطلب المباشر القديم
                        // (v143) الثغرة غالبًا موسيقى/مؤثرات: الرد الفاضي إجابة صحيحة، وماينفعش نعيد الطلب لحد ما الموديل "يلاقي" كلام
                        var base: List<Sub> = if (off) txFillOffline(w2, near) else txFillSubs(w2, near, key) ?: run {
                            val r = Api.generate(curModel(), key, buildPrompt(w2.durSec, w2.startSec, hole = true, holeNear = near), w2.bytes)
                            val j = if (r.text.isBlank()) null else Parse.json(r.text)
                            if (j == null) emptyList() else Subs.splitAll(Parse.subs(j, w2.startSec, w2.durSec)).filter { !it.isSound && (near || (!it.faint && !it.lowConf)) }.map { Subs.capPace(it) }
                        }
                        if (!off && base.any { LangGuard.foreign(it) }) base = fixForeign(base)
                        val sp2 = Speech.activeSpans(w2.bytes, w2.gain)?.let { Speech.absolute(it, w2.startSec) }
                        if (sp2 != null) base = base.mapNotNull { Speech.fit(it, sp2) }
                        base = base.filter { val m = (it.start + it.end) / 2; m >= h[0] - 0.5 && m <= h[1] + 0.5 }.map { it.copy(chunk = i) }
                        if (base.isEmpty()) { got = true; host.log("… ثغرة ${"%.0f".format(java.util.Locale.US, pt[0])}ث: مفيهاش كلام — اتساب زي ما هي"); continue }
                        synchronized(lock) { subs = Subs.merge(Subs.dedup(subs + base)).sortedBy { it.start } }
                        if (!off) pool.good(key); got = true
                        host.changed(); persist()
                        host.log("✅ ثغرة ${"%.0f".format(java.util.Locale.US, pt[0])}ث→${"%.0f".format(java.util.Locale.US, pt[1])}ث: اتضاف ${base.size} جملة")
                    } catch (e: ApiErr) {
                        if (e.code == 429) pool.block(key, 60_000) else if (e.code == 403) pool.block(key, 3_600_000) else if (e.code >= 500) { host.log("⚠ ثغرة: ضغط على الموديل (" + e.code + ") — هتتعاد لما يهدى"); holeRequeue(i, rawStart, rawEnd, w, key0); return } else { host.log("⚠ ثغرة: " + (e.message ?: "").take(80)); return }
                        key = pool.pick(key, rr.getAndIncrement()) ?: return
                    } catch (e: IOException) { if (netHold(e, "ثغرة")) { tries--; continue }; host.log("📶 ثغرة: مشكلة اتصال"); return }   // (v1101)
                }
            }
        }
    }

    /**
     * (v283) نفس مرحلتين txFillSubs بس من غير جيميناي: (1) الصوت ← نص أصلي بالأوفلاين (Whisper/SenseVoice/السحابي)،
     * (2) النص ← ترجمة بنفس سلسلة مترجم الباتشات (جوجل / خارجي)، أو من غير ترجمة في «تفريغ بس». أي فشل ← قائمة فاضية (مفيش رجوع لجيميناي).
     * Whisper على مقاطع قصيرة بيهلوس أكتر: فلتر الأوفلاين (noSpeech/logProb) + هنا بنشيل التكرار الحرفي والنصوص القصيرة جدًا.
     */
    private fun txFillOffline(w: WavChunk, near: Boolean): List<Sub> {
        val none = Api.Result("{\"subtitles\":[]}", "STOP")
        val r = if (groqTxOn()) try { groqResult(w.bytes, w.durSec) } catch (e: Throwable) { host.log("⚠ Groq سدّ الثغرات فشل: " + (e.message ?: e.javaClass.simpleName).take(80)); none } else Offline.transcribe(w.bytes, w.durSec, effectiveGloss().joinToString(", ") { it.term }, { host.log(it) }, { none }, { host.notice(it) }, offSession)   // (v1369) Groq بيسد ثغراته بنفسه
        val j = if (r.text.isBlank()) null else Parse.json(r.text)
        if (j == null) return emptyList()
        val seen = HashMap<String, Int>()
        val raw = Subs.splitAll(TParse.transcript(j, w.startSec, w.durSec)).filter { !it.isSound && it.original.isNotBlank() && (near || (!it.faint && !it.lowConf)) }
            .filter { s -> val k = s.original.lowercase().filter { it.isLetterOrDigit() }; k.length >= 2 && (seen.merge(k, 1, Int::plus) ?: 1) <= 1 }
        if (raw.isEmpty()) return emptyList()
        if (transOnly) return raw.map { Subs.capPace(it.copy(translated = it.original, pivot = "", src = if (groqTxOn()) "groq" else "whisper")) }   // (v1373) جمل سدّ الفجوات بتتلوّن بلون مصدرها برضه (كانت بتطلع بيضا)
        val tr = googleItems(raw.map { it.original })
        return raw.mapIndexed { q, s -> Subs.capPace(s.copy(translated = tr.getOrNull(q)?.trim().orEmpty().ifBlank { s.original }, pivot = "")) }
    }

    /**
     * (v239) سدّ ثغرة/فجوة بأسلوب الوضع 4 في **كل** الأوضاع: (1) الصوت ← نص أصلي بس (من غير عبء الترجمة، فالموديل بيسمع أكتر ومابيسيبش جمل)
     * (2) النص الأصلي ← ترجمة بالسياق اللي حواليه. بيرجّع null لو فيه كلام اتنسخ والترجمة فشلت (الكولر بيرجع للطلب المباشر القديم)، وفاضي لو مفيش كلام.
     * بيرمي ApiErr/IOException زي أي طلب عادي (الكولر بيتصرف في 429 وغيره).
     */
    private fun txFillSubs(w: WavChunk, near: Boolean, key: String): List<Sub>? {
        val r = Api.generate(curModel(), key, buildPrompt(w.durSec, w.startSec, hole = true, holeNear = near, tx = true), w.bytes)
        val j = if (r.text.isBlank()) null else Parse.json(r.text)
        if (j == null) return emptyList()
        val raw = Subs.splitAll(TParse.transcript(j, w.startSec, w.durSec)).filter { !it.isSound && it.original.isNotBlank() && (near || (!it.faint && !it.lowConf)) }
        if (raw.isEmpty()) return emptyList()
        val dl = convDialect.let { if (it.isBlank() || it == "فصحى") "" else it }
        val c = if (dl.isEmpty() || dl == conf.lang) conf else dialConf.getOrPut(dl) { conf.withLang(dl) }
        val first = raw.first().start; val last = raw.last().end
        val before = synchronized(lock) { subs.filter { it.start < first && it.translated.isNotBlank() }.takeLast(12) }
        val after = synchronized(lock) { subs.filter { it.start > last && it.original.isNotBlank() }.take(6) }
        val out = arrayOfNulls<Pair<String, String>>(raw.size)
        for (round in 0 until 2) {
            val missing = raw.indices.filter { out[it] == null }
            if (missing.isEmpty()) break
            val prompt = toneB() + ModePrompts.translate(pb, c, missing.map { raw[it] }, before, after, effectiveChars(), effectiveGloss(), round > 0)
            val rr2 = Api.generate(curModel(), key, prompt, null, maxTokens = (missing.size * 150).coerceIn(2048, 8192), temp = 0.2)
            val jj = if (rr2.text.isBlank()) null else Parse.json(rr2.text)
            if (jj != null) for ((ix, pr) in TParse.translations(jj, missing.size)) out[missing[ix]] = pr
        }
        var list = raw.mapIndexedNotNull { q, sb -> out[q]?.let { sb.copy(translated = it.first.trim(), pivot = it.second) } }
        if (list.isEmpty()) return null
        if (LangGuard.foreignOf(list).isNotEmpty()) list = fixForeign(list)
        return list.map { Subs.capPace(it) }
    }

    /** (v177) في جملة مترجمة (مش وصف صوت) بتنتهي قبل بداية المجال أو بتبدأ بعد نهايته بـ ≤1.5ث؟ */
    private fun nearSpeech(a: Double, b: Double): Boolean = synchronized(lock) { subs.any { !it.isSound && (Math.abs(it.end - a) <= 1.5 || Math.abs(it.start - b) <= 1.5) } }

    private fun fillGap(a: Double, b: Double, key0: String) {
        val w = src().wav(a, b) ?: return
        if (w.silent) { host.log("🔇 الفجوة ${a.toInt()}ث صامتة — اتخطّيت"); return }
        var key = key0; var tries = 0
        val near = nearSpeech(a, b)
        val off = offFill()
        var gapFb: String? = null
        while (running && tries++ < 3) {
            try {
                var base: List<Sub> = if (off) txFillOffline(w, near) else txFillSubs(w, near, key) ?: run {   // (v239) ترانسكريبشن ثم ترجمة منفصلة (أسلوب الوضع 4)، والقديم احتياطي
                    val r = Api.generate(gapFb ?: curModel(), key, buildPrompt(w.durSec, w.startSec, hole = true, holeNear = near), w.bytes)
                    val j = if (r.text.isBlank()) null else Parse.json(r.text)
                    if (j == null) emptyList() else Subs.splitAll(Parse.subs(j, w.startSec, w.durSec)).filter { !it.isSound && (near || (!it.faint && !it.lowConf)) }.map { Subs.capPace(it) }
                }
                if (!off && base.any { LangGuard.foreign(it) }) base = fixForeign(base)
                val sp = Speech.activeSpans(w.bytes, w.gain)?.let { Speech.absolute(it, w.startSec) }
                if (sp != null) base = base.mapNotNull { Speech.fit(it, sp) }
                val marked = base.map { it.copy(translated = "«" + it.translated + "»", chunk = -2) }
                if (marked.isEmpty()) { host.log("… فجوة ${a.toInt()}ث: مفيهاش كلام — اتساب زي ما هي"); return }
                synchronized(lock) { subs = Subs.merge(Subs.dedup(subs + marked)).sortedBy { it.start } }
                if (!off) pool.good(key); host.changed(); persist()
                host.log("✅ فجوة ${a.toInt()}ث: اتسدّ ${marked.size} جملة")
                return
            } catch (e: ApiErr) {
                if (e.code == 429) { noteQuota(); pool.block(key, 60_000) } else if (e.code == 403) pool.block(key, 3_600_000) else if (e.code == 404 && gapFb != null) { Models.markDead(gapFb!!); val nx = Models.alt(curModel(), key); gapFb = if (nx == curModel()) null else nx; host.log("⚠ موديل احتياطي مش متاح (404) — " + (gapFb ?: "الأساسي")) } else if (e.code >= 500 && !Models.FALLBACK) { if ((gapRetry.merge(a.toInt(), 1, Int::plus) ?: 1) <= 3) gapTried.remove(a, b) } else if (e.code >= 500 && gapFb == null) { gapFb = Models.alt(curModel(), key).let { if (it == curModel()) null else it }; host.log("⚠ جيميناي عليه ضغط — سدّ الفجوة بموديل " + gapFb) } else throw e
                key = pool.gapKey(gapKeys - key, rr.getAndIncrement()) ?: return
            }
        }
    }

    // ===== الحفظ =====
    /** حفظ مؤجّل: بيجمّع كل طلبات الحفظ في 3 ثواني في كتابة واحدة على خيط لوحده (بدل ما كل باتش يكتب الملف كله). الحفظ الإجباري (إغلاق/نهاية) بيروح لـ doPersist مباشرة */
    private val persistPending = AtomicBoolean(false)
    private val persistEx = java.util.concurrent.Executors.newSingleThreadScheduledExecutor { r -> Thread(r).also { it.isDaemon = true; it.name = "persist" } }
    private fun persist() {
        if (store == null || isClosed) return
        if (!persistPending.compareAndSet(false, true)) return
        try { persistEx.schedule({ persistPending.set(false); try { doPersist() } catch (e: Exception) { LogStore.err("Engine:persist", e) } }, 3, java.util.concurrent.TimeUnit.SECONDS) }   // (v468)
        catch (_: RejectedExecutionException) { persistPending.set(false); doPersist() }
    }
    private fun doPersist(force: Boolean = false) {
        val st = store ?: return
        if (persistBlocked) return
        if (isClosed && !force) return   // خيط متأخر من إنجن اتقفل: ممنوع يكتب
        val saved = synchronized(lock) {
            val fr = failed.filter { it.value >= MAX_FAILS }.keys.sorted().map { doubleArrayOf(cStart(it), cStart(it + 1)) }
            Saved(conf.chunkSec, srcLang, detDone, Subs.readabilityAll(subs), done.list(), fr, chars.toList(), gloss.toList(), synchronized(tplCache) { HashMap(tplCache) }, host.position(), autoCharsAttempts, HashMap(bounds), gapTried.list(), imported)   // (v469) A9: محسّن قراءة (≤42 حرف/سطر) على نسخة الحفظ بس — حالة الذاكرة ما بتتغيّرش
        }
        try { st.save(saved) } catch (e: Exception) { warnUser("save", "⚠ مقدرتش أحفظ تقدّم الترجمة — راجع مساحة التخزين، ممكن تضيع لو التطبيق اتقفل"); host.log("⚠ تعذر حفظ التقدم: " + (e.message ?: "").take(80)) }
    }
}
